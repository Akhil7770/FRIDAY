# Cost Estimator Data Pipeline

A comprehensive data pipeline system for healthcare cost estimation that processes provider data, rates, claims, and related information using Apache Airflow orchestration on Google Cloud Platform.

## 🏗️ Architecture Overview

This project implements a multi-tier data pipeline architecture:

- **Orchestration**: Apache Airflow (Google Cloud Composer)
- **Data Processing**: Apache Beam (Google Dataflow)  
- **Data Storage**: Google BigQuery, Google Cloud Spanner
- **File Storage**: Google Cloud Storage
- **Environment**: Google Cloud Platform
- **CI/CD**: Jenkins

## 🎯 Project Purpose

The Cost Estimator Data Pipeline is designed to:

- Process healthcare provider information and maintain provider tables
- Handle various rate structures (standard rates, complex rates, out-of-network rates)
- Manage claims-based contract data and rates
- Generate cost estimation data for healthcare services
- Synchronize data between BigQuery and Spanner databases
- Provide audit logging and data quality monitoring

## 📁 Directory Structure

```
cost-estimator-data-pipelines/
├── dags/                           # Airflow DAGs and related code
│   ├── config/                     # Configuration files
│   │   ├── airflow_dev_config.json
│   │   ├── dev_cfg.json
│   │   └── Spanner_adhoc_config.json
│   ├── py/                         # Python DAG implementations
│   │   ├── run_provider_pipeline_daily.py
│   │   ├── run_standard_rates_pipeline.py
│   │   ├── run_*_pipeline.py       # Various pipeline DAGs
│   │   ├── dataflow-bq-spanner.py  # BQ to Spanner utility
│   │   └── scripts/                # Utility scripts
│   └── sql/                        # SQL queries and transformations
│       ├── providers_table/
│       ├── rates_table/
│       ├── ClaimBasedRates/
│       ├── lookup_tables/
│       └── service_code_master/
├── pipeline/                       # Deployment configurations
│   └── values.yaml
├── jenkinsfile.yaml               # CI/CD pipeline configuration
├── Pipfile                        # Python dependencies
└── README.md
```

## 🔧 Prerequisites

- **Python 3.x** with pip
- **Apache Airflow** (via Google Cloud Composer)
- **Google Cloud SDK** configured with appropriate permissions
- **Access to Google Cloud Services**:
  - BigQuery
  - Cloud Spanner
  - Cloud Storage
  - Dataflow
  - Composer

## 📦 Dependencies

Install Python dependencies using Pipenv:

```bash
pip install pipenv
pipenv install
```

Key dependencies include:
- `google-cloud-bigquery`
- `google-cloud-spanner`
- `apache-beam`
- `pandas`
- `dynaconf`
- `pysftp`

## ⚙️ Configuration

### Environment Configuration

The project supports multiple environments (dev, prod) with separate configuration files:

- `dags/config/dev_cfg.json` - Development environment settings
- `dags/config/airflow_dev_config.json` - Airflow-specific configuration

### Key Configuration Parameters

```json
{
  "config": {
    "CODE_BUCKET": "prv-ps-ce-code-hcb-dev",
    "DATA_BUCKET": "prv-ps-ce-data-hcb-dev", 
    "GCP_ENV": "dev",
    "REGION": "us-east4",
    "TENANT": "prv-ps-ce",
    "bq_dataset": {
      "ce_project": "anbc-hcb-dev",
      "ce_dataset": "prv_ps_ce_hcb_dev"
    }
  }
}
```

## 🚀 Available Data Pipelines

### Core Pipelines

1. **Provider Pipeline** (`run_provider_pipeline_daily.py`)
   - Processes provider data daily
   - Maintains provider tables with current information
   - Handles provider flagging and validation

2. **Standard Rates Pipeline** (`run_standard_rates_pipeline.py`)
   - Processes standard healthcare service rates
   - Updates rate tables with current pricing information

3. **Claims-Based Contract Pipeline** (`run_claimsbased_contract_pipeline.py`)
   - Handles claims-based contract rates
   - Processes contract-specific pricing rules

4. **Out-of-Network Rates Pipeline** (`run_out_of_network_rates_bqpipeline.py`)
   - Manages out-of-network provider rates
   - Calculates alternative pricing structures

5. **Complex Rates Pipeline** (`run_non_standard_complex_rates_bqpipeline.py`)
   - Handles complex rate calculations
   - Supports various payment methodologies (DRG, APC, etc.)

### Data Synchronization

- **BQ to Spanner Pipelines**: Multiple pipelines for syncing data between BigQuery and Spanner
  - Provider data sync
  - Rates data sync  
  - Claims data sync
  - Out-of-network rates sync

### Utility Pipelines

- **Service Code Master** (`run_service_code_master_monthly.py`)
- **Audit Logs** (`run_audit_logs_on_bqtables.py`)
- **Adhoc Processing** (`ce-adhoc-dag.py`)

## 🔄 Development Workflow

### 1. Local Development

```bash
# Clone the repository
git clone <repository-url>
cd cost-estimator-data-pipelines

# Install dependencies
pipenv install

# Activate virtual environment
pipenv shell
```

### 2. Configuration Setup

- Update configuration files in `dags/config/` for your environment
- Ensure GCP credentials are properly configured
- Set environment variables as needed

### 3. Testing

```bash
# Run tests
pipenv run pytest

# Test specific DAG
python dags/py/run_provider_pipeline_daily.py
```

### 4. Deployment

The project uses Jenkins for CI/CD. Deployment is automated through:

```yaml
# pipeline/values.yaml
deploy:
  type: dag
  composer:
    labels:
      composer-version: 6
```

## 📊 Monitoring and Maintenance

### Logging

- Centralized logging through Google Cloud Logging
- Email notifications for pipeline failures
- Audit logs for data quality monitoring

### Data Quality

- Built-in data validation steps
- Audit logging for tracking data changes
- Automated data quality checks

### Performance Monitoring

- Pipeline execution metrics
- Resource utilization tracking
- Cost monitoring and optimization

## 🔒 Security and Access Control

- Service account-based authentication
- Role-based access control (RBAC)
- Encrypted data transfer and storage
- Audit trail for all operations

## 🚨 Troubleshooting

### Common Issues

1. **Permission Errors**: Ensure service accounts have proper IAM roles
2. **Configuration Issues**: Verify environment-specific config files
3. **Data Quality Failures**: Check audit logs for data validation errors
4. **Pipeline Failures**: Review Airflow logs and email notifications

### Support

For issues and questions:
- Check Airflow UI logs
- Review Google Cloud Console for service-specific errors
- Contact the development team: `amanullam@aetna.com`

## 📈 Performance Considerations

- Pipelines are optimized for large-scale data processing
- Uses Apache Beam for distributed processing
- Implements incremental data loading where possible
- Monitors and optimizes BigQuery queries for cost efficiency

## 🔄 Version Control

- Uses Git for version control
- Follow GitFlow branching strategy
- All changes require code review
- Automated testing on pull requests

---

