-- Create temp table anbr
CREATE OR REPLACE TEMP TABLE anbr AS (
    SELECT DISTINCT g.PROVIDER_BUSINESS_GROUP_NBR,
            PAYMENT_METHOD_CD,
            SERVICE_GROUP_CD AS DFT_SERVICE_GROUP_CD,
            l.SERVICE_GROUP_TYPE_CD,
            q.CONTRACT_EFFECTIVE_DT,
            q.CONTRACT_TERM_DT,
            l.PLACE_OF_SERVICE_KEY_CD,
            l.RATING_SYSTEM_CD,
            l.GEOGRAPHIC_AREA_CD,
            l.ZIP_CD,
            l.DEFAULT_RATING_SYSTEM_IND,
            l.DEFAULT_RATING_SYSTEM_CD,
            l.DEFAULT_GEOGRAPHIC_AREA_CD,
            l.RATE_PERCENTAGE,
            g.PRODUCT_CD,
            pos.MEMBER_PLACE_OF_SERVICE_CD AS PLACE_OF_SERVICE_CD,
            l.SERVICE_GROUP_CHANGED_IND
    FROM `{{edp_project}}.{{edp_dataset_view}}.{{tic_scm_fee_service_line_detail_view}}` l
    CROSS JOIN UNNEST(SPLIT(l.PLACE_OF_SERVICE_KEY_CD, '')) AS unnested
    INNER JOIN `{{edp_project}}.{{edp_dataset_view}}.{{tic_scm_fee_service_qualifier_detail_view}}` q
        ON l.QUALIFIER_ID = q.QUALIFIER_ID
    INNER JOIN `{{edp_project}}.{{edp_dataset_view}}.{{tic_epdb_contract_provider_business_group_view}}` g
        ON g.PROVIDER_BUSINESS_GROUP_NBR = q.PROVIDER_BUSINESS_GROUP_NBR
    INNER JOIN `{{edp_project}}.{{edp_dataset}}.{{tic_scsr_place_of_service_affiliation}}` pos
        ON pos.OWNER_PLACE_OF_SERVICE_CD = unnested
    WHERE PAYMENT_METHOD_CD IN ('PERRT', 'PERAMF')
        AND service_group_type_cd = 'CNTDEF'
);

-- Create temp table scm
CREATE OR REPLACE TEMP TABLE scm AS (
    SELECT DISTINCT TRIM(primary_svc_cd) AS primary_svc_cd,
        TRIM(servc_type) AS servc_type,
        TRIM(supporting_pos_cd) AS supporting_pos_cd
    FROM {{ce_project}}.{{ce_dataset}}.{{ce_scm}}
    WHERE in_scope_ind = 1
);

-- Insert Case 1 - RO
INSERT INTO `{{ce_project}}.{{ce_dec_dataset}}.{{ce_rates_table}}`
    (
    RATE_SYSTEM_CD,
    SERVICE_CD,
    SERVICE_TYPE_CD,
    SERVICE_GROUP_CD,
    SERVICE_GROUPING_PRIORITY_NBR,
    SERVICE_GROUP_CHANGED_IND,
    PROVIDER_BUSINESS_GROUP_NBR,
    PRODUCT_CD,
    PLACE_OF_SERVICE_CD,
    GEOGRAPHIC_AREA_CD,
    EXTENSION_CD,
    EXTENSION_TYPE,
    SPECIALTY_CD,
    SPECIALTY_TYPE_CD,
    PAYMENT_METHOD_CD,
    RATE,
    CNT_EFFTV_DT,
    CNT_TERMN_DT,
    CONTRACT_TYPE,
    LOGIC_TYPE
)
    SELECT DISTINCT RT_DTL.RATE_SYSTEM_CD,
        primary_svc_cd AS SERVICE_CD,
        original_service_type AS SERVICE_TYPE_CD,
        DFT_SERVICE_GROUP_CD AS SERVICE_GROUP_CD,
        svcdtl.SERVICE_GROUPING_PRIORITY_NBR AS SERVICE_GROUPING_PRIORITY_NBR,
        SERVICE_GROUP_CHANGED_IND,
        PROVIDER_BUSINESS_GROUP_NBR,
        TSDC.PRODUCT_CD,
        supporting_pos_cd AS PLACE_OF_SERVICE_CD,
        RT_DTL.GEOGRAPHIC_AREA_CD,
        EXTENSION_CD,
        EXTENSION_TYPE_CD AS EXTENSION_TYPE,
        RT_DTL.SPECIALTY_CD,
        RT_DTL.SPECIALTY_TYPE_CD,
        PAYMENT_METHOD_CD,
        TRUNC(CAST(RATE_PERCENTAGE AS FLOAT64) * CAST(RATE_AMT AS FLOAT64), 2) AS RATE,
        CAST(CONTRACT_EFFECTIVE_DT AS STRING) AS CNT_EFFTV_DT,
        CAST(CONTRACT_TERM_DT AS STRING) AS CNT_TERMN_DT,
        'D' AS CONTRACT_TYPE,
        'CASE1_COMPLEX_DEFAULT' AS LOGIC_TYPE
    FROM anbr
    INNER JOIN scm 
        ON scm.supporting_pos_cd = anbr.PLACE_OF_SERVICE_CD
    INNER JOIN (
            SELECT DISTINCT RATE_SYSTEM_CD,
                GEOGRAPHIC_AREA_CD,
                GEOGRAPHIC_AREA_TYPE_CD,
                PRODUCT_PLATFORM_CD,
                PRODUCT_CD,
                OVERRIDE_RATE_SYSTEM_CD
            FROM `{{edp_project}}.{{edp_dataset_view}}.{{tic_scsr_rate_override_view}}`
    ) rt_ovrrd
        ON anbr.RATING_SYSTEM_CD = rt_ovrrd.RATE_SYSTEM_CD
        AND anbr.ZIP_CD = rt_ovrrd.GEOGRAPHIC_AREA_CD
    INNER JOIN (
            SELECT DISTINCT RATE_SYSTEM_CD,
                SERVICE_CD,
                CASE
                    WHEN UPPER(SERVICE_TYPE_CD) = 'ADA' THEN 'CDT'
                    WHEN UPPER(SERVICE_TYPE_CD) = 'ASA' THEN 'CPT'
                    WHEN UPPER(SERVICE_TYPE_CD) = 'CMG' THEN 'HIPPS'
                    WHEN UPPER(SERVICE_TYPE_CD) = 'CPT4' THEN 'CPT'
                    WHEN UPPER(SERVICE_TYPE_CD) = 'HCPC' THEN 'HCPCS'
                    WHEN UPPER(SERVICE_TYPE_CD) = 'ICD10DX' THEN 'ICD'
                    WHEN UPPER(SERVICE_TYPE_CD) = 'ICD10PX' THEN 'ICD'
                    WHEN UPPER(SERVICE_TYPE_CD) = 'ICD9' THEN 'ICD'
                    WHEN UPPER(SERVICE_TYPE_CD) = 'REV' THEN 'RC'
                    ELSE UPPER(SERVICE_TYPE_CD)
                END AS SERVICE_TYPE_CD,
                GEOGRAPHIC_AREA_CD,
                EXTENSION_CD,
                EXTENSION_TYPE_CD,
                SPECIALTY_CD,
                SPECIALTY_TYPE_CD,
                DIFFERENTIATION_CRITERIA_ID,
                RATE_AMT,
                SERVICE_TYPE_CD AS original_service_type
            FROM `{{edp_project}}.{{edp_dataset_view}}.{{tic_scsr_rate_detail_view}}`
            WHERE GEOGRAPHIC_AREA_CD = 'NONE'
    ) rt_dtl
        ON rt_ovrrd.OVERRIDE_RATE_SYSTEM_CD = rt_dtl.RATE_SYSTEM_CD
        AND rt_dtl.SERVICE_CD = scm.primary_svc_cd
        AND rt_dtl.original_service_type = scm.servc_type
    INNER JOIN {{edp_project}}.{{edp_dataset}}.{{tic_scsr_differentiation_criteria}} TSDC
        ON TSDC.DIFFERENTIATION_CRITERIA_ID = rt_dtl.DIFFERENTIATION_CRITERIA_ID
        AND  scm.supporting_pos_cd = TSDC.PLACE_OF_SERVICE_CD
    join {{edp_project}}.{{edp_dataset}}.{{tic_scsr_service_detail}} svcdtl  
        on svcdtl.SERVICE_CD = trim(scm.primary_svc_cd) 
        and svcdtl.SERVICE_TYPE_CD = trim(scm.servc_type)
    WHERE CAST(CAST(RATE_PERCENTAGE AS FLOAT64) * CAST(RATE_AMT AS FLOAT64) AS FLOAT64) >= 0.01
    AND TSDC.PRODUCT_CD = 'ALL';


-- Insert Case 2 - No RO
INSERT INTO `{{ce_project}}.{{ce_dec_dataset}}.{{ce_rates_table}}`
        (
    RATE_SYSTEM_CD,
    SERVICE_CD,
    SERVICE_TYPE_CD,
    SERVICE_GROUP_CD,
    SERVICE_GROUPING_PRIORITY_NBR,
    SERVICE_GROUP_CHANGED_IND,
    PROVIDER_BUSINESS_GROUP_NBR,
    PRODUCT_CD,
    PLACE_OF_SERVICE_CD,
    GEOGRAPHIC_AREA_CD,
    EXTENSION_CD,
    EXTENSION_TYPE,
    SPECIALTY_CD,
    SPECIALTY_TYPE_CD,
    PAYMENT_METHOD_CD,
    RATE,
    CNT_EFFTV_DT,
    CNT_TERMN_DT,
    CONTRACT_TYPE,
    LOGIC_TYPE
)
    SELECT DISTINCT RT_DTL.RATE_SYSTEM_CD,
        primary_svc_cd AS SERVICE_CD,
        original_service_type AS SERVICE_TYPE_CD,
        DFT_SERVICE_GROUP_CD AS SERVICE_GROUP_CD,
        svcdtl.SERVICE_GROUPING_PRIORITY_NBR AS SERVICE_GROUPING_PRIORITY_NBR,
        SERVICE_GROUP_CHANGED_IND,
        PROVIDER_BUSINESS_GROUP_NBR,
        TSDC.PRODUCT_CD,
        supporting_pos_cd AS PLACE_OF_SERVICE_CD,
        RT_DTL.GEOGRAPHIC_AREA_CD,
        EXTENSION_CD,
        EXTENSION_TYPE_CD AS EXTENSION_TYPE,
        RT_DTL.SPECIALTY_CD,
        RT_DTL.SPECIALTY_TYPE_CD,
        PAYMENT_METHOD_CD,
        TRUNC(CAST(RATE_PERCENTAGE AS FLOAT64) * CAST(RATE_AMT AS FLOAT64), 2) AS RATE,
        CAST(CONTRACT_EFFECTIVE_DT AS STRING) AS CNT_EFFTV_DT,
        CAST(CONTRACT_TERM_DT AS STRING) AS CNT_TERMN_DT,
        'D' AS CONTRACT_TYPE,
        'CASE2_COMPLEX_DEFAULT' AS LOGIC_TYPE
    FROM anbr
    INNER JOIN scm 
        ON scm.supporting_pos_cd = anbr.PLACE_OF_SERVICE_CD
    LEFT JOIN (
            SELECT DISTINCT RATE_SYSTEM_CD,
                GEOGRAPHIC_AREA_CD,
                GEOGRAPHIC_AREA_TYPE_CD,
                PRODUCT_PLATFORM_CD,
                PRODUCT_CD,
                OVERRIDE_RATE_SYSTEM_CD
            FROM `{{edp_project}}.{{edp_dataset_view}}.{{tic_scsr_rate_override_view}}`
    ) rt_ovrrd
        ON anbr.RATING_SYSTEM_CD = rt_ovrrd.RATE_SYSTEM_CD
        AND anbr.ZIP_CD = rt_ovrrd.GEOGRAPHIC_AREA_CD
    INNER JOIN (
            SELECT DISTINCT RATE_SYSTEM_CD,
                SERVICE_CD,
                CASE
                    WHEN UPPER(SERVICE_TYPE_CD) = 'ADA' THEN 'CDT'
                    WHEN UPPER(SERVICE_TYPE_CD) = 'ASA' THEN 'CPT'
                    WHEN UPPER(SERVICE_TYPE_CD) = 'CMG' THEN 'HIPPS'
                    WHEN UPPER(SERVICE_TYPE_CD) = 'CPT4' THEN 'CPT'
                    WHEN UPPER(SERVICE_TYPE_CD) = 'HCPC' THEN 'HCPCS'
                    WHEN UPPER(SERVICE_TYPE_CD) = 'ICD10DX' THEN 'ICD'
                    WHEN UPPER(SERVICE_TYPE_CD) = 'ICD10PX' THEN 'ICD'
                    WHEN UPPER(SERVICE_TYPE_CD) = 'ICD9' THEN 'ICD'
                    WHEN UPPER(SERVICE_TYPE_CD) = 'REV' THEN 'RC'
                    ELSE UPPER(SERVICE_TYPE_CD)
                END AS SERVICE_TYPE_CD,
                GEOGRAPHIC_AREA_CD,
                EXTENSION_CD,
                EXTENSION_TYPE_CD,
                SPECIALTY_CD,
                SPECIALTY_TYPE_CD,
                DIFFERENTIATION_CRITERIA_ID,
                RATE_AMT,
                SERVICE_TYPE_CD AS original_service_type
            FROM `{{edp_project}}.{{edp_dataset_view}}.{{tic_scsr_rate_detail_view}}`
    ) rt_dtl
        ON RATING_SYSTEM_CD = rt_dtl.RATE_SYSTEM_CD
        AND anbr.GEOGRAPHIC_AREA_CD = rt_dtl.GEOGRAPHIC_AREA_CD
        AND rt_dtl.SERVICE_CD = scm.primary_svc_cd
        AND rt_dtl.original_service_type = scm.servc_type
    INNER JOIN {{edp_project}}.{{edp_dataset}}.{{tic_scsr_differentiation_criteria}} TSDC
        ON TSDC.DIFFERENTIATION_CRITERIA_ID = rt_dtl.DIFFERENTIATION_CRITERIA_ID
        AND  scm.supporting_pos_cd = TSDC.PLACE_OF_SERVICE_CD
    join {{edp_project}}.{{edp_dataset}}.{{tic_scsr_service_detail}} svcdtl  
        on svcdtl.SERVICE_CD = trim(scm.primary_svc_cd) 
        and svcdtl.SERVICE_TYPE_CD = trim(scm.servc_type)
    WHERE (rt_ovrrd.RATE_SYSTEM_CD IS NULL OR rt_ovrrd.GEOGRAPHIC_AREA_CD IS NULL)
    AND CAST(CAST(RATE_PERCENTAGE AS FLOAT64) * CAST(RATE_AMT AS FLOAT64) AS FLOAT64) >= 0.01
    AND TSDC.PRODUCT_CD = 'ALL';


-- Insert Case 3 - No RO and Default Ind
INSERT INTO `{{ce_project}}.{{ce_dec_dataset}}.{{ce_rates_table}}`
        (
    RATE_SYSTEM_CD,
    SERVICE_CD,
    SERVICE_TYPE_CD,
    SERVICE_GROUP_CD,
    SERVICE_GROUPING_PRIORITY_NBR,
    SERVICE_GROUP_CHANGED_IND,
    PROVIDER_BUSINESS_GROUP_NBR,
    PRODUCT_CD,
    PLACE_OF_SERVICE_CD,
    GEOGRAPHIC_AREA_CD,
    EXTENSION_CD,
    EXTENSION_TYPE,
    SPECIALTY_CD,
    SPECIALTY_TYPE_CD,
    PAYMENT_METHOD_CD,
    RATE,
    CNT_EFFTV_DT,
    CNT_TERMN_DT,
    CONTRACT_TYPE,
    LOGIC_TYPE
)
    SELECT DISTINCT
        rt_dtl2.RATE_SYSTEM_CD,
        primary_svc_cd AS SERVICE_CD,
        rt_dtl2.original_service_type AS SERVICE_TYPE_CD,
        DFT_SERVICE_GROUP_CD AS SERVICE_GROUP_CD,
        svcdtl.SERVICE_GROUPING_PRIORITY_NBR AS SERVICE_GROUPING_PRIORITY_NBR,
        SERVICE_GROUP_CHANGED_IND,
        PROVIDER_BUSINESS_GROUP_NBR,
        TSDC.PRODUCT_CD,
        supporting_pos_cd AS PLACE_OF_SERVICE_CD,
        rt_dtl2.GEOGRAPHIC_AREA_CD,
        rt_dtl2.EXTENSION_CD,
        rt_dtl2.EXTENSION_TYPE_CD AS EXTENSION_TYPE,
        rt_dtl2.SPECIALTY_CD,
        rt_dtl2.SPECIALTY_TYPE_CD,
        PAYMENT_METHOD_CD,
        TRUNC(CAST(RATE_PERCENTAGE AS FLOAT64) * CAST(rt_dtl2.RATE_AMT AS FLOAT64), 2) AS RATE,
        CAST(CONTRACT_EFFECTIVE_DT AS STRING) AS CNT_EFFTV_DT,
        CAST(CONTRACT_TERM_DT AS STRING) AS CNT_TERMN_DT,
        'D' AS CONTRACT_TYPE,
        'CASE3_COMPLEX_DEFAULT' AS LOGIC_TYPE
    FROM anbr
    INNER JOIN scm 
        ON scm.supporting_pos_cd = anbr.PLACE_OF_SERVICE_CD
    LEFT JOIN (
            SELECT DISTINCT RATE_SYSTEM_CD,
                GEOGRAPHIC_AREA_CD,
                GEOGRAPHIC_AREA_TYPE_CD,
                PRODUCT_PLATFORM_CD,
                PRODUCT_CD,
                OVERRIDE_RATE_SYSTEM_CD
            FROM `{{edp_project}}.{{edp_dataset_view}}.{{tic_scsr_rate_override_view}}`
    ) rt_ovrrd
        ON anbr.RATING_SYSTEM_CD = rt_ovrrd.RATE_SYSTEM_CD
        AND anbr.ZIP_CD = rt_ovrrd.GEOGRAPHIC_AREA_CD
    LEFT JOIN (
            SELECT DISTINCT RATE_SYSTEM_CD,
                SERVICE_CD,
                CASE
                    WHEN UPPER(SERVICE_TYPE_CD) = 'ADA' THEN 'CDT'
                    WHEN UPPER(SERVICE_TYPE_CD) = 'ASA' THEN 'CPT'
                    WHEN UPPER(SERVICE_TYPE_CD) = 'CMG' THEN 'HIPPS'
                    WHEN UPPER(SERVICE_TYPE_CD) = 'CPT4' THEN 'CPT'
                    WHEN UPPER(SERVICE_TYPE_CD) = 'HCPC' THEN 'HCPCS'
                    WHEN UPPER(SERVICE_TYPE_CD) = 'ICD10DX' THEN 'ICD'
                    WHEN UPPER(SERVICE_TYPE_CD) = 'ICD10PX' THEN 'ICD'
                    WHEN UPPER(SERVICE_TYPE_CD) = 'ICD9' THEN 'ICD'
                    WHEN UPPER(SERVICE_TYPE_CD) = 'REV' THEN 'RC'
                    ELSE UPPER(SERVICE_TYPE_CD)
                END AS SERVICE_TYPE_CD,
                GEOGRAPHIC_AREA_CD,
                EXTENSION_CD,
                EXTENSION_TYPE_CD,
                SPECIALTY_CD,
                SPECIALTY_TYPE_CD,
                DIFFERENTIATION_CRITERIA_ID,
                RATE_AMT,
                SERVICE_TYPE_CD AS original_service_type
            FROM `{{edp_project}}.{{edp_dataset_view}}.{{tic_scsr_rate_detail_view}}`
        ) rt_dtl
        ON anbr.RATING_SYSTEM_CD = rt_dtl.RATE_SYSTEM_CD
        AND anbr.GEOGRAPHIC_AREA_CD = rt_dtl.GEOGRAPHIC_AREA_CD
        AND rt_dtl.SERVICE_CD = scm.primary_svc_cd
        AND rt_dtl.original_service_type = scm.servc_type
    INNER JOIN (
            SELECT DISTINCT RATE_SYSTEM_CD,
                SERVICE_CD,
                CASE
                    WHEN UPPER(SERVICE_TYPE_CD) = 'ADA' THEN 'CDT'
                    WHEN UPPER(SERVICE_TYPE_CD) = 'ASA' THEN 'CPT'
                    WHEN UPPER(SERVICE_TYPE_CD) = 'CMG' THEN 'HIPPS'
                    WHEN UPPER(SERVICE_TYPE_CD) = 'CPT4' THEN 'CPT'
                    WHEN UPPER(SERVICE_TYPE_CD) = 'HCPC' THEN 'HCPCS'
                    WHEN UPPER(SERVICE_TYPE_CD) = 'ICD10DX' THEN 'ICD'
                    WHEN UPPER(SERVICE_TYPE_CD) = 'ICD10PX' THEN 'ICD'
                    WHEN UPPER(SERVICE_TYPE_CD) = 'ICD9' THEN 'ICD'
                    WHEN UPPER(SERVICE_TYPE_CD) = 'REV' THEN 'RC'
                    ELSE UPPER(SERVICE_TYPE_CD)
                END AS SERVICE_TYPE_CD,
                GEOGRAPHIC_AREA_CD,
                EXTENSION_CD,
                EXTENSION_TYPE_CD,
                SPECIALTY_CD,
                SPECIALTY_TYPE_CD,
                DIFFERENTIATION_CRITERIA_ID,
                RATE_AMT,
                SERVICE_TYPE_CD AS original_service_type
            FROM `{{edp_project}}.{{edp_dataset_view}}.{{tic_scsr_rate_detail_view}}`
        ) rt_dtl2
        ON default_RATING_SYSTEM_CD = rt_dtl2.RATE_SYSTEM_CD
        AND default_GEOGRAPHIC_AREA_CD = rt_dtl2.GEOGRAPHIC_AREA_CD
        AND rt_dtl2.SERVICE_CD = scm.primary_svc_cd
        AND rt_dtl2.original_service_type = scm.servc_type
    INNER JOIN {{edp_project}}.{{edp_dataset}}.{{tic_scsr_differentiation_criteria}} TSDC
        ON TSDC.DIFFERENTIATION_CRITERIA_ID = rt_dtl2.DIFFERENTIATION_CRITERIA_ID
        AND  scm.supporting_pos_cd = TSDC.PLACE_OF_SERVICE_CD
    join {{edp_project}}.{{edp_dataset}}.{{tic_scsr_service_detail}} svcdtl  
        on svcdtl.SERVICE_CD = trim(scm.primary_svc_cd) 
        and svcdtl.SERVICE_TYPE_CD = trim(scm.servc_type)
    WHERE (rt_ovrrd.RATE_SYSTEM_CD IS NULL OR rt_ovrrd.GEOGRAPHIC_AREA_CD IS NULL)
    AND (rt_dtl.GEOGRAPHIC_AREA_CD IS NULL OR rt_dtl.RATE_SYSTEM_CD IS NULL)
    AND default_rating_system_ind = 'Y'
    AND CAST(CAST(RATE_PERCENTAGE AS FLOAT64) * CAST(rt_dtl2.RATE_AMT AS FLOAT64) AS FLOAT64) >= 0.01
    AND TSDC.PRODUCT_CD = 'ALL';
