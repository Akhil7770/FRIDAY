-- Create anbr with correct UNNEST and JOINs
CREATE OR REPLACE TEMP TABLE anbr AS
    SELECT DISTINCT g.PROVIDER_BUSINESS_GROUP_NBR,
        l.RATE_PERCENTAGE,
        l.FLAT_RATE_AMT,
        l.RATE_PER_TYPE_CD,
        l.PAYMENT_METHOD_CD,
        l.SERVICE_GROUP_CD AS DFT_SERVICE_GROUP_CD,
        l.SERVICE_GROUP_TYPE_CD,
        g.NETWORK_ID,
        q.CONTRACT_EFFECTIVE_DT,
        q.CONTRACT_TERM_DT,
        q.QUALIFIER_ID,
        l.STRUCTURED_STATEMENT_ID,
        pos.MEMBER_PLACE_OF_SERVICE_CD AS PLACE_OF_SERVICE_CD,
        g.PRODUCT_CD,
        l.SERVICE_GROUP_CHANGED_IND
    FROM `{{edp_project}}.{{edp_dataset_view}}.{{tic_scm_fee_service_line_detail_hsq_view}}` l
    CROSS JOIN UNNEST(SPLIT(l.PLACE_OF_SERVICE_KEY_CD, '')) AS unnested
    INNER JOIN `{{edp_project}}.{{edp_dataset_view}}.{{tic_scm_fee_service_qualifier_detail_hsq_view}}` q
        ON l.QUALIFIER_ID = q.QUALIFIER_ID
    INNER JOIN `{{edp_project}}.{{edp_dataset_view}}.{{tic_epdb_contract_provider_business_group_view}}` g
        ON g.PROVIDER_BUSINESS_GROUP_NBR = q.PROVIDER_BUSINESS_GROUP_NBR
    INNER JOIN `{{edp_project}}.{{edp_dataset}}.{{tic_scsr_place_of_service_affiliation}}` pos
        ON pos.OWNER_PLACE_OF_SERVICE_CD = unnested
    WHERE
        l.PAYMENT_METHOD_CD IN (
            'PERBIL', 'PERBLX', 'PERINV', 'PBLXDL', 'FLAT', 'PDIEM', 'CASE',
            'PERUNT', 'OPPDMC', 'OPTHYA', 'OPTHYI', 'OPPDML'
        )
        AND l.SERVICE_GROUP_TYPE_CD = 'CNTDEF';


-- Create scm
CREATE OR REPLACE TEMP TABLE scm AS
    SELECT DISTINCT TRIM(primary_svc_cd) AS primary_svc_cd,
        TRIM(servc_type) AS servc_type,
        TRIM(supporting_pos_cd) AS supporting_pos_cd
    FROM {{ce_project}}.{{ce_dataset}}.{{ce_scm}}
    WHERE in_scope_ind = 1;


-- Insert into target table with correct join
INSERT INTO `{{ce_project}}.{{ce_dec_dataset}}.{{ce_rates_table}}`
    (
    RATE_SYSTEM_CD,
    SERVICE_CD,
    SERVICE_TYPE_CD,
    SERVICE_GROUP_CD,
    SERVICE_GROUPING_PRIORITY_NBR,
    SERVICE_GROUP_CHANGED_IND,
    PROVIDER_BUSINESS_GROUP_NBR,
    PRODUCT_CD,
    PLACE_OF_SERVICE_CD,
    GEOGRAPHIC_AREA_CD,
    EXTENSION_CD,
    EXTENSION_TYPE,
    SPECIALTY_CD,
    SPECIALTY_TYPE_CD,
    PAYMENT_METHOD_CD,
    RATE,
    CNT_EFFTV_DT,
    CNT_TERMN_DT,
    CONTRACT_TYPE,
    LOGIC_TYPE
)
    SELECT DISTINCT
        '' AS RATE_SYSTEM_CD,
        scm.primary_svc_cd AS SERVICE_CD,
        scm.servc_type AS SERVICE_TYPE_CD,
        anbr.DFT_SERVICE_GROUP_CD AS SERVICE_GROUP_CD,
        svcdtl.SERVICE_GROUPING_PRIORITY_NBR AS SERVICE_GROUPING_PRIORITY_NBR,
        anbr.SERVICE_GROUP_CHANGED_IND,
        anbr.PROVIDER_BUSINESS_GROUP_NBR,
        anbr.PRODUCT_CD,
        scm.supporting_pos_cd AS PLACE_OF_SERVICE_CD,
        '' AS GEOGRAPHIC_AREA_CD,
        '' AS EXTENSION_CD,
        '' AS EXTENSION_TYPE,
        '' AS SPECIALTY_CD,
        '' AS SPECIALTY_TYPE_CD,
        anbr.PAYMENT_METHOD_CD,
        CAST(
            CASE
                WHEN anbr.PAYMENT_METHOD_CD IN ('PERBIL', 'PERBLX', 'PERINV', 'PBLXDL') THEN cast(TRUNC(CAST(anbr.RATE_PERCENTAGE AS FLOAT64) * 100, 2) as float64)
                WHEN anbr.PAYMENT_METHOD_CD IN ('FLAT', 'CASE', 'OPPDML') THEN cast(anbr.FLAT_RATE_AMT as float64)
                WHEN anbr.PAYMENT_METHOD_CD IN ('PDIEM', 'PERUNT', 'OPPDMC', 'OPTHYA', 'OPTHYI') THEN SAFE_CAST(anbr.RATE_PER_TYPE_CD AS FLOAT64) -- Explicitly cast to FLOAT64
            END AS FLOAT64
        )
         AS RATE,
        CAST(anbr.CONTRACT_EFFECTIVE_DT AS STRING) AS CNT_EFFTV_DT,
        CAST(anbr.CONTRACT_TERM_DT AS STRING) AS CNT_TERMN_DT,
        'D' AS CONTRACT_TYPE,
        'NS_DEFAULT' AS LOGIC_TYPE
    FROM anbr
    INNER JOIN scm 
        ON scm.supporting_pos_cd = anbr.PLACE_OF_SERVICE_CD
    join {{edp_project}}.{{edp_dataset}}.{{tic_scsr_service_detail}} svcdtl  
        on svcdtl.SERVICE_CD = trim(scm.primary_svc_cd) 
        and svcdtl.SERVICE_TYPE_CD = trim(scm.servc_type);
