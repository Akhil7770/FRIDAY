create or replace temp table `unnest_zips` as (
    select insurer_cd,
        client_region_key_id,
        zip_code_un 
    from {{ce_project}}.{{ce_dataset}}.{{cet_cvs_out_of_network_region_crosswalk}},unnest(split(zip_cd,';')) as zip_code_un 
    );

create or replace table `{{ce_project}}.{{ce_dec_dataset}}.{{cet_outofnetwork_allowed_amounts}}`as(
    select
        generate_uuid() as UUID_KEY,
        trim(OONnk.billing_cd) as SERVICE_CD,
        trim(OONnk.billing_cd_type_cd) as SERVICE_TYPE_CD,
        trim(OONnk.service_type_desc) as SERVICE_TYPE_DESC,
        trim(scm.supporting_pos_cd) as PLACE_OF_SERVICE_CD,
        trim(zipun.zip_code_un) as ZIP_CODE_UN,
        trim(OONnk.service_maximum_amt) as RATE,
        trim(OONnk.update_type_cd) as UPDATE_TYPE_CD,
        trim(OONnk.insurer_cd) as INSURER_CD,
        trim(OONnk.product_cd) as PRODUCT_CD,
        trim(OONnk.billing_cd_type_version_year_nbr) as BILLING_CD_TYPE_VERSION_YEAR_NBR,
        trim(OONnk.billing_class_desc) as BILLING_CLASS_DESC,  
        trim(OONnk.pos_collection_key_cd) as POS_COLLECTION_KEY_CD,
        trim(OONnk.client_region_key_id) as CLIENT_REGION_KEY_ID,
        trim(OONnk.modifier_cd) as MODIFIER_CD,          
        '' AS UPDATE_DTS,
        CURRENT_TIMESTAMP() AS INSERT_DTS,   
        'SYSTEM' AS INSERT_USER   
    from  {{ce_project}}.{{ce_dataset}}.{{cet_cvs_out_of_network_allowed_amount}} OONnk
    join unnest_zips zipun
        on trim(OONnk.client_region_key_id) = trim(zipun.client_region_key_id)
    join {{ce_project}}.{{ce_dataset}}.{{ce_scm}} scm
        on trim(scm.primary_svc_cd) = trim(OONnk.billing_cd)
    inner join {{ce_project}}.{{ce_dataset}}.{{cet_cvs_place_of_service_mapping}} pos
        on pos.pos_collection_key_cd = OONnk.pos_collection_key_cd
        and scm.supporting_pos_cd = pos.place_of_service_cd
    where scm.in_scope_ind  = 1
    and scm.trmn_dt > CURRENT_DATE()
    );



CREATE OR REPLACE TEMP TABLE BUCKETED AS (
  SELECT
    *,
    MOD(ABS(FARM_FINGERPRINT(UUID_KEY)),3) AS bucket
  FROM
    {{ce_project}}.{{ce_dec_dataset}}.{{cet_outofnetwork_allowed_amounts}} );
CREATE OR REPLACE TABLE
  {{ce_project}}.{{ce_dec_dataset}}.{{cet_outofnetwork_allowed_amounts1}} AS
SELECT
  *
FROM
  BUCKETED
WHERE
  bucket =0;
  CREATE OR REPLACE TABLE
  {{ce_project}}.{{ce_dec_dataset}}.{{cet_outofnetwork_allowed_amounts2}} AS
SELECT
  *
FROM
  BUCKETED
WHERE
  bucket =1;
    CREATE OR REPLACE TABLE
  {{ce_project}}.{{ce_dec_dataset}}.{{cet_outofnetwork_allowed_amounts3}} AS
SELECT
  *
FROM
  BUCKETED
WHERE
  bucket =2;
