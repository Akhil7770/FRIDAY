
-- 1,174,290,415 records returned after joining with SCM

INSERT INTO `{{ce_project}}.{{ce_dec_dataset}}.{{ce_rates_table}}` (
    
    RATE_SYSTEM_CD,
    SERVICE_CD,
    SERVICE_TYPE_CD,
    SERVICE_GROUP_CD,
    SERVICE_GROUPING_PRIORITY_NBR,
    SERVICE_GROUP_CHANGED_IND,
    PROVIDER_BUSINESS_GROUP_NBR,
    PRODUCT_CD,
    PLACE_OF_SERVICE_CD,
    GEOGRAPHIC_AREA_CD,
    EXTENSION_CD,
    EXTENSION_TYPE,
    SPECIALTY_CD,
    SPECIALTY_TYPE_CD,
    PAYMENT_METHOD_CD,
    RATE,
    CNT_EFFTV_DT,
    CNT_TERMN_DT,
    CONTRACT_TYPE,
    LOGIC_TYPE
)
SELECT DISTINCT
    
    rt.RATE_SYSTEM_CD AS RATE_SYSTEM_CD,
    CASE
        WHEN LENGTH(TRIM(svcdtl.SERVICE_CD)) = 3 AND svcdtl.SERVICE_TYPE_CD IN ('REV', 'RC')
        THEN CONCAT('0', TRIM(svcdtl.SERVICE_CD))
        ELSE svcdtl.SERVICE_CD
    END AS SERVICE_CD,
    svcdtl.SERVICE_TYPE_CD AS SERVICE_TYPE_CD,
    ld.SERVICE_GROUP_CD,
    svcdtl.SERVICE_GROUPING_PRIORITY_NBR,
    ld.SERVICE_GROUP_CHANGED_IND as SERVICE_GROUP_CHANGED_IND,
    qd.PROVIDER_BUSINESS_GROUP_NBR AS PROVIDER_BUSINESS_GROUP_NBR,
    TSDC.PRODUCT_CD,
     trim(scm.supporting_pos_cd) as PLACE_OF_SERVICE_CD,
    rt.GEOGRAPHIC_AREA_CD AS  GEOGRAPHIC_AREA_CD,
    rt.EXTENSION_CD AS EXTENSION_CD,
    rt.EXTENSION_TYPE_CD AS EXTENSION_TYPE,
    rt.SPECIALTY_CD,
    rt.SPECIALTY_TYPE_CD,
    ld.PAYMENT_METHOD_CD,
    CAST(ld.RATE_PERCENTAGE AS FLOAT64) * CAST(rt.RATE_AMT AS FLOAT64) AS RATE,
     CAST(qd.CONTRACT_EFFECTIVE_DT AS STRING) AS CNT_EFFTV_DT,
    CAST(qd.CONTRACT_TERM_DT AS STRING) AS CNT_TERMN_DT,
    'C' AS CONTRACT_TYPE,
    'B12_PERRT_PERAMF_NON_ROR' AS LOGIC_TYPE

FROM
    {{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_line_detail_view}} ld
JOIN {{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_detail_view}} sd
    ON sd.STRUCTURED_STATEMENT_ID = ld.STRUCTURED_STATEMENT_ID


JOIN
    {{ce_project}}.{{ce_dataset}}.{{ce_scm}} scm
ON
   trim(scm.primary_svc_cd) between sd.LOW_SERVICE_CD AND sd.HIGH_SERVICE_CD
 and trim(scm.servc_type) = sd.SERVICE_TYPE_CD

JOIN {{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_Qualifier_detail_view}} qd
    ON qd.QUALIFIER_ID = ld.QUALIFIER_ID
LEFT JOIN {{ce_project}}.{{ce_dataset}}.{{cet_scsr_rate_override_view}} ro
    ON ld.RATING_SYSTEM_CD = ro.RATE_SYSTEM_CD
    AND ld.ZIP_CD = ro.GEOGRAPHIC_AREA_CD

JOIN {{ce_project}}.{{ce_dataset}}.{{cet_scsr_rate_detail_view}} rt
    ON rt.SERVICE_CD = trim(scm.primary_svc_cd)
    AND rt.SERVICE_TYPE_CD = trim(scm.servc_type)
    AND TRIM(rt.RATE_SYSTEM_CD) = TRIM(ld.RATING_SYSTEM_CD)
    AND TRIM(rt.GEOGRAPHIC_AREA_CD) = TRIM(ld.GEOGRAPHIC_AREA_CD)

join {{ce_project}}.{{ce_dataset}}.{{cet_scsr_service_detail_view}} svcdtl
  on svcdtl.SERVICE_CD = trim(scm.primary_svc_cd)
 and svcdtl.SERVICE_TYPE_CD = trim(scm.servc_type)


JOIN {{ce_project}}.{{ce_dataset}}.{{cet_scsr_differentiation_criteria_view}} TSDC
    ON TSDC.DIFFERENTIATION_CRITERIA_ID = rt.DIFFERENTIATION_CRITERIA_ID
    and scm.supporting_pos_cd = TSDC.PLACE_OF_SERVICE_CD
JOIN (
    SELECT DISTINCT pbgnbr.PROVIDER_BUSINESS_GROUP_NBR
    FROM {{ce_project}}.{{ce_dataset}}.{{cet_business_group_view}} pbgnbr
) pbgnbr
    ON pbgnbr.PROVIDER_BUSINESS_GROUP_NBR = qd.PROVIDER_BUSINESS_GROUP_NBR
WHERE
    ld.PAYMENT_METHOD_CD IN ('PERRT', 'PERAMF')
    AND ld.SERVICE_GROUP_CD <> ''
    AND ld.SERVICE_GROUP_CHANGED_IND = 'Y'
    AND ro.RATE_SYSTEM_CD IS NULL
    AND scm.in_scope_ind = 1
    AND scm.trmn_dt > CURRENT_DATE()

UNION ALL

SELECT DISTINCT
     
    rt.RATE_SYSTEM_CD AS RATE_SYSTEM_CD,
    CASE
        WHEN LENGTH(TRIM(svcdtl.SERVICE_CD)) = 3 AND svcdtl.SERVICE_TYPE_CD IN ('REV', 'RC')
        THEN CONCAT('0', TRIM(svcdtl.SERVICE_CD))
        ELSE svcdtl.SERVICE_CD
    END AS SERVICE_CD,
    svcdtl.SERVICE_TYPE_CD AS SERVICE_TYPE_CD,
    ld.SERVICE_GROUP_CD,
      svcdtl.SERVICE_GROUPING_PRIORITY_NBR,
    ld.SERVICE_GROUP_CHANGED_IND as SERVICE_GROUP_CHANGED_IND,
    qd.PROVIDER_BUSINESS_GROUP_NBR AS PROVIDER_BUSINESS_GROUP_NBR,
    TSDC.PRODUCT_CD,
      trim(scm.supporting_pos_cd) as PLACE_OF_SERVICE_CD,
    rt.GEOGRAPHIC_AREA_CD AS GEOGRAPHIC_AREA_CD,
    rt.EXTENSION_CD AS EXTENSION_CD,
    rt.EXTENSION_TYPE_CD AS EXTENSION_TYPE_CD,
    rt.SPECIALTY_CD,
    rt.SPECIALTY_TYPE_CD,
    ld.PAYMENT_METHOD_CD,
    CAST(ld.RATE_PERCENTAGE AS FLOAT64) * CAST(rt.RATE_AMT AS FLOAT64) AS RATE,
    CAST(qd.CONTRACT_EFFECTIVE_DT AS STRING) AS CNT_EFFTV_DT,
    CAST(qd.CONTRACT_TERM_DT AS STRING) AS CNT_TERMN_DT,
       'C' AS CONTRACT_TYPE,
    'B12_PERRT_PERAMF_NON_ROR' AS LOGIC_TYPE
FROM
    {{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_line_detail_view}} ld

JOIN {{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_detail_view}} sd
    ON sd.STRUCTURED_STATEMENT_ID = ld.STRUCTURED_STATEMENT_ID

--JOIN {{ce_project}}.{{ce_dataset}}.{{cet_scsr_service_detail_view}} svcdtl
--    ON svcdtl.SERVICE_CD BETWEEN sd.LOW_SERVICE_CD AND sd.HIGH_SERVICE_CD
--    AND svcdtl.SERVICE_TYPE_CD = sd.SERVICE_TYPE_CD

JOIN
    {{ce_project}}.{{ce_dataset}}.{{ce_scm}} scm
ON
   trim(scm.primary_svc_cd) between sd.LOW_SERVICE_CD AND sd.HIGH_SERVICE_CD
 and trim(scm.servc_type) = sd.SERVICE_TYPE_CD

JOIN {{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_Qualifier_detail_view}} qd
    ON qd.QUALIFIER_ID = ld.QUALIFIER_ID
LEFT JOIN {{ce_project}}.{{ce_dataset}}.{{cet_scsr_rate_override_view}} ro
    ON ld.RATING_SYSTEM_CD = ro.RATE_SYSTEM_CD
    AND ld.ZIP_CD = ro.GEOGRAPHIC_AREA_CD


LEFT JOIN {{ce_project}}.{{ce_dataset}}.{{cet_scsr_rate_detail_view}} rt
    ON rt.SERVICE_CD = trim(scm.primary_svc_cd)
    AND rt.SERVICE_TYPE_CD = trim(scm.servc_type)
    AND TRIM(rt.RATE_SYSTEM_CD) = TRIM(ld.RATING_SYSTEM_CD)
    AND TRIM(rt.GEOGRAPHIC_AREA_CD) = TRIM(ld.GEOGRAPHIC_AREA_CD)


JOIN {{ce_project}}.{{ce_dataset}}.{{cet_scsr_rate_detail_view}} rt2
    ON rt2.SERVICE_CD = trim(scm.primary_svc_cd)
    AND rt2.SERVICE_TYPE_CD = trim(scm.servc_type)
    AND rt.RATE_SYSTEM_CD = ro.OVERRIDE_RATE_SYSTEM_CD
    AND TRIM(rt2.RATE_SYSTEM_CD) = TRIM(ld.DEFAULT_RATING_SYSTEM_CD)
    AND TRIM(rt2.GEOGRAPHIC_AREA_CD) = TRIM(ld.DEFAULT_GEOGRAPHIC_AREA_CD)

join {{ce_project}}.{{ce_dataset}}.{{cet_scsr_service_detail_view}} svcdtl
  on svcdtl.SERVICE_CD = trim(scm.primary_svc_cd)
 and svcdtl.SERVICE_TYPE_CD = trim(scm.servc_type)


JOIN {{ce_project}}.{{ce_dataset}}.{{cet_scsr_differentiation_criteria_view}} TSDC
    ON TSDC.DIFFERENTIATION_CRITERIA_ID = rt2.DIFFERENTIATION_CRITERIA_ID
    and scm.supporting_pos_cd = TSDC.PLACE_OF_SERVICE_CD
JOIN (
    SELECT DISTINCT pbgnbr.PROVIDER_BUSINESS_GROUP_NBR
    FROM {{ce_project}}.{{ce_dataset}}.{{cet_business_group_view}} pbgnbr
) pbgnbr
    ON pbgnbr.PROVIDER_BUSINESS_GROUP_NBR = qd.PROVIDER_BUSINESS_GROUP_NBR
WHERE
    ld.PAYMENT_METHOD_CD IN ('PERRT', 'PERAMF')
    AND ld.SERVICE_GROUP_CD <> ''
    AND ld.SERVICE_GROUP_CHANGED_IND = 'Y'
    AND ro.RATE_SYSTEM_CD IS NULL
    AND rt.SERVICE_CD IS NULL
    AND ld.DEFAULT_RATING_SYSTEM_IND = 'Y'
     AND scm.in_scope_ind = 1
     AND scm.trmn_dt > CURRENT_DATE();
