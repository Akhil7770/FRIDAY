-- We are not getting if servie type code is empty
-- no data after joining with service master
INSERT INTO `{{ce_project}}.{{ce_dec_dataset}}.{{ce_rates_table}}` (
    
    RATE_SYSTEM_CD,
    SERVICE_CD,
    SERVICE_TYPE_CD,
    SERVICE_GROUP_CD,
    SERVICE_GROUPING_PRIORITY_NBR,
    SERVICE_GROUP_CHANGED_IND,
    PROVIDER_BUSINESS_GROUP_NBR,
    PRODUCT_CD,
    PLACE_OF_SERVICE_CD,
    GEOGRAPHIC_AREA_CD,
    EXTENSION_CD,
    EXTENSION_TYPE,
    SPECIALTY_CD,
    SPECIALTY_TYPE_CD,
    PAYMENT_METHOD_CD,
    RATE,
    CNT_EFFTV_DT,
    CNT_TERMN_DT,
    CONTRACT_TYPE,
    LOGIC_TYPE
)
select distinct
   
  '' as RATE_SYSTEM_CD,
  case when (length(trim(svcdtl.SERVICE_CD))=3 and svcdtl.SERVICE_TYPE_CD in ('REV','RC')) then
  CONCAT('0',trim(svcdtl.SERVICE_CD)) else
  svcdtl.SERVICE_CD end as SERVICE_CD,
  svcdtl.SERVICE_TYPE_CD as SERVICE_TYPE_CD,
   ld.SERVICE_GROUP_CD,
   svcdtl.SERVICE_GROUPING_PRIORITY_NBR,
   ld.SERVICE_GROUP_CHANGED_IND as SERVICE_GROUP_CHANGED_IND,
   qd.PROVIDER_BUSINESS_GROUP_NBR as PROVIDER_BUSINESS_GROUP_NBR,
   pbgnbr.PRODUCT_CD ,
 trim(scm.supporting_pos_cd) as PLACE_OF_SERVICE_CD,
  '' as GEOGRAPHIC_AREA_CD,
  '' as EXTENSION_CD ,
  '' as EXTENSION_TYPE ,
   '' as SPECIALTY_CD ,
  '' as SPECIALTY_TYPE_CD ,
    ld.PAYMENT_METHOD_CD ,
         cast(ld.RATE_PER_TYPE_CD as FLOAT64)*cast((CAST(svcdtl.ANESTHESIA_UNIT_CNT AS FLOAT64)+1) as FLOAT64) as RATE,
  CAST(qd.CONTRACT_EFFECTIVE_DT AS STRING) AS CNT_EFFTV_DT,
    CAST(qd.CONTRACT_TERM_DT AS STRING) AS CNT_TERMN_DT,
    'C' AS CONTRACT_TYPE,
    'C3_PERBU' AS LOGIC_TYPE

from  {{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_line_detail_view}}  ld

Join {{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_detail_view}}  sd
    on SD.STRUCTURED_STATEMENT_ID = ld.STRUCTURED_STATEMENT_ID
  
JOIN
    {{ce_project}}.{{ce_dataset}}.{{ce_scm}} scm
ON
    trim(scm.primary_svc_cd) BETWEEN sd.LOW_SERVICE_CD AND sd.HIGH_SERVICE_CD
    AND trim(scm.servc_type) = sd.SERVICE_TYPE_CD

join {{ce_project}}.{{ce_dataset}}.{{cet_scsr_service_detail_view}} svcdtl
  on svcdtl.SERVICE_CD = trim(scm.primary_svc_cd)
 and svcdtl.SERVICE_TYPE_CD = trim(scm.servc_type)

join {{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_Qualifier_detail_view}}  qd
    on qd.QUALIFIER_ID = CAST(ld.QUALIFIER_ID as INT)

join {{ce_project}}.{{ce_dataset}}.{{cet_scsr_service_Affiliation_view}}  aff
  on aff.MEMBER_SERVICE_CD = trim(scm.primary_svc_cd)
  and aff.MEMBER_SERVICE_TYPE_CD = trim(scm.servc_type)

  join {{ce_project}}.{{ce_dataset}}.{{cet_business_group_view}} pbgnbr
    on pbgnbr.PROVIDER_BUSINESS_GROUP_NBR = qd.PROVIDER_BUSINESS_GROUP_NBR

   

where ld.PAYMENT_METHOD_CD in ('PERBU')
  and SERVICE_GROUP_CD = '' 
  AND scm.in_scope_ind = 1
  AND scm.trmn_dt > CURRENT_DATE();
