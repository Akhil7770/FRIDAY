-- no data
INSERT INTO `{{ce_project}}.{{ce_dec_dataset}}.{{ce_rates_table}}` (
    
    RATE_SYSTEM_CD,
    SERVICE_CD,
    SERVICE_TYPE_CD,
    SERVICE_GROUP_CD,
    SERVICE_GROUPING_PRIORITY_NBR,
    SERVICE_GROUP_CHANGED_IND,
    PROVIDER_BUSINESS_GROUP_NBR,
    PRODUCT_CD,
    PLACE_OF_SERVICE_CD,
    GEOGRAPHIC_AREA_CD,
    EXTENSION_CD,
    EXTENSION_TYPE,
    SPECIALTY_CD,
    SPECIALTY_TYPE_CD,
    PAYMENT_METHOD_CD,
    RATE,
    CNT_EFFTV_DT,
    CNT_TERMN_DT,
    CONTRACT_TYPE,
    LOGIC_TYPE
    
)
SELECT DISTINCT
    
   rv.RATE_SYSTEM_CD,
    CASE
        WHEN LENGTH(TRIM(svcdtl.SERVICE_CD)) = 3 AND svcdtl.SERVICE_TYPE_CD IN ('REV', 'RC')
        THEN CONCAT('0', TRIM(svcdtl.SERVICE_CD))
        ELSE svcdtl.SERVICE_CD
    END AS SERVICE_CD,
    svcdtl.SERVICE_TYPE_CD,
    ld.SERVICE_GROUP_CD,
    svcdtl.SERVICE_GROUPING_PRIORITY_NBR,
    ld.SERVICE_GROUP_CHANGED_IND as SERVICE_GROUP_CHANGED_IND,
    qd.PROVIDER_BUSINESS_GROUP_NBR AS PROVIDER_BUSINESS_GROUP_NBR,
    pbgnbr.PRODUCT_CD,
    trim(scm.supporting_pos_cd) as PLACE_OF_SERVICE_CD,
    '' AS GEOGRAPHIC_AREA_CD,
    '' AS EXTENSION_CD,
    '' AS EXTENSION_TYPE,
    '' AS SPECIALTY_CD,
    '' AS SPECIALTY_TYPE_CD,
    ld.PAYMENT_METHOD_CD,
    CAST(ld.FLAT_RATE_AMT AS FLOAT64) * CAST(rv.RELATIVE_VALUE_AMT AS FLOAT64) AS RATE,
    CAST(qd.CONTRACT_EFFECTIVE_DT AS STRING) AS CNT_EFFTV_DT,
    CAST(qd.CONTRACT_TERM_DT AS STRING) AS CNT_TERMN_DT,
    'C' AS CONTRACT_TYPE,
    'C12_DRGWT' AS LOGIC_TYPE
FROM
    `{{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_line_detail_view}}` ld
JOIN `{{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_detail_view}}` sd
    ON ld.STRUCTURED_STATEMENT_ID = sd.STRUCTURED_STATEMENT_ID
JOIN
    {{ce_project}}.{{ce_dataset}}.{{ce_scm}} scm
ON
    trim(scm.primary_svc_cd) BETWEEN sd.LOW_SERVICE_CD AND sd.HIGH_SERVICE_CD
    AND trim(scm.servc_type) = sd.SERVICE_TYPE_CD
JOIN `{{ce_project}}.{{ce_dataset}}.{{cet_scsr_service_detail_view}}` svcdtl
    on svcdtl.SERVICE_CD = trim(scm.primary_svc_cd)
 and svcdtl.SERVICE_TYPE_CD = trim(scm.servc_type)
JOIN `{{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_Qualifier_detail_view}}` qd
    ON qd.QUALIFIER_ID = CAST(ld.QUALIFIER_ID AS INT)
JOIN `{{ce_project}}.{{ce_dataset}}.{{cet_scsr_service_Affiliation_view}}` aff
    on aff.MEMBER_SERVICE_CD = trim(scm.primary_svc_cd)
  and aff.MEMBER_SERVICE_TYPE_CD = trim(scm.servc_type)
JOIN `{{ce_project}}.{{ce_dataset}}.{{cet_scsr_relative_value_view}}` rv
    on rv.SERVICE_CD = trim(scm.primary_svc_cd)
  and rv.SERVICE_TYPE_CD = trim(scm.servc_type)
JOIN `{{ce_project}}.{{ce_dataset}}.{{cet_business_group_view}}` pbgnbr
    ON pbgnbr.PROVIDER_BUSINESS_GROUP_NBR = qd.PROVIDER_BUSINESS_GROUP_NBR
WHERE
    ld.PAYMENT_METHOD_CD IN ('DRGWT')
    AND ld.SERVICE_GROUP_CD = ''
    AND rv.RATE_SYSTEM_CD = 'MCAREW'
    AND scm.in_scope_ind = 1
  AND scm.trmn_dt > CURRENT_DATE();
