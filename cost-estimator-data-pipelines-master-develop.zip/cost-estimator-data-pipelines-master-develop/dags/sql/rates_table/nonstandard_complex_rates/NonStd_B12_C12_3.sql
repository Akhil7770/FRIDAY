--B12 and C12  can be combined
--B12 SERVICE_GROUP_CD field is populated and the service grouping changed indicator is equal to ‘Y’   and sd.LOW_SERVICE_CD <> ''  and sd.HIGH_SERVICE_CD <> ''
--C12 SERVICE_GROUP_CD =''  and sd.LOW_SERVICE_CD <> ''  and sd.HIGH_SERVICE_CD <> ''
-- no data
INSERT INTO `{{ce_project}}.{{ce_dec_dataset}}.{{ce_rates_table}}` (
    
    RATE_SYSTEM_CD,
    SERVICE_CD,
    SERVICE_TYPE_CD,
    SERVICE_GROUP_CD,
    SERVICE_GROUPING_PRIORITY_NBR,
    SERVICE_GROUP_CHANGED_IND,
    PROVIDER_BUSINESS_GROUP_NBR,
    PRODUCT_CD,
    PLACE_OF_SERVICE_CD,
    GEOGRAPHIC_AREA_CD,
    EXTENSION_CD,
    EXTENSION_TYPE,
    SPECIALTY_CD,
    SPECIALTY_TYPE_CD,
    PAYMENT_METHOD_CD,
    RATE,
    CNT_EFFTV_DT,
    CNT_TERMN_DT,
    CONTRACT_TYPE,
    LOGIC_TYPE
)
  WITH FilteredScmFeeServiceDetails  AS (
    SELECT distinct
        sd.LOW_SERVICE_CD,
        sd.high_SERVICE_CD,
        sd.SERVICE_TYPE_CD,
        SD.STRUCTURED_STATEMENT_ID,
        SD.OPERATOR_CD
    FROM
        `{{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_detail_hsq_view}}` SD
    WHERE
        sd.LOW_SERVICE_CD <> ''
    and sd.HIGH_SERVICE_CD <> ''
    and sd.OPERATOR_CD NOT IN ('AND','INC')
),
FilteredServiceDetails AS (
    SELECT
        svcdtl.SERVICE_CD,
        svcdtl.SERVICE_TYPE_CD,
        svcdtl.SERVICE_GROUPING_PRIORITY_NBR
       
    FROM
        `{{ce_project}}.{{ce_dataset}}.{{cet_scsr_service_detail_view}}` svcdtl
    WHERE
        svcdtl.SERVICE_TYPE_CD <> ''
),
FilteredLineDetails AS (
    SELECT
        ld.*
    FROM
        `{{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_line_detail_hsq_view}}` ld
    WHERE
        (ld.SERVICE_GROUP_CD <> '' AND
        ld.SERVICE_GROUP_CHANGED_IND = 'Y')
        OR ld.SERVICE_GROUP_CD =''
)
SELECT DISTINCT
    '' AS RATE_SYSTEM_CD,
    CASE
        WHEN (LENGTH(TRIM(svcdtl.SERVICE_CD)) = 3 AND svcdtl.SERVICE_TYPE_CD IN ('REV', 'RC'))
        THEN CONCAT('0', TRIM(svcdtl.SERVICE_CD))
        ELSE svcdtl.SERVICE_CD
    END AS SERVICE_CD,
    svcdtl.SERVICE_TYPE_CD as SERVICE_TYPE_CD,
    ld.SERVICE_GROUP_CD as SERVICE_GROUP_CD,
    svcdtl.SERVICE_GROUPING_PRIORITY_NBR as SERVICE_GROUPING_PRIORITY_NBR,
    ld.SERVICE_GROUP_CHANGED_IND as SERVICE_GROUP_CHANGED_IND,
    qd.PROVIDER_BUSINESS_GROUP_NBR as PROVIDER_BUSINESS_GROUP_NBR,
    pbgnbr.PRODUCT_CD as PRODUCT_CD,
    trim(scm.supporting_pos_cd) as PLACE_OF_SERVICE_CD,
    --POS.MEMBER_PLACE_OF_SERVICE_CD as PLACE_OF_SERVICE_CD,
    '' as GEOGRAPHIC_AREA_CD,
    '' as EXTENSION_CD,
    '' as EXTENSION_TYPE,
    '' as SPECIALTY_CD,
    '' as SPECIALTY_TYPE_CD,
    ld.PAYMENT_METHOD_CD as PAYMENT_METHOD_CD,
    cast(ld.RATE_PER_TYPE_CD as FLOAT64) as RATE,
    CAST(qd.CONTRACT_EFFECTIVE_DT AS STRING) AS CNT_EFFTV_DT,
    CAST(qd.CONTRACT_TERM_DT AS STRING) AS CNT_TERMN_DT,
    'N' AS CONTRACT_TYPE,
    'B12_C12_3' as LOGIC_TYPE
FROM
    FilteredLineDetails ld
JOIN
    FilteredScmFeeServiceDetails sd
    ON sd.STRUCTURED_STATEMENT_ID = ld.STRUCTURED_STATEMENT_ID
JOIN
    FilteredServiceDetails svcdtl
    ON svcdtl.SERVICE_CD BETWEEN sd.LOW_SERVICE_CD AND sd.HIGH_SERVICE_CD
    AND svcdtl.SERVICE_TYPE_CD = sd.SERVICE_TYPE_CD
 
join `{{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_Qualifier_detail_hsq_view}}` qd
    on qd.QUALIFIER_ID = ld.QUALIFIER_ID
 
   join {{ce_project}}.{{ce_dataset}}.{{ce_scm}} scm
    ON trim(scm.primary_svc_cd) = svcdtl.SERVICE_CD
    AND trim(scm.servc_type) = svcdtl.SERVICE_TYPE_CD
 
  join
    (select distinct pbgnbr.PROVIDER_BUSINESS_GROUP_NBR ,pbgnbr.PRODUCT_CD
    from  {{ce_project}}.{{ce_dataset}}.{{cet_business_group_view}} pbgnbr) Pbgnbr
    on pbgnbr.PROVIDER_BUSINESS_GROUP_NBR = qd.PROVIDER_BUSINESS_GROUP_NBR
where
ld.PAYMENT_METHOD_CD in ('PERUNT' )
  and ((ld.SERVICE_GROUP_CD <> '' and ld.SERVICE_GROUP_CHANGED_IND = 'Y') OR ld.SERVICE_GROUP_CD ='')
  and  ld.SERVICE_GROUP_CD =''
  and sd.LOW_SERVICE_CD <> ''
  and sd.HIGH_SERVICE_CD <> ''
  and svcdtl.SERVICE_TYPE_CD <> ''
  and sd.OPERATOR_CD NOT IN ('AND','INC')
    AND scm.in_scope_ind = 1
  AND scm.trmn_dt > CURRENT_DATE();
