-- no data
INSERT INTO `{{ce_project}}.{{ce_dec_dataset}}.{{ce_rates_table}}` (
    
    RATE_SYSTEM_CD,
    SERVICE_CD,
    SERVICE_TYPE_CD,
    SERVICE_GROUP_CD,
    SERVICE_GROUPING_PRIORITY_NBR,
    SERVICE_GROUP_CHANGED_IND,
    PROVIDER_BUSINESS_GROUP_NBR,
    PRODUCT_CD,
    PLACE_OF_SERVICE_CD,
    GEOGRAPHIC_AREA_CD,
    EXTENSION_CD,
    EXTENSION_TYPE,
    SPECIALTY_CD,
    SPECIALTY_TYPE_CD,
    PAYMENT_METHOD_CD,
    RATE,
    CNT_EFFTV_DT,
    CNT_TERMN_DT,
    CONTRACT_TYPE,
    LOGIC_TYPE
)
WITH valid_service_codes AS (
    SELECT
        sd.LOW_SERVICE_CD,
        sd.HIGH_SERVICE_CD,
        sd.LOW_VALUE_CD,
        sd.HIGH_VALUE_CD,
        sd.OPERATOR_CD,
        sd.STRUCTURED_STATEMENT_ID,
        sd.SEQUENCE_NBR,
        sd.SERVICE_TYPE_CD,
        sd.FACTOR_TYPE_CD,
        qd.PROVIDER_BUSINESS_GROUP_NBR,
        ld.PAYMENT_METHOD_CD,
        ld.SERVICE_GROUP_CD as SERVICE_GROUP_CD,
        ld.SERVICE_GROUP_CHANGED_IND as SERVICE_GROUP_CHANGED_IND,
        case when ld.PAYMENT_METHOD_CD='PDIEM' then cast(ld.RATE_PER_TYPE_CD as FLOAT64) else
        case when ld.PAYMENT_METHOD_CD='PERUNT' then cast(ld.RATE_PER_TYPE_CD as FLOAT64) else
        case when ld.PAYMENT_METHOD_CD='OPPDMC' then cast(ld.RATE_PER_TYPE_CD as FLOAT64) else
        case when ld.PAYMENT_METHOD_CD='OPTHYA' then cast(ld.RATE_PER_TYPE_CD as FLOAT64) else
        case when ld.PAYMENT_METHOD_CD='OPTHYI'  then cast(ld.RATE_PER_TYPE_CD as FLOAT64) else
 
        case when ld.PAYMENT_METHOD_CD='PERBIL' then (cast(ld.RATE_PERCENTAGE as FLOAT64) * 100) else
        case when ld.PAYMENT_METHOD_CD='PERBLX' then (cast(ld.RATE_PERCENTAGE as FLOAT64) * 100) else
        case when ld.PAYMENT_METHOD_CD='PERINV' then (cast(ld.RATE_PERCENTAGE as FLOAT64) * 100) else
        case when ld.PAYMENT_METHOD_CD='PBLXDL'  then (cast(ld.RATE_PERCENTAGE as FLOAT64) * 100) else
 
        case when ld.PAYMENT_METHOD_CD='FLAT' then cast(ld.FLAT_RATE_AMT as FLOAT64) else
        case when ld.PAYMENT_METHOD_CD='CASE' then cast(ld.FLAT_RATE_AMT as FLOAT64) else
        case when ld.PAYMENT_METHOD_CD='OPPDML' then cast(ld.FLAT_RATE_AMT as FLOAT64) else 0 end
        end end end end end end end end end end end RATE,
        qd.CONTRACT_EFFECTIVE_DT as CNT_EFFTV_DT,
        qd.CONTRACT_TERM_DT as CNT_TERMN_DT

    FROM
        `{{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_line_detail_hsq_view}}` ld
        Join `{{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_detail_hsq_view}}` sd
   on SD.STRUCTURED_STATEMENT_ID = ld.STRUCTURED_STATEMENT_ID

   JOIN `{{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_Qualifier_detail_hsq_view}}` qd
   on qd.QUALIFIER_ID = ld.QUALIFIER_ID

    WHERE
        (sd.LOW_SERVICE_CD IS NOT NULL OR sd.HIGH_SERVICE_CD IS NOT NULL OR sd.LOW_VALUE_CD IS NOT NULL OR sd.HIGH_VALUE_CD IS NOT NULL)
        and ld.PAYMENT_METHOD_CD in ('FLAT','PDIEM','CASE','PERUNT','OPPDMC','OPTHYA','OPTHYI','PERBIL','PERBLX','PERINV','PBLXDL','OPPDML' )
        and ((ld.SERVICE_GROUP_CD <> '' and ld.SERVICE_GROUP_CHANGED_IND = 'Y') OR ld.SERVICE_GROUP_CD ='')
),


filtered_service_codes AS (
    SELECT
        v.LOW_SERVICE_CD,
        v.HIGH_SERVICE_CD,
        v.LOW_VALUE_CD,
        v.HIGH_VALUE_CD,
        v.OPERATOR_CD,
        v.SERVICE_TYPE_CD,
        v.FACTOR_TYPE_CD,
        v.PROVIDER_BUSINESS_GROUP_NBR,
        v.PAYMENT_METHOD_CD,
        v.RATE,
        v.CNT_EFFTV_DT,
        v.CNT_TERMN_DT ,
        v.SERVICE_GROUP_CD,
        v.SERVICE_GROUP_CHANGED_IND
    FROM
        valid_service_codes v
    WHERE
        (v.OPERATOR_CD IS NULL OR v.OPERATOR_CD NOT IN ('INC', 'AND'))
        OR (v.OPERATOR_CD = 'AND' AND (
            (v.LOW_SERVICE_CD IS NOT NULL AND v.HIGH_SERVICE_CD IS NOT NULL AND v.LOW_VALUE_CD IS NOT NULL AND v.HIGH_VALUE_CD IS NOT NULL)
            AND NOT (v.LOW_SERVICE_CD > v.HIGH_SERVICE_CD OR v.LOW_VALUE_CD > v.HIGH_VALUE_CD)
            AND NOT (v.LOW_SERVICE_CD IS NULL AND v.HIGH_SERVICE_CD IS NULL AND v.LOW_VALUE_CD IS NULL AND v.HIGH_VALUE_CD IS NULL)
        ))
),

service_code_groups AS (
    SELECT
        f.LOW_SERVICE_CD,
        f.HIGH_SERVICE_CD,
        f.LOW_VALUE_CD,
        f.HIGH_VALUE_CD,
        f.OPERATOR_CD,
        f.SERVICE_TYPE_CD,
        f.FACTOR_TYPE_CD,
        f.PROVIDER_BUSINESS_GROUP_NBR,
        f.PAYMENT_METHOD_CD,
        f.RATE,
        f.CNT_EFFTV_DT,
        f.CNT_TERMN_DT,
        f.SERVICE_GROUP_CD,
        f.SERVICE_GROUP_CHANGED_IND
    FROM
        filtered_service_codes f
    WHERE
        (f.OPERATOR_CD = 'AND' AND (
            (f.LOW_SERVICE_CD IS NOT NULL AND f.HIGH_SERVICE_CD IS NOT NULL AND f.LOW_VALUE_CD IS NOT NULL AND f.HIGH_VALUE_CD IS NOT NULL)
            AND NOT (f.LOW_SERVICE_CD > f.HIGH_SERVICE_CD OR f.LOW_VALUE_CD > f.HIGH_VALUE_CD)
        ))
        OR (f.OPERATOR_CD = 'INC' AND (
            NOT (f.LOW_SERVICE_CD > f.HIGH_SERVICE_CD OR f.LOW_VALUE_CD > f.HIGH_VALUE_CD)
            OR (f.LOW_SERVICE_CD IS NOT NULL AND f.HIGH_SERVICE_CD IS NOT NULL AND f.LOW_VALUE_CD IS NULL AND f.HIGH_VALUE_CD IS NULL)
        ))
)
--select * from    `{{ce_project}}.{{ce_dataset}}.{{cet_scsr_service_detail_view}}` svcdtl  limit 10

SELECT DISTINCT
     
    '' as RATE_SYSTEM_CD,
    case when (length(trim(svcdtl.SERVICE_CD))=3 and svcdtl.SERVICE_TYPE_CD in ('REV','RC'))
    then concat('0',trim(svcdtl.SERVICE_CD)) else svcdtl.SERVICE_CD end as SERVICE_CD,
    svcdtl.SERVICE_TYPE_CD,

    -- s.LOW_SERVICE_CD,
    -- s.HIGH_SERVICE_CD,
    -- s.LOW_VALUE_CD,
    -- s.HIGH_VALUE_CD,
    -- s.OPERATOR_CD,
    -- s.SERVICE_TYPE_CD,
    -- s.FACTOR_TYPE_CD,

    s.SERVICE_GROUP_CD,
    svcdtl.SERVICE_GROUPING_PRIORITY_NBR,
    s.SERVICE_GROUP_CHANGED_IND,
    s.PROVIDER_BUSINESS_GROUP_NBR,
    Pbgnbr.PRODUCT_CD,
    trim(scm.supporting_pos_cd) as PLACE_OF_SERVICE_CD,
    '' as GEOGRAPHIC_AREA_CD,
    '' as EXTENSION_CD,
    '' as EXTENSION_TYPE,
    '' as SPECIALTY_CD,
    '' as SPECIALTY_TYPE_CD,
    s.PAYMENT_METHOD_CD,
    s.RATE,
    cast(s.CNT_EFFTV_DT as STRING) AS CNT_EFFTV_DT,
    cast(s.CNT_TERMN_DT as STRING) AS CNT_TERMN_DT,
    'N' as CONTRACT_TYPE,
    'B12_B3_C12_C3_COMBINED' as LOGIC_TYPE
FROM
    service_code_groups s

JOIN
   `{{ce_project}}.{{ce_dataset}}.{{cet_scsr_service_detail_view}}` svcdtl
    ON (svcdtl.SERVICE_CD BETWEEN s.LOW_SERVICE_CD AND s.HIGH_SERVICE_CD  and svcdtl.SERVICE_TYPE_CD = s.SERVICE_TYPE_CD )
    OR (svcdtl.SERVICE_CD BETWEEN s.LOW_VALUE_CD AND s.HIGH_VALUE_CD  and svcdtl.SERVICE_CD = s.FACTOR_TYPE_CD)


 JOIN {{ce_project}}.{{ce_dataset}}.{{ce_scm}} scm
    ON trim(scm.primary_svc_cd) = svcdtl.SERVICE_CD
    AND trim(scm.servc_type) = svcdtl.SERVICE_TYPE_CD

join
    (select distinct pbgnbr.PROVIDER_BUSINESS_GROUP_NBR ,pbgnbr.PRODUCT_CD
    from  {{ce_project}}.{{ce_dataset}}.{{cet_business_group_view}} pbgnbr) Pbgnbr
    on pbgnbr.PROVIDER_BUSINESS_GROUP_NBR = s.PROVIDER_BUSINESS_GROUP_NBR

WHERE
    (s.OPERATOR_CD = 'AND' AND (
        (s.LOW_SERVICE_CD IS NOT NULL AND s.HIGH_SERVICE_CD IS NOT NULL)
        OR (s.LOW_VALUE_CD IS NOT NULL AND s.HIGH_VALUE_CD IS NOT NULL)
    ))
    OR (s.OPERATOR_CD = 'INC' AND (
        (s.LOW_SERVICE_CD IS NOT NULL AND s.HIGH_SERVICE_CD IS NOT NULL AND s.LOW_VALUE_CD IS NULL AND s.HIGH_VALUE_CD IS NULL)
        OR (s.LOW_SERVICE_CD IS NOT NULL AND s.HIGH_SERVICE_CD IS NOT NULL AND s.LOW_VALUE_CD IS NOT NULL AND s.HIGH_VALUE_CD IS NOT NULL)
    ))
