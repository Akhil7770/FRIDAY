--33,910,970  records found
-- 3,312,131 records found after joining with {{ce_scm}}
INSERT INTO `{{ce_project}}.{{ce_dec_dataset}}.{{ce_rates_table}}` (
    
    RATE_SYSTEM_CD,
    SERVICE_CD,
    SERVICE_TYPE_CD,
    SERVICE_GROUP_CD,
    SERVICE_GROUPING_PRIORITY_NBR,
    SERVICE_GROUP_CHANGED_IND,
    PROVIDER_BUSINESS_GROUP_NBR,
    PRODUCT_CD,
    PLACE_OF_SERVICE_CD,
    GEOGRAPHIC_AREA_CD,
    EXTENSION_CD,
    EXTENSION_TYPE,
    SPECIALTY_CD,
    SPECIALTY_TYPE_CD,
    PAYMENT_METHOD_CD,
    RATE,
    CNT_EFFTV_DT,
    CNT_TERMN_DT,
    CONTRACT_TYPE,
    LOGIC_TYPE
)
SELECT DISTINCT
     
    rv.RATE_SYSTEM_CD,
    CASE
        WHEN LENGTH(TRIM(aff.MEMBER_SERVICE_CD)) = 3 AND aff.MEMBER_SERVICE_TYPE_CD IN ('REV', 'RC')
        THEN CONCAT('0', TRIM(aff.MEMBER_SERVICE_CD))
        ELSE aff.MEMBER_SERVICE_CD
    END AS SERVICE_CD,
    aff.MEMBER_SERVICE_TYPE_CD AS SERVICE_TYPE_CD,
    ld.SERVICE_GROUP_CD,
    svcdtl.SERVICE_GROUPING_PRIORITY_NBR,
    ld.SERVICE_GROUP_CHANGED_IND as SERVICE_GROUP_CHANGED_IND,
    qd.PROVIDER_BUSINESS_GROUP_NBR AS PROVIDER_BUSINESS_GROUP_NBR,
    pbgnbr.PRODUCT_CD,
    trim(scm.supporting_pos_cd) as PLACE_OF_SERVICE_CD,
    '' AS GEOGRAPHIC_AREA_CD,
    '' AS EXTENSION_CD,
    '' AS EXTENSION_TYPE,
    '' AS SPECIALTY_CD,
    '' AS SPECIALTY_TYPE_CD,
    ld.PAYMENT_METHOD_CD,
    CAST(ld.FLAT_RATE_AMT AS FLOAT64) * CAST(RELATIVE_VALUE_AMT AS FLOAT64) AS RATE,
    CAST(qd.CONTRACT_EFFECTIVE_DT AS STRING) AS CNT_EFFTV_DT,
    CAST(qd.CONTRACT_TERM_DT AS STRING) AS CNT_TERMN_DT,
    'C' AS CONTRACT_TYPE,
    'A1B_DRGWT' AS LOGIC_TYPE
FROM
    {{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_line_detail_view}} ld
JOIN {{ce_project}}.{{ce_dataset}}.{{cet_scsr_service_Affiliation_view}} aff
    ON ld.SERVICE_GROUP_CD = aff.OWNER_SERVICE_CD
    AND ld.SERVICE_GROUP_TYPE_CD = aff.OWNER_SERVICE_TYPE_CD
JOIN
    {{ce_project}}.{{ce_dataset}}.{{ce_scm}} scm
ON
    trim(scm.primary_svc_cd) = aff.MEMBER_SERVICE_CD
    AND trim(scm.servc_type) = aff.MEMBER_SERVICE_TYPE_CD
JOIN {{ce_project}}.{{ce_dataset}}.{{cet_scsr_relative_value_view}} rv
    ON rv.SERVICE_CD = aff.MEMBER_SERVICE_CD
    AND rv.SERVICE_TYPE_CD = aff.MEMBER_SERVICE_TYPE_CD
JOIN {{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_detail_view}} sd
    ON sd.STRUCTURED_STATEMENT_ID = ld.STRUCTURED_STATEMENT_ID
JOIN {{ce_project}}.{{ce_dataset}}.{{cet_scsr_service_detail_view}} svcdtl
    ON svcdtl.SERVICE_CD = trim(scm.primary_svc_cd)
    AND svcdtl.SERVICE_TYPE_CD = trim(scm.servc_type)
JOIN {{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_Qualifier_detail_view}} qd
    ON qd.QUALIFIER_ID = CAST(ld.QUALIFIER_ID AS INT)
JOIN {{ce_project}}.{{ce_dataset}}.{{cet_business_group_view}} pbgnbr
    ON pbgnbr.PROVIDER_BUSINESS_GROUP_NBR = qd.PROVIDER_BUSINESS_GROUP_NBR
WHERE
    ld.PAYMENT_METHOD_CD = 'DRGWT'
    AND ld.SERVICE_GROUP_CD <> ''
    AND ld.SERVICE_GROUP_CHANGED_IND = 'N'
    AND aff.MEMBER_SERVICE_TYPE_CD NOT IN ('AEG', 'SPU')
    AND aff.MEMBER_SERVICE_CD <> 'DEFAULT'
    AND scm.in_scope_ind = 1
    AND scm.trmn_dt > CURRENT_DATE();
