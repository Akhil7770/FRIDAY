update  {{ce_project}}.{{ce_dec_dataset}}.{{ce_rates_table}}
set uuid_key = generate_uuid()
where 1=1;

CREATE OR REPLACE TEMP TABLE BUCKETED AS (
  SELECT
    *,
    MOD(ABS(FARM_FINGERPRINT(UUID_KEY)),3) AS bucket
  FROM
    {{ce_project}}.{{ce_dec_dataset}}.{{ce_rates_table}} );
CREATE OR REPLACE TABLE
  {{ce_project}}.{{ce_dec_dataset}}.{{cet_rates1}} AS
SELECT
  *
FROM
  BUCKETED
WHERE
  bucket =0;
  CREATE OR REPLACE TABLE
  {{ce_project}}.{{ce_dec_dataset}}.{{cet_rates2}} AS
SELECT
  *
FROM
  BUCKETED
WHERE
  bucket =1;
    CREATE OR REPLACE TABLE
  {{ce_project}}.{{ce_dec_dataset}}.{{cet_rates3}} AS
SELECT
  *
FROM
  BUCKETED
WHERE
  bucket =2;
alter table {{ce_project}}.{{ce_dec_dataset}}.{{cet_rates1}} 
drop column bucket;
alter table {{ce_project}}.{{ce_dec_dataset}}.{{cet_rates2}} 
drop column bucket;
alter table {{ce_project}}.{{ce_dec_dataset}}.{{cet_rates3}} 
drop column bucket;
