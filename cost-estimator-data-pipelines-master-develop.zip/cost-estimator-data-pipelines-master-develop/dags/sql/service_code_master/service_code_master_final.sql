--FINAL Service Code Master
DROP TABLE IF EXISTS {{ce_project}}.{{ce_dec_dataset}}.{{ce_scm}};
CREATE TABLE {{ce_project}}.{{ce_dec_dataset}}.{{ce_scm}} AS
SELECT DISTINCT 
  TRIM(u.servc_cd) AS primary_svc_cd,
  TRIM(u.servc_type) AS servc_type,
  u.svc_name,
  u.svc_desc,
  f.`Consumer-Friendly Title` AS user_friendly_title,
  f.`Consumer-Friendly Description` AS user_friendly_desc,
  u.age_rnge_low AS min_age,
  u.age_rnge_hi AS max_age,
  u.efftv_dt,
  u.trmn_dt,
  'Medical' AS benefit_types,
  a.in_scope_ind,
  --nullif(SPLIT(combos, '-')[OFFSET(0)], 'x') as supporting_drg_cd,
  --nullif(SPLIT(combos, '-')[OFFSET(1)], 'x') as supporting_rev_cd,
  combos aS supporting_pos_cd,
  map.combined_specialties AS specialty_codes
FROM {{ce_project}}.{{ce_dataset}}.scsr_dtl_unique u 
LEFT JOIN {{ce_project}}.{{ce_dataset}}.{{scm_in_scope}} a
  ON 
    TRIM(u.servc_cd) = TRIM(a.primary_svc_cd) AND 
    TRIM(u.servc_type) = TRIM(a.servc_type)
LEFT JOIN {{ce_project}}.{{ce_dataset}}.default_combos c 
  ON 
    TRIM(u.servc_cd) = TRIM(c.primary_svc_cd) AND 
    TRIM(u.servc_type) = TRIM(c.servc_type)
LEFT JOIN {{ce_project}}.{{provider_ds_hcb_dev}}.{{specialty_mapping_final}} map 
  ON 
    TRIM(u.servc_cd) = TRIM(map.primary_svc_cd) AND 
    TRIM(u.servc_type) = TRIM(map.servc_type)
LEFT JOIN {{ce_project}}.{{ce_dataset}}.SCM_deduped_26082025 f
  ON 
    TRIM(u.servc_cd) = TRIM(f.primary_svc_cd) AND 
    TRIM(u.servc_type) = TRIM(f.servc_type)
WHERE 
  TRIM(u.servc_cd) != '' ;

