-- Service Code Master
DECLARE lookback int64 DEFAULT 36;

-- 1. Builds an initial SCSR table that is unique at the service code level
DROP TABLE IF EXISTS {{ce_project}}.{{ce_dataset}}.scsr_dtl_unique;
CREATE TABLE {{ce_project}}.{{ce_dataset}}.scsr_dtl_unique AS 
  WITH ranked_services AS (
    SELECT 
      servc_cd, 
      servc_type,
      abbrv_defn AS svc_name,
      servc_defn1 AS svc_desc,
      age_rnge_low,
      age_rnge_hi,
      gender_restriction,
      pre_admn_tstng,
      office_visit,
      folup_days,
      efftv_dt,
      trmn_dt,
      ROW_NUMBER() OVER (PARTITION BY servc_cd, servc_type ORDER BY efftv_dt DESC) AS rn
    FROM {{edp_project}}.{{edp_hcb_core_srcv}}.{{scsr_svc_cd_dtl}}
    WHERE 
      TRIM(servc_type) NOT IN ('SCFAECLM') -- we should add the other out of scope service types.
      AND err_ind != 'Y'
  )
  SELECT 
    servc_cd, 
    servc_type,
    svc_name,
    svc_desc,
    age_rnge_low,
    age_rnge_hi,
    efftv_dt,
    trmn_dt
  FROM ranked_services
  WHERE rn = 1
;

-- 2. Identify the claims considered In-Scope and Join to Supplemental Claim Information
DROP TABLE IF EXISTS {{ce_project}}.{{ce_dataset}}.service_code_mstr_claim_base;
CREATE TABLE {{ce_project}}.{{ce_dataset}}.service_code_mstr_claim_base AS 
WITH recent_claim_lines AS (
  SELECT 
    claim_line_id,
    prcdr_cd,
    revenue_cd,
    allowed_amt,
    summarized_srv_ind,
    duplicate_ind,
    clm_ln_status_cd,
    src_cust_subseg_cd,
    business_ln_cd,
    adjn_dt,
    dci_dt,
    hcfa_plc_srv_cd,
    file_id,
    PRODUCT_LN_CD,
    classification_cd,
    src_specialty_cd,
    srv_prvdr_id
  FROM {{edp_project}}.{{edp_core_dataset_view}}.{{claim_line}}
  WHERE 
    --allowed_amt > 0 AND -- only claims with allowed amounts greater than 0
    TRIM(summarized_srv_ind) = 'Y' AND -- final versions of claims only
    TRIM(duplicate_ind) = 'N' AND -- remove duplicates
    --TRIM(clm_ln_status_cd) != 'D' AND -- remove denied claims
    --TRIM(src_cust_subseg_cd) != 'AGB' AND -- remove Aetna international
    TRIM(business_ln_cd) = 'CP' AND -- commercial only
    TRIM(reporting_ctg_cd) IN ('US','AE','CB') AND -- Aetna + USHC claims only 
    --TRIM(product_ln_cd) NOT IN ('13','86') AND -- remove indemnity claims
    TRIM(prcdr_cd) != 'A' AND -- remove claims with internal procedure codes
    adjn_dt >= DATE_SUB(CURRENT_DATE(), INTERVAL lookback MONTH) AND -- claim was incurred and adjudicated within the past 3 years
    dci_dt >= DATE_SUB(CURRENT_DATE(), INTERVAL lookback MONTH)),

DRG_tmp AS (
  SELECT 
    *
  FROM `{{edp_project}}.{{edp_core_dataset_view}}.{{t_edw_clm_ln_x_drg_type}} `
  WHERE
    TRIM(drg_cd) NOT IN ('0','000','U','NA') -- removes defaults
    AND TRIM(drg_cd) IS NOT NULL -- remove nulls
    AND TRIM(drg_type_cd)!='D' -- remove denied DRGs
),

DRG_tmp2 AS (
  SELECT 
    *,
    ROW_NUMBER() OVER (PARTITION BY claim_line_id ORDER BY -- defines how to select a single DRG per claim line
      CASE 
          WHEN DRG_type_cd = 'P' THEN 1
          WHEN DRG_type_cd = 'A' THEN 2
          WHEN DRG_type_cd = 'B' THEN 3
          ELSE 4
      END) AS rn
  FROM DRG_tmp
),
  
DRG AS (
    SELECT
      *
    FROM DRG_tmp2
    WHERE 
      rn=1)
SELECT 
    recent_claim_lines.*,
    DRG.drg_cd
  FROM recent_claim_lines
  LEFT OUTER JOIN DRG 
  ON 
    recent_claim_lines.claim_line_id = DRG.claim_line_id;

-- 3a. When procedure code is available, map to service code master
DROP TABLE IF EXISTS {{ce_project}}.{{ce_dataset}}.service_code_mstr_claim_base_agg;
CREATE TABLE {{ce_project}}.{{ce_dataset}}.service_code_mstr_claim_base_agg AS WITH 
prcdr AS (
  SELECT 
    prcdr_cd AS primary_svc_cd,
    "prcdr_cd" AS claim_svc_cd_type,
    drg_cd AS supporting_drg,
    revenue_cd AS supporting_revenue_cd,
    hcfa_plc_srv_cd AS pos_cd,
    COUNT(*) as claim_cnt, 
    sum(allowed_amt) as allowed_amt
  FROM {{ce_project}}.{{ce_dataset}}.service_code_mstr_claim_base
  WHERE 
    TRIM(prcdr_cd) IS NOT NULL OR 
    TRIM(prcdr_cd)!='' OR 
    TRIM(prcdr_cd)!='A'
  GROUP BY 
    1,2,3,4,5),

drg AS (
  SELECT 
    drg_cd AS primary_svc_cd,
    "drg_cd" AS claim_svc_cd_type,
    "" AS supporting_drg,
    revenue_cd AS supporting_revenue_cd,
    hcfa_plc_srv_cd AS pos_cd,
    COUNT(*) as claim_cnt,
    sum(allowed_amt) as allowed_amt
  FROM {{ce_project}}.{{ce_dataset}}.service_code_mstr_claim_base
  WHERE 
    (TRIM(prcdr_cd) IS NULL OR 
    TRIM(prcdr_cd)='' OR 
    TRIM(prcdr_cd)='A') AND 
    (TRIM(drg_cd) IS NOT NULL OR TRIM(drg_cd)!='')
  GROUP BY 
    1,2,3,4,5),

rev AS (
  SELECT 
    revenue_cd AS primary_svc_cd,
    "revenue_cd" AS claim_svc_cd_type,
    drg_cd AS supporting_drg,
    "" AS supporting_revenue_cd,
    hcfa_plc_srv_cd AS pos_cd,
    COUNT(*) as claim_cnt,
    sum(allowed_amt) as allowed_amt
  FROM {{ce_project}}.{{ce_dataset}}.service_code_mstr_claim_base
  WHERE 
    (TRIM(prcdr_cd) IS NULL OR 
    TRIM(prcdr_cd)='' OR 
    TRIM(prcdr_cd)='A') AND 
    (TRIM(drg_cd) IS NULL OR TRIM(drg_cd)='') AND 
    (TRIM(revenue_cd) IS NOT NULL OR TRIM(revenue_cd)!='')
  GROUP BY 
    1,2,3,4,5)

SELECT * FROM prcdr
UNION ALL
SELECT * FROM drg
UNION ALL
SELECT * FROM rev;

--In Scope Code list saved in seperate table to avoid circular refrences in supporting code refreshes (combos, specialties)
DROP TABLE IF EXISTS {{ce_project}}.{{ce_dataset}}.{{scm_in_scope}};
CREATE TABLE {{ce_project}}.{{ce_dataset}}.{{scm_in_scope}} AS
SELECT 
  primary_svc_cd,
  claim_svc_cd_type,
  u.servc_type,
  --string_AGG(concat(coalesce(nullif(pos_cd, ''), 'x'),":", claim_cnt)) as pos_counts,
  CASE 
    WHEN TRIM(a.primary_svc_cd) IN ('D7270', 	'D7287', 	'D7440', 	'D7441', 	'D7465', 	'D7490', 	'D7511', 	'D7520', 	'D7521', 	'D7530', 	'D7540', 	'D7560', 	'D7610', 'D7620', 	'D7630', 	'D7640', 	'D7650', 	'D7660', 	'D7670', 	'D7671', 	'D7680', 	'D7710', 	'D7720', 	'D7730', 	'D7740', 	'D7750', 	'D7760', 	'D7770', 	'D7771', 	'D7780', 	'D7910', 	'D7980', 	'D7981', 	'D7982', 	'D7983', 	'D7990', 	'D7997') then 1 --Megan only medical CDT addition
    WHEN trim(u.servc_type) = 'CDT' THEN 0
    WHEN trim(a.primary_svc_cd) IS NOT NULL THEN 1
  ELSE 0 END AS in_scope_ind 
FROM {{ce_project}}.{{ce_dataset}}.service_code_mstr_claim_base_agg a 
LEFT JOIN {{ce_project}}.{{ce_dataset}}.scsr_dtl_unique u 
  ON TRIM(a.primary_svc_cd) = TRIM(u.servc_cd)
WHERE 
  primary_svc_cd != '' AND 
  TRIM(servc_type) IN ('CPT4', 'ASA', 'HCPC', 'DRG', 'CDT', 'REV') AND 
  CASE 
    WHEN claim_svc_cd_type = 'revenue_cd' THEN TRIM(servc_type) = 'REV' 
    WHEN claim_svc_cd_type = 'drg_cd' THEN TRIM(servc_type) = 'DRG' 
  ELSE claim_svc_cd_type = 'prcdr_cd' END
GROUP BY 
  primary_svc_cd, 
  claim_svc_cd_type, 
  u.servc_type;

