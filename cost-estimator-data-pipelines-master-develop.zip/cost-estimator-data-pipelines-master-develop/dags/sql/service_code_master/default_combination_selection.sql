--Table has all code combination for in scope codes
drop table if exists {{ce_project}}.{{ce_dataset}}.code_combos;
create table {{ce_project}}.{{ce_dataset}}.code_combos as
  WITH primary_svc_cd_tbl as (
    select 
      m.primary_svc_cd,
      m.servc_type, 
      coalesce(nullif(nullif(nullif(b.hcfa_plc_srv_cd,''),'U'),'N'),'x') as hcfa_plc_srv_cd,
      claim_line_id,
      allowed_amt,
      src_specialty_cd,
      srv_prvdr_id
    from {{ce_project}}.{{ce_dataset}}.service_code_mstr_claim_base b
    --The 2 clauses are needed since table is distinct at the service code + service type level
    --Only DRG and REV have cross over codes
      inner join {{ce_project}}.{{ce_dataset}}.{{scm_in_scope}} m 
        on case when trim(b.prcdr_cd) != '' then b.prcdr_cd
            when trim(b.prcdr_cd) = '' and b.drg_cd is not NULL then b.drg_cd
            when trim(b.prcdr_cd) = '' and b.drg_cd is NULL and trim(b.revenue_cd) != '' then b.revenue_cd end = trim(m.primary_svc_cd)
        and case when trim(b.prcdr_cd) != '' then 'prcdr_cd'
            when trim(b.prcdr_cd) = '' and b.drg_cd is not NULL then 'DRG'
            when trim(b.prcdr_cd) = '' and b.drg_cd is NULL and trim(b.revenue_cd) != '' then 'REV' end = case when trim(primary_svc_cd) in ('1001', '1002', '1006') --These codes are REV but come through with prcdr_cd 
                                                                                                          then 'prcdr_cd'
                                                                                                          when trim(m.servc_type) not in ('DRG', 'REV') 
                                                                                                          then 'prcdr_cd' else trim(m.servc_type) end
    where m.in_scope_ind = 1
  ),
  specialty_mapping_filter AS (
    SELECT 
      psc.*, 
      dm.specialty_cd, 
      map.combined_specialties
    FROM 
      primary_svc_cd_tbl psc
      LEFT OUTER JOIN {{edp_project}}.{{edp_core_dataset_view}}.{{provider_dm}} dm 
        ON psc.srv_prvdr_id = dm.provider_id
      JOIN {{ce_project}}.{{provider_ds_hcb_dev}}.{{specialty_mapping_final}} map 
        ON psc.primary_svc_cd = map.primary_svc_cd 
          AND TRIM(psc.servc_type) = TRIM(map.servc_type)
    WHERE 
      dm.specialty_cd IS NULL
      OR (
       CASE 
         WHEN TRIM(dm.specialty_cd) IS NULL 
             OR TRIM(dm.specialty_cd) = 'U' 
             OR TRIM(dm.specialty_cd) = '00000' 
             OR TRIM(dm.specialty_cd) = '' 
         THEN dm.provider_type_cd 
         ELSE dm.specialty_cd 
       END
      ) IN UNNEST(SPLIT(map.combined_specialties, ','))
    --) select distinct primary_svc_cd, servc_type from specialty_mapping_filter
    --) select distinct * from specialty_mapping_filter where primary_svc_cd = '21154'
  ),
  freq as (
    SELECT
      primary_svc_cd,
      servc_type,
      hcfa_plc_srv_cd as combos,
      COUNT(distinct claim_line_id) AS frequency, 
      sum(allowed_amt) as allowed_amt
    FROM
      --specialty_mapping_filter t
      primary_svc_cd_tbl t
    GROUP BY
      primary_svc_cd, servc_type, hcfa_plc_srv_cd
    order by frequency desc
  )
  select *, 
      rank() over(partition by primary_svc_cd, servc_type order by frequency desc) as freq_rank,
      sum(frequency) over(partition by primary_svc_cd, servc_type) as clm_sub_total,
      count(combos) over(partition by primary_svc_cd, servc_type) as combo_cnt, 
      sum(frequency) over(partition by primary_svc_cd, servc_type order by frequency desc) as cumulative_total,
      sum(allowed_amt) over(partition by primary_svc_cd, servc_type) as allowed_amt_total
    from freq
;

--Getting avg rate for prcdr_cd, service type
--After review, many of the POS rates in each service code are the same 
-- drop table if exists {{ce_project}}.{{ce_dataset}}.service_code_avg_rate;
-- Create table {{ce_project}}.{{ce_dataset}}.service_code_avg_rate AS 
--   select 
--     r.service_cd,
--     r.service_type_cd,
--     r.place_of_service_cd,
--     avg(cast(r.rate as FLOAT64)) as avg_rate
--   from {{ce_project}}.{{ce_dataset}}.cet_combined_rates r
--     inner join {{ce_project}}.{{ce_dataset}}.service_code_master m
--       on trim(r.service_cd) = trim(m.primary_svc_cd) and trim(r.service_type_cd) = trim(m.servc_type)
--   where m.in_scope_ind = 1
--   group by r.service_cd, r.service_type_cd, r.place_of_service_cd
--;

--Adding default POS for procedure codes with only NULL POS combinations
drop table if exists {{ce_project}}.{{ce_dataset}}.default_pos;
create table {{ce_project}}.{{ce_dataset}}.default_pos as 
  select servc_type, pos, freq_sum, rank() over (partition by servc_type order by freq_sum desc) as freq_rank
  from (
    select distinct servc_type, combos as pos, sum(frequency) as freq_sum
    from {{ce_project}}.{{ce_dataset}}.code_combos
    where combos != 'x'
    group by servc_type, combos
  ) sub
;

--Default POS Selection
drop table if exists {{ce_project}}.{{ce_dataset}}.default_combos;
create table {{ce_project}}.{{ce_dataset}}.default_combos as 
  --100% or more share from single code
  With 
  ER_Keep as (
    select distinct 
      c.primary_svc_cd,
      c.servc_type, 
      '23' as combos
    from {{ce_project}}.{{ce_dataset}}.code_combos c
    where c.primary_svc_cd in ('99281', '99282', '99283', '99284', '99285', '99053')
  ),
  ER_Remove as (
    select c.*, 
      COUNT(CASE WHEN c.combos = '23' THEN 1 WHEN c.combos = 'x' THEN 1 ELSE NULL END) OVER (PARTITION BY c.primary_svc_cd, c.servc_type) AS er_count
    from {{ce_project}}.{{ce_dataset}}.code_combos c
      left join ER_Keep k 
        on trim(c.primary_svc_cd) = trim(k.primary_svc_cd) and trim(c.servc_type) = trim(k.servc_type)
    where k.primary_svc_cd is NULL and k.servc_type is NULL --Taking out codes that are in KEEP
      and (c.combos = '23' or c.combos = 'x')  
  ),
  subset_0 as (
    select distinct 
      c.primary_svc_cd,
      c.servc_type, 
      combos
    from ( select primary_svc_cd, servc_type, combos as POS, clm_sub_total, sum(frequency) as NULL_clm_cnt 
            from {{ce_project}}.{{ce_dataset}}.code_combos 
            where combos = 'x'
            group by primary_svc_cd, servc_type, combos, clm_sub_total 
          ) c
      inner join {{ce_project}}.{{ce_dataset}}.default_pos dp 
        on trim(c.servc_type) = trim(dp.servc_type)
      inner join {{ce_project}}.{{ce_dataset}}.code_combos cc
        on trim(c.primary_svc_cd) = trim(cc.primary_svc_cd)
    where (NULL_clm_cnt/c.clm_sub_total) = 1 --Only pulling combo with 100
      and cc.freq_rank = 1 --Pulling most common combo
      and dp.freq_rank = 1 --Pulling top default POS for a service type
  ),
  --80% or more share from single code
  subset_1 as (
    select c.*
    from {{ce_project}}.{{ce_dataset}}.code_combos c
      LEFT JOIN subset_0 s --Removing subset 1
        ON TRIM(c.primary_svc_cd) = TRIM(s.primary_svc_cd) AND TRIM(c.servc_type) = TRIM(s.servc_type)
      LEFT JOIN ER_Remove er
        ON TRIM(c.primary_svc_cd) = TRIM(er.primary_svc_cd) AND TRIM(c.servc_type) = TRIM(er.servc_type) and trim(c.combos) = trim(er.combos) 
    where er.primary_svc_cd is NULL and er.servc_type is NULL
      and (c.frequency/c.clm_sub_total) >= 0.80
      and c.combos != 'x'
  ),
  --Only ER POS per service code (0 codes) 
  subset_2a as (
    select *
    from (
      select er.primary_svc_cd, er.servc_type, dp.pos as combos
        , ROW_NUMBER() OVER (PARTITION BY er.primary_svc_cd, er.servc_type order by er.combos) as min_combo
      from {{ce_project}}.{{ce_dataset}}.code_combos c 
        left join ER_Remove er 
          ON TRIM(c.primary_svc_cd) = TRIM(er.primary_svc_cd) AND TRIM(c.servc_type) = TRIM(er.servc_type) and trim(c.combos) = trim(er.combos) 
        LEFT JOIN subset_0 z 
          on TRIM(c.primary_svc_cd) = TRIM(z.primary_svc_cd) AND TRIM(c.servc_type) = TRIM(z.servc_type) and trim(c.combos) = trim(z.combos) 
        left join subset_1 s 
          on TRIM(c.primary_svc_cd) = TRIM(s.primary_svc_cd) AND TRIM(c.servc_type) = TRIM(s.servc_type) and trim(c.combos) = trim(s.combos) 
        inner join {{ce_project}}.{{ce_dataset}}.default_pos dp 
          on trim(c.servc_type) = trim(dp.servc_type) 
      where trim(er.primary_svc_cd) is not null 
        and er.er_count = er.combo_cnt
        and s.primary_svc_cd is NULL and s.servc_type is NULL
        and z.primary_svc_cd is NULL and z.servc_type is NULL
    ) sub
    where min_combo = 1
  ),
  --Only 1 combo left after removing ER POS (73 codes)
  subset_2b as (
    select *
    from (
      select distinct c.primary_svc_cd, c.servc_type, c.combos
        --row_number() over (partition by c.primary_svc_cd, c.servc_type) as t
      from {{ce_project}}.{{ce_dataset}}.code_combos c
        LEFT JOIN ER_Remove er  
          ON TRIM(c.primary_svc_cd) = TRIM(er.primary_svc_cd) AND TRIM(c.servc_type) = TRIM(er.servc_type) --and trim(c.combos) = trim(er.combos) 
        LEFT JOIN subset_0 z 
          on TRIM(c.primary_svc_cd) = TRIM(z.primary_svc_cd) AND TRIM(c.servc_type) = TRIM(z.servc_type) and trim(c.combos) = trim(z.combos) 
        left join subset_1 s 
          on TRIM(c.primary_svc_cd) = TRIM(s.primary_svc_cd) AND TRIM(c.servc_type) = TRIM(s.servc_type) and trim(c.combos) = trim(s.combos) 
      where (er.combo_cnt - er.er_count) = 1
        and s.primary_svc_cd is NULL and s.servc_type is NULL
        and z.primary_svc_cd is NULL and z.servc_type is NULL
    ) sub
    where combos != '23' and combos != 'x'
  ),
  --Code with the most volume, no ties, no ER (10,642 codes)
  subset_3 as (
    SELECT *
    FROM (
        SELECT 
            c.*, 
            MAX(c.frequency) OVER (PARTITION BY c.primary_svc_cd, c.servc_type) AS max_frequency,
            COUNT(*) OVER (PARTITION BY c.primary_svc_cd, c.servc_type, c.frequency) AS freq_count
        FROM {{ce_project}}.{{ce_dataset}}.code_combos c
        LEFT JOIN ER_Remove er  
            ON TRIM(c.primary_svc_cd) = TRIM(er.primary_svc_cd) AND TRIM(c.servc_type) = TRIM(er.servc_type) and trim(c.combos) = trim(er.combos)
        LEFT JOIN subset_0 z --Removing subset 1
            ON TRIM(c.primary_svc_cd) = TRIM(z.primary_svc_cd) AND TRIM(c.servc_type) = TRIM(z.servc_type)      
        LEFT JOIN subset_1 s --Removing subset 1
            ON TRIM(c.primary_svc_cd) = TRIM(s.primary_svc_cd) AND TRIM(c.servc_type) = TRIM(s.servc_type)
        LEFT JOIN subset_2a ss --Removing subset 2a
            ON TRIM(c.primary_svc_cd) = TRIM(ss.primary_svc_cd) AND TRIM(c.servc_type) = TRIM(ss.servc_type)
        LEFT JOIN subset_2b sss --Removing subset 2b
            ON TRIM(c.primary_svc_cd) = TRIM(sss.primary_svc_cd) AND TRIM(c.servc_type) = TRIM(sss.servc_type)
        WHERE er.combos is NULL 
            AND z.primary_svc_cd IS NULL AND z.servc_type IS NULL 
            AND s.primary_svc_cd IS NULL AND s.servc_type IS NULL
            AND ss.primary_svc_cd IS NULL AND ss.servc_type IS NULL
            AND sss.primary_svc_cd IS NULL AND sss.servc_type IS NULL
    ) subquery
    WHERE frequency = max_frequency AND freq_count = 1
  ),
  --Code with Max avg rate per POS
  subset_4 as (
    select *
    From
      (
      select c.*, r.avg_rate,
        --Added POS_min so that we can chose a combo when there are multiple top freq, and POS has same Rate
        ROW_NUMBER() OVER (PARTITION BY c.primary_svc_cd, c.servc_type, c.frequency, cast(avg_rate as STRING) order by c.combos) as POS_min,
        MAX(r.avg_rate) OVER (PARTITION BY c.primary_svc_cd, c.servc_type) AS max_rate,
        MAX(c.frequency) OVER (PARTITION BY c.primary_svc_cd, c.servc_type) AS max_frequency
      FROM {{ce_project}}.{{ce_dataset}}.code_combos c
        LEFT JOIN ER_Remove er  
          ON TRIM(c.primary_svc_cd) = TRIM(er.primary_svc_cd) AND TRIM(c.servc_type) = TRIM(er.servc_type) and trim(c.combos) = trim(er.combos)
        INNER JOIN {{ce_project}}.{{ce_dataset}}.service_code_avg_rate r 
          ON TRIM(c.primary_svc_cd) = TRIM(r.service_cd) AND TRIM(c.servc_type) = TRIM(r.service_type_cd) and TRIM(c.combos) = trim(r.place_of_service_cd) 
        LEFT JOIN subset_0 z --Removing subset 1
          ON TRIM(c.primary_svc_cd) = TRIM(z.primary_svc_cd) AND TRIM(c.servc_type) = TRIM(z.servc_type)
        LEFT JOIN subset_1 s --Removing subset 1
          ON TRIM(c.primary_svc_cd) = TRIM(s.primary_svc_cd) AND TRIM(c.servc_type) = TRIM(s.servc_type)
        LEFT JOIN subset_2a ss --Removing subset 2a
          ON TRIM(c.primary_svc_cd) = TRIM(ss.primary_svc_cd) AND TRIM(c.servc_type) = TRIM(ss.servc_type)
        LEFT JOIN subset_2b sss --Removing subset 2b
          ON TRIM(c.primary_svc_cd) = TRIM(sss.primary_svc_cd) AND TRIM(c.servc_type) = TRIM(sss.servc_type)
        LEFT JOIN subset_3 ssss --Removing subset 3
          ON TRIM(c.primary_svc_cd) = TRIM(ssss.primary_svc_cd) AND TRIM(c.servc_type) = TRIM(ssss.servc_type)
        WHERE er.combos is NULL 
          AND z.primary_svc_cd IS NULL AND z.servc_type IS NULL
          AND s.primary_svc_cd IS NULL AND s.servc_type IS NULL
          AND ss.primary_svc_cd IS NULL AND ss.servc_type IS NULL
          AND sss.primary_svc_cd IS NULL AND sss.servc_type IS NULL
          AND ssss.primary_svc_cd IS NULL AND ssss.servc_type IS NULL
          and c.combos != 'x'
      )sub
    where sub.frequency = sub.max_frequency and avg_rate = max_rate and POS_min = 1
  ),
  --Codes with no matching rates
  subset_5 as (
    select c.*
      FROM (
          select *, ROW_NUMBER() OVER (PARTITION BY primary_svc_cd, servc_type order by combos) as min_combo
            from {{ce_project}}.{{ce_dataset}}.code_combos
              --where combos != '23' and combos != 'x'
              ) c
        LEFT JOIN ER_Remove er  
            ON TRIM(c.primary_svc_cd) = TRIM(er.primary_svc_cd) AND TRIM(c.servc_type) = TRIM(er.servc_type) and trim(c.combos) = trim(er.combos)
        LEFT JOIN subset_0 z --Removing subset 1
          ON TRIM(c.primary_svc_cd) = TRIM(z.primary_svc_cd) AND TRIM(c.servc_type) = TRIM(z.servc_type)
        LEFT JOIN subset_1 s --Removing subset 1
          ON TRIM(c.primary_svc_cd) = TRIM(s.primary_svc_cd) AND TRIM(c.servc_type) = TRIM(s.servc_type)
        LEFT JOIN subset_2a ss --Removing subset 2a
          ON TRIM(c.primary_svc_cd) = TRIM(ss.primary_svc_cd) AND TRIM(c.servc_type) = TRIM(ss.servc_type)
        LEFT JOIN subset_2b sss --Removing subset 2b
          ON TRIM(c.primary_svc_cd) = TRIM(sss.primary_svc_cd) AND TRIM(c.servc_type) = TRIM(sss.servc_type)
        LEFT JOIN subset_3 ssss --Removing subset 3
          ON TRIM(c.primary_svc_cd) = TRIM(ssss.primary_svc_cd) AND TRIM(c.servc_type) = TRIM(ssss.servc_type)
        LEFT JOIN subset_4 sssss --Removing subset 4
          ON TRIM(c.primary_svc_cd) = TRIM(sssss.primary_svc_cd) AND TRIM(c.servc_type) = TRIM(sssss.servc_type)
        WHERE er.combos is NULL 
          AND z.primary_svc_cd IS NULL AND z.servc_type IS NULL
          AND s.primary_svc_cd IS NULL AND s.servc_type IS NULL
          AND ss.primary_svc_cd IS NULL AND ss.servc_type IS NULL
          AND sss.primary_svc_cd IS NULL AND sss.servc_type IS NULL
          AND ssss.primary_svc_cd IS NULL AND ssss.servc_type IS NULL
          AND sssss.primary_svc_cd IS NULL AND sssss.servc_type IS NULL
          and c.combos != 'x'
          and c.min_combo = 1
  )
  -- Union of all subsets
  SELECT primary_svc_cd, servc_type, combos, 'subset_0' as source_subset
    FROM subset_0 
    UNION ALL
    SELECT primary_svc_cd, servc_type, combos, 'subset_1' as source_subset
    FROM subset_1
    UNION ALL
    SELECT primary_svc_cd, servc_type, combos, 'subset_2a' as source_subset
    FROM subset_2a
    UNION ALL
    SELECT primary_svc_cd, servc_type, combos, 'subset_2b' as source_subset
    FROM subset_2b
    UNION ALL
    SELECT primary_svc_cd, servc_type, combos, 'subset_3' as source_subset
    FROM subset_3
    UNION ALL
    SELECT primary_svc_cd, servc_type, combos, 'subset_4' as source_subset
    FROM subset_4
    UNION ALL
    SELECT primary_svc_cd, servc_type, combos, 'subset_5' as source_subset
    FROM subset_5
    ORDER BY primary_svc_cd, servc_type
;

-- select distinct *
-- from `{{ce_project}}.{{ce_dataset}}.default_combos`
-- where combos = '23'

--Missing CODES from Specialty Mapping
--     with test as (
--       SELECT 
--         recent_claim_lines.*,
--       FROM `{{ce_project}}.{{ce_dataset}}.default_combos` recent_claim_lines 
--       inner join (select * from {{ce_project}}.{{ce_dataset}}.service_code_master where in_scope_ind = 1) scm 
--         on TRIM(recent_claim_lines.primary_svc_cd) = scm.primary_svc_cd
--     )
--     select distinct scm.*
--     from (select * from {{ce_project}}.{{ce_dataset}}.service_code_master where in_scope_ind = 1) scm
--       left join test t
--         on scm.primary_svc_cd = t.primary_svc_cd
--     where t.primary_svc_cd is null
-- ;

--MANUAL INPUT FOR ONE TIME FIX
-- INSERT INTO `{{ce_project}}.{{ce_dataset}}.default_combos` (
--     primary_svc_cd,
--     servc_type,
--     combos,
--     source_subset
-- )
-- VALUES
--     ('G9083', 'HCPC', 'x-x-20', 'Manual'),
--     ('88028', 'CPT4', 'x-x-21', 'Manual');


