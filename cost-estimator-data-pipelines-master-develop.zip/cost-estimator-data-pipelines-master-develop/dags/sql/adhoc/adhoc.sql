DROP VIEW IF EXISTS `anbc-hcb-dev.prv_ps_ce_dec_hcb_dev.CET_RATES_VIEW`;
DROP VIEW IF EXISTS `anbc-hcb-dev.prv_ps_ce_dec_hcb_dev.CET_PROVIDERS_VIEW`;
