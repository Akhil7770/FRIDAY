drop table if exists CET_RATES_RETL1;
CREATE TABLE CET_RATES_RETL1 (
                    UUID_KEY                      STRING(100),
                    RATE_SYSTEM_CD                STRING(100),
                    SERVICE_CD                    STRING(100),
                    SERVICE_TYPE_CD               STRING(100),
                    SERVICE_GROUP_CD              STRING(100),
                    SERVICE_GROUPING_PRIORITY_NBR STRING(100),
                    PROVIDER_BUSINESS_GROUP_NBR   INT64,
                    PRODUCT_CD                    STRING(100),
                    PLACE_OF_SERVICE_CD           STRING(100),
                    GEOGRAPHIC_AREA_CD            STRING(100),
                    EXTENSION_CD                  STRING(100),
                    EXTENSION_TYPE                STRING(100),
                    SPECIALTY_CD                  STRING(100),
                    SPECIALTY_TYPE_CD             STRING(100),
                    PAYMENT_METHOD_CD             STRING(100),
                    RATE                          FLOAT64,
                    CNT_EFFTV_DT                  STRING(100),
                    CNT_TERMN_DT                  STRING(100),
                    CONTRACT_TYPE                 STRING(100),
                    LOGIC_TYPE                    STRING(100)
                ) PRIMARY KEY (UUID_KEY);


drop table if exists CET_RATES_RETL2;
CREATE TABLE CET_RATES_RETL2 (
                    UUID_KEY                      STRING(100),
                    RATE_SYSTEM_CD                STRING(100),
                    SERVICE_CD                    STRING(100),
                    SERVICE_TYPE_CD               STRING(100),
                    SERVICE_GROUP_CD              STRING(100),
                    SERVICE_GROUPING_PRIORITY_NBR STRING(100),
                    PROVIDER_BUSINESS_GROUP_NBR   INT64,
                    PRODUCT_CD                    STRING(100),
                    PLACE_OF_SERVICE_CD           STRING(100),
                    GEOGRAPHIC_AREA_CD            STRING(100),
                    EXTENSION_CD                  STRING(100),
                    EXTENSION_TYPE                STRING(100),
                    SPECIALTY_CD                  STRING(100),
                    SPECIALTY_TYPE_CD             STRING(100),
                    PAYMENT_METHOD_CD             STRING(100),
                    RATE                          FLOAT64,
                    CNT_EFFTV_DT                  STRING(100),
                    CNT_TERMN_DT                  STRING(100),
                    CONTRACT_TYPE                 STRING(100),
                    LOGIC_TYPE                    STRING(100)
                ) PRIMARY KEY (UUID_KEY);

drop table if exists CET_RATES_RETL3;
CREATE TABLE CET_RATES_RETL3 (
                    UUID_KEY                      STRING(100),
                    RATE_SYSTEM_CD                STRING(100),
                    SERVICE_CD                    STRING(100),
                    SERVICE_TYPE_CD               STRING(100),
                    SERVICE_GROUP_CD              STRING(100),
                    SERVICE_GROUPING_PRIORITY_NBR STRING(100),
                    PROVIDER_BUSINESS_GROUP_NBR   INT64,
                    PRODUCT_CD                    STRING(100),
                    PLACE_OF_SERVICE_CD           STRING(100),
                    GEOGRAPHIC_AREA_CD            STRING(100),
                    EXTENSION_CD                  STRING(100),
                    EXTENSION_TYPE                STRING(100),
                    SPECIALTY_CD                  STRING(100),
                    SPECIALTY_TYPE_CD             STRING(100),
                    PAYMENT_METHOD_CD             STRING(100),
                    RATE                          FLOAT64,
                    CNT_EFFTV_DT                  STRING(100),
                    CNT_TERMN_DT                  STRING(100),
                    CONTRACT_TYPE                 STRING(100),
                    LOGIC_TYPE                    STRING(100)
                ) PRIMARY KEY (UUID_KEY);


DROP TABLE cet_rates_all;

CREATE TABLE cet_rates_all (
                    UUID_KEY                      STRING(100),
                    RATE_SYSTEM_CD                STRING(100),
                    SERVICE_CD                    STRING(100),
                    SERVICE_TYPE_CD               STRING(100),
                    SERVICE_GROUP_CD              STRING(100),
                    SERVICE_GROUPING_PRIORITY_NBR STRING(100),
                    PROVIDER_BUSINESS_GROUP_NBR   INT64,
                    PRODUCT_CD                    STRING(100),
                    PLACE_OF_SERVICE_CD           STRING(100),
                    GEOGRAPHIC_AREA_CD            STRING(100),
                    EXTENSION_CD                  STRING(100),
                    EXTENSION_TYPE                STRING(100),
                    SPECIALTY_CD                  STRING(100),
                    SPECIALTY_TYPE_CD             STRING(100),
                    PAYMENT_METHOD_CD             STRING(100),
                    RATE                          FLOAT64,
                    CNT_EFFTV_DT                  STRING(100),
                    CNT_TERMN_DT                  STRING(100),
                    CONTRACT_TYPE                 STRING(100),
                    LOGIC_TYPE                    STRING(100)
                ) PRIMARY KEY (UUID_KEY);
                
insert into cet_rates_all(UUID_KEY,RATE_SYSTEM_CD,SERVICE_CD,SERVICE_TYPE_CD,
SERVICE_GROUP_CD,
SERVICE_GROUPING_PRIORITY_NBR, PROVIDER_BUSINESS_GROUP_NBR,  
PRODUCT_CD,PLACE_OF_SERVICE_CD,GEOGRAPHIC_AREA_CD,EXTENSION_CD,
EXTENSION_TYPE,SPECIALTY_CD,SPECIALTY_TYPE_CD,PAYMENT_METHOD_CD,RATE,CNT_EFFTV_DT,  
CNT_TERMN_DT,CONTRACT_TYPE,LOGIC_TYPE )
select * from CET_RATES_RETL1;

insert into cet_rates_all(UUID_KEY,RATE_SYSTEM_CD,SERVICE_CD,SERVICE_TYPE_CD,
SERVICE_GROUP_CD,
SERVICE_GROUPING_PRIORITY_NBR, PROVIDER_BUSINESS_GROUP_NBR,  
PRODUCT_CD,PLACE_OF_SERVICE_CD,GEOGRAPHIC_AREA_CD,EXTENSION_CD,
EXTENSION_TYPE,SPECIALTY_CD,SPECIALTY_TYPE_CD,PAYMENT_METHOD_CD,RATE,CNT_EFFTV_DT,  
CNT_TERMN_DT,CONTRACT_TYPE,LOGIC_TYPE )
select * from CET_RATES_RETL2;

insert into cet_rates_all(UUID_KEY,RATE_SYSTEM_CD,SERVICE_CD,SERVICE_TYPE_CD,
SERVICE_GROUP_CD,
SERVICE_GROUPING_PRIORITY_NBR, PROVIDER_BUSINESS_GROUP_NBR,  
PRODUCT_CD,PLACE_OF_SERVICE_CD,GEOGRAPHIC_AREA_CD,EXTENSION_CD,
EXTENSION_TYPE,SPECIALTY_CD,SPECIALTY_TYPE_CD,PAYMENT_METHOD_CD,RATE,CNT_EFFTV_DT,  
CNT_TERMN_DT,CONTRACT_TYPE,LOGIC_TYPE )
select * from CET_RATES_RETL3;

CREATE INDEX IF NOT EXISTS standard_index ON cet_rates_all (SERVICE_CD,SERVICE_TYPE_CD,GEOGRAPHIC_AREA_CD,PLACE_OF_SERVICE_CD,PRODUCT_CD, PROVIDER_BUSINESS_GROUP_NBR);
CREATE INDEX IF NOT EXISTS non_standard_index ON cet_rates_all (SERVICE_CD,SERVICE_TYPE_CD,RATE_SYSTEM_CD,PRODUCT_CD,GEOGRAPHIC_AREA_CD,PLACE_OF_SERVICE_CD,CONTRACT_TYPE,PROVIDER_BUSINESS_GROUP_NBR);
        
CREATE OR REPLACE TEMP TABLE BUCKETED AS (
  SELECT
    *,
    MOD(ABS(FARM_FINGERPRINT(UUID_KEY)),3) AS bucket
  FROM
    anbc-hcb-dev.prv_ps_ce_dec_hcb_dev.CET_RATES );
CREATE OR REPLACE TABLE
  anbc-hcb-dev.prv_ps_ce_dec_hcb_dev.CET_RATES1 AS
SELECT
  *
FROM
  anbc-dev-prv-ps-ce._1968f02ca461e012a51a306360fafd5fbb68c02b._5c8946cd_a0c0_420e_a50c_3c04c3610b07_BUCKETED
WHERE
  bucket =0;
  CREATE OR REPLACE TABLE
  anbc-hcb-dev.prv_ps_ce_dec_hcb_dev.CET_RATES2 AS
SELECT
  *
FROM
  anbc-dev-prv-ps-ce._1968f02ca461e012a51a306360fafd5fbb68c02b._5c8946cd_a0c0_420e_a50c_3c04c3610b07_BUCKETED
WHERE
  bucket =1;
    CREATE OR REPLACE TABLE
  anbc-hcb-dev.prv_ps_ce_dec_hcb_dev.CET_RATES3 AS
SELECT
  *
FROM
  anbc-dev-prv-ps-ce._1968f02ca461e012a51a306360fafd5fbb68c02b._5c8946cd_a0c0_420e_a50c_3c04c3610b07_BUCKETED
WHERE
  bucket =2;

