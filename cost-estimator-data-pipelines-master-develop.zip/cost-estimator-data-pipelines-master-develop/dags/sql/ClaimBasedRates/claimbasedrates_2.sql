create or replace table {{ce_project}}.{{ce_dec_dataset}}.{{ce_clmamounts}}
as (
select clmsrates.*,pos.MEMBER_PLACE_OF_SERVICE_CD as PLACE_OF_SERVICE_CD, 
    '' AS UPDATE_DTS,
    CURRENT_TIMESTAMP() AS INSERT_DTS,   
    'SYSTEM' AS INSERT_USER 
from {{ce_project}}.{{ce_dec_dataset}}.{{ce_clmrates_table}} clmsrates
JOIN {{ce_project}}.{{ce_dataset}}.{{cet_scsr_place_of_service_affiliation_view}} pos
    ON pos.OWNER_PLACE_OF_SERVICE_CD = clmsrates.PLACE_OF_SERVICE_KEY_CD
join {{ce_project}}.{{ce_dataset}}.{{ce_scm}} scm
on trim(scm.primary_svc_cd) = trim(clmsrates.SERVICE_CD) 
and scm.supporting_pos_cd = pos.MEMBER_PLACE_OF_SERVICE_CD
join {{ce_project}}.{{ce_dataset}}.{{cet_address_detail_view}} AS t1
on SUBSTR(clmsrates.PROVIDER_IDENTIFICATION_NBR,4,7)= cast(t1.PROVIDER_IDENTIFICATION_NBR as string)
and substr(clmsrates.TAX_IDENTIFICATION_NBR,2,9)=t1.TAX_IDENTIFICATION_NBR
and clmsrates.NETWORK_ID = t1.NETWORK_ID
)