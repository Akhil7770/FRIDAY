--B12 and C12  can be combined
--B12 SERVICE_GROUP_CD field is populated and the service grouping changed indicator is equal to ‘Y’   and sd.LOW_SERVICE_CD <> ''  and sd.HIGH_SERVICE_CD <> ''
--C12 SERVICE_GROUP_CD =''  and sd.LOW_SERVICE_CD <> ''  and sd.HIGH_SERVICE_CD <> ''
 --47,212
INSERT INTO `{{ce_project}}.{{ce_dec_dataset}}.{{ce_rates_table}}` (
    
    RATE_SYSTEM_CD,
    SERVICE_CD,
    SERVICE_TYPE_CD,
    SERVICE_GROUP_CD,
    SERVICE_GROUPING_PRIORITY_NBR,
    PROVIDER_BUSINESS_GROUP_NBR,
    PRODUCT_CD,
    PLACE_OF_SERVICE_CD,
    GEOGRAPHIC_AREA_CD,
    EXTENSION_CD,
    EXTENSION_TYPE,
    SPECIALTY_CD,
    SPECIALTY_TYPE_CD,
    PAYMENT_METHOD_CD,
    RATE,
    CNT_EFFTV_DT,
    CNT_TERMN_DT,
    UPDATE_DTS,
    INSERT_DTS,
    INSERT_USER
)
  select distinct
  
  '' as RATE_SYSTEM_CD,
    case when (length(trim(svcdtl.SERVICE_CD))=3 and svcdtl.SERVICE_TYPE_CD in ('REV','RC'))
    then concat('0',trim(svcdtl.SERVICE_TYPE_CD)) else svcdtl.SERVICE_CD end as SERVICE_CD,
    svcdtl.SERVICE_TYPE_CD as SERVICE_TYPE_CD,
    ld.SERVICE_GROUP_CD as SERVICE_GROUP_CD,
    svcdtl.SERVICE_GROUPING_PRIORITY_NBR as SERVICE_GROUPING_PRIORITY_NBR,
    qd.PROVIDER_BUSINESS_GROUP_NBR as PROVIDER_BUSINESS_GROUP_NBR,
    pbgnbr.PRODUCT_CD as PRODUCT_CD,
    trim(scm.supporting_pos_cd) as PLACE_OF_SERVICE_CD,
    --POS.MEMBER_PLACE_OF_SERVICE_CD as PLACE_OF_SERVICE_CD,
    '' as GEOGRAPHIC_AREA_CD,
    '' as EXTENSION_CD,
    '' as EXTENSION_TYPE,
    '' as SPECIALTY_CD,
    '' as SPECIALTY_TYPE_CD,
    ld.PAYMENT_METHOD_CD as PAYMENT_METHOD_CD,
    case when ld.PAYMENT_METHOD_CD='FLAT' then cast(ld.FLAT_RATE_AMT as FLOAT64) 
    end RATE,
      CAST(qd.CONTRACT_EFFECTIVE_DT AS STRING) AS CNT_EFFTV_DT,
    CAST(qd.CONTRACT_TERM_DT AS STRING) AS CNT_TERMN_DT,
    '' AS UPDATE_DTS,
    CURRENT_TIMESTAMP() AS INSERT_DTS,
    'SYSTEM' AS INSERT_USER
from
  `{{ce_project}}.{{ce_dec_dataset}}.{{cet_scm_fee_service_line_detail_hsq_view}}` ld
    Join `{{ce_project}}.{{ce_dec_dataset}}.{{cet_scm_fee_service_detail_hsq_view}}` sd
   on SD.STRUCTURED_STATEMENT_ID = ld.STRUCTURED_STATEMENT_ID

  join `{{ce_project}}.{{ce_dataset}}.{{cet_scsr_service_detail_view}}` svcdtl
   on svcdtl.SERVICE_CD between sd.LOW_SERVICE_CD and sd.HIGH_SERVICE_CD
   and svcdtl.SERVICE_TYPE_CD = sd.SERVICE_TYPE_CD

  join `{{ce_project}}.{{ce_dec_dataset}}.{{cet_scm_fee_service_Qualifier_detail_hsq_view}}` qd
    on qd.QUALIFIER_ID = ld.QUALIFIER_ID

   join {{ce_project}}.{{ce_dataset}}.{{ce_scm}} scm
    ON trim(scm.primary_svc_cd) = svcdtl.SERVICE_CD
    AND trim(scm.servc_type) = svcdtl.SERVICE_TYPE_CD

	join
    (select distinct pbgnbr.PROVIDER_BUSINESS_GROUP_NBR ,pbgnbr.PRODUCT_CD
    from  {{ce_project}}.{{ce_dataset}}.{{cet_business_group_view}} pbgnbr) Pbgnbr
    on pbgnbr.PROVIDER_BUSINESS_GROUP_NBR = qd.PROVIDER_BUSINESS_GROUP_NBR

  where
  ld.PAYMENT_METHOD_CD in ('FLAT' )
  and ld.SERVICE_GROUP_CD =''
  and sd.LOW_SERVICE_CD <> ''
  and sd.HIGH_SERVICE_CD <> ''
  and svcdtl.SERVICE_TYPE_CD <> ''
  and sd.OPERATOR_CD NOT IN ('AND','INC')
    AND scm.in_scope_ind = 1
  AND scm.trmn_dt > CURRENT_DATE();
