-- CREATE OR REPLACE TABLE {{ce_project}}.{{ce_dataset}}.{{cet_prvflag}} AS
--     WITH prv_flag AS (
--         -- Step 1: Select distinct provider IDs and tax IDs, and determine the cet_smartcompare_flag
--             SELECT DISTINCT 
--                 prvdr_id_no, -- Provider ID
--                -- rmbrcp_taxid_no, -- Tax ID
--                 CASE 
--                     WHEN TRIM(flag_cd) IN (
--                        'ASCALRG','ASCBH','ASCCARD','ASCCTS','ASCDRMT','ASCER','ASCENDO','ASCGAST','ASCGENS',
--                        'ASCINFC','ASCONCL','ASCNEPH','ASCNRLY','ASCNRSG','ASCOBGN','ASCOPTH','ASCORTH',
--                        'ASCOTOL','ASCPHYS','ASCPLST','ASCPODI','ASCPCP','ASCPLMO','ASCRHEU','ASCUROL','ASCVASC'
--                     ) THEN 'Y' -- If the flag code matches one of the specified values, set cet_smartcompare_flag to 'Y'
--                     ELSE 'N' -- Otherwise, set cet_smartcompare_flag to 'N'
--                 END AS cet_smartcompare_flag
--             FROM {{edp_project}}.{{edp_hcb_core_srcv}}.{{epdb_prvflag}} -- Source table containing provider flag data
--             WHERE prvflag_exprtn_dt = '9999-12-31' and prvflag_spsd_dt = '0001-01-01'
--         ),

--         filtered_prv_flag AS (
--             -- Step 2: Use ROW_NUMBER() to prioritize records with cet_smartcompare_flag = 'Y'
--             SELECT DISTINCT
--                 prvdr_id_no,
--                 --rmbrcp_taxid_no,
--                 cet_smartcompare_flag,
--                 ROW_NUMBER() OVER (
--                     PARTITION BY prvdr_id_no 
--                     ORDER BY CASE WHEN cet_smartcompare_flag = 'Y' THEN 1 ELSE 2 END
--                 ) AS row_num -- Assign row numbers, prioritizing 'Y' over 'N'
--             FROM prv_flag
--     )

--     -- Step 3: Create or replace the CET_PRVFLAG table in the target dataset
--     SELECT 
--         GENERATE_UUID() AS STG_CET_PRVFLAG_RECORD_ID, -- Generate a unique ID for each record
--         prvdr_id_no AS PROVIDER_IDENTIFICATION_NBR, -- Provider ID
--        -- rmbrcp_taxid_no AS TAX_IDENTIFICATION_NBR, -- Tax ID
--         cet_smartcompare_flag AS SC_FLAG, -- SmartCompare flag determined in the previous step
--         '' AS UPDATE_DTS, -- Placeholder for update timestamp (empty for now)
--         CURRENT_TIMESTAMP() AS INSERT_DTS, -- Timestamp for when the record is inserted
--         'SYSTEM' AS INSERT_USER -- User/system responsible for the insert
--     FROM filtered_prv_flag
--     WHERE row_num = 1 and cet_smartcompare_flag = 'Y'; -- Only include the highest-priority record (Y > N);



CREATE OR REPLACE TABLE {{ce_project}}.{{ce_dec_dataset}}.{{cet_prvflag}} AS
    WITH prv_flag AS (
        -- Step 1: Select distinct provider IDs and tax IDs, and determine the cet_smartcompare_flag
            SELECT DISTINCT 
                prvdr_id_no, -- Provider ID
                TRIM(flag_cd) AS flag_cd, -- Trim whitespace from flag code
                CASE 
                    WHEN TRIM(flag_cd) IN (
                       'ASCALRG','ASCBH','ASCCARD','ASCCTS','ASCDRMT','ASCER','ASCENDO','ASCGAST','ASCGENS',
                       'ASCINFC','ASCONCL','ASCNEPH','ASCNRLY','ASCNRSG','ASCOBGN','ASCOPTH','ASCORTH',
                       'ASCOTOL','ASCPHYS','ASCPLST','ASCPODI','ASCPCP','ASCPLMO','ASCRHEU','ASCUROL','ASCVASC'
                    ) THEN 'Yes' 
                    WHEN TRIM(flag_cd) LIKE '%XSTEER%' THEN 'Yes' -- If the flag code matches one of the specified values, set cet_smartcompare_flag to 'Y'
                    ELSE 'No' -- Otherwise, set cet_smartcompare_flag to 'N'
                END AS cet_smartcompare_flag
            FROM {{edp_project}}.{{edp_hcb_core_srcv}}.{{epdb_prvflag}} -- Source table containing provider flag data
            WHERE prvflag_exprtn_dt = '9999-12-31' and prvflag_spsd_dt = '0001-01-01'
        )

    -- Step 2: Create or replace the CET_PRVFLAG table in the target dataset
    SELECT 
        GENERATE_UUID() AS STG_CET_PRVFLAG_RECORD_ID, -- Generate a unique ID for each record
        CAST(prvdr_id_no AS STRING) AS PROVIDER_IDENTIFICATION_NBR, -- Provider ID
        flag_cd AS FLAG_CD, -- Flag code (trimmed)
        cet_smartcompare_flag AS PRV_FLAG, -- SmartCompare flag determined in the previous step
        '' AS UPDATE_DTS, -- Placeholder for update timestamp (empty for now)
        CURRENT_TIMESTAMP() AS INSERT_DTS, -- Timestamp for when the record is inserted
        'SYSTEM' AS INSERT_USER -- User/system responsible for the insert
    FROM prv_flag WHERE cet_smartcompare_flag = 'Yes'; 