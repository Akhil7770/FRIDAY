CREATE TABLE IF NOT EXISTS `anbc-hcb-dev.prv_ps_ce_hcb_dev.PAYMENT_METHOD_HIERARCHY` (
    PAYMENT_METHOD_CD STRING,
    SCORE INTEGER
);


INSERT INTO `anbc-hcb-dev.prv_ps_ce_hcb_dev.PAYMENT_METHOD_HIERARCHY` (PAYMENT_METHOD_CD, SCORE)
VALUES
    ('BURG', 999), -- Burgess methods
    ('MDALLW', 998), -- md* payment methods
    ('DRGWT', 800),
    ('DRG-OTHER', 700), -- not used
    ('APCWT', 600), -- APCWT/ASCWT
    ('ASCWT', 601), -- APCWT/ASCWT
    ('WHOLEBILL', 500), -- When the method is applied to whole claim
    ('CASEWT', 400), -- old, not used
    ('CASE', 300),
    ('OPPDMC', 202),
    ('OPPD', 201), -- OPTHYA/OPTHYI
    ('PDIEM', 200),
    ('PBLXDL-OPPDML-WB', 199), -- Per day methods with whole bills
    ('PERLINE', 1),
    ('NO-SUPPORTED-PM-ON-CLAIM', 0); -- 003 is not valid for SCORE