
CREATE OR REPLACE TABLE {{ce_project}}.{{ce_dataset}}.{{ce_provider_table}}  options (  labels=[("owner", "amanullam_aetna_com"),("costcenter","13345")]   )  as  (
  SELECT DISTINCT
  cast(NULLIF(cast(t1.PROVIDER_IDENTIFICATION_NBR as string),'')as int64) as PROVIDER_IDENTIFICATION_NBR,
  NULLIF(t1.NATIONAL_PROVIDER_ID,'') as NATIONAL_PROVIDER_ID,
  NULLIF(t1.TAX_IDENTIFICATION_NBR,'') as TAX_IDENTIFICATION_NBR,
  NULLIF(t1.TAX_IDENTIFICATION_FORMAT_CD,'') as TAX_IDENTIFICATION_FORMAT_CD,
  NULLIF(t1.NETWORK_ID,'') as NETWORK_ID,
  NULLIF(t1.NETWORK_TYPE_CD,'') as NETWORK_TYPE_CD,
  NULLIF(t3.SPECIALTY_CD,'') as SPECIALTY_CD,
  NULLIF(t3.PRIMARY_SPECIALTY_IND,'') as PRIMARY_SPECIALTY_IND,
  cast(NULLIF(cast(t1.SERVICE_LOCATION_NBR as string),'') as int64) as SERVICE_LOCATION_NBR,
  NULLIF(t1.PROVIDER_TYPE_CD,'') as PROVIDER_TYPE_CD,
  NULLIF(t3.PROVIDER_TYPE_DESC,'') as PROVIDER_TYPE_DESC,
  NULLIF(t1.PRODUCT_CD,'') as PRODUCT_CD,
  NULLIF(t1.RATING_SYSTEM_CD,'') as RATING_SYSTEM_CD,
  cast(NULLIF(cast(t2.PROVIDER_BUSINESS_GROUP_NBR as string),'')as int64) as PROVIDER_BUSINESS_GROUP_NBR,
  cast(NULLIF(cast(t2.PROVIDER_BUSINESS_GROUP_SCORE_NBR as string),'')as int64) as PROVIDER_BUSINESS_GROUP_SCORE_NBR,
  cast(NULLIF(cast(t2.PROVIDER_ORGANIZATION_NBR as string),'')as int64) as PROVIDER_ORGANIZATION_NBR,
  NULLIF(t1.ZIP_CD,'') as ZIP_CD,
  NULLIF(t1.GEOGRAPHIC_AREA_CD,'') AS EPDB_GEOGRAPHIC_AREA_CD,
  '' AS UPDATE_DTS,
  CURRENT_TIMESTAMP() AS INSERT_DTS,
  'SYSTEM' AS INSERT_USER
  FROM
  {{ce_project}}.{{ce_dataset}}.{{cet_address_detail_view}} AS t1
  
  LEFT JOIN
  {{ce_project}}.{{ce_dataset}}.{{cet_business_group_view}} AS t2
  ON
    t1.provider_identification_nbr = t2.provider_identification_nbr
    AND t1.tax_identification_nbr = t2.tax_identification_nbr
    AND t1.service_location_nbr = t2.service_location_nbr
    AND t1.network_id = t2.network_id
  LEFT JOIN 
  {{ce_project}}.{{ce_dataset}}.{{cet_specialty}} as t3
    ON
    t1.PROVIDER_IDENTIFICATION_NBR = t3.PROVIDER_IDENTIFICATION_NBR
    AND t1.NETWORK_ID = t3.NETWORK_ID

);

