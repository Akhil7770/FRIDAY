CREATE OR REPLACE TABLE {{ce_project}}.{{ce_dec_dataset}}.{{ce_dec_provider_table}}  options (  labels=[("owner", "amanullam_aetna_com"),("costcenter","13345")]   )  as  
  SELECT distinct 
    generate_uuid() as UUID_KEY,
    PROVIDER_IDENTIFICATION_NBR,
    NATIONAL_PROVIDER_ID,
    `anbc-dev-prv-ps-ce.voltage_anbc_dev_prv_ps_ce.encryptTinEntUsEast4`(TAX_IDENTIFICATION_NBR)  as TAX_IDENTIFICATION_NBR,
    TAX_IDENTIFICATION_FORMAT_CD,
    NETWORK_ID,
    NETWORK_TYPE_CD,
    SPECIALTY_CD,
    PRIMARY_SPECIALTY_IND,
    SERVICE_LOCATION_NBR,
    PROVIDER_TYPE_CD,
    PROVIDER_TYPE_DESC,
    PRODUCT_CD,
    RATING_SYSTEM_CD,
    PROVIDER_BUSINESS_GROUP_NBR,
    PROVIDER_BUSINESS_GROUP_SCORE_NBR,
    PROVIDER_ORGANIZATION_NBR,
    ZIP_CD,
    EPDB_GEOGRAPHIC_AREA_CD,
    '' AS UPDATE_DTS,
    CURRENT_TIMESTAMP() AS INSERT_DTS,   
    'SYSTEM' AS INSERT_USER 
  FROM
  {{ce_project}}.{{ce_dataset}}.{{ce_provider_table}};