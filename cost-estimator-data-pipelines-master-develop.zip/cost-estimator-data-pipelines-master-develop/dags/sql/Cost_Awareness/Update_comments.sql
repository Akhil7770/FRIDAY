MERGE `{{ce_project}}.{{ce_dataset}}.{{cost_awareness_providers}}` t
USING (
SELECT DISTINCT
  srv_prvdr_id,
  TRIM(srv_location_nbr) AS srv_location_nbr,
  LPAD(CAST(ntwk_id AS STRING), 5, '0') AS ntwk_id,
  TRIM(prcdr_cd) AS prcdr_cd,
  TRIM(e_pos_cd) AS e_pos_cd,
  srv_cd_type
FROM
  `{{ce_project}}.{{ce_dataset}}.{{cost_awareness_providers}}` k
WHERE e_pos_cd IS NOT NULL
  AND e_rate IS NULL
  AND NOT EXISTS (
    SELECT 1 
    FROM `{{ce_project}}.{{ce_dec_dataset}}.{{ce_provider_table}}` p 
    WHERE p.PROVIDER_IDENTIFICATION_NBR = k.srv_prvdr_id
      AND CAST(p.SERVICE_LOCATION_NBR AS STRING) = k.srv_location_nbr
      AND LPAD(CAST(p.network_id AS STRING), 5, '0') = k.ntwk_id  
  )
)s on
 t.srv_prvdr_id = s.srv_prvdr_id
  AND TRIM(t.srv_location_nbr) = s.srv_location_nbr
  AND LPAD(CAST(t.ntwk_id AS STRING), 5, '0') = s.ntwk_id  
  AND TRIM(t.prcdr_cd) = s.prcdr_cd
  AND TRIM(t.e_pos_cd) = s.e_pos_cd
  and t.srv_cd_type = s.srv_cd_type
  and t.e_rate is null
WHEN MATCHED THEN
    UPDATE SET t.comments = "provider details not found"; --426,151

MERGE `{{ce_project}}.{{ce_dataset}}.{{cost_awareness_providers}}` t
USING (
WITH outreach_keys AS (
    SELECT DISTINCT
      srv_prvdr_id,
      TRIM(srv_location_nbr) AS srv_location_nbr,
      LPAD(CAST(ntwk_id AS STRING), 5, '0') AS ntwk_id,
      TRIM(prcdr_cd) AS prcdr_cd,
      TRIM(e_pos_cd) AS e_pos_cd,
      srv_cd_type,
      p.PRODUCT_CD ,
      p.epdb_GEOGRAPHIC_AREA_CD,
      p.RATING_SYSTEM_CD
    FROM
      `{{ce_project}}.{{ce_dataset}}.{{cost_awareness_providers}}` k
      join   `{{ce_project}}.{{ce_dec_dataset}}.{{ce_provider_table}}` p
      ON p.PROVIDER_IDENTIFICATION_NBR = k.srv_prvdr_id
     AND CAST(p.SERVICE_LOCATION_NBR AS STRING) = k.srv_location_nbr
     AND LPAD(CAST(p.network_id AS STRING), 5, '0') = k.ntwk_id 
      where e_rate IS NULL
      and comments is NULL
      and pbg_nbrs is null
      and e_pos_cd is not null
      and p.PROVIDER_BUSINESS_GROUP_NBR is null
  )
  select * from outreach_keys ok
  where not exists (
    select 1 from `{{ce_project}}.{{ce_dec_dataset}}.{{ce_rates_table}}` r
where 
  (ok.PRODUCT_CD = r.PRODUCT_CD or r.PRODUCT_CD = 'ALL') 
      AND ok.epdb_GEOGRAPHIC_AREA_CD = r.GEOGRAPHIC_AREA_CD 
      AND ok.RATING_SYSTEM_CD = r.RATE_SYSTEM_CD     
      AND CAST(r.service_cd AS STRING)  = ok.prcdr_cd 
      AND CAST(r.service_type_cd AS STRING)  = ok.srv_cd_type
      AND CAST(r.place_of_service_cd AS STRING)= ok.e_pos_cd 
      and r.PROVIDER_BUSINESS_GROUP_NBR is null
      and r.CONTRACT_TYPE ='S'
  ) )s on
 t.srv_prvdr_id = s.srv_prvdr_id
  AND TRIM(t.srv_location_nbr) = s.srv_location_nbr
  AND LPAD(CAST(t.ntwk_id AS STRING), 5, '0') = s.ntwk_id  
  AND TRIM(t.prcdr_cd) = s.prcdr_cd
  AND TRIM(t.e_pos_cd) = s.e_pos_cd
  and t.srv_cd_type = s.srv_cd_type
  and t.e_rate is null
WHEN MATCHED THEN
    UPDATE SET t.comments = "std category- no rates found for this"; --178

 

MERGE `{{ce_project}}.{{ce_dataset}}.{{cost_awareness_providers}}` t
USING (
WITH outreach_keys AS (
    SELECT DISTINCT
      srv_prvdr_id,
      TRIM(srv_location_nbr) AS srv_location_nbr,
      LPAD(CAST(ntwk_id AS STRING), 5, '0') AS ntwk_id,
      TRIM(prcdr_cd) AS prcdr_cd,
      TRIM(e_pos_cd) AS e_pos_cd,
      srv_cd_type,
      p.PRODUCT_CD ,
      p.PROVIDER_BUSINESS_GROUP_NBR
    FROM
      `{{ce_project}}.{{ce_dataset}}.{{cost_awareness_providers}}` k
      join   `{{ce_project}}.{{ce_dec_dataset}}.{{ce_provider_table}}` p
      ON p.PROVIDER_IDENTIFICATION_NBR = k.srv_prvdr_id
     AND CAST(p.SERVICE_LOCATION_NBR AS STRING) = k.srv_location_nbr
     AND LPAD(CAST(p.network_id AS STRING), 5, '0') = k.ntwk_id 
      where e_rate IS NULL
      and comments is NULL
      and pbg_nbrs is not null
      and e_pos_cd is not null
      and p.PROVIDER_BUSINESS_GROUP_NBR is not null
  )
  select distinct  srv_prvdr_id,
      TRIM(srv_location_nbr) AS srv_location_nbr,
      LPAD(CAST(ntwk_id AS STRING), 5, '0') AS ntwk_id,
      TRIM(prcdr_cd) AS prcdr_cd,
      TRIM(e_pos_cd) AS e_pos_cd,
      srv_cd_type,
  from outreach_keys ok
  where not exists (
    select 1 from `{{ce_project}}.{{ce_dec_dataset}}.{{ce_rates_table}}` r
where 
  (ok.PRODUCT_CD = r.PRODUCT_CD or r.PRODUCT_CD = 'ALL')   
      AND CAST(r.service_cd AS STRING)  = ok.prcdr_cd 
      AND CAST(r.service_type_cd AS STRING)  = ok.srv_cd_type
      AND CAST(r.place_of_service_cd AS STRING)= ok.e_pos_cd 
      and r.PROVIDER_BUSINESS_GROUP_NBR is not null
      and r.PROVIDER_BUSINESS_GROUP_NBR = ok.PROVIDER_BUSINESS_GROUP_NBR
      AND CONTRACT_TYPE IN ('C', 'N','D')
  ) )s on
 t.srv_prvdr_id = s.srv_prvdr_id
  AND TRIM(t.srv_location_nbr) = s.srv_location_nbr
  AND LPAD(CAST(t.ntwk_id AS STRING), 5, '0') = s.ntwk_id  
  AND TRIM(t.prcdr_cd) = s.prcdr_cd
  AND TRIM(t.e_pos_cd) = s.e_pos_cd
  and  t.srv_cd_type = s.srv_cd_type
  and t.e_rate is null
WHEN MATCHED THEN
    UPDATE SET t.comments = "non std category- no rates found for this"; --398,200

 
