MERGE `{{ce_project}}.{{ce_dataset}}.{{cost_awareness_providers}}` t1
using  (select 
max(RATE) as Rate,
PROVIDER_IDENTIFICATION_NBR,
NETWORK_ID 
,PLACE_OF_SERVICE_CD 
,SERVICE_CD 
,SERVICE_TYPE_CD,
 ARRAY_AGG(Payment_method_cd ORDER BY Rate DESC LIMIT 1)[OFFSET(0)] as Payment_method_cd
from `{{ce_project}}.{{ce_dec_dataset}}.{{ce_clmamounts}}`
group by
PROVIDER_IDENTIFICATION_NBR,
NETWORK_ID 
,PLACE_OF_SERVICE_CD 
,SERVICE_CD 
,SERVICE_TYPE_CD) t2
on t1.srv_prvdr_id = cast(t2.PROVIDER_IDENTIFICATION_NBR as int64)
and t1.ntwk_id = t2.NETWORK_ID
and t1.pos_cd = t2.PLACE_OF_SERVICE_CD
and t1.prcdr_cd = t2.SERVICE_CD
and t1.srv_cd_type = t2.SERVICE_TYPE_CD
when MATCHED then
UPDATE SET t1.e_rate = CAST(t2.RATE AS STRING),
 t1.e_contract_type = "CLAIMS"
 ,t1.Payment_method_cd = t2.Payment_method_cd; --95,258 
