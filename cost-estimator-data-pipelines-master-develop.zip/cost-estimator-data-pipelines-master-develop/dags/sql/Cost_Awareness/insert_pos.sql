MERGE `{{ce_project}}.{{ce_dataset}}.{{cost_awareness_providers}}` t1
USING (
    SELECT DISTINCT
        primary_svc_cd,
        supporting_pos_cd
    FROM `{{ce_project}}.{{ce_dataset}}.{{ce_scm}}`
    WHERE in_scope_ind = 1
) t2
ON t1.prcdr_cd = t2.primary_svc_cd
WHEN MATCHED THEN
    UPDATE SET e_pos_cd = t2.supporting_pos_cd;