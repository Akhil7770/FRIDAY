# Importing necessary modules and classes
import os, sys
sys.path.insert(0,os.path.abspath(os.path.dirname(__file__)))
from airflow.providers.google.cloud.sensors.dataflow import DataflowJobStatusSensor
from airflow.utils.dates import days_ago
from airflow import models
from airflow.models import DAG
from google.auth import impersonated_credentials, default
from airflow.providers.google.cloud.operators.bigquery import BigQueryInsertJobOperator
from datetime import datetime, timedelta
import os
from google.cloud import bigquery
from google.auth import impersonated_credentials
#from google.cloud import storage_transfer
import logging
import email_context as ec
import calling_config as ct 
from airflow.operators.python_operator import PythonOperator, BranchPythonOperator
from google.cloud import storage
import json
import pandas as pd
from google.cloud import dataflow_v1beta3
import pandas_gbq
from google.auth import impersonated_credentials
# from airflow.providers.google.cloud.transfers.bigquery_to_spanner import BigQueryToCloudSpannerOperator
from google.cloud import spanner
import google.auth
from google.cloud.spanner_v1 import param_types
from decimal import Decimal
from airflow.providers.apache.beam.operators.beam import BeamRunPythonPipelineOperator
from airflow.providers.google.cloud.operators.dataflow import DataflowConfiguration
from airflow.utils.task_group import TaskGroup
import pendulum, requests, time
from airflow.operators.email import EmailOperator
from airflow.utils.trigger_rule import TriggerRule
from airflow.utils.email import send_email

# APP_NAME=ct.config['config']['labels']['APP_NAME']

PROJECT_ID = os.environ.get("GCP_PROJECT").replace("-hcb","")+'-prv-ps-ce' 
TENANT = 'prv-ps-ce'
connect_sa = f"prv-ps-ce-hcb-connect@{PROJECT_ID}.iam.gserviceaccount.com"
resource_sa = f"gchcb-prv-ps-ce-ontpd@{PROJECT_ID}.iam.gserviceaccount.com"
#resource_sa = f"gchcb-provider-genai-secure-ontpd@anbc-hcb-dev.iam.gserviceaccount.com"
decrypt_sa = f"gchcb-prv-ps-ce-dec-ontpd@{PROJECT_ID}.iam.gserviceaccount.com"

# REPO_NAME = ct.config['config']['REPO_NAME']
# CUR_DIR = os.path.abspath(os.path.dirname(__file__))
USER = 'schubertc1'
ENV = ct.config['config']['GCP_ENV']
DAG_ID = f"{TENANT}-cost-estimator-data-pipelines-reverser-etl-Rates-bq-to-spanner"
owner_name = f"{USER}_aetna_com"
if ENV.lower() == 'dev':
      RUN_ENV = 'nonprod'
elif ENV.lower() == 'prod':
      RUN_ENV = 'prod'
subnetwork_uri = ct.config['config']['subnetwork_uri']

bq_dataset = ct.config['config']['bq_dataset']['ce_dataset']
bq_dec_dataset = ct.config['config']['bq_dataset']['ce_dec_dataset']
bq_project = ct.config['config']['bq_dataset']['ce_project']
bq_input_table = ct.config['config']['APP_READ_TABLES']['ce_rates_table']
spanner_project_id = ct.config['config']['spanner_project_id']
spanner_instance_id = ct.config['config']['spanner_instance_id'] 
spanner_database_id = ct.config['config']['spanner_database_id']
spanner_table_name = ct.config['config']['spanner_tables']['spanner_rates_table']['table_name']
spanner_stg_table_name = ct.config['config']['spanner_tables']['spanner_rates_table']['stg_name']
spanner_bkp_table_name=ct.config['config']['spanner_tables']['spanner_rates_table']['bkp_name']
py_folder_path = f"{TENANT}-hcb/cost-estimator-data-pipelines/py" 
sql_folder_path = f"{TENANT}-hcb/cost-estimator-data-pipelines/sql/rates_table/rates_index.sql" 
index_name_1 = ct.config['config']['spanner_tables']['spanner_rates_table']['index_name_1']
index_name_2 = ct.config['config']['spanner_tables']['spanner_rates_table']['index_name_2']
bq_rates1_table = ct.config['config']['APP_READ_TABLES']['cet_rates1']
bq_rates2_table = ct.config['config']['APP_READ_TABLES']['cet_rates2']
bq_rates3_table = ct.config['config']['APP_READ_TABLES']['cet_rates3']
REGION = ct.config['config']['REGION']

if ENV == 'dev':
    py_requirements_var = ['pip==22.2.2', 'apache-beam[gcp]==2.61.0']
    py_interpreter_var = "python3.11"
else:
    py_requirements_var = ['pip==22.2.2', 'apache-beam[gcp]==2.46.0']
    py_interpreter_var = "python3.8"


databases  = ct.config['config']['bq_dataset']

db = f"provider_de_hcb_{ENV}"
project_specific = {
    "db": db
    
}
COSTCENTER=ct.config['config']['COSTCENTER']
LABELS_CALL=ct.config['config']['labels']['CREATE_TABLE_LABEL']
LABELS=LABELS_CALL.format(OWNER=owner_name,COSTCENTER=COSTCENTER)
app_read_tables  = ct.config['config']['APP_READ_TABLES']

# Merging different config parameters into a single dictionary
params = ec.merge(app_read_tables, databases, project_specific)
params['COSTCENTER']= COSTCENTER
params['LABELS']=LABELS
params["owner_name"] = owner_name
VAULT = ct.config['config']['VAULT'] 
KMS_KEYRING = ct.config['config']['KMS_KEYRING'] 
#Define timezone

cache_url=ct.config['config']['cache_url']


credential, project= google.auth.default()
target_credentials= impersonated_credentials.Credentials(credential, target_principal= decrypt_sa, target_scopes= ["https://www.googleapis.com/auth/cloud-platform"])


success_to_mail=["Prananditha.Manchikatla@CVSHealth.com"]
success_cc_mail = ["AmanullaM@aetna.com"]

if ENV == 'dev':
    to_mail=["Prananditha.Manchikatla@CVSHealth.com"]
    cc_mail= ["AmanullaM@aetna.com"]
if ENV == 'prod':
    to_mail=["Prananditha.Manchikatla@CVSHealth.com"]
    cc_mail = ["AmanullaM@aetna.com"]

date_timezone=str(pendulum.now('US/Eastern'))


def email_function(flag,**kwargs):
    
    task_id = kwargs["task_instance"].task_id
    DAG_ID = kwargs["task_instance"].dag_id
    logs_url = kwargs['task_instance'].log_url
    to_email = to_mail
    cc_email = cc_mail
    if flag == 'failure':
         msg = '''
         <tr>
               <p>Hi ,</p> 
                <p>Below are the details about the run</p>
                
                <p>Dag_id   : %s,</p> 
                <p>Task_id  : %s,</p>
                <p>Status   :  <b style="color:red;">%s</b>,</p>
                <p>Date_Time: %s,</p>
                <p>Log_URL  : %s,</p>
                <p>              </p>
                <p>Thanks,\n     </p>
                <p>IO-OPS       </p>
                </tr>
                '''% (DAG_ID,task_id,"Failure",date_timezone,logs_url)
    else:
            msg = '''
            <tr>
                   <p>Hi ,</p> 
                   <p>Below are the details about the run</p>
                   
                   <p>Dag_id   : %s,</p> 
                   <p>Task_id  : %s,</p>
                   <p>Status   :  <b style="color:green;">%s</b>,</p>
                   <p>Date_Time: %s,</p>
                   <p>Log_URL  : %s,</p>
                   <p>              </p>
                   <p>Thanks,\n     </p>
                   <p>IO-OPS       </p>
                   </tr>
                   '''% (DAG_ID,task_id,"Success",date_timezone,logs_url)
        
        
    subject = "Cost Estimator"+ " : Spanner Data Load "+ flag + "!!"  

    send_email(to=to_email,cc=cc_email, subject=subject, html_content=msg)

def task_fail():
     raise Exception("Spanner Data Not found> Hence, not deleting CACHE!")


def create_staging_table(staging_table_name,**kwargs):
        
        spanner_index_name = []
        bkp_index_name = []
        stg_index_name = []
        counter = 0
        spanner_client = spanner.Client(credentials= target_credentials)
        instance = spanner_client.instance(spanner_instance_id)
        database = instance.database(spanner_database_id)
        get_index_query = f"""SELECT TABLE_NAME,INDEX_NAME  FROM information_schema.indexes 
            WHERE 
            (table_name LIKE  '{spanner_table_name}' or table_name LIKE  '{staging_table_name}' or table_name LIKE  '{spanner_bkp_table_name}_%')
            and INDEX_TYPE = 'INDEX'"""
        with database.snapshot() as snapshot:
            results = snapshot.execute_sql(get_index_query)
            # Convert results to list to avoid generator exhaustion
            results_list = list(results)
            spanner_index_name.extend([row[1] for row in results_list if row[0] == spanner_table_name])     
            stg_index_name.extend([row[1] for row in results_list if row[0] == staging_table_name])
            bkp_index_name.extend([row[1] for row in results_list if row[0].startswith(spanner_bkp_table_name)])
        if len(spanner_index_name) > 0:
            counter = spanner_index_name[0].split('_')[-1]
            # Validate that counter is numeric, default to 0 if not
            if not counter.isdigit():
                counter = 0
        kwargs['ti'].xcom_push(key='indexes', value=bkp_index_name)
        kwargs['ti'].xcom_push(key='counter', value=counter)
        if len(stg_index_name) > 0:
            for index in stg_index_name:
                print(index)
                ddl_stat = [f"""DROP INDEX IF EXISTS {index}"""]
                op = database.update_ddl(ddl_stat)
                op.result()
                print(f"index {index} deleted successfully")

        ddl_stat= [
             f"""DROP TABLE IF EXISTS {staging_table_name}"""]
        op = database.update_ddl(ddl_stat)
        op.result()

        ddl_stat = [
            # To ensure we are using stage table for data dump and not main table
            f"""CREATE table {staging_table_name} (
                    UUID_KEY                      STRING(100),
                    RATE_SYSTEM_CD                STRING(100),
                    SERVICE_CD                    STRING(100),
                    SERVICE_TYPE_CD               STRING(100),
                    SERVICE_GROUP_CD              STRING(100),
                    SERVICE_GROUPING_PRIORITY_NBR STRING(100),
                    SERVICE_GROUP_CHANGED_IND    STRING(100),  
                    PROVIDER_BUSINESS_GROUP_NBR   INT64,
                    PRODUCT_CD                    STRING(100),
                    PLACE_OF_SERVICE_CD           STRING(100),
                    GEOGRAPHIC_AREA_CD            STRING(100),
                    EXTENSION_CD                  STRING(100),
                    EXTENSION_TYPE                STRING(100),
                    SPECIALTY_CD                  STRING(100),
                    SPECIALTY_TYPE_CD             STRING(100),
                    PAYMENT_METHOD_CD             STRING(100),
                    RATE                          FLOAT64,
                    CNT_EFFTV_DT                  STRING(100),
                    CNT_TERMN_DT                  STRING(100),
                    CONTRACT_TYPE                 STRING(100),
                    LOGIC_TYPE                    STRING(100) 
                ) PRIMARY KEY (UUID_KEY)"""
            #,f"""CREATE INDEX IF NOT EXISTS {index_name_1}_{int(counter)+1} ON {staging_table_name} (SERVICE_CD,SERVICE_TYPE_CD,GEOGRAPHIC_AREA_CD,PLACE_OF_SERVICE_CD,PRODUCT_CD, PROVIDER_BUSINESS_GROUP_NBR)""",
            #f"""CREATE INDEX IF NOT EXISTS {index_name_2}_{int(counter)+1} ON {staging_table_name} (SERVICE_CD,SERVICE_TYPE_CD,RATE_SYSTEM_CD,PRODUCT_CD,GEOGRAPHIC_AREA_CD,PLACE_OF_SERVICE_CD,CONTRACT_TYPE,PROVIDER_BUSINESS_GROUP_NBR)"""
        ]
        op = database.update_ddl(ddl_stat)
        op.result()
        print(f"Staging table {staging_table_name} created successfully")

def create_spanner_index(staging_table_name,**kwargs):
        ti = kwargs['ti']
        spanner_client = spanner.Client(credentials= target_credentials)
        instance = spanner_client.instance(spanner_instance_id)
        database = instance.database(spanner_database_id)
        counter = ti.xcom_pull(task_ids='e2e_spanner_case_volume.staging_table_create',key='counter')
        index_name_1_new = f"{index_name_1}_{int(counter)+1}"
        index_name_2_new = f"{index_name_2}_{int(counter)+1}"
        ddl_stat = [
            f"""CREATE INDEX IF NOT EXISTS {index_name_1_new} ON {staging_table_name} (SERVICE_CD,SERVICE_TYPE_CD,RATE_SYSTEM_CD,GEOGRAPHIC_AREA_CD,PLACE_OF_SERVICE_CD,PRODUCT_CD,CONTRACT_TYPE)""",
            f"""CREATE INDEX IF NOT EXISTS {index_name_2_new} ON {staging_table_name} (SERVICE_CD,SERVICE_TYPE_CD,PLACE_OF_SERVICE_CD,PRODUCT_CD,PROVIDER_BUSINESS_GROUP_NBR,SPECIALTY_CD,CONTRACT_TYPE)"""
        ]
        op = database.update_ddl(ddl_stat)
        op.result(timeout=36000)
        print(f"Indexes {index_name_1_new} and {index_name_2_new} created successfully")
def drop_table():
     bigquery_client = bigquery.Client(credentials= target_credentials)
     bigquery_client.delete_table(f"{bq_project}.{bq_dec_dataset}.{bq_rates1_table}")
     bigquery_client.delete_table(f"{bq_project}.{bq_dec_dataset}.{bq_rates2_table}")
     bigquery_client.delete_table(f"{bq_project}.{bq_dec_dataset}.{bq_rates3_table}")
     print(f"Tables CET_RATES1, CET_RATES2, CET_RATES3 deleted successfully")

def sleep_task_time():
      print('sleeping for 10 mins....')
      time.sleep(600)

def spanner_count_query(spanner_instance_id, spanner_database_id, table_name):
        

        client = spanner.Client(credentials= target_credentials)
        instance = client.instance(spanner_instance_id)
        database = instance.database(spanner_database_id)

        with database.snapshot() as snapshot:
              results = snapshot.execute_sql(f'select count(*) from {table_name}')

              for row in results:
                  count = row[0]
                  # row = next(results)
                  count = row[0]
                  print(f"Rates Table Count : {count}")
                  return count


def branch_based_on_count(ti):
      count = ti.xcom_pull(task_ids='spanner_count')
      if count > 0:
            return 'swap_tables'
      else:
            return 'send_failure_email'

def insert_audit_log(spanner_instance_id, spanner_database_id, table_name, **kwargs):
    """
    Get count from final table and insert audit record into Spanner
    """
    spanner_client = spanner.Client(credentials=target_credentials)
    instance = spanner_client.instance(spanner_instance_id)
    database = instance.database(spanner_database_id)
    
    # Get count from the final table
    with database.snapshot() as snapshot:
        count_query = f"SELECT COUNT(*) FROM {table_name}"
        results = snapshot.execute_sql(count_query)
        for row in results:
            table_count = row[0]
            break
    
    # Insert audit record
    current_timestamp = datetime.now()
    
    audit_data = [
        (
            f"Rates_{current_timestamp.strftime('%Y%m%d%H%M%S')}",  # audit_id
            "Rates",  # table_name
            current_timestamp,  # audit_date
            table_count,  # table_count
            "SUCCESS"  # status
        )
    ]
    
    database.run_in_transaction(lambda transaction: transaction.insert_or_update(
        'Audit_CE_logs',
        columns=['audit_id', 'table_name', 'audit_date', 'table_count', 'status'],
        values=audit_data
    ))
    
    print(f"Audit log inserted: Table={table_name}, Count={table_count}, Date={current_timestamp}")
    return table_count  


def swapping_tables(table_name, staging_table_name, backup_table_name,**kwargs):
      # Appended timestamp to backup table name
      timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
      backup_table_name_with_timestamp = f"""{backup_table_name}_{timestamp}"""
      
      spanner_client = spanner.Client(credentials= target_credentials)
      instance = spanner_client.instance(spanner_instance_id)
      database = instance.database(spanner_database_id)
      if database.table(table_name).exists():
           ddl_statement = [
           # To make sure main table has latest data dump from staging
           f"""ALTER TABLE {table_name} RENAME TO {backup_table_name_with_timestamp}""",
           f"""ALTER TABLE {staging_table_name} RENAME TO {table_name}"""
           ]
      else:
           ddl_statement = [
           # To make sure main table has latest data dump from staging
           f"""ALTER TABLE {staging_table_name} RENAME TO {table_name}"""
           ]
           
      
      operation = database.update_ddl(ddl_statement)
      operation.result()
      print(f"Tables swapped successfully")
      kwargs['ti'].xcom_push(key='backup_table_name', value=backup_table_name_with_timestamp)
      return backup_table_name_with_timestamp

# To delete all backup tables
def delete_all_old_backup_tables(spanner_instance_id, spanner_database_id,staging_table_name, **Kwargs):
      ti=Kwargs['ti']
      backup_tables = []
      client = spanner.Client(credentials= target_credentials)
      instance = client.instance(spanner_instance_id)
      database = instance.database(spanner_database_id)
      backup_table_name_with_timestamp = ti.xcom_pull(task_ids='swap_tables',key='backup_table_name')
      query = f"""SELECT table_name FROM information_schema.tables 
            WHERE 
            table_name LIKE '{spanner_bkp_table_name}_%'
            and not table_name = '{backup_table_name_with_timestamp}'"""
      with database.snapshot() as snapshot:
        results = snapshot.execute_sql(query)
        backup_tables.extend([row[0] for row in results])
      indexes = ti.xcom_pull(task_ids='e2e_spanner_case_volume.staging_table_create', key='indexes')
      if indexes:
          for index in indexes:
              drop_index_statement = [f"""DROP INDEX IF EXISTS {index}"""]
              operation = database.update_ddl(drop_index_statement)
      if backup_tables:
           for backup_table in backup_tables:
                print(f"Deleting old backup table: {backup_table}")
                drop_statement = f"""DROP TABLE {backup_table}"""
                operation = database.update_ddl([drop_statement])
                operation.result()  # Wait for the operation to complete
                print(f"Old Backup table {backup_table} deleted successfully")

def fetch_and_push_dataflow_job_id(ti, project_id, location, job_name):
    job_name = job_name.replace('_', '-')
    base_credentials, _ = default()
    # Impersonate connect_sa
    impersonated_creds = impersonated_credentials.Credentials(
        source_credentials=base_credentials,
        target_principal=connect_sa,
        target_scopes=["https://www.googleapis.com/auth/cloud-platform"]
    )
    client = dataflow_v1beta3.JobsV1Beta3Client(credentials=impersonated_creds)
    request = dataflow_v1beta3.ListJobsRequest(project_id=project_id, location=location)
    jobs = client.list_jobs(request=request)
    for job in jobs.jobs:
        if job.current_state.name in ("JOB_STATE_RUNNING", "JOB_STATE_STARTING","JOB_STATE_PENDING") and job.name.startswith(job_name):
            ti.xcom_push(key='dataflow_job', value=job.id)
            print(f"Pushed Dataflow job ID: {job.id}")
            return job.id

    raise Exception(f"No Dataflow job found with name: {job_name}") 
           
default_args = {
    "start_date": days_ago(1),
    "project_id": PROJECT_ID,
    "retries": 0,
    "email_on_failure": False,
    "depends_on_past": False,
    "email_on_retry": False,
    "schedule_interval": "@once",
    "on_success_callback": ec.success_call,
    "on_failure_callback": ec.fail_call,
    "dataflow_kms_key": f"projects/anbc-mgmt/locations/{REGION}/keyRings/{KMS_KEYRING}/cryptoKeys/{PROJECT_ID}"  #need to check
}

with DAG(DAG_ID,
        schedule_interval=  None,  # Every 1 hr
        default_args=default_args,
        is_paused_upon_creation=True,
        catchup=False,
        user_defined_macros=params,
        tags=ct.DAG_TAGS # has to be included as per ANBC
        ) as dag:
    
    
    spanner_count = PythonOperator(

            task_id='spanner_count',
            python_callable = spanner_count_query,
            op_kwargs={
                  'spanner_instance_id': spanner_instance_id,
                  "spanner_database_id": spanner_database_id,
                  'table_name': spanner_stg_table_name
            }
      )
              
    audit_log_task = PythonOperator(
        task_id='insert_audit_log',
        python_callable=insert_audit_log,
        op_kwargs={
            'spanner_instance_id': spanner_instance_id,
            'spanner_database_id': spanner_database_id,
            'table_name': spanner_table_name  # This should be the final table name after swap
        }
    )
              

    branching = BranchPythonOperator(
            task_id = 'check_for_spanner',
            python_callable = branch_based_on_count,
            provide_context = True,
      )

    send_success_email = PythonOperator(
            task_id ='send_success_email',
            python_callable = email_function,
            op_kwargs={
                  'flag': 'success'
            },
            provide_context = True
     )

    send_failure_email = PythonOperator(
            task_id ='send_failure_email',
            python_callable = email_function,
            op_kwargs={
                  'flag': 'failure'
            },
            provide_context = True
      )

    failure_task = PythonOperator(

            task_id='failing_DAG_no_spanner_data',
            python_callable = task_fail
      )

    
    swap_tables = PythonOperator (
           task_id ='swap_tables',
           python_callable = swapping_tables,
            op_kwargs={
                  'spanner_instance_id': spanner_instance_id,
                  "spanner_database_id": spanner_database_id,
                  'table_name': spanner_table_name,
                  'staging_table_name': spanner_stg_table_name,
                  'backup_table_name' : spanner_bkp_table_name
            }
      )
    
    delete_old_backup_tables = PythonOperator(
           task_id ='delete_old_backup_tables',
           python_callable = delete_all_old_backup_tables,
           op_kwargs={
                'spanner_instance_id': spanner_instance_id,
                'spanner_database_id': spanner_database_id,
                'staging_table_name': spanner_stg_table_name
            }
    )
    create_index = PythonOperator(
        task_id ='create_index',
        python_callable = create_spanner_index,
        op_kwargs={
                  'staging_table_name': spanner_stg_table_name
            }
        ) 
    
    drop_table_task = PythonOperator(
        task_id ='drop_table',
        python_callable = drop_table
        ) 

    with TaskGroup(group_id= 'e2e_spanner_case_volume') as e2e_spanner_case_volume:
        staging_table_create = PythonOperator(
            task_id ='staging_table_create',
            python_callable = create_staging_table,
            op_kwargs={
                  'staging_table_name': spanner_stg_table_name
            }
      )
        export_to_spanner_01 = BigQueryInsertJobOperator(
        task_id="export_bq_to_spanner_01",
        impersonation_chain=decrypt_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "query": {
                "query": f"""
                EXPORT DATA OPTIONS(
                    uri="https://spanner.googleapis.com/projects/{spanner_project_id}/instances/{spanner_instance_id}/databases/{spanner_database_id}",
                    format="CLOUD_SPANNER",
                    spanner_options='{{"table":"{spanner_stg_table_name}"}}'
                ) AS SELECT * FROM {bq_project}.{bq_dec_dataset}.{bq_rates1_table};
                """,
                "useLegacySql": False
            }
        }
        )
        export_to_spanner_02 = BigQueryInsertJobOperator(
        task_id="export_bq_to_spanner_02",
        impersonation_chain=decrypt_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "query": {
                "query": f"""
                EXPORT DATA OPTIONS(
                    uri="https://spanner.googleapis.com/projects/{spanner_project_id}/instances/{spanner_instance_id}/databases/{spanner_database_id}",
                    format="CLOUD_SPANNER",
                    spanner_options='{{"table":"{spanner_stg_table_name}"}}'
                ) AS SELECT * FROM {bq_project}.{bq_dec_dataset}.{bq_rates2_table};
                """,
                "useLegacySql": False
            }
        }
        )

        export_to_spanner_03 = BigQueryInsertJobOperator(
        task_id="export_bq_to_spanner_03",
        impersonation_chain=decrypt_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "query": {
                "query": f"""
                EXPORT DATA OPTIONS(
                    uri="https://spanner.googleapis.com/projects/{spanner_project_id}/instances/{spanner_instance_id}/databases/{spanner_database_id}",
                    format="CLOUD_SPANNER",
                    spanner_options='{{"table":"{spanner_stg_table_name}"}}'
                ) AS SELECT * FROM {bq_project}.{bq_dec_dataset}.{bq_rates3_table};
                """,
                "useLegacySql": False
            }
        }
        )
        
    



    staging_table_create >> export_to_spanner_01 >> export_to_spanner_02 >> export_to_spanner_03 
#     truncate_table_spanner >> bq_spanner_convert

    e2e_spanner_case_volume >> create_index >> spanner_count >> branching >> [swap_tables,send_failure_email] 
    swap_tables >> delete_old_backup_tables >> audit_log_task >> send_success_email >> drop_table_task
    send_failure_email >> failure_task

