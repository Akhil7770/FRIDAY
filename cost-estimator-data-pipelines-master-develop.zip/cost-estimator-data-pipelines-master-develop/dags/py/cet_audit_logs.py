import hashlib, sys, os, time, argparse, site, logging, json

from google.cloud import bigquery
import google.auth
from google.auth import impersonated_credentials
from google.cloud import storage
import pandas as pd
import datetime as dt
import subprocess
from pandas.io import gbq
import zipfile
import io
import re
import gcsfs
import email_context as ec
import calling_config as ct
from datetime import datetime
#from config import config

sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))
logging = logging.getLogger("airflow.task")
CUR_DIR = os.path.abspath(os.path.dirname(__file__))

job_start_load_dts = dt.datetime.now()

logging.info("Job Start Time : {}".format(job_start_load_dts))
# logging.info('Log File: {}'.format(log_file_name))

# Config File Setup
PROJECT_ID = os.environ.get("GCP_PROJECT").replace("-hcb","")+'-prv-ps-ce'
# constant vars
resource_sa = f"gchcb-prv-ps-ce-ontpd@{PROJECT_ID}.iam.gserviceaccount.com"
decrypt_sa = f"gchcb-prv-ps-ce-dec-ontpd@{PROJECT_ID}.iam.gserviceaccount.com"
TENANT = 'prv-ps-ce'
USER = ct.config["config"]["USER"]
GCP_ENV = ct.config["config"]["GCP_ENV"]

DAG_PATH = os.environ.get('DAGS_FOLDER')

code_bucket = ct.config["config"]["CODE_BUCKET"]
data_bucket = ct.config["config"]["DATA_BUCKET"]

COSTCENTER = ct.config["config"]["COSTCENTER"]

now = datetime.now()
date_of_run = now.strftime("%Y%m%d") #'05022025'
app_read_tables = ct.config["config"]["APP_READ_TABLES"]
databases = ct.config["config"]["bq_dataset"]
owner_name = f"{USER}_aetna_com"
bucket_name = ct.config['config']['CE_DATA_BUCKET']
project_id_ce = ct.config['config']['bq_dataset']['ce_project']
dataset_id = ct.config['config']['bq_dataset']['ce_dataset']
dec_dataset_id = ct.config['config']['bq_dataset']['ce_dec_dataset']

LABELS_CALL = ct.config["config"]["labels"]["CREATE_TABLE_LABEL"]
LABELS = LABELS_CALL.format(OWNER=owner_name, COSTCENTER=COSTCENTER)
credential, project = google.auth.default()
target_credentials = impersonated_credentials.Credentials(credential, target_principal=decrypt_sa, target_scopes=[
    "https://www.googleapis.com/auth/cloud-platform"])
bq_client = bigquery.Client(project=PROJECT_ID, credentials=target_credentials) # EngX Compute


def cet_audit_logs_main(dataset_id, table_name):
    if table_name == 'CET_RATES':
        query = f"""INSERT INTO `{project_id_ce}.{dec_dataset_id}.cet_audit_logs`
                        SELECT '{table_name}' AS TABLE_NAME, 
                            LOGIC_TYPE AS LOGIC_TYPE,
                            COUNT(*) AS NUMBER_OF_RECORDS,
                            CURRENT_TIMESTAMP() AS INSERT_TIMESTAMP
                        FROM `{project_id_ce}.{dataset_id}.{table_name}`
                        GROUP BY LOGIC_TYPE;"""
        print(query)
        bq_client.query(query).result()
        logging.info(f"Audit logs for {table_name} table have been inserted successfully into cet_audit_logs table.")

    else:
        query = f"""INSERT INTO `{project_id_ce}.{dec_dataset_id}.cet_audit_logs`
                        SELECT '{table_name}' AS TABLE_NAME, 
                            '{table_name}' AS LOGIC_TYPE,
                            COUNT(*) AS NUMBER_OF_RECORDS,
                            CURRENT_TIMESTAMP() AS INSERT_TIMESTAMP
                        FROM `{project_id_ce}.{dataset_id}.{table_name}`;"""
        bq_client.query(query).result()
        logging.info(f"Audit logs for {table_name} table have been inserted successfully into cet_audit_logs table.")
    logging.info(f"Audit logs for {table_name} table have been processed successfully.")
    
def cet_audit_log_table_creation():
    query = f"""CREATE TABLE IF NOT EXISTS `{project_id_ce}.{dec_dataset_id}.cet_audit_logs` (
                    TABLE_NAME STRING,
                    LOGIC_TYPE STRING,
                    NUMBER_OF_RECORDS INT64,
                    INSERT_TIMESTAMP TIMESTAMP
        )
                OPTIONS(
                    description='Audit logs for CET tables'
                );"""
    bq_client.query(query).result()
    logging.info('CET Audit Logs table created successfully.')