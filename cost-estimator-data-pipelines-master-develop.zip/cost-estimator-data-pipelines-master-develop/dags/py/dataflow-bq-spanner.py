"""
    BQ-Spanner Utility is a bulk ingestion pattern that leverages 
    Apache Beam for distributed processing. 

"""

import argparse
import google.auth
from google.auth import impersonated_credentials
import json
import io
import regex
import sys
from google.cloud import bigquery
from google.cloud import spanner
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions
from apache_beam.io.gcp.experimental.spannerio import WriteToSpanner
import os

PROJECT_ID = os.environ.get("GCP_PROJECT")

class BQToSpannerLoader(PipelineOptions):
    """ Pipeline  options to pass to worker nodes on Beam Pipeline """
    @classmethod
    def _add_argparse_args(cls, parser: argparse.ArgumentParser()) -> None:
        parser.add_argument(
            '--input_query',
            required=True,
            help='Query that needs to be employed to read data from BQ table')
        parser.add_argument(
            '--bq_project_id',
            required=True,
            help='project-id where your BQ table resides')
        parser.add_argument(
            '--bq_dataset_id',
            required=True,
            help='dataset-id where your BQ table resides')
        parser.add_argument(
            '--bq_table_id',
            required=True,
            help='BQ Table that you want to finally load to'
        )
        parser.add_argument(
            '--spanner_project_id',
            required=True,
            help='Spanner Project that you want to load to'
        )
        parser.add_argument(
            '--spanner_instance_id',
            required=True,
            help='Spanner instance that you want to load to'
        )
        parser.add_argument(
            '--spanner_database_id',
            required=True,
            help='spanner database that you want to load to'
        )
        parser.add_argument(
            '--spanner_table_id',
            required=True,
            help='spanner table that you want to load to'
        )
        parser.add_argument(
            '--spanner_table_pk',
            required=False,
            help='spanner table primary key, if you have multiple separate it by comma(,)'
        )
        parser.add_argument(
            '--spanner_drop_indexes',
            action='append',
            required=False,
            default=[],
            help='spanner table indexes to be dropped'
        )
        parser.add_argument(
            '--spanner_create_indexes',
            action='append',
            required=False,
            default=[],
            help='spanner table indexes to be created'
        )
        parser.add_argument(
            '--min_batch_size',
            type=int,
            required=False,
            default=500,
            help='min_batch_size for batch elements'
        )
        parser.add_argument(
            '--max_batch_size',
            type=int,
            required=False,
            default=2000,
            help='max_batch_size for batch elements'
        )


resource_sa = f"gchcb-prv-ps-ce-dec-ontpd@anbc-dev-prv-ps-ce.iam.gserviceaccount.com" # change it prod/dev
pipeline_options = PipelineOptions()
p = beam.Pipeline(options=pipeline_options)
bq_spanner_options = pipeline_options.view_as(BQToSpannerLoader)

class CreateRowFn(beam.DoFn):
    def __init__(self, spanner_table_id):
        self.spanner_table_id = spanner_table_id

    def process(self, batch):
        from apache_beam.io.gcp.experimental.spannerio import WriteMutation
        from google.cloud.spanner_v1 import Mutation
        # d = {key: str(d[key]) for key in d.keys()}
        # #return [WriteMutation.insert_or_update(table=bq_spanner_options.spanner_table_id, columns=tuple(d), values=[tuple(d.values())])]
        # return [WriteMutation.insert_or_update(table=self.spanner_table_id, columns=tuple(d), values=[tuple(d.values())])]
        mutations = []
        for d in batch:
            d = {key: str(d[key]) for key in d.keys()}
            mutations.append(
                WriteMutation.insert_or_update(
                    table=self.spanner_table_id,
                    columns=tuple(d),
                    values=[tuple(d.values())]
                )
            )
        return mutations


                                     
write_spanner = (
    p
    | 'read' >> beam.io.ReadFromBigQuery(query=bq_spanner_options.input_query, use_standard_sql=True, method='EXPORT', temp_dataset=beam.io.gcp.internal.clients.bigquery.DatasetReference(datasetId=bq_spanner_options.bq_dataset_id, projectId=bq_spanner_options.bq_project_id))
    | 'BatchRows' >> beam.BatchElements(min_batch_size=bq_spanner_options.min_batch_size, max_batch_size=bq_spanner_options.max_batch_size)
    | 'transform' >> beam.ParDo(CreateRowFn(bq_spanner_options.spanner_table_id))
    | 'Write to Spanner' >> WriteToSpanner(bq_spanner_options.spanner_project_id, bq_spanner_options.spanner_instance_id, bq_spanner_options.spanner_database_id)
)

p.run()
