import os, sys
import json
import re
from google.cloud import bigquery as bq

client = bq.Client()

cur_dir = os.path.dirname(os.path.realpath(__file__))
# query_dir = os.path.join(cur_dir, "..", "queries")

cfg_path = sys.argv[1]
# cfg_path = os.path.join(cur_dir, "..", "config", cfg_file)
cfg = json.load(open(cfg_path, "r"))

query_path = sys.argv[2]


def flatten_json(y):
    out = {}

    def flatten(x):
        if isinstance(x, dict):
            for k, v in x.items():
                if k in out:
                    raise ValueError(f"Duplicate key found: {k}")
                if isinstance(v, dict):
                    flatten(v)
                else:
                    out[k] = v
        else:
            raise ValueError("Input must be a dictionary at the top level.")

    flatten(y)
    return out


def query_bq(flat_cfg, query_file, max_results, output_file):
    query_str = open(query_file, "r").read()
    pattern = r"{{\w+}}"
    matches = list(set(re.findall(pattern, query_str)))
    # print("Parameter matches:", matches)

    for match in matches:
        param = match[2:-2]
        if param in flat_cfg:
            query_str = query_str.replace(match, flat_cfg[param])
        else:
            ValueError(f"Key {param} not found in the configuration.")

    # print(query_str)
    print("Executing query...")
    client.query(query_str)
    # use the following instead to WAIT for the query to finish executing:
    # num_new_rows = (
    #     client.query(query_str).result(max_results=max_results).num_dml_affected_rows
    # )

    file_name = query_file.split("\\")[-1]
    # print(f"Num rows from {file_name}: {num_new_rows}")
    # open(output_file, "a").write(f"{file_name}, {num_new_rows}\n")
    open(output_file, "a").write(f"{file_name} executed\n")


def user_input():
    cont, brk = False, False
    user_input = (
        input("Press Enter to continue, 's' to skip, 'b' to break: ").strip().lower()
    )
    if user_input == "s":
        print("Skipping this file")
        cont = True
    elif user_input == "b":
        print("Exiting")
        brk = True
    return cont, brk


def process_queries(output_file, max_results=10, require_user_input=False):
    flat_cfg = flatten_json(cfg)
    if not os.path.isfile(query_path):
        for file_name in os.listdir(query_path):
            file_path = os.path.join(query_path, file_name)
            if os.path.isfile(file_path):  # Ensure it's a file
                print(f"Ready to process file: {file_name}")
                if require_user_input:
                    cont, brk = user_input()
                    if cont:
                        continue
                    elif brk:
                        break
                query_bq(flat_cfg, file_path, max_results, output_file)
    else:
        query_bq(flat_cfg, query_path, max_results, output_file)
    print("Done")


if __name__ == "__main__":
    # EXECUTE THE FOLLOWING COMMAND BEFORE RUNNING:
    # gcloud auth application-default login

    process_queries("out-processed_queries.csv")
