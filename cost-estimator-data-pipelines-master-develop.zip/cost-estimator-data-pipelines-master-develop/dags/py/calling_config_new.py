import os
import json

# -----------------------------------------------------------------------------
# THIS FILE CONTAINS ALL CONFIG LEVEL DETAILS AND DAG_TAGS-- PATH OF CONFIG AND READING CONFIG IS BEING DONE IN THIS PYTHON FILE
# -----------------------------------------------------------------------------

PROJECT_ID = os.environ.get("GCP_PROJECT").replace("-hcb", "") + "-prv-ps-ce"
DAG_PATH = os.environ["DAGS_FOLDER"]
ENV = os.environ.get("GCP_PROJECT").split("-")[-1]
RESOURCE_SA = f"gchcb-prv-ps-ce-ontpd@anbc-{ENV}-prv-ps-ce.iam.gserviceaccount.com"

CURR_DIR = os.path.abspath(os.path.dirname(__file__))
PARENT_DIR = os.path.dirname(CURR_DIR)

config_path = os.path.join(PARENT_DIR, "config", f"{ENV}_cfg_new.json")
with open(config_path) as f:
    config = json.load(f)

DAG_TAGS = ["tenant:prv-ps-ce", f"owner:{config['config']['USER']}@aetna.com"]


# UNUSED:
subnetwork_uri = f"io-hcb-{ENV}-vm"
IMAGE_VERSION = "1.5.53-centos8"
CONFIG_BUCKET = f"provider-de-data-hcb-{ENV}"
PIP_PACKAGES = "google-cloud-bigquery,pandas,google-cloud-logging,google-api-python-client,google-auth,google-auth-httplib2,google-auth-oauthlib,google-cloud-bigquery-storage,pydata-google-auth,pandas-gbq"
cluster_config_load = {
    "master_config": {
        "num_instances": 1,
        "machine_type_uri": "n2-standard-2",
        "disk_config": {"boot_disk_size_gb": 500},
    },
    "worker_config": {
        "num_instances": 2,
        "machine_type_uri": "n2-standard-2",
        "disk_config": {"boot_disk_size_gb": 500},
    },
    "secondary_worker_config": {
        "num_instances": 0,
        "machine_type_uri": "n2-standard-2",
        "disk_config": {"boot_disk_size_gb": 500},
        "preemptibility": "NON_PREEMPTIBLE",
    },
    "software_config": {
        "image_version": IMAGE_VERSION,
        "properties": {
            "dataproc:efm.spark.shuffle": "primary-worker",
            "dataproc:efm.mapreduce.shuffle": "hcfs",
            "dataproc:pip.packages": PIP_PACKAGES,
        },
    },
    "gce_cluster_config": {
        "zone_uri": "us-east4-a",
        "subnetwork_uri": subnetwork_uri,
        "internal_ip_only": True,
        "tags": ["io-dataproc"],
        "service_account": RESOURCE_SA,
        "service_account_scopes": ["https://www.googleapis.com/auth/cloud-platform"],
    },
    "config_bucket": CONFIG_BUCKET,
}
