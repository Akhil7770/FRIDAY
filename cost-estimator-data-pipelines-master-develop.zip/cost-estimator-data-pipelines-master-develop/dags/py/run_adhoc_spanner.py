# Importing necessary modules and classes
import os, sys
sys.path.insert(0,os.path.abspath(os.path.dirname(__file__)))

from airflow.utils.dates import days_ago
from airflow import models
from airflow.models import DAG
from airflow.providers.google.cloud.operators.bigquery import BigQueryInsertJobOperator
from datetime import datetime, timedelta
import os
from google.cloud import bigquery
from google.auth import default
from google.auth import impersonated_credentials
from airflow.providers.google.cloud.sensors.dataflow import DataflowJobStatusSensor

#from google.cloud import storage_transfer
import logging
import email_context as ec
import calling_config as ct 
from airflow.operators.python_operator import PythonOperator, BranchPythonOperator
from google.cloud import storage
import json
import pandas as pd
import pandas_gbq
from google.auth import impersonated_credentials
# from airflow.providers.google.cloud.transfers.bigquery_to_spanner import BigQueryToCloudSpannerOperator
from google.cloud import spanner
import google.auth
from google.cloud.spanner_v1 import param_types
from decimal import Decimal
from airflow.providers.apache.beam.operators.beam import BeamRunPythonPipelineOperator
from airflow.providers.google.cloud.operators.dataflow import DataflowConfiguration
from airflow.utils.task_group import TaskGroup
import pendulum, requests, time
from airflow.operators.email import EmailOperator
from airflow.utils.trigger_rule import TriggerRule
from airflow.utils.email import send_email
from airflow.operators.dummy_operator import DummyOperator
from airflow.providers.google.cloud.sensors.dataflow import DataflowJobStatusSensor
from google.cloud import dataflow_v1beta3

DAG_PATH = os.environ.get('DAGS_FOLDER')
# APP_NAME=ct.config['config']['labels']['APP_NAME']
config_path = 'prv-ps-ce-hcb/cost-estimator-data-pipelines/config/' # changed the path from 'prv-cda-hcb/rfl-caregiver/config/'
config_path = os.path.join(DAG_PATH, config_path)
PROJECT_ID = os.environ.get("GCP_PROJECT").replace("-hcb","")+'-prv-ps-ce' 
TENANT = 'prv-ps-ce'
connect_sa = f"prv-ps-ce-hcb-connect@{PROJECT_ID}.iam.gserviceaccount.com"
resource_sa = f"gchcb-prv-ps-ce-ontpd@{PROJECT_ID}.iam.gserviceaccount.com"
#resource_sa = f"gchcb-provider-genai-secure-ontpd@anbc-hcb-dev.iam.gserviceaccount.com"
decrypt_sa = f"gchcb-prv-ps-ce-dec-ontpd@{PROJECT_ID}.iam.gserviceaccount.com"
with open(config_path + f'Spanner_adhoc_config.json') as f:
    config = json.load(f)
print(config)
# REPO_NAME = ct.config['config']['REPO_NAME']
# CUR_DIR = os.path.abspath(os.path.dirname(__file__))
USER = 'schubertc1'
ENV = config['config']['GCP_ENV']
DAG_ID = f"{TENANT}-cost-estimator-data-pipelines-{USER}-run_spanner_adhoc"

owner_name = f"{USER}_aetna_com"
if ENV.lower() == 'dev':
      RUN_ENV = 'nonprod'
      to_mail=["Prananditha.Manchikatla@CVSHealth.com"]
      cc_mail= ["AmanullaM@aetna.com"]
elif ENV.lower() == 'prod':
      RUN_ENV = 'prod'
      to_mail=["Prananditha.Manchikatla@CVSHealth.com"]
      cc_mail= ["AmanullaM@aetna.com"]
subnetwork_uri = config['config']['subnetwork_uri']

spanner_instance_id = config['config']['spanner_instance_id'] #
spanner_database_id = config['config']['spanner_database_id']
bq_project = config['config']['APP_READ_TABLES']['bq_project']
bq_dataset = config['config']['APP_READ_TABLES']['bq_dataset']
bq_table = config['config']['bq_tables']['bq_provider_table']
query = config['config']['QUERY']
spanner_table_name = config['config']['spanner_tables']['spanner_provider_table']['table_name']
spanner_update_flag = config['config']['spanner_update']
bq_to_spanner_load_flag = config['config']['bq_to_spanner_load']
schema = config['config']['schema']
dataflow_config = config['config']['dataflow_config']
py_folder_path = f"{TENANT}-hcb/cost-estimator-data-pipelines/py" 
sql_folder_path = f"{TENANT}-hcb/cost-estimator-data-pipelines/sql/adhoc/Spanner_adhoc.sql" 
REGION = config['config']['REGION']

if ENV == 'dev':
    py_requirements_var = ['pip==22.2.2', 'apache-beam[gcp]==2.61.0']
    py_interpreter_var = "python3.11"
else:
    py_requirements_var = ['pip==22.2.2', 'apache-beam[gcp]==2.46.0']
    py_interpreter_var = "python3.8"

databases  = ct.config['config']['bq_dataset']

db = f"provider_de_hcb_{ENV}"
project_specific = {
    "db": db
    
}
COSTCENTER=config['config']['COSTCENTER']
LABELS_CALL=config['config']['labels']['CREATE_TABLE_LABEL']
LABELS=LABELS_CALL.format(OWNER=owner_name,COSTCENTER=COSTCENTER)

# Merging different config parameters into a single dictionary
app_read_tables = ct.config["config"]["APP_READ_TABLES"]
params = ec.merge(app_read_tables, databases, project_specific)

params["COSTCENTER"] = COSTCENTER
params["LABELS"] = LABELS
params["owner_name"] = owner_name
VAULT = config['config']['VAULT'] 
KMS_KEYRING = config['config']['KMS_KEYRING'] 
#Define timezone




credential, project= google.auth.default()
target_credentials= impersonated_credentials.Credentials(credential, target_principal= decrypt_sa, target_scopes= ["https://www.googleapis.com/auth/cloud-platform"])


success_to_mail=["Prananditha.Manchikatla@CVSHealth.com"]
success_cc_mail = ["AmanullaM@aetna.com"]


date_timezone=str(pendulum.now('US/Eastern'))

date_timezone=str(pendulum.now('US/Eastern'))

# def delete_spanner_table():
date_timezone=str(pendulum.now('US/Eastern'))

def check_index_status(database, table_name, index_name):
    """Check the status of an index (READY, BUILDING, etc.)"""
    try:
        query = f"""
        SELECT INDEX_STATE 
        FROM INFORMATION_SCHEMA.INDEXES 
        WHERE TABLE_NAME = '{table_name}' 
        AND INDEX_NAME = '{index_name}'
        """
        with database.snapshot() as snapshot:
            results = snapshot.execute_sql(query)
            for row in results:
                return row[0] if row[0] else None
        return None
    except Exception as e:
        print(f"Error checking index status: {e}")
        return None

def wait_for_index_ready(database, table_name, index_name, max_wait_time=36000):
    """Wait for an index to be ready (not building/backfilling)"""
    import time
    start_time = time.time()
    
    while time.time() - start_time < max_wait_time:
        status = check_index_status(database, table_name, index_name)
        print(f"Index {index_name} status: {status}")
        
        if status == 'READY':
            print(f"Index {index_name} is ready!")
            return True
        elif status == 'BUILDING':
            print(f"Index {index_name} is still building, waiting...")
            time.sleep(30)  # Wait 30 seconds before checking again
        else:
            print(f"Index {index_name} status unknown: {status}")
            time.sleep(30)
    
    print(f"Timeout waiting for index {index_name} to be ready after {max_wait_time} seconds")
    return False

def extract_index_info(query):
    """Extract table name and index name from CREATE INDEX query"""
    import re
    # Simple regex to extract table and index names
    match = re.search(r'CREATE INDEX (?:IF NOT EXISTS )?(\w+) ON (\w+)', query, re.IGNORECASE)
    if match:
        return match.group(1), match.group(2)  # index_name, table_name
    return None, None

# def delete_spanner_table():

def spanner_update():
        
        spanner_client = spanner.Client(credentials= target_credentials)
        instance = spanner_client.instance(spanner_instance_id)
        database = instance.database(spanner_database_id)
        sql_file_path=os.path.join(os.environ.get('DAGS_FOLDER'),sql_folder_path)
        with open(sql_file_path, 'r') as file:  
            sql_query = file.read()
        ddl_stat = [stmt.strip() for stmt in sql_query.split(';') if stmt.strip()]
        print("Executing the Adhoc query on Spanner database")
        print(ddl_stat)
        for query in ddl_stat:
            if query.lower().startswith(('create', 'drop', 'alter')):
                 print(f"Executing query: {query}")
                 op = database.update_ddl([query])
                 op.result(timeout=36000)
                 print(f"Executed DDL")
            elif query.lower().startswith(('insert', 'update', 'delete')):
                 print(f"Executing query: {query}")
                 def dml_transaction(transaction):
                      row_count = transaction.execute_update(query)
                      print(f"Rows affected: {row_count}")
                 database.run_in_transaction(dml_transaction)
                 print(f"Executed DML")
            else:
                 print(f"Executing query: {query}")
                 with database.snapshot() as snapshot:
                      results = snapshot.execute_sql(query)
                      output = [row[0] for row in results]
                      print(f"Executed DML")
def bq_to_spanner_load():
     print("Executing the BQ to Spanner load")
     spanner_client = spanner.Client(credentials= target_credentials)
     instance = spanner_client.instance(spanner_instance_id)
     database = instance.database(spanner_database_id)
     table = database.table(spanner_table_name)
     if table.exists():
          print(f"Table {spanner_table_name} already exists")
     else:
          print(f"Table {spanner_table_name} does not exist")
          ddl_stat = [stmt.strip() for stmt in schema.split(';') if stmt.strip()]
          op = database.update_ddl(ddl_stat)
          op.result()
          print(f"Table {spanner_table_name} created")



def flag_check():
     if spanner_update_flag == 'true':
          return 'run_adhoc_query_spanner'
     elif bq_to_spanner_load_flag == 'true':
          return 'run_adhoc_bq_to_spanner'
     else:
          return 'end'

def fetch_and_push_dataflow_job_id(ti, project_id, location, job_name):
    job_name = job_name.replace('_', '-')
    base_credentials, _ = default()
    # Impersonate connect_sa
    impersonated_creds = impersonated_credentials.Credentials(
        source_credentials=base_credentials,
        target_principal=connect_sa,
        target_scopes=["https://www.googleapis.com/auth/cloud-platform"]
    )
    client = dataflow_v1beta3.JobsV1Beta3Client(credentials=impersonated_creds)
    request = dataflow_v1beta3.ListJobsRequest(project_id=project_id, location=location)
    jobs = client.list_jobs(request=request)
    for job in jobs.jobs:
        print(job)
        if job.current_state.name in ("JOB_STATE_RUNNING", "JOB_STATE_STARTING") and job.name.startswith(job_name):
            ti.xcom_push(key='dataflow_job', value=job.id)
            print(f"Pushed Dataflow job ID: {job.id}")
            return job.id

    raise Exception(f"No Dataflow job found with name: {job_name}")           

default_args = {
    "start_date": days_ago(1),
    "project_id": PROJECT_ID,
    "retries": 0,
    "email_on_failure": False,
    "depends_on_past": False,
    "email_on_retry": False,
    "schedule_interval": "@once",
    "on_success_callback": ec.success_call,
    "on_failure_callback": ec.fail_call,
    "dataflow_kms_key": f"projects/anbc-mgmt/locations/{REGION}/keyRings/{KMS_KEYRING}/cryptoKeys/{PROJECT_ID}"  #need to check
}

with DAG(DAG_ID,
        schedule_interval=  None,  # Every 1 hr
        default_args=default_args,
        is_paused_upon_creation=True,
        catchup=False,
        user_defined_macros=params,
        tags=ct.DAG_TAGS # has to be included as per ANBC
        ) as dag:
    run_adhoc_query_spanner = PythonOperator(
         task_id='run_adhoc_query_spanner',
         python_callable=spanner_update,
         provide_context=True,
         dag=dag
    )
    run_dataflow = BeamRunPythonPipelineOperator(
            task_id=f"Adhoc_BQ_to_Spanner_load_dataflow",
            runner="DataflowRunner",
            py_file=f"{os.path.join(os.environ.get('DAGS_FOLDER'),py_folder_path)}/dataflow-bq-spanner.py",
            pipeline_options={ #need to check
                "tempLocation": f"gs://prv-ps-ce-dec-data-hcb-{ENV}/stg-temp-dataflow", 
                "maxNumWorkers": dataflow_config['maxNumWorkers'],
                "workerMachineType":dataflow_config['workerMachineType'],
               # "subnetwork": f"regions/us-east4/subnetworks/{subnetwork_uri}",
                "subnetwork": dataflow_config['subnetwork'],
                "experiments": dataflow_config['experiments'],
                "no_use_public_ips": None,
                "worker_zone": "us-east4-a",
                "impersonate_service_account": connect_sa,
                "service_account_email": decrypt_sa,
                "staging_location": f"gs://prv-ps-ce-dec-data-hcb-{ENV}/stg-temp-dataflow",
                "temp_dataset": f"{bq_project}.temp_dataflow",
                "input_query": f"{query}",
                "bq_project_id": f"{bq_project}",
                "bq_dataset_id": f"{bq_dataset}",
                "bq_table_id": f"{bq_table}",
                "spanner_project_id": f"anbc-hcb-{ENV}",
                "spanner_instance_id": f"{spanner_instance_id}",
                "spanner_database_id": f"{spanner_database_id}",
                "spanner_table_id": f"{spanner_table_name}",
                "dataflow_kms_key": f"projects/{VAULT}/locations/us-east4/keyRings/{KMS_KEYRING}/cryptoKeys/gk-{PROJECT_ID}-us-east4",
                "min_batch_size":dataflow_config['min_batch_size'],
                "max_batch_size":dataflow_config['max_batch_size']
            },
            py_options=[],
            py_requirements=py_requirements_var,
            py_interpreter=py_interpreter_var,
            py_system_site_packages=False,
            dataflow_config=DataflowConfiguration(
                job_name=f'adhc_bq_to_spanner',
                location='us-east4',
                project_id=PROJECT_ID,
                impersonation_chain=connect_sa,
                drain_pipeline=False,
                cancel_timeout=5 * 60,
                wait_until_finished=True,
                )
      )
    run_adhoc_bq_to_spanner = PythonOperator(
         task_id='run_adhoc_bq_to_spanner',
         python_callable=bq_to_spanner_load,
         provide_context=True,
         dag=dag
    )
#     delete_spanner = PythonOperator(
#             task_id='delete_spanner_table',
#             python_callable=delete_spanner_table,
#             provide_context=True,
#             dag=dag
#     )
    branching = BranchPythonOperator(
            task_id = 'check_for_spanner',
            python_callable = flag_check,
            provide_context = True,
      )
    push_job_id = PythonOperator(
           task_id='push_dataflow_job_id',
           python_callable=fetch_and_push_dataflow_job_id,
           op_kwargs={
                'project_id': PROJECT_ID,
                'location': 'us-east4',
                'job_name':"adhc_bq_to_spanner",  # match your Dataflow job_name
                },
                provide_context=True,
                )
    start = DummyOperator(task_id='start', dag=dag)
    end = DummyOperator(task_id='end', dag=dag)
    wait_for_dataflow = DataflowJobStatusSensor(
         task_id='wait_for_dataflow',
         project_id=PROJECT_ID,
         location='us-east4',
         job_id="{{task_instance.xcom_pull(task_ids='push_dataflow_job_id', key='dataflow_job')}}",
         expected_statuses=['JOB_STATE_DONE'],
         timeout=60*60*2,  # 2 hours
         poke_interval=60,
         impersonation_chain=connect_sa
      )

start >> branching >> [run_adhoc_query_spanner,run_adhoc_bq_to_spanner]
run_adhoc_bq_to_spanner >> run_dataflow >> push_job_id >>wait_for_dataflow >> end
run_adhoc_query_spanner >> end

