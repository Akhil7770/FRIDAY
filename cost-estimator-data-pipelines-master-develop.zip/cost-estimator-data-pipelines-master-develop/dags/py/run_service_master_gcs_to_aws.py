from airflow.utils.dates import days_ago
from airflow import models
from airflow.models import DAG
from airflow.providers.google.cloud.transfers.bigquery_to_gcs import BigQueryToGCSOperator
from airflow.providers.google.cloud.operators.bigquery import BigQueryInsertJobOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonVirtualenvOperator
from datetime import datetime, timedelta,timezone
import os
import json
import os, sys
import uuid
import pandas as pd
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))
from google.cloud import bigquery
from google.cloud import storage
from google.auth import impersonated_credentials
import logging
import email_context as ec
import calling_config as ct
from datetime import datetime
from dateutil.relativedelta import relativedelta
import google
from google.auth import impersonated_credentials
from airflow.operators.dagrun_operator import TriggerDagRunOperator
from duplicate_check_scm import check_duplicate_counts

log = logging.getLogger(__name__)

job_start_load_dts = datetime.now()
log.info("\nJob Start Time : {}".format(job_start_load_dts))

PROJECT_ID = os.environ.get("GCP_PROJECT").replace("-hcb","")+'-prv-ps-ce'
# constant vars
resource_sa = f"gchcb-prv-ps-ce-ontpd@{PROJECT_ID}.iam.gserviceaccount.com"
decrypt_sa = f"gchcb-prv-ps-ce-dec-ontpd@{PROJECT_ID}.iam.gserviceaccount.com"
TENANT = 'prv-ps-ce'
USER = ct.config["config"]["USER"]
GCP_ENV = ct.config["config"]["GCP_ENV"]
DAG_ID = f"{TENANT}-cost-estimator-data-pipelines-service-master-gcstoaws"  
owner_name = f"{USER}_aetna_com"
DAGS_FOLDER = os.environ["DAGS_FOLDER"]
user_low = f"{USER}".lower()
code_bucket = ct.config["config"]["CE_CODE_BUCKET"]
data_bucket = ct.config["config"]["CE_DATA_BUCKET"]
TRIGGER_DAG_ID = f"{TENANT}-cost-estimator-data-pipelines-cet_audit_logs"
COSTCENTER = ct.config["config"]["COSTCENTER"]

now = datetime.now()
date_of_run = now.strftime("%Y%m%d") #'05022025'
app_read_tables = ct.config["config"]["APP_READ_TABLES"]
databases = ct.config["config"]["bq_dataset"]
ppk_file_path = ct.config["config"]["ppk_file_path"] # Path to the PPK file for SFTP connection
bucket_name = ct.config['config']['CE_DATA_BUCKET']
project_id_ce = ct.config['config']['bq_dataset']['ce_project']
dataset_id = ct.config['config']['bq_dataset']['ce_dec_dataset']
ce_scm = ct.config["config"]["APP_READ_TABLES"]["ce_scm"]
LABELS_CALL = ct.config["config"]["labels"]["CREATE_TABLE_LABEL"]
LABELS = LABELS_CALL.format(OWNER=owner_name, COSTCENTER=COSTCENTER)
credential, project = google.auth.default()
target_credentials = impersonated_credentials.Credentials(credential, target_principal=decrypt_sa, target_scopes=[
    "https://www.googleapis.com/auth/cloud-platform"])
bq_client = bigquery.Client(project=PROJECT_ID, credentials=target_credentials) # EngX Compute
PK_FILE = f"key_{GCP_ENV}.ppk"
s3_host_name = ct.config["config"]["s3_hostname"]
s3_username = ct.config["config"]["s3_username"]







# Function to add metadata and save the final JSON file
def generate_final_json(**kwargs):
    query = f"""SELECT
                trim(primary_svc_cd) as SERVICE_CD, 
                trim(servc_type) as SERVICE_TYPE_CD,
                trim(svc_name) as SERVICE_NAME, 
                trim(svc_desc) as SERVICE_DESCRIPTION,
                trim(user_friendly_title) AS USER_FRIENDLY_TITLE,
                trim(user_friendly_desc) AS USER_FRIENDLY_DESCRIPTION,
                min_age as MINIMUM_AGE, 
                max_age as MAXIMUM_AGE, 
                efftv_dt as EFFECTIVE_DATE, 
                trmn_dt as TERMINATION_DATE, 
                trim(benefit_types) as BENEFIT_TYPES,
                --trim(supporting_drg_cd) as SUPPORTING_DRG_CD,
                --trim(supporting_rev_cd) as SUPPORTING_REV_CD,
                trim(supporting_pos_cd) as DEFAULT_POS_CD,
                trim(specialty_codes) AS SPECIALTY_CODES
                FROM `{project_id_ce}.{dataset_id}.{ce_scm}` 
                WHERE in_scope_ind=1 and trmn_dt > CURRENT_DATE();"""
    
    # query = f"""SELECT trim(a.primary_svc_cd) as SERVICE_CD, 
    #             trim(a.servc_type) as SERVICE_TYPE_CD,
    #             trim(a.svc_name) as SERVICE_NAME, 
    #             trim(a.svc_desc) as SERVICE_DESCRIPTION,
    #             trim(a.user_friendly_title) AS USER_FRIENDLY_TITLE,
    #             trim(a.user_friendly_desc) AS USER_FRIENDLY_DESCRIPTION,
    #             a.min_age as MINIMUM_AGE, 
    #             a.max_age as MAXIMUM_AGE, 
    #             a.efftv_dt as EFFECTIVE_DATE, 
    #             a.trmn_dt as TERMINATION_DATE, 
    #             trim(a.benefit_types) as BENEFIT_TYPES,
    #             trim(a.supporting_pos_cd) as DEFAULT_POS_CD,
    #             trim(a.specialty_codes) AS SPECIALTY_CODES
    #             FROM `{project_id_ce}.{dataset_id}.{ce_scm}` a
    #             INNER JOIN `{project_id_ce}.prv_ps_ce_hcb_dev.dental_codes_temp_9_4_25` b
    #             ON TRIM(a.servc_type) = TRIM(b.servc_type) AND TRIM(a.primary_svc_cd) = TRIM(b.primary_svc_cd);"""
    
    log.info('Executing query to fetch data from BigQuery')
    try:
        query_job = bq_client.query(query)  # Execute the query

        # Convert the query result to a Pandas DataFrame
        records = query_job.to_dataframe()
        # Convert all datetime or date columns to strings
        for column in records.select_dtypes(include=["datetime", "object"]).columns:
            records[column] = records[column].astype(str)
        print(records.head())

        # Replace NaN values with None to ensure they are serialized as null in JSON
        records = records.where(pd.notnull(records), None)
    
    except Exception as e:
        raise RuntimeError(f"Failed to execute query: {e}")

    print('Exporting data into JSON file')
    # Add metadata
    metadata = {
        "file_id": f"{date_of_run}_service_master",#f"{date_of_run}_temp_cdt",#
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "source_system": "COST-ESTIMATOR-GCP",
        "destination_system": "AETNA HEALTH-AWS",
        "data": records.to_dict(orient="records"),  # Convert DataFrame to a list of dictionaries
        "checksum": str(uuid.uuid4()),  # Randomly generated checksum
        "schema_version": "1.0",
    }

    # Convert metadata to JSON string
    metadata_json = json.dumps(metadata, indent=4)

    # Upload JSON directly to GCS
    target_credentials_gcs = impersonated_credentials.Credentials(credential, target_principal=resource_sa, target_scopes=[
    "https://www.googleapis.com/auth/cloud-platform"])
    client = storage.Client(project=PROJECT_ID,credentials=target_credentials_gcs)
    bucket = client.bucket(bucket_name)
    blob = bucket.blob(f"service_code_master/{date_of_run}_service_master.json")
    #bucket.blob(f"service_code_master/{date_of_run}_temp_cdt.json")
    
    blob.upload_from_string(metadata_json, content_type="application/json")
    log.info('Service Code master file {} populated successfully'.format(blob))


# Function to transfer the JSON file from GCS to AWS SFTP
# This function would contain the logic to transfer the file
def sftp_gcs_aws(DAG_ID, PROJECT_ID, RESOURCE_SA,DATA_BUCKET, PK_FILE, s3_host_name, s3_username, date_of_run):
    try:
        import pysftp
        from google.cloud import storage
        import os
        import shutil
        from pathlib import Path
        from google.cloud import secretmanager
        import google.auth
        from google.auth import impersonated_credentials
        import requests

        credentials, project = google.auth.default()

        print("#############################################")
        print("#############################################")
        print("#############################################")
        # Create a directory in composer node
        cwd = os.getcwd()
        print("current working dir: {}".format(cwd))
        local_sftp_dir = cwd + f"/{DAG_ID}"
        print("composer node sftp directory: {}".format(local_sftp_dir))
        Path(local_sftp_dir).mkdir(parents=True, exist_ok=True)

        try:
            response = requests.get("https://api.ipify.org?format=json")
            response.raise_for_status()
            ip_address = response.json().get("ip")
            print(f"Public IP Address: {ip_address}")
    
        except requests.exceptions.RequestException as e:
            print(f"Error retrieving public IP address: {e}")
            return None

        # Download the file from gcs bucket
        storage_client = storage.Client()
        target_credentials = impersonated_credentials.Credentials(
                                source_credentials = credentials,
                                target_principal = RESOURCE_SA,
                                target_scopes = ["https://www.googleapis.com/auth/cloud-platform"], 
                                lifetime=3600)

        client = secretmanager.SecretManagerServiceClient(credentials=target_credentials)
        storage_client = storage.Client(credentials=target_credentials,project=PROJECT_ID)
        bucket = storage_client.get_bucket(DATA_BUCKET)
        blob = bucket.blob(PK_FILE)
        source_folder = "service_code_master"  # Replace with the path to your source folder.
        target_folder_sftp = "transparency"#"cost-transparency-bundles-npr" # Replace with the path to your target folder on SFTP server.
        files = bucket.list_blobs(prefix=source_folder)
        print(files)

        private_key_scm = blob.download_as_text()
        #tmp_key_path = os.path.abspath(ppk_file_path)
        tmp_key_path = '/tmp/temp_private_key.ppk'
        with open(tmp_key_path, 'w') as temp_key_file:
            temp_key_file.write(private_key_scm)


        cnopts = pysftp.CnOpts()
        cnopts.compression = True
        cnopts.hostkeys = None
        


        with pysftp.Connection(host=s3_host_name, username=s3_username,private_key= tmp_key_path, cnopts =cnopts) as sftp:
            if not sftp.exists(target_folder_sftp):
                sftp.mkdir(target_folder_sftp)
                print(f'SFTP directory "{target_folder_sftp}" created')
            sftp.chdir(target_folder_sftp)
    
        # Iterate through files in the source folder
            for filename in files:
                if date_of_run in filename.name:
                    file_blob = bucket.blob(filename.name)
                    file_service = file_blob.download_as_text()
                    local_file_path = filename.name.split('/')[1]
                    with open(local_file_path, 'w') as temp_json_file:
                        temp_json_file.write(file_service)
                    sftp.put(local_file_path)
                    print(sftp.listdir())
                    os.remove(local_file_path)
            target_file_count = len(sftp.listdir())
            print(f"total number of files uploaded in s3 : {target_file_count}")
            # sftp.close()
            # kwargs['ti'].xcom_push(key='target_file_count', value=target_file_count)
        os.remove(tmp_key_path)
        


    except Exception as err:
        raise Exception(err)

    finally:
        # Deleting local copy
        if os.path.exists(local_sftp_dir):
            # removing directory
            shutil.rmtree(local_sftp_dir, ignore_errors=False)
##
    
    

def get_public_ip():
    import requests
    try:
        response = requests.get("https://api.ipify.org?format=json")
        response.raise_for_status()
        ip_address = response.json().get("ip")
        print(f"Public IP Address: {ip_address}")
    
    except requests.exceptions.RequestException as e:
        print(f"Error retrieving public IP address: {e}")
        return None
    

# Set up the default arguments for the DAG
default_args = {
    "start_date": days_ago(1),
    "project_id": PROJECT_ID,
    "retries": 0,
    "email_on_failure": False,
    "depends_on_past": False,
    "email_on_retry": False,
    "on_success_callback": ec.success_call,
    "on_failure_callback": ec.fail_call,
}

with DAG(
    DAG_ID,
    schedule_interval=None,
    default_args=default_args,
    is_paused_upon_creation=True,
    catchup=False, 
    tags=ct.DAG_TAGS,  # has to be included as per ANBC
) as dag:

    scm_source_tables_duplicate_check  = PythonOperator(
                task_id="scm_source_tables_duplicate_check",
                python_callable=check_duplicate_counts ,  # entrypoint
                dag=dag
    )   
    # Task 2: Export the filtered table to GCS
    extract_bigquery_to_json = PythonOperator(
                                task_id="generate_final_json",
                                python_callable=generate_final_json,
                                provide_context=True,
                            )
    
    run_gcs_aws = PythonVirtualenvOperator(
        task_id="run_gcs_aws",
        dag=dag,
        python_callable=sftp_gcs_aws,
        op_args=[DAG_ID, PROJECT_ID, resource_sa,data_bucket, PK_FILE, s3_host_name, s3_username, date_of_run ],
        requirements=[
            "pysftp", "google-cloud-secret-manager==2.16.0"
        ],
        system_site_packages=True,
    )

    # Define task dependencies
    scm_source_tables_duplicate_check >> extract_bigquery_to_json >> run_gcs_aws
