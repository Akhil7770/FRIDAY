import hashlib, sys, os, time, argparse, site, logging, json

from google.cloud import bigquery
import google.auth
from google.auth import impersonated_credentials
from google.cloud import storage
import pandas as pd
import datetime as dt
import subprocess
from pandas.io import gbq
import zipfile
import io
import re
import gcsfs
import email_context as ec
import calling_config as ct
from datetime import datetime
#from config import config

sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))
logging = logging.getLogger("airflow.task")
CUR_DIR = os.path.abspath(os.path.dirname(__file__))

job_start_load_dts = dt.datetime.now()

logging.info("Job Start Time : {}".format(job_start_load_dts))
# logging.info('Log File: {}'.format(log_file_name))

# Config File Setup
PROJECT_ID = os.environ.get("GCP_PROJECT").replace("-hcb","")+'-prv-ps-ce'
# constant vars
resource_sa = f"gchcb-prv-ps-ce-ontpd@{PROJECT_ID}.iam.gserviceaccount.com"
decrypt_sa = f"gchcb-prv-ps-ce-dec-ontpd@{PROJECT_ID}.iam.gserviceaccount.com"
TENANT = 'prv-ps-ce'
USER = ct.config["config"]["USER"]
GCP_ENV = ct.config["config"]["GCP_ENV"]

DAG_PATH = os.environ.get('DAGS_FOLDER')

code_bucket = ct.config["config"]["CODE_BUCKET"]
data_bucket = ct.config["config"]["DATA_BUCKET"]

COSTCENTER = ct.config["config"]["COSTCENTER"]

now = datetime.now()
date_of_run = now.strftime("%Y%m%d") #'05022025'
app_read_tables = ct.config["config"]["APP_READ_TABLES"]
databases = ct.config["config"]["bq_dataset"]
owner_name = f"{USER}_aetna_com"
bucket_name = ct.config['config']['CE_DATA_BUCKET']
project_id_ce = ct.config['config']['bq_dataset']['ce_project']
dataset_id = ct.config['config']['bq_dataset']['ce_dataset']
dec_dataset_id = ct.config['config']['bq_dataset']['ce_dec_dataset']
provider_ds_hcb_dev = ct.config['config']['bq_dataset']['provider_ds_hcb_dev']
scm_in_scope = ct.config['config']['APP_READ_TABLES']['scm_in_scope']
specialty_mapping_final = ct.config['config']['APP_READ_TABLES']['specialty_mapping_final']
ce_scm = ct.config['config']['APP_READ_TABLES']['ce_scm']
LABELS_CALL = ct.config["config"]["labels"]["CREATE_TABLE_LABEL"]
LABELS = LABELS_CALL.format(OWNER=owner_name, COSTCENTER=COSTCENTER)
credential, project = google.auth.default()
target_credentials = impersonated_credentials.Credentials(credential, target_principal=decrypt_sa, target_scopes=[
    "https://www.googleapis.com/auth/cloud-platform"])
bq_client = bigquery.Client(project=PROJECT_ID, credentials=target_credentials) # EngX Compute

def check_duplicate_counts():
    # Initialize BigQuery client
    # Query 1
    query1 = f"""
    SELECT COUNT(*) AS count FROM (
    SELECT servc_cd, servc_type 
    FROM {project_id_ce}.{dataset_id}.scsr_dtl_unique
    GROUP BY servc_cd, servc_type 
    HAVING COUNT(*) > 1);
    """
    query_job1 = bq_client.query(query1)
    result1 = query_job1.result()
    count1 = [row['count'] for row in result1][0]
    print(f"scsr_dtl_unique: Duplicate Count = {count1}")
    if count1 > 0:
        raise ValueError(f"Error: {query1} returned a count greater than 0 (Count = {count1}).")

    # Query 2
    query2 = f"""
    SELECT COUNT(*) AS count FROM (
    SELECT primary_svc_cd, servc_type 
    FROM {project_id_ce}.{dataset_id}.{scm_in_scope}
    GROUP BY primary_svc_cd, servc_type 
    HAVING COUNT(*) > 1);
    """
    query_job2 = bq_client.query(query2)
    result2 = query_job2.result()
    count2 = [row['count'] for row in result2][0]
    print(f"scm_in_scope: Duplicate Count = {count2}")
    if count2 > 0:
        raise ValueError(f"Error: {query2} returned a count greater than 0 (Count = {count2}).")

    # Query 3
    query3 = f"""
    SELECT COUNT(*) AS count FROM (
    SELECT primary_svc_cd, servc_type 
    FROM {project_id_ce}.{dataset_id}.default_combos
    GROUP BY primary_svc_cd, servc_type 
    HAVING COUNT(*) > 1);
    """
    query_job3 = bq_client.query(query3)
    result3 = query_job3.result()
    count3 = [row['count'] for row in result3][0]
    print(f"default_combos: Duplicate Count = {count3}")
    if count3 > 0:
        raise ValueError(f"Error: {query3} returned a count greater than 0 (Count = {count3}).")

    # Query 4
    query4 = f"""
    SELECT COUNT(*) AS count FROM (
    SELECT primary_svc_cd, servc_type 
    FROM {project_id_ce}.{provider_ds_hcb_dev}.{specialty_mapping_final}
    GROUP BY primary_svc_cd, servc_type 
    HAVING COUNT(*) > 1);
    """
    query_job4 = bq_client.query(query4)
    result4 = query_job4.result()
    count4 = [row['count'] for row in result4][0]
    print(f"specialty_mapping_final: Duplicate Count = {count4}")
    if count4 > 0:
        raise ValueError(f"Error: {query4} returned a count greater than 0 (Count = {count4}).")

    # Query 5
    query5 = f"""
    SELECT COUNT(*) AS count FROM (
    SELECT primary_svc_cd, servc_type 
    FROM {project_id_ce}.{dataset_id}.SCM_deduped_26082025
    GROUP BY primary_svc_cd, servc_type 
    HAVING COUNT(*) > 1);
    """
    query_job5 = bq_client.query(query5)
    result5 = query_job5.result()
    count5 = [row['count'] for row in result5][0]
    print(f"SCM_deduped_26082025: Duplicate Count = {count5}")
    if count5 > 0:
        raise ValueError(f"Error: {query5} returned a count greater than 0 (Count = {count5}).")

    # Query 6
    query6 = f"""
    SELECT COUNT(*) AS count FROM (
    SELECT primary_svc_cd, servc_type 
    FROM `{project_id_ce}.{dec_dataset_id}.{ce_scm}`
    GROUP BY primary_svc_cd, servc_type 
    HAVING COUNT(*) > 1);
    """
    query_job6 = bq_client.query(query6)
    result6 = query_job6.result()
    count6 = [row['count'] for row in result6][0]
    print(f"service_code_master: Duplicate Count = {count6}")
    if count6 > 0:
        raise ValueError(f"Error: {query6} returned a count greater than 0 (Count = {count6}).")

    print("All queries passed with count = 0.")
