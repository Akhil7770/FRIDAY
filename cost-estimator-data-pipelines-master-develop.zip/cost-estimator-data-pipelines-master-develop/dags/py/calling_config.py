import os
import json
from google.protobuf.duration_pb2 import Duration

#-----------------------------------------------------------------------------
# THIS FILE CONTAINS ALL CONFIG LEVEL DETAILS AND DAG_TAGS-- PATH OF CONFIG AND READING CONFIG IS BEING DONE IN THIS PYTHON FILE
#-----------------------------------------------------------------------------

PROJECT_ID = os.environ.get("GCP_PROJECT").replace("-hcb","")+'-prv-ps-ce'  # changed the id to prv-ps-ce from -prv-cda
DAG_PATH = os.environ.get('DAGS_FOLDER')
ENV = os.environ.get("GCP_PROJECT").split('-')[-1]
IMAGE_VERSION = '1.5.53-centos8'

# connect_sa = f"provider-de-hcb-connect@anbc-hcb-dev.iam.gserviceaccount.com"
RESOURCE_SA = f"gchcb-prv-ps-ce-ontpd@anbc-{ENV}-prv-ps-ce.iam.gserviceaccount.com"
# RESOURCE_SA = f"gchcb-pricing-arme-ontpd@{PROJECT_ID}-prv-cda.iam.gserviceaccount.com"
CONFIG_BUCKET = f"provider-de-data-hcb-{ENV}"
PIP_PACKAGES = "google-cloud-bigquery,pandas,google-cloud-logging,google-api-python-client,google-auth,google-auth-httplib2,google-auth-oauthlib,google-cloud-bigquery-storage,pydata-google-auth,pandas-gbq"
print(ENV,DAG_PATH)


config_path = 'prv-ps-ce-hcb/cost-estimator-data-pipelines/config/' # changed the path from 'prv-cda-hcb/rfl-caregiver/config/'
config_path = os.path.join(DAG_PATH, config_path)

airflow_env_config_path = 'prv-ps-ce-hcb/cost-estimator-data-pipelines/config/'   # changed the path from 'prv-cda-hcb/rfl-caregiver/config/'
airflow_config_path = os.path.join(DAG_PATH, airflow_env_config_path)

subnetwork_uri = f"io-hcb-{ENV}-vm"
safe_config_file = f'{ENV}_cfg.json'
safe_airflow_config_file = f'airflow_{ENV}_config.json'

config_path = os.path.join(config_path, safe_config_file)
airflow_config_path = os.path.join(airflow_config_path, safe_airflow_config_file)

if not os.path.exists(config_path):
    raise FileNotFoundError(f"Configuration file {config_path} does not exist.")
if not os.path.exists(airflow_config_path):
    raise FileNotFoundError(f"Airflow configuration file {airflow_config_path} does not exist.")

with open(config_path) as f:
    config = json.load(f)
print(config)

with open(airflow_config_path) as f1:
    ae_config = json.load(f1)
    
DAG_TAGS = ["tenant:prv-ps-ce", f"owner:{config['config']['USER']}@aetna.com"]
du = Duration()
ttl = du.FromSeconds(3600)
print(DAG_TAGS)


cluster_config_load = {
    "master_config": {
        "num_instances": 1,
        "machine_type_uri": "n2-standard-2",
        "disk_config": {"boot_disk_size_gb": 500}
    },
    "worker_config": {
        "num_instances": 2,
        "machine_type_uri": "n2-standard-2",
        "disk_config": {"boot_disk_size_gb": 500}
    },
    "secondary_worker_config": {
        "num_instances": 0,
        "machine_type_uri": "n2-standard-2",
        "disk_config": {"boot_disk_size_gb": 500},
        "preemptibility": "NON_PREEMPTIBLE"
    },
    "software_config": {
        "image_version": IMAGE_VERSION,
        "properties": {
            "dataproc:efm.spark.shuffle": "primary-worker",
            "dataproc:efm.mapreduce.shuffle": "hcfs",
	        "dataproc:pip.packages": PIP_PACKAGES
        }
    },
    "gce_cluster_config": {
        "zone_uri": "us-east4-a",
        "subnetwork_uri": subnetwork_uri,
        "internal_ip_only": True,
        "tags": [
            "io-dataproc"
        ],
        "service_account": RESOURCE_SA,
        "service_account_scopes": [
            "https://www.googleapis.com/auth/cloud-platform"
        ]

    },
    "config_bucket": CONFIG_BUCKET
}
