import json
import logging
import os
from airflow.utils.email import send_email
#os.system('pip3 install pendulum')
import pendulum


SUB_APP='cost-cost-estimator-data-pipelines' #changed from rfl_caregiver


success_to_mail=["amanullam@aetna.com"]
success_cc_mail = [""]

fail_to_mail=["amanullam@aetna.com"]
fail_cc_mail=[""]


def merge(*args):
    j = {}
    for i in args:
        j.update(i)
    return j


def success_call(context):
    email_function(context, "Success")


def fail_call(context):
    email_function(context, "Failed")

date_timezone=str(pendulum.now('US/Eastern'))

def email_function(context,status):
    dag_run = context.get('dag_run')
    task_id = context["task_instance"].task_id
    DAG_ID = context["task_instance"].dag_id
    logs_url = context.get('task_instance').log_url
    if task_id == "DAG_Successfully_Executed":
        to_email = success_to_mail
        cc_email = success_cc_mail
        msg = '''
            <tr>
                    <p>Hi ,</p> 
                    <p>Below are the details about the run</p>
                    
                    <p>Dag_id   : %s,</p> 
                    <p>Task_id  : %s,</p> 
                    <p>Status   : <b style="color:green;">%s</b>,</p>
                    <p>Date_Time: %s,</p>
                    <p>Log_URL  : %s,</p>
                    <p>              </p>
                    <p>Thanks,\n     </p>
                    <p>IO-OPS       </p>
            </tr>
          '''% (DAG_ID,task_id,status,date_timezone,logs_url) 
    else:
        to_email = fail_to_mail
        cc_email = fail_cc_mail
        msg = '''
            <tr>
                    <p>Hi ,</p> 
                    <p>Below are the details about the run</p>
                    
                    <p>Dag_id   : %s,</p> 
                    <p>Task_id  : %s,</p> 
                    <p>Status   :  <b style="color:red;">%s</b>,</p>
                    <p>Date_Time: %s,</p>
                    <p>Log_URL  : %s,</p>
                    <p>              </p>
                    <p>Thanks,\n     </p>
                    <p>IO-OPS       </p>
            </tr>
          '''% (DAG_ID,task_id,status,date_timezone,logs_url)
        
        
    subject = SUB_APP+ " : Composer Dag Status: task id: " + task_id + "   " + status + "!!"  

    send_email(to=to_email,cc=cc_email, subject=subject, html_content=msg)
