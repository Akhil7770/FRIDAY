from abc import ABC, abstractmethod
from typing import List

from app.schemas.accumulator_response import AccumulatorResponse
from app.schemas.benefit_response import BenefitApiResponse, Benefit
from app.schemas.cost_estimator_request import ProviderInfo


class BenefitAccumulatorMatcherServiceInterface(ABC):
    @abstractmethod
    def get_selected_benefits(
        self,
        membershipId: str,
        benefit_response: BenefitApiResponse,
        accumulator_response: AccumulatorResponse,
        provider_info: ProviderInfo,
        isOutofNetwork: bool,
        pcp_specialty_codes: List[str],
    ) -> List[Benefit]:
        """
        Get all data needed for member pay calculation by matching benefit tiers and accumulators.

        Args:
            membershipId: Member ID for accumulator matching
            benefit_response: Response from benefit service
            accumulator_response: Response from accumulator service
            provider_info: Provider information including specialty and tier
            isOutofNetwork: Whether the provider is out of network
            pcp_specialty_codes: List of specialty codes that qualify as PCP

        Returns:
            List of selected benefits with matched accumulators
        """
        pass
