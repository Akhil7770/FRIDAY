from abc import ABC, abstractmethod
from typing import List

from app.models.rate_criteria import NegotiatedRate
from app.schemas.cost_estimator_request import CostEstimatorRequest


class CostEstimationServiceInterface(ABC):
    @abstractmethod
    async def estimate_cost(self, request):
        pass

    @abstractmethod
    async def get_rate_only(
        self, request: CostEstimatorRequest
    ) -> List[NegotiatedRate]:
        pass
