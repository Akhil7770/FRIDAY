from typing import Dict, Any
from abc import ABC
import ssl
import os

import aiohttp
from tenacity import retry, stop_after_attempt, wait_exponential

from app.core.logger import logger
from app.core.circuitbreaker.circuit_breaker import circuit_breaker
from app.core.observability.metrics.metrics_decorators import response_time
from app.services.token_service import TokenServiceInterface


class TokenServiceImpl(TokenServiceInterface):
    """Service for handling authentication token operations."""

    def __init__(self):
        # Create SSL context that doesn't verify certificates
        self.ssl_context = ssl.create_default_context()
        self.ssl_context.check_hostname = False
        self.ssl_context.verify_mode = ssl.CERT_NONE

    @circuit_breaker("token_service")
    @retry(
        stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=4, max=10)
    )
    @response_time("token_api", "get_new_token")
    async def get_token(self) -> Dict[str, Any]:
        """
        Get a new authentication token.

        Returns:
            Dict[str, Any]: Token data containing access_token and id_token

        Raises:
            Exception: If token retrieval fails
        """
        headers = {
            "Content-Type": "application/x-www-form-urlencoded",
        }

        TOKEN_URL = os.getenv("TOKEN_URL")

        if not TOKEN_URL:
            raise ValueError("TOKEN_URL environment variable is not set")
        # For form-urlencoded, use data instead of json
        payload = {
            "scope": "APPPII APPPHI",
            "grant_type": "client_credentials",
            "client_id": os.getenv("CLIENT_ID"),
            "client_secret": os.getenv("CLIENT_SECRET"),
        }

        try:
            connector = aiohttp.TCPConnector(ssl=self.ssl_context)
            async with aiohttp.ClientSession(connector=connector) as session:
                async with session.post(
                    url=TOKEN_URL, headers=headers, data=payload
                ) as response:
                    if response.status == 200:
                        token_data = await response.json()
                        logger.info("Successfully retrieved new token")
                        return token_data
                    else:
                        error_msg = (
                            f"Failed to get new token. Status: {response.status}"
                        )
                        logger.error(error_msg)
                        raise Exception(error_msg)
        except Exception as e:
            logger.error(f"Error in get_new_token: {str(e)}")
            raise
