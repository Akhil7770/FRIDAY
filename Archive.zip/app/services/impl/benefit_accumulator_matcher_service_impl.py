from typing import List

from app.core.logger import logger
from app.exception.exceptions import BenefitsNotFoundException
from app.models.selected_benefit import SelectedBenefit, SelectedCoverage
from app.schemas.accumulator_response import AccumulatorResponse
from app.schemas.benefit_response import BenefitApiResponse, Benefit
from app.schemas.cost_estimator_request import ProviderInfo
from app.services.benefit_accumulator_matcher_service import (
    BenefitAccumulatorMatcherServiceInterface,
)


class BenefitAccumulatorMatcherServiceImpl(BenefitAccumulatorMatcherServiceInterface):
    """Unified service implementation for matching benefit tiers and accumulators."""

    def get_selected_benefits(
        self,
        membershipId: str,
        benefit_response: BenefitApiResponse,
        accumulator_response: AccumulatorResponse,
        provider_info: ProviderInfo,
        isOutofNetwork: bool,
        pcp_specialty_codes: List[str],
    ) -> List[SelectedBenefit]:
        """
        Returns a list of benefits matching the provider tier and speciality.
        """
        try:
            selected_benefits: List[SelectedBenefit] = []

            if provider_info.speciality.code in pcp_specialty_codes:
                provider_designation = "PCP"
            else:
                provider_designation = None
            provider_tier = provider_info.providerNetworkParticipation.providerTier

            for service_info_item in benefit_response.serviceInfo:
                for benefit in service_info_item.benefit:

                    if (
                        benefit.networkCategory == "InNetwork" and not isOutofNetwork
                    ) or (benefit.networkCategory == "OutofNetwork" and isOutofNetwork):

                        # obtain provider designation from benefit
                        benefit_provider_designation = None
                        for service_provider in benefit.serviceProvider:
                            if service_provider.providerDesignation != "":
                                benefit_provider_designation = (
                                    service_provider.providerDesignation
                                )
                                break

                        benefit_tier = (
                            benefit.benefitTier.benefitTierName
                            if benefit.benefitTier
                            else ""
                        )

                        if provider_tier == "" and benefit_tier != "":
                            logger.error(f"Not expecting any tiered benefits")
                            continue

                        if (
                            provider_designation is None
                            or (
                                provider_designation is not None
                                and benefit_provider_designation is not None
                                and provider_designation == benefit_provider_designation
                            )
                        ) and provider_tier == benefit_tier:
                            if (
                                provider_designation is not None
                                and provider_designation.upper() == "PCP"
                            ):
                                logger.info(
                                    f"Adding PCP benefit for benefit code {benefit.benefitCode}"
                                )
                            if (
                                benefit.benefitProvider
                                and benefit.benefitProvider.upper() == "CVSMINCL"
                            ):
                                logger.info(
                                    f"Adding Minute Clinic benefit for benefit code {benefit.benefitCode}"
                                )
                            selected_benefit = self._build_benefit_with_accumulators(
                                membershipId, benefit, accumulator_response
                            )
                            selected_benefits.append(selected_benefit)

            return selected_benefits

        except Exception as e:
            logger.error(f"Error finding matching benefits: {str(e)}")
            if "Not finding matching benefits for provider" in str(e):
                raise BenefitsNotFoundException(
                    f"Not finding matching benefits for provider"
                )
            return []

    def _build_benefit_with_accumulators(
        self,
        membershipId: str,
        benefit: Benefit,
        accumulator_response: AccumulatorResponse,
    ) -> SelectedBenefit:
        """
        Build a benefit object with matched accumulators.
        """
        try:
            # initialize selected coverage with all fields from benefit.coverages[0] except relatedAccumulators list
            selected_coverage = SelectedCoverage(
                **{
                    k: v
                    for k, v in benefit.coverages[0].__dict__.items()
                    if k != "relatedAccumulators"
                },
            )
            # initialize selected benefit with all fields from benefit except coverages list
            selected_benefit = SelectedBenefit(
                coverage=selected_coverage,
                **{k: v for k, v in benefit.__dict__.items() if k != "coverages"},
            )

            related_accumulators = benefit.coverages[0].relatedAccumulators
            member = accumulator_response.get_member_by_id(membershipId)

            if related_accumulators and member:
                for rel_acc in related_accumulators:
                    # If code is empty string, set it to 'Limit' (matching the mock data format)
                    if rel_acc.code == "":
                        rel_acc.code = "Limit"

                    for member_acc in member.accumulators:
                        if member_acc.matches(rel_acc):
                            selected_benefit.coverage.matchedAccumulators.append(
                                member_acc
                            )
                            break  # Only one match per related accumulator

            return selected_benefit

        except Exception as e:
            logger.error(f"Error matching accumulators to benefits: {str(e)}")
            return selected_benefit
