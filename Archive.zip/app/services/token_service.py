from typing import Dict, Any
from abc import ABC, abstractmethod


class TokenServiceInterface(ABC):
    """Service for handling authentication token operations."""

    @abstractmethod
    async def get_token(self) -> Dict[str, Any]:
        pass
