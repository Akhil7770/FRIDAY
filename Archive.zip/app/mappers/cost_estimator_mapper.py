from typing import List

from app.models.rate_criteria import CostEstimatorRateCriteria
from app.schemas.benefit_request import (
    BenefitRequest,
    ServiceInfo,
    ServiceCodeInfo,
    ProviderType,
    PlaceOfService,
    ProviderSpecialty,
    Modifier,
    SupportingServiceCodes,
)
from app.exception.exceptions import ProviderNotFoundException
from app.schemas.cost_estimator_request import CostEstimatorRequest


class CostEstimatorMapper:
    @staticmethod
    def to_benefit_request(request: CostEstimatorRequest) -> List[BenefitRequest]:
        """
        Maps a RequestModel to a BenefitRequest.

        Args:
            request (RequestModel): The input request model

        Returns:
            BenefitRequest: The mapped benefit request
        """
        benefit_requests = []
        if request.providerInfo is not None:
            for provider in request.providerInfo:
                service_info = ServiceInfo(
                    serviceCodeInfo=ServiceCodeInfo(
                        code=request.service.code.strip(),
                        type=request.service.type.strip(),
                        modifier=(
                            [
                                Modifier(
                                    code=request.service.modifier.modifierCode.strip()
                                )
                            ]
                            if hasattr(request.service, "modifier")
                            and hasattr(request.service.modifier, "modifierCode")
                            and request.service.modifier.modifierCode.strip()
                            else []
                        ),
                        supportingServiceCodes=(
                            [
                                SupportingServiceCodes(
                                    code=request.service.supportingService.code.strip(),
                                    type=request.service.supportingService.type.strip(),
                                )
                            ]
                            if hasattr(request.service, "supportingService")
                            and hasattr(request.service.supportingService, "code")
                            and request.service.supportingService.code.strip()
                            else []
                        ),
                        providerType=[ProviderType(code=provider.providerType)],
                        placeOfService=[
                            PlaceOfService(code=request.service.placeOfService.code)
                        ],
                        providerSpecialty=[
                            ProviderSpecialty(
                                code=(
                                    provider.speciality.code.strip()
                                    if hasattr(provider, "speciality")
                                    and hasattr(provider.speciality, "code")
                                    else ""
                                )
                            )
                        ],
                        pin=provider.providerIdentificationNumber.strip(),  # Default empty PIN for now
                    )
                )
                benefit_request = BenefitRequest(
                    membershipID=request.membershipId.strip(),
                    benefitProductType=request.benefitProductType,
                    serviceInfo=[service_info],
                )
                benefit_requests.append(benefit_request)

        return benefit_requests

    @staticmethod
    def to_rate_criteria(
        request: CostEstimatorRequest,
    ) -> List[CostEstimatorRateCriteria]:
        """
        Maps a RequestModel to CostEstimatorRateCriteria.

        Args:
            request (CostEstimatorRequest): The input request model

        Returns:
            CostEstimatorRateCriteria: The mapped rate criteria
        """
        if request.providerInfo is None:
            # Set default values when providerInfo is not available
            return [
                CostEstimatorRateCriteria(
                    providerIdentificationNumber="",
                    serviceCode=request.service.code.strip(),
                    serviceType=request.service.type.strip(),
                    serviceLocationNumber="",
                    networkId=None,
                    placeOfService=request.service.placeOfService.code.strip(),
                    zipCode=request.zipCode.strip(),
                    isOutofNetwork=True,
                    providerSpecialtyCode=None,
                    providerType=None,
                )
            ]
        if len(request.providerInfo) == 0:
            raise ProviderNotFoundException("ProviderInfo list is empty")
        else:
            # Use the first providerInfo when available
            return [
                CostEstimatorRateCriteria(
                    providerIdentificationNumber=provider.providerIdentificationNumber.lstrip(
                        "0"
                    )
                    or "0",
                    serviceCode=request.service.code.strip(),
                    serviceType=request.service.type.strip(),
                    serviceLocationNumber=provider.serviceLocation.lstrip("0") or "0",
                    networkId=provider.providerNetworks.networkID.zfill(5),
                    placeOfService=request.service.placeOfService.code.strip(),
                    zipCode=request.zipCode.strip(),
                    isOutofNetwork=False,
                    providerSpecialtyCode=provider.speciality.code.strip(),
                    providerType=provider.providerType,
                )
                for provider in request.providerInfo
            ]
