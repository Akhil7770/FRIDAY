SELECT Max(RATE) AS RATE
FROM CET_RATES
WHERE
    RATE_SYSTEM_CD = @ratesystemcd
    AND SERVICE_CD = @servicecd
    AND SERVICE_TYPE_CD = @servicetype
    AND GEOGRAPHIC_AREA_CD = @geographicareacd
    AND PLACE_OF_SERVICE_CD = @placeofservice
    AND (PRODUCT_CD = @productcd OR PRODUCT_CD = 'ALL')
    AND CONTRACT_TYPE = 'S'