import asyncio
import time
from concurrent.futures import ThreadPoolExecutor
from contextlib import asynccontextmanager
from typing import Optional, List, Dict, Any

from google.cloud.spanner_v1 import SpannerAsyncClient

from app.core.logger import logger


class SpannerClient:
    def __init__(
        self,
        project_id: str,
        instance_id: str,
        database_id: str,
        max_workers: int = 40,
        pool_size: int = 20,
    ):
        """Initialize async Spanner client with proper connection pooling."""
        self.project_id = project_id
        self.instance_id = instance_id
        self.database_id = database_id
        self.max_workers = max_workers
        self.pool_size = pool_size

        # Create database path
        self.database_path = (
            f"projects/{project_id}/instances/{instance_id}/databases/{database_id}"
        )

        # Connection pool - stores (client, session) tuples
        self._client_pool = asyncio.Queue(maxsize=pool_size)
        self._executor = ThreadPoolExecutor(max_workers=max_workers)
        self._pool_initialized = False
        self._pool_lock = asyncio.Lock()

        logger.info(
            f"Async SpannerClient initialized for database: {self.database_path}"
        )
        logger.info(f"Connection pool size: {pool_size}, Max workers: {max_workers}")

    async def _initialize_pool(self):
        """Initialize the connection pool with pre-created clients and sessions."""
        if self._pool_initialized:
            return

        async with self._pool_lock:
            if self._pool_initialized:
                return

            logger.info(
                f"Initializing connection pool with {self.pool_size} connections..."
            )

            # Create connections in batches to avoid overwhelming the system
            batch_size = min(10, self.pool_size)
            for i in range(0, self.pool_size, batch_size):
                batch_tasks = []
                for j in range(min(batch_size, self.pool_size - i)):
                    batch_tasks.append(self._create_client_and_session())

                # Create batch of connections
                connections = await asyncio.gather(*batch_tasks, return_exceptions=True)

                # Add successful connections to pool
                successful_connections = 0
                for connection in connections:
                    if isinstance(connection, Exception):
                        logger.error(f"Failed to create connection: {connection}")
                    else:
                        await self._client_pool.put(connection)
                        successful_connections += 1

                logger.info(
                    f"Added {successful_connections} connections to pool in this batch"
                )

                # Small delay between batches
                if i + batch_size < self.pool_size:
                    await asyncio.sleep(0.1)

            self._pool_initialized = True
            logger.info(
                f"Connection pool initialized with {self._client_pool.qsize()} connections"
            )

    async def _create_client_and_session(self):
        """Create a new client and session pair."""
        try:
            client = SpannerAsyncClient()
            session = await client.create_session(
                request={"database": self.database_path}
            )
            return (client, session)
        except Exception as e:
            logger.error(f"Failed to create client and session: {e}")
            raise

    async def _validate_session(self, client, session):
        """Validate that a session is still active."""
        try:
            # Try to get session info to validate it's still active
            await client.get_session(request={"name": session.name})
            return True
        except Exception as e:
            logger.warning(f"Session validation failed: {e}")
            return False

    @asynccontextmanager
    async def _get_client_and_session(self):
        """Context manager for getting client and session from pool."""
        # Ensure pool is initialized
        await self._initialize_pool()

        # Get connection from pool
        client, session = None, None
        try:
            logger.info(
                f"Requesting connection from pool. Available connections: {self._client_pool.qsize()}"
            )
            client, session = await asyncio.wait_for(
                self._client_pool.get(), timeout=30.0
            )
            logger.info(
                f"Successfully retrieved connection from pool. Remaining connections: {self._client_pool.qsize()}"
            )
        except asyncio.TimeoutError:
            logger.error("Timeout waiting for connection from pool")
            raise Exception("Connection pool exhausted")

        # Validate session before using it
        if not await self._validate_session(client, session):
            logger.warning("Retrieved session is invalid, creating new one")
            try:
                # Delete the invalid session
                await client.delete_session(request={"name": session.name})
            except Exception as e:
                logger.warning(f"Failed to delete invalid session: {e}")

            # Create a new session
            try:
                client, session = await self._create_client_and_session()
                logger.info("Created new session to replace invalid one")
            except Exception as e:
                logger.error(f"Failed to create new session: {e}")
                raise

        try:
            yield client, session
        finally:
            # Return connection to pool
            try:
                logger.info(
                    f"Returning connection to pool. Available connections before return: {self._client_pool.qsize()}"
                )
                await self._client_pool.put((client, session))
                logger.info(
                    f"Successfully returned connection to pool. Available connections after return: {self._client_pool.qsize()}"
                )
            except Exception as e:
                logger.error(f"Failed to return connection to pool: {e}")
                # If we can't return to pool, create a new one
                try:
                    logger.info("Creating replacement connection due to return failure")
                    new_connection = await self._create_client_and_session()
                    await self._client_pool.put(new_connection)
                    logger.info(
                        f"Successfully created and added replacement connection. Pool size: {self._client_pool.qsize()}"
                    )
                except Exception as create_error:
                    logger.error(
                        f"Failed to create replacement connection: {create_error}"
                    )

    async def execute_query(
        self, query: str, params: Optional[Dict[str, Any]] = None, max_retries: int = 2
    ) -> List[Dict[str, Any]]:
        """Execute a read-only query using pooled connections with retry logic."""
        start_time = time.time()
        last_exception = None

        for attempt in range(max_retries + 1):
            try:
                logger.info(f"Executing async query (attempt {attempt + 1}): {query}")
                logger.info(f"Query params: {params}")

                async with self._get_client_and_session() as (client, session):
                    logger.info(
                        f"Using pooled connection for query execution. Session: {session.name}"
                    )
                    # Execute query using session
                    request_data = {
                        "session": session.name,
                        "sql": query,
                        "params": params or {},
                    }

                    response = await client.execute_sql(request=request_data)

                    # Get column names from the result set metadata
                    columns = []
                    if hasattr(response, "metadata") and response.metadata:
                        columns = [
                            field.name for field in response.metadata.row_type.fields
                        ]
                    elif hasattr(response, "fields"):
                        columns = [field.name for field in response.fields]
                    else:
                        # Fallback: use generic column names if metadata not available
                        if response.rows:
                            columns = [
                                f"column_{i}" for i in range(len(response.rows[0]))
                            ]
                        else:
                            return []

                    # Convert to list of dictionaries with column names
                    rows = []
                    for row in response.rows:
                        row_dict = dict(zip(columns, row))
                        rows.append(row_dict)

                    execution_time = time.time() - start_time
                    logger.debug(
                        f"Query executed in {execution_time:.3f}s, returned {len(rows)} rows"
                    )
                    return rows

            except Exception as e:
                last_exception = e
                execution_time = time.time() - start_time

                # Check if this is a session-related error
                error_str = str(e).lower()
                is_session_error = any(
                    keyword in error_str
                    for keyword in [
                        "session does not exist",
                        "session not found",
                        "invalid session",
                        "session expired",
                    ]
                )

                if is_session_error and attempt < max_retries:
                    logger.warning(
                        f"Session error on attempt {attempt + 1}, retrying: {str(e)}"
                    )
                    # Clean up invalid sessions before retry
                    await self.cleanup_invalid_sessions()
                    continue
                else:
                    logger.error(
                        f"Error executing async read-only query after {execution_time:.3f}s: {str(e)}"
                    )
                    logger.error(f"Query: {query}")
                    logger.error(f"Params: {params}")
                    logger.error(f"Exception type: {type(e)}")
                    logger.error(f"Exception details: {e}")
                    break

        # If we get here, all retries failed
        execution_time = time.time() - start_time
        logger.error(
            f"Query failed after {max_retries + 1} attempts and {execution_time:.3f}s: {str(last_exception)}"
        )
        return []

    async def get_pool_status(self) -> Dict[str, Any]:
        """Get current pool status for monitoring."""
        return {
            "pool_size": self.pool_size,
            "available_connections": self._client_pool.qsize(),
            "pool_initialized": self._pool_initialized,
            "max_workers": self.max_workers,
        }

    async def cleanup_invalid_sessions(self):
        """Clean up invalid sessions from the pool."""
        logger.info("Starting cleanup of invalid sessions...")
        valid_connections = []
        invalid_count = 0

        # Get all connections from pool
        temp_connections = []
        while not self._client_pool.empty():
            try:
                connection = await self._client_pool.get()
                temp_connections.append(connection)
            except Exception as e:
                logger.error(f"Error getting connection during cleanup: {e}")

        # Validate each connection
        for client, session in temp_connections:
            if await self._validate_session(client, session):
                valid_connections.append((client, session))
            else:
                invalid_count += 1
                try:
                    await client.delete_session(request={"name": session.name})
                    logger.info(f"Deleted invalid session: {session.name}")
                except Exception as e:
                    logger.warning(f"Failed to delete invalid session: {e}")

        # Return valid connections to pool
        for connection in valid_connections:
            try:
                await self._client_pool.put(connection)
            except Exception as e:
                logger.error(f"Failed to return valid connection to pool: {e}")

        logger.info(
            f"Cleanup completed. Removed {invalid_count} invalid sessions, kept {len(valid_connections)} valid sessions"
        )
        return invalid_count

    async def close_pool(self):
        """Close all connections in the pool."""
        logger.info("Closing connection pool...")

        # Close all connections in pool
        while not self._client_pool.empty():
            try:
                client, session = await self._client_pool.get()
                await client.delete_session(request={"name": session.name})
            except Exception as e:
                logger.error(f"Error closing connection: {e}")

        self._pool_initialized = False
        logger.info("Connection pool closed")

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close_pool()
        logger.info("Async SpannerClient closed")
