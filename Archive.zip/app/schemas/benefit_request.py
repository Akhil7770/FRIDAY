from typing import List

from pydantic import BaseModel


class ProviderType(BaseModel):
    code: str


class PlaceOfService(BaseModel):
    code: str


class ProviderSpecialty(BaseModel):
    code: str


class Modifier(BaseModel):
    code: str


class SupportingServiceCodes(BaseModel):
    code: str
    type: str


class ServiceCodeInfo(BaseModel):
    code: str
    type: str
    modifier: List[Modifier]
    supportingServiceCodes: List[SupportingServiceCodes]
    placeOfService: List[PlaceOfService]
    providerType: List[ProviderType]
    providerSpecialty: List[ProviderSpecialty]
    pin: str


class ServiceInfo(BaseModel):
    serviceCodeInfo: ServiceCodeInfo


class BenefitRequest(BaseModel):
    """Model for benefit request data."""

    membershipID: str
    benefitProductType: str
    serviceInfo: List[ServiceInfo]
