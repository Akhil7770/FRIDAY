"""
OpenTelemetry Metrics for GCP Integration

This module contains OpenTelemetry metrics that will be exported to GCP.
"""

import os

# OpenTelemetry imports - assuming always available in GCP
from opentelemetry import metrics  # type: ignore
from opentelemetry.exporter.otlp.proto.grpc.metric_exporter import (  # type: ignore
    OTLPMetricExporter,
)
from opentelemetry.sdk.metrics import MeterProvider  # type: ignore
from opentelemetry.sdk.metrics.export import PeriodicExportingMetricReader  # type: ignore
from opentelemetry.sdk.resources import Resource  # type: ignore

from app.core.logger import logger

# Initialize metrics variables
meter = None
error_counter = None
response_time_histogram = None
exception_counter = None
request_counter = None


def initialize_metrics():
    """Initialize OpenTelemetry metrics."""
    global meter, error_counter
    global response_time_histogram, exception_counter, request_counter

    logger.info("Creating OpenTelemetry metrics...")

    error_counter = meter.create_counter(  # type: ignore
        name="cost_estimator_errors_total",
        unit="1",
        description="Total number of errors in cost estimation service",
    )
    # A counter is a metric type that:
    # Only increases (never decreases)
    # Tracks cumulative totals (total requests, total errors, etc.)
    # Resets to 0 when the application restarts
    # Provides rate calculations when queried over time
    request_counter = meter.create_counter(  # type: ignore
        name="cost_estimator_requests_total",
        unit="1",
        description="Total number of cost estimation requests",
    )

    response_time_histogram = meter.create_histogram(  # type: ignore
        name="response_time_seconds",
        unit="s",
        description="Response time for all API calls (benefit, accumulator, spanner, etc.)",
    )

    exception_counter = meter.create_counter(  # type: ignore
        name="cost_estimator_exception_total",
        unit="1",
        description="Total number of exceptions in cost estimation service",
    )

    logger.info("All metrics created successfully")


def get_meter():
    """Get the OpenTelemetry meter."""
    global meter
    if meter is None:
        meter = metrics.get_meter("cost_estimator_calc_service")
        logger.info("Meter created: %s", meter)
    return meter


# Configure OpenTelemetry metrics for GCP
# Note: gRPC endpoints should NOT include https:// prefix
otlp_endpoint = os.getenv(
    "OTEL_EXPORTER_OTLP_METRICS_ENDPOINT",
    "https://otelc-gmp-collector-grpc.hcb-dev.aig.aetna.com",
)

logger.info(f"OTLP endpoint: {otlp_endpoint}")
logger.info("Configuring OpenTelemetry metrics for GCP")
logger.info("OTLP endpoint: %s", otlp_endpoint)
logger.info("Service name: %s", os.getenv("OTEL_SERVICE_NAME", "APM0016344"))

# Create resource with service information
resource = Resource.create(
    {
        "service.name": os.getenv("OTEL_SERVICE_NAME", "APM0016344"),
        "service.version": "1.0.0",
        "deployment.environment": os.getenv("ENVIRONMENT", "unknown"),
    }
)

# Create OTLP exporter for GCP
# insecure=False means TLS is ENABLED (secure connection on port 443)
# insecure=True means TLS is DISABLED (insecure connection)
otlp_exporter = OTLPMetricExporter(
    endpoint=otlp_endpoint,
    insecure=True,
    timeout=30,
)

# Create metric reader
metric_reader = PeriodicExportingMetricReader(
    otlp_exporter,
    export_interval_millis=30000,  # Export every 30 seconds
    export_timeout_millis=30000,  # 30 second timeout
)

# Create and set meter provider
provider = MeterProvider(metric_readers=[metric_reader], resource=resource)
metrics.set_meter_provider(provider)
logger.info("OpenTelemetry metrics provider configured successfully")

# Get meter and initialize metrics
meter = metrics.get_meter("cost_estimator_calc_service")
initialize_metrics()

# Enable aiohttp client metrics instrumentation
try:
    from opentelemetry.instrumentation.aiohttp_client import AioHttpClientInstrumentor

    AioHttpClientInstrumentor().instrument(meter_provider=provider)
    logger.info("aiohttp client metrics instrumentation enabled")
except Exception as e:
    logger.warning(f"Failed to enable aiohttp client metrics: {e}")
