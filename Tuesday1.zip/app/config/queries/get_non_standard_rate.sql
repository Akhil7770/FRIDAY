SELECT
  payment_method_cd,
  service_group_changed_ind,
  service_grouping_priority_nbr,
  max(rate) AS rate
FROM CET_RATES
WHERE
  SERVICE_CD = @servicecd
  AND SERVICE_TYPE_CD = @servicetype
  AND PLACE_OF_SERVICE_CD = @placeofservice
  AND (PRODUCT_CD = @productcd OR PRODUCT_CD = 'ALL')
  AND PROVIDER_BUSINESS_GROUP_NBR IN UNNEST(@providerbusinessgroupnbr)
  AND CONTRACT_TYPE IN ('C', 'N')
GROUP BY payment_method_cd, service_group_changed_ind, service_grouping_priority_nbr;