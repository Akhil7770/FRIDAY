WITH base AS (
  SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    specialty_cd,
    rate
  FROM CET_RATES
  WHERE
    SERVICE_CD = @servicecd
    AND SERVICE_TYPE_CD = @servicetype
    AND PLACE_OF_SERVICE_CD = @placeofservice
    AND PRODUCT_CD IN (@productcd, 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR IN UNNEST(@providerbusinessgroupnbr)
    AND CONTRACT_TYPE IN ('C', 'N')
),
flag AS (
  SELECT EXISTS (SELECT 1 FROM base WHERE specialty_cd = @providerspecialtycode) AS has_providerspecialtycode
)
SELECT
  b.payment_method_cd,
  b.service_group_changed_ind,
  b.service_grouping_priority_nbr,
  MAX(b.rate) AS rate
FROM base b
CROSS JOIN flag f
WHERE b.specialty_cd = CASE WHEN f.has_providerspecialtycode THEN @providerspecialtycode ELSE '' END
GROUP BY
  b.payment_method_cd,
  b.service_group_changed_ind,
  b.service_grouping_priority_nbr;