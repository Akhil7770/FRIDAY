from typing import Optional, Dict

from fastapi import APIRouter, Header, Request

from app.core.logger import logger
from app.core.observability.tracing.tracing_decorators import trace_request_response
from app.core.observability.metrics.metrics_decorators import response_time
from app.core.service_factory import ServiceFactory
from app.schemas.cost_estimator_request import CostEstimatorRequest

service_factory = ServiceFactory()
cost_estimation_service = service_factory.cost_estimation_service()
router = APIRouter()


@router.post(
    "/rate",
    summary="Retrieve cost estimate for member",
    tags=["Cost Estimation"],
)
@trace_request_response(
    span_name="cost_estimation_endpoint",
    capture_request=True,
    capture_response=True,
    max_request_size=4096,
    max_response_size=4096,
    include_headers=True,
    sensitive_fields=[],
)
async def estimate_cost(request: CostEstimatorRequest, http_request: Request):
    # Extract headers from the FastAPI request object
    headers: Dict[str, str] = {}
    headers["x-eieusercontext"] = http_request.headers.get("x-eieusercontext", "")
    headers["x-eieapplication"] = http_request.headers.get("x-eieapplication", "")
    headers["x-eieversion"] = http_request.headers.get("x-eieversion", "")
    headers["x-apitransactionid"] = http_request.headers.get("x-apitransactionid", "")
    headers["x-global-transaction-id"] = http_request.headers.get(
        "x-global-transaction-id", ""
    )

    logger.info(f"Request New Headers: {headers}")

    # Call the service to get the cost estimation
    logger.info(f"Cost Estimation Request: {request}")
    response = await cost_estimation_service.estimate_cost(request, headers=headers)
    logger.info(f"Cost Estimation Response: {response}")
    return response


@router.post(
    "/rate-only",
    summary="Retrieve rate only for member",
    tags=["Cost Estimation"],
)
async def get_rate_only(
    request: CostEstimatorRequest,
):
    response = await cost_estimation_service.get_rate_only(request)
    return response
