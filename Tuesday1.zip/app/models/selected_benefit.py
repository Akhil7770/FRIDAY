from typing import List

from pydantic import BaseModel, Field

from app.schemas.accumulator_response import Accumulator
from app.schemas.benefit_response import BenefitTier, Prerequisite, ServiceProviderItem


class SelectedCoverage(BaseModel):
    sequenceNumber: int
    benefitDescription: str
    costShareCopay: float
    costShareCoinsurance: float
    copayAppliesOutOfPocket: str
    coinsAppliesOutOfPocket: str
    deductibleAppliesOutOfPocket: str
    deductibleAppliesOutOfPocketOtherIndicator: str
    copayCountToDeductibleIndicator: str
    copayContinueWhenDeductibleMetIndicator: str
    copayContinueWhenOutOfPocketMaxMetIndicator: str
    coinsuranceToOutOfPocketOtherIndicator: str
    copayToOutofPocketOtherIndicator: str
    isDeductibleBeforeCopay: str
    benefitLimitation: str
    isServiceCovered: str
    matchedAccumulators: List[Accumulator] = Field(default_factory=list)


class SelectedBenefit(BaseModel):
    benefitName: str
    benefitCode: int
    isInitialBenefit: str
    benefitTier: BenefitTier
    networkCategory: str
    prerequisites: List[Prerequisite]
    benefitProvider: str
    serviceProvider: List[ServiceProviderItem]
    coverage: SelectedCoverage
