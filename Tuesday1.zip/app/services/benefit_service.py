from abc import ABC, abstractmethod

from app.schemas.benefit_request import BenefitRequest
from app.schemas.benefit_response import BenefitApiResponse


class BenefitServiceInterface(ABC):
    @abstractmethod
    async def get_benefit(self, request: BenefitRequest) -> BenefitApiResponse:
        """
        Abstract method to get benefit information using a BenefitRequest object.
        Returns a BenefitApiResponse object.
        """
        pass
