from app.core.base import Handler, InsuranceContext


class ServiceCoverageHandler(Handler):
    """Check if service is covered"""

    def set_benefit_limitation_handler(self, handler):
        self._benefit_limitation_handler = handler
        return handler

    def process(self, context: InsuranceContext) -> InsuranceContext:
        if not context.is_service_covered:
            context.trace_decision("Process", "The service is not covered", False)
            return self._apply_no_coverage(context)

        context.trace_decision("Process", "The service is covered", True)

        return self._benefit_limitation_handler.handle(context)

    def _apply_no_coverage(self, context: InsuranceContext) -> InsuranceContext:
        """Apply logic when service isn't covered"""

        context.member_pays = context.service_amount
        context.service_amount = 0
        context.calculation_complete = True
        context.trace_decision(
            "Process",
            "The service is not covered",
            True,
        )

        context.trace("_apply_no_coverage", "Logic applied")

        return context
