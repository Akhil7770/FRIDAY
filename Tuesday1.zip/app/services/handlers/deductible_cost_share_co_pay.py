from app.core.base import Handler


class DeductibleCostShareCoPayHandler(Handler):
    """Determines any member cost share co pays and where to route logic"""

    def set_deductible_co_pay_handler(self, handler):
        self._deductible_co_pay_handler = handler
        return handler

    def set_deductible_co_insurance_handler(self, handler):
        self._deductible_co_insurance_handler = handler
        return handler

    def process(self, context):

        if context.copay_continue_when_deductible_met:
            context.trace_decision(
                "Process", "The Copay continue when deductible met", True
            )  # This logic determines path A (co-insurance) and B (co-pay)
            if context.cost_share_copay > 0:
                context.trace_decision(
                    "Process", "The cost share co-pay is greater than zero", True
                )
                return self._deductible_co_pay_handler.handle(context)
            else:
                context.trace_decision(
                    "Process", "The cost share co-pay is greater than zero", False
                )
                return self._deductible_co_insurance_handler.handle(context)
        else:
            context.trace_decision(
                "Process", "The Copay continue when deductible met", False
            )
            return self._deductible_co_insurance_handler.handle(context)
