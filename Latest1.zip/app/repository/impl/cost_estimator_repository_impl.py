from app.repository.cost_estimator_repository import CostEstimatorRepositoryInterface
from app.database.spanner_client import SpannerClient
from app.config.database_config import spanner_config
from app.config.queries import RATE_QUERIES
from app.core.logger import logger
from tenacity import retry, stop_after_attempt, wait_exponential
from app.core.circuitbreaker.circuit_breaker import circuit_breaker
from app.models.rate_criteria import CostEstimatorRateCriteria, NegotiatedRate
from typing import Any, Optional, List, Dict
from app.core.constants import (
    PERCENTAGE_PAYMENT_METHOD_CODES,
    PAYMENT_METHOD_HIERARCHY_CACHE_KEY,
    RATE_TYPE_PERCENTAGE,
    RATE_TYPE_AMOUNT,
    PCP_SPECIALTY_CODES_CACHE_KEY,
)
import pandas as pd
from pandas import DataFrame
from app.core.observability import response_time


class CostEstimatorRepositoryImpl(CostEstimatorRepositoryInterface):
    def __init__(self):
        """Initialize repository with Spanner client."""
        if not spanner_config.is_valid():
            raise ValueError(
                "Invalid Spanner configuration. Please check environment variables."
            )

        self.db = SpannerClient(
            project_id=spanner_config.project_id,
            instance_id=spanner_config.instance_id,
            database_id=spanner_config.database_id,
            max_workers=40,  # Increase for better parallelism
        )

        # Initialize cache as instance variable instead of on db object
        self._cache = {}

    @circuit_breaker("rate_repository")
    @retry(
        stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=4, max=10)
    )
    @response_time("spanner_rate_repository", "get_rate")
    async def get_rate(
        self, rate_criteria: CostEstimatorRateCriteria, *args, **kwargs
    ) -> NegotiatedRate:
        """
        Retrieve the rate based on network status and criteria.

        Args:
            is_out_of_network: Whether to get out-of-network rate
            rate_criteria: Criteria for rate lookup
            *args: Variable length argument list
            **kwargs: Arbitrary keyword arguments

        Returns:
            NegotiatedRate: The negotiated rate object
        """

        # Try claim-based rate first - provide default values for missing parameters
        params = self._build_rate_params(rate_criteria)

        # Initialize negotiated_rate to avoid undefined variable errors
        negotiated_rate = None

        # Try out-of-network rate first
        if rate_criteria.isOutofNetwork:
            out_of_network_result = await self._get_out_of_network_rate(params)
            negotiated_rate = self.build_negotiated_rate(out_of_network_result)
            if negotiated_rate.isRateFound:
                return negotiated_rate
            else:
                logger.info("No out-of-network rate found")
        else:
            # Try claim-based rate next
            claim_result = await self._get_claim_based_rate(params)
            # Check if claim-based rate was found
            negotiated_rate = self.build_negotiated_rate(claim_result)
            if negotiated_rate.isRateFound:
                return negotiated_rate
            else:
                logger.info(
                    "No claim-based rate found, proceeding to get provider info"
                )

            params = self._add_optional_provider_params(rate_criteria, params)
            provider_info_result = await self._get_provider_info(params)

            # Extract provider information and update params
            updated_params = self._extract_provider_info_and_update_params(
                provider_info_result, params
            )

            if updated_params and "contracttype" in updated_params:
                contract_type = updated_params["contracttype"]
                del updated_params["contracttype"]
                if contract_type == "S":
                    del updated_params["providerbusinessgroupnbr"]
                    get_standard_rate = await self._get_standard_rate(updated_params)
                    negotiated_rate = self.build_negotiated_rate(get_standard_rate)
                else:
                    # You need to get the rate from somewhere - this might need adjustment
                    get_non_standard_rate = await self._get_non_standard_rate(
                        updated_params
                    )
                    negotiated_rate = self.build_negotiated_rate(get_non_standard_rate)
                    if not negotiated_rate.isRateFound:
                        get_default_rate = await self._get_default_rate(updated_params)
                        negotiated_rate = self.build_negotiated_rate(get_default_rate)
            else:
                # No provider info found, create a default negotiated rate
                negotiated_rate = NegotiatedRate(
                    paymentMethod="",
                    rate=0.0,
                    isRateFound=False,
                    rateType="",
                    isProviderInfoFound=False,
                )

        return negotiated_rate

    def get_pbg_with_highest_pbg_score(self, result: DataFrame) -> DataFrame:
        # Custom function to find maximum score because result can contain null values too
        result["PROVIDER_BUSINESS_GROUP_SCORE_NBR".lower()] = result[
            "PROVIDER_BUSINESS_GROUP_SCORE_NBR".lower()
        ].astype(float)
        max_score_value = result["PROVIDER_BUSINESS_GROUP_SCORE_NBR".lower()].max()

        # If the max score we got comes out to be None or NaN, return the result as it is. This will lead our code to find standard rate
        if self._value_is_null(max_score_value):
            logger.warning(
                "All the PROVIDER_BUSINESS_GROUP_SCORE_NBR values were NONE in the PROVIDER_INFO RESULT"
            )
            return result
        result = DataFrame(
            result[
                result["PROVIDER_BUSINESS_GROUP_SCORE_NBR".lower()] == max_score_value
            ]
        ).reset_index(
            drop=True
        )  # added DF init to hide typing error, even though it is not needed
        return result

    async def _get_provider_info(self, params: Dict[str, Any]) -> DataFrame:
        try:
            if "providerspecialtycode" in params:
                provider_info_query = RATE_QUERIES.get(
                    "get_provider_info_with_specialty_cd"
                )
            elif "providertype" in params:
                provider_info_query = RATE_QUERIES.get(
                    "get_provider_info_with_provider_type_cd"
                )
            else:
                provider_info_query = RATE_QUERIES.get("get_provider_info")
            if not provider_info_query:
                logger.error("get_provider_info not found in RATE_QUERIES")
                return DataFrame()
            result = await self.db.execute_query(provider_info_query, params)

            if len(result) > 1:
                result = self.get_pbg_with_highest_pbg_score(result)

            return result
        except Exception as e:
            logger.error("Error in _get_provider_info: %s", str(e))
            return DataFrame()

    async def _get_out_of_network_rate(self, params: Dict[str, Any]) -> DataFrame:
        try:
            out_of_network_query = RATE_QUERIES.get("get_out_of_network_rate")
            if not out_of_network_query:
                logger.error("get_out_of_network_rate not found in RATE_QUERIES")
                return DataFrame()
            result = await self.db.execute_query(out_of_network_query, params)
            return result
        except Exception as e:
            logger.error("Error in _get_out_of_network_rate: %s", str(e))
            return DataFrame()

    async def _get_claim_based_rate(self, params: Dict[str, Any]) -> DataFrame:
        try:

            claim_query = RATE_QUERIES.get("get_claim_based_rate")
            if not claim_query:
                logger.error("get_claim_based_rate not found in RATE_QUERIES")
                return DataFrame()
            # Execute the actual query with parameters
            result = await self.db.execute_query(claim_query, params)

            return result
        except Exception as e:
            logger.error("Error in _get_claim_based_rate: %s", str(e))
            return DataFrame()

    def select_rate_query(
        self, contract_type: str, params: Dict[str, Any]
    ) -> str | None:
        query = ""
        if contract_type == "N":
            if "providerspecialtycode" in params:
                query = RATE_QUERIES.get("get_non_standard_rate_with_specialty_cd")
            elif "providertype" in params:
                query = RATE_QUERIES.get("get_non_standard_rate_with_provider_type_cd")
            else:
                query = RATE_QUERIES.get("get_non_standard_rate")
        elif contract_type == "D":
            if "providerspecialtycode" in params:
                query = RATE_QUERIES.get("get_default_rate_with_specialty_cd")
            elif "providertype" in params:
                query = RATE_QUERIES.get("get_default_rate_with_provider_type_cd")
            else:
                query = RATE_QUERIES.get("get_default_rate")
        return query

    async def _get_non_standard_rate(self, params: Dict[str, Any]) -> DataFrame:
        try:
            non_standard_query = self.select_rate_query("N", params)
            if not non_standard_query:
                logger.error("get_non_standard_rate not found in RATE_QUERIES")
                return DataFrame()
            result = await self.db.execute_query(non_standard_query, params)

            # If result has more than 1 payment method, use hierarchy to get best one
            if len(result) > 1:
                result = await self._select_payment_method(result)
                return result
            else:
                return result
        except Exception as e:
            logger.error("Error in _get_non_standard_rate: %s", str(e))
            return DataFrame()

    async def _get_standard_rate(self, params: Dict[str, Any]) -> DataFrame:
        try:
            standard_query = RATE_QUERIES.get("get_standard_rate")
            if not standard_query:
                logger.error("get_standard_rate not found in RATE_QUERIES")
                return DataFrame()
            result = await self.db.execute_query(standard_query, params)
            return result
        except Exception as e:
            logger.error("Error in _get_standard_rate: %s", str(e))
            return DataFrame()

    async def _get_default_rate(self, params: Dict[str, Any]) -> DataFrame:
        try:
            default_query = self.select_rate_query("D", params)
            if not default_query:
                logger.error("get_default_rate not found in RATE_QUERIES")
                return DataFrame()
            result = await self.db.execute_query(default_query, params)
            # If result has more than 1 payment method, use hierarchy to get best one
            if len(result) > 1:
                result = await self._select_payment_method(result)
                return result
            else:
                return result
        except Exception as e:
            logger.error("Error in _get_default_rate: %s", str(e))
            return DataFrame()

    def select_rate_when_scores_are_equal(self, result: DataFrame) -> DataFrame:
        """
        Choose the best row from the list of rows with equal scores.
        """

        result["rate"] = result["rate"].astype(float)
        ind_Y = result[result["service_group_changed_ind"] == "Y"]
        if len(ind_Y) > 0:
            return DataFrame(ind_Y[ind_Y["rate"] == ind_Y["rate"].max()]).reset_index(
                drop=True
            )

        ind_N = result[result["service_group_changed_ind"] == "N"]
        if len(ind_N) > 0:
            # If there are multiple non-standard rates with the same priority, select the best one
            ind_N["service_grouping_priority_nbr"] = ind_N[
                "service_grouping_priority_nbr"
            ].astype(float)
            min_service_grouping_priority_nbr = ind_N[
                ind_N["service_grouping_priority_nbr"]
                == ind_N["service_grouping_priority_nbr"].min()
            ]
            return DataFrame(
                min_service_grouping_priority_nbr[
                    min_service_grouping_priority_nbr["rate"]
                    == min_service_grouping_priority_nbr["rate"].min()
                ]
            ).reset_index(drop=True)

        return DataFrame() if len(result) == 0 else result.head(1)

    async def _select_payment_method(self, result: DataFrame) -> DataFrame:

        if "payment_method_cd" not in result.columns:
            logger.error("payment_method_cd not found in result")
            return DataFrame()

        result["scored_rows"] = (
            result["payment_method_cd".lower()]
            .astype(str)
            .apply(self.get_cached_payment_method_score)
        ).astype(float)

        if all(result["scored_rows"].apply(self._value_is_null)):
            logger.warning("No valid payment methods found in cache hierarchy")
            return DataFrame()

        rows_with_highest_payment_method_score = DataFrame(
            result[result["scored_rows"] == result["scored_rows"].max()].drop(
                columns=["scored_rows"]
            )
        )

        if len(rows_with_highest_payment_method_score) > 1:
            return self.select_rate_when_scores_are_equal(
                rows_with_highest_payment_method_score
            )
        else:
            return rows_with_highest_payment_method_score

    def build_negotiated_rate(self, result: DataFrame) -> NegotiatedRate:
        """
        Build a NegotiatedRate object from query result.
        """
        result.reset_index(drop=True, inplace=True)

        if (result is None or len(result) == 0) or (
            result["rate"][0] is None or result["rate"][0] == ""
        ):
            return NegotiatedRate(
                paymentMethod="",
                rate=0.0,
                isRateFound=False,
                rateType="",
                isProviderInfoFound=True,
            )

        rate = result["rate"][0]
        if "payment_method_cd" in result.columns:
            paymentMethod = str(result["payment_method_cd"][0]).strip()
        else:
            paymentMethod = ""
        # Determine rate type based on payment method
        if paymentMethod in PERCENTAGE_PAYMENT_METHOD_CODES:
            rateType = RATE_TYPE_PERCENTAGE
        else:
            rateType = RATE_TYPE_AMOUNT

        return NegotiatedRate(
            paymentMethod=paymentMethod,
            rate=float(rate),  # type: ignore
            isRateFound=True,
            rateType=rateType,
            isProviderInfoFound=True,
        )

    def _extract_provider_info_and_update_params(
        self, result: DataFrame, params: Dict[str, Any]
    ) -> Dict[str, Any] | None:
        """
        Extract provider information and update query parameters.

        Args:
            result: Query result with format [{'PROVIDER_BUSINESS_GROUP_NBR': 'None', 'PRODUCT_CD': 'MHMO', 'RATING_SYSTEM_CD': 'REF', 'EPDB_GEOGRAPHIC_AREA_CD': 'MD01'}, ...]
            params: Original query parameters

        Returns:
            Updated parameters dictionary with provider data, or None if no provider data found
        """
        if result is None or len(result) == 0:
            return None

        result.reset_index(drop=True, inplace=True)

        updated_params = params.copy()

        # Remove keys from dictionary using del
        if "provideridentificationnumber" in updated_params:
            del updated_params["provideridentificationnumber"]
        if "networkid" in updated_params:
            del updated_params["networkid"]
        if "servicelocationnumber" in updated_params:
            del updated_params["servicelocationnumber"]

        # Get first row of provider data
        provider_business_group_nbr = result["PROVIDER_BUSINESS_GROUP_NBR".lower()][0]
        product_cd = result["PRODUCT_CD".lower()][0]
        rating_system_cd = result["RATING_SYSTEM_CD".lower()][0]
        geographic_area_cd = result["EPDB_GEOGRAPHIC_AREA_CD".lower()][0]

        if not any(
            [
                self._value_is_null(product_cd),
                self._value_is_null(rating_system_cd),
                self._value_is_null(geographic_area_cd),
            ]
        ):
            # Determine contract type based on provider_business_group_nbr
            if self._value_is_null(provider_business_group_nbr):
                contract_type = "S"
            else:
                contract_type = "N"
            updated_params.update(
                {
                    "productcd": product_cd,  # Product Code
                    "ratesystemcd": rating_system_cd,  # Rating System Code
                    "geographicareacd": geographic_area_cd,  # Geographic Area Code
                    "contracttype": contract_type,
                }
            )

        updated_params.update(
            {
                "providerbusinessgroupnbr": result[
                    "PROVIDER_BUSINESS_GROUP_NBR".lower()
                ].tolist()
            }
        )

        return updated_params

    def _build_rate_params(
        self, rate_criteria: CostEstimatorRateCriteria
    ) -> Dict[str, Any]:
        """
        Build rate parameters from rate criteria.

        Args:
            rate_criteria: Rate criteria object

        Returns:
            Dictionary of rate parameters
        """
        if rate_criteria.isOutofNetwork:
            return {
                "servicecd": rate_criteria.serviceCode,
                "placeofservice": rate_criteria.placeOfService,
                "servicetype": rate_criteria.serviceType,
                "zipcode": rate_criteria.zipCode,
            }
        else:
            return {
                "servicecd": rate_criteria.serviceCode,
                "provideridentificationnumber": rate_criteria.providerIdentificationNumber,
                "placeofservice": rate_criteria.placeOfService,
                "servicetype": rate_criteria.serviceType,
                "networkid": rate_criteria.networkId,
                "servicelocationnumber": rate_criteria.serviceLocationNumber,
            }

    def _add_optional_provider_params(
        self, rate_criteria: CostEstimatorRateCriteria, params: Dict[str, Any]
    ) -> Dict[str, Any]:
        if (
            rate_criteria.providerSpecialtyCode
            and rate_criteria.providerSpecialtyCode != ""
        ):
            params["providerspecialtycode"] = rate_criteria.providerSpecialtyCode
        if rate_criteria.providerType and rate_criteria.providerType != "":
            params["providertype"] = rate_criteria.providerType
        return params

    async def load_payment_method_hierarchy(self) -> None:
        """Load payment method hierarchy from Spanner into cache, optimized to avoid unnecessary DB calls."""

        payment_info_query = RATE_QUERIES.get("get_payment_method_hierarchy")
        if not payment_info_query:
            logger.error("get_payment_method_hierarchy not found in RATE_QUERIES")
            return None
        try:
            result = await self.db.execute_query(payment_info_query)
            if "payment_method_cd" not in result.columns:
                logger.error("payment_method_cd not found in result")
                return None
            if "score" not in result.columns:
                logger.error("score not found in result")
                return None
            result_no_nulls = result[
                ~result["payment_method_cd"].apply(self._value_is_null)
            ][~result["score"].apply(self._value_is_null)]
            hierarchy = dict(
                zip(result_no_nulls["payment_method_cd"], result_no_nulls["score"])
            )
            self._cache[PAYMENT_METHOD_HIERARCHY_CACHE_KEY] = hierarchy
        except Exception as e:
            logger.error("Failed to load payment method hierarchy: %s", str(e))

    def get_cached_payment_method_score(self, payment_method_cd: str) -> Optional[int]:
        payment_method_score = self._cache.get(
            PAYMENT_METHOD_HIERARCHY_CACHE_KEY, {}
        ).get(payment_method_cd)
        if self._value_is_null(payment_method_score):
            logger.warning(
                "Payment Method %s not found in hierarchy", payment_method_cd
            )
            return None
        return payment_method_score

    async def load_pcp_specialty_codes(self) -> None:
        query = "SELECT SPECIALTY_CODE FROM CET_PCP_SPECIALTY_CODE"
        try:
            result = await self.db.execute_query(query)
            self._cache[PCP_SPECIALTY_CODES_CACHE_KEY] = result[
                "SPECIALTY_CODE".lower()
            ].tolist()
        except Exception as e:
            logger.error("Failed to load pcp specialty codes: %s", str(e))

    def get_cached_pcp_specialty_codes(self) -> List[str]:
        return self._cache.get(PCP_SPECIALTY_CODES_CACHE_KEY, [])

    def _is_float(self, value: Any) -> bool:
        try:
            float(value)
            return True
        except (TypeError, ValueError):
            return False

    def _value_is_null(self, value: Any) -> bool:
        return (
            value is None
            or pd.isnull(value)
            or value == ""
            or str(value).lower() in ["none", "nan", "null"]
        )
