from typing import Optional

from app.core.base import Handler, InsuranceContext


class CostShareCoPayHandler(Handler):
    """Check cost share when there is no accumlated deductible"""

    def set_oopmax_copay_handler(self, handler):
        self._oopmax_copay_handler = handler
        return handler

    def set_deductible_co_insurance_handler(self, handler):
        self._deductible_co_insurance_handler = handler
        return handler

    def process(self, context):
        # Calculate min_oopmax using the logic: if one is None, use the other; if both exist, use min
        min_oopmax = self._calculate_min_oopmax(context)

        if (
            context.cost_share_copay > 0
            and context.cost_share_copay > context.service_amount
        ):
            # Member pays lesser of service amount and remaining OOPMax individual or family.
            # The value is applied to OOPMax individual and family calculated value
            if min_oopmax is not None and context.service_amount < min_oopmax:
                context.trace_decision(
                    "Process",
                    "The service amount is less than the individual and family OOPMax",
                    True,
                )
                return self._apply_member_pays_service_amount(context)
            else:
                context.trace_decision(
                    "Process",
                    "The service amount is less than the individual and family OOPMax",
                    False,
                )
                return self._apply_member_pays_oopmax_difference(context)
        else:
            # Member pays lesser of the cost share copay amount and remaining OOPMax individual or family calculated.
            # The value is applied to OOPMax individual and family calculated value
            if ( min_oopmax is not None and context.cost_share_copay < min_oopmax):
                context.trace_decision(
                    "Process",
                    "The cost share co-pay is less than the individual and family OOPMax",
                    True,
                )
                return self._apply_member_pays_cost_share_copay(context)
            else:
                context.trace_decision(
                    "Process",
                    "The cost share co-pay is less than the individual and family OOPMax",
                    False,
                )
                return self._apply_member_pays_oopmax_difference(context)

    def _calculate_min_oopmax(self, context: InsuranceContext) -> Optional[float]:
        """Calculate minimum OOP max value handling None cases properly"""
        if (
            context.oopmax_individual_calculated is not None
            and context.oopmax_family_calculated is not None
        ):
            # Both exist: use minimum
            return min(
                context.oopmax_individual_calculated, context.oopmax_family_calculated
            )
        elif context.oopmax_individual_calculated is not None:
            # Only individual exists: use individual
            return context.oopmax_individual_calculated
        elif context.oopmax_family_calculated is not None:
            # Only family exists: use family
            return context.oopmax_family_calculated
        else:
            # Both are None: return None
            return None

    def _apply_member_pays_cost_share_copay(
        self, context: InsuranceContext
    ) -> InsuranceContext:
        """The member pays cost share copay and its applied to OOPMax"""

        context.member_pays = context.member_pays + context.cost_share_copay

        context.amount_copay = context.amount_copay + context.cost_share_copay
        if context.oopmax_individual_calculated is not None:
            context.oopmax_individual_calculated -= context.cost_share_copay
        if context.oopmax_family_calculated is not None:
            context.oopmax_family_calculated -= context.cost_share_copay
        context.service_amount = context.service_amount - context.cost_share_copay
        context.cost_share_copay = 0
        context.trace("_apply_member_pays_cost_share_copay", "Logic applied")

        return self._deductible_co_insurance_handler.handle(context)

    def _apply_member_pays_oopmax_difference(
        self, context: InsuranceContext
    ) -> InsuranceContext:
        """Member pays lesser of the OOPMax and its applied to OOPMax. OOPMax is now met

        NOTE: This path continues to oopmax_copay_handler ONLY if copay_continue_when_oop_met is 'Y'.
        Otherwise, it completes the calculation without calling oopmax_copay_handler.
        """
        min_oopmax = self._calculate_min_oopmax(context)

        if min_oopmax is not None:
            context.member_pays = context.member_pays + min_oopmax
            context.amount_copay = context.amount_copay + min_oopmax
            context.cost_share_copay = context.cost_share_copay - min_oopmax
            context.service_amount = context.service_amount - min_oopmax

            # Update both individual and family calculated values
            if context.oopmax_individual_calculated is not None:
                context.oopmax_individual_calculated = (
                    context.oopmax_individual_calculated - min_oopmax
                )
            if context.oopmax_family_calculated is not None:
                context.oopmax_family_calculated = (
                    context.oopmax_family_calculated - min_oopmax
                )
        else:
            # No OOP max values available, set calculation complete and return
            # context.calculation_complete = True
            # return context
            print("No OOP max values available")

        context.trace("_apply_member_pays_oopmax_difference", "Logic applied")

        # Check if copay should continue when OOPMax is met
        if context.copay_continue_when_oop_met:
            context.trace_decision(
                "OOPMax Copay Handler",
                "Copay continues when OOPMax met indicator is Y, calling oopmax_copay_handler",
                True,
            )
            # Continue to oopmax_copay_handler
            return self._oopmax_copay_handler.handle(context)
        else:
            context.trace_decision(
                "OOPMax Copay Handler",
                "Copay does not continue when OOPMax met, completing calculation",
                False,
            )
            # Complete the calculation without calling oopmax_copay_handler
            context.calculation_complete = True
            return context

    def _apply_member_pays_service_amount(
        self, context: InsuranceContext
    ) -> InsuranceContext:
        """Member pays service amount and OOPMax is updated"""

        context.member_pays = context.member_pays + context.service_amount
        if context.oopmax_individual_calculated is not None:
            context.oopmax_individual_calculated -= context.service_amount
        if context.oopmax_family_calculated is not None:
            context.oopmax_family_calculated -= context.service_amount
        context.amount_copay = context.amount_copay
        context.cost_share_copay = context.cost_share_copay
        context.service_amount = 0
        context.calculation_complete = True

        context.trace("_apply_member_pays_service_amount", "Logic applied")

        return context
