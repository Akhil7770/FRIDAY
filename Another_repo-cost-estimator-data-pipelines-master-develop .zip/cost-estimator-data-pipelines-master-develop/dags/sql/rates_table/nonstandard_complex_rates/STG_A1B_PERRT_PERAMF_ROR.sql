-- taking time to execute the query
-- can we comment 'HMO' in below query check with priya and jyoti  - can we comment 'HMO' in below query check with priya and jyoti - discussed with jyoti and priya , we don't need 'HMO' condition
-- 1,685,421 records after joining with service code master
INSERT INTO `{{ce_project}}.{{ce_dec_dataset}}.{{ce_rates_table}}` (
    
    RATE_SYSTEM_CD,
    SERVICE_CD,
    SERVICE_TYPE_CD,
    SERVICE_GROUP_CD,
    SERVICE_GROUPING_PRIORITY_NBR,
    SERVICE_GROUP_CHANGED_IND,
    PROVIDER_BUSINESS_GROUP_NBR,
    PRODUCT_CD,
    PLACE_OF_SERVICE_CD,
    GEOGRAPHIC_AREA_CD,
    EXTENSION_CD,
    EXTENSION_TYPE,
    SPECIALTY_CD,
    SPECIALTY_TYPE_CD,
    PAYMENT_METHOD_CD,
    RATE,
    CNT_EFFTV_DT,
    CNT_TERMN_DT,
    CONTRACT_TYPE,
    LOGIC_TYPE
)
select distinct
 
rv.RATE_SYSTEM_CD,
case when (length(trim(aff.MEMBER_SERVICE_CD))=3 and aff.MEMBER_SERVICE_TYPE_CD in ('REV','RC')) then concat('0',trim(aff.MEMBER_SERVICE_CD)) else aff.MEMBER_SERVICE_CD end as SERVICE_CD,
aff.MEMBER_SERVICE_TYPE_CD as SERVICE_TYPE_CD,
ld.SERVICE_GROUP_CD,
svcdtl.SERVICE_GROUPING_PRIORITY_NBR,
ld.SERVICE_GROUP_CHANGED_IND as SERVICE_GROUP_CHANGED_IND,
qd.PROVIDER_BUSINESS_GROUP_NBR as PROVIDER_BUSINESS_GROUP_NBR,
pbgnbr.PRODUCT_CD,
trim(scm.supporting_pos_cd) as PLACE_OF_SERVICE_CD,
rv.GEOGRAPHIC_AREA_CD ,
rv.EXTENSION_CD , -- applicable for only PERRT/PERAMF
rv.EXTENSION_TYPE_CD as EXTENSION_TYPE, -- applicable for only PERRT/PERAMF
rv.SPECIALTY_CD , -- applicable for only PERRT/PERAMF
rv.SPECIALTY_TYPE_CD ,
ld.PAYMENT_METHOD_CD ,
case when ld.RATE_PERCENTAGE <>'1.0000' then cast(ld.RATE_PERCENTAGE as FLOAT64) * cast(RATE_AMT as FLOAT64) 
     when ld.RATE_PERCENTAGE = '1.0000' then cast(RATE_AMT as FLOAT64) 
end as RATE,
CAST(qd.CONTRACT_EFFECTIVE_DT AS STRING) AS CNT_EFFTV_DT,
    CAST(qd.CONTRACT_TERM_DT AS STRING) AS CNT_TERMN_DT,
    'C' AS CONTRACT_TYPE,
    'A1B_PERRT_PERAMF_ROR' AS LOGIC_TYPE

from
{{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_line_detail_view}} ld 

join {{ce_project}}.{{ce_dataset}}.{{cet_scsr_service_Affiliation_view}} aff
  on ld.SERVICE_GROUP_CD = aff.OWNER_SERVICE_CD
 and ld.SERVICE_GROUP_TYPE_CD = aff.OWNER_SERVICE_TYPE_CD
 JOIN
    {{ce_project}}.{{ce_dataset}}.{{ce_scm}} scm
ON
    trim(scm.primary_svc_cd) = aff.MEMBER_SERVICE_CD
    AND trim(scm.servc_type) = aff.MEMBER_SERVICE_TYPE_CD

 join {{ce_project}}.{{ce_dataset}}.{{cet_scsr_rate_override_view}} ro
   on ld.RATING_SYSTEM_CD = ro.RATE_SYSTEM_CD
  and ld.ZIP_CD = ro.GEOGRAPHIC_AREA_CD

join {{ce_project}}.{{ce_dataset}}.{{cet_scsr_rate_detail_view}} rv
  on rv.SERVICE_CD = MEMBER_SERVICE_CD
 and rv.SERVICE_TYPE_CD = MEMBER_SERVICE_TYPE_CD
 and rv.RATE_SYSTEM_CD = ro.OVERRIDE_RATE_SYSTEM_CD
 and rv.GEOGRAPHIC_AREA_CD = 'NONE'

Join {{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_detail_view}} sd
  on SD.STRUCTURED_STATEMENT_ID = ld.STRUCTURED_STATEMENT_ID

 join {{ce_project}}.{{ce_dataset}}.{{cet_scsr_service_detail_view}} svcdtl
    ON svcdtl.SERVICE_CD = trim(scm.primary_svc_cd)
    AND svcdtl.SERVICE_TYPE_CD = trim(scm.servc_type)
  
join {{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_Qualifier_detail_view}} qd
  on qd.QUALIFIER_ID  = ld.QUALIFIER_ID 

join {{ce_project}}.{{ce_dataset}}.{{cet_business_group_view}} pbgnbr
    on pbgnbr.PROVIDER_BUSINESS_GROUP_NBR = qd.PROVIDER_BUSINESS_GROUP_NBR


where
ld.PAYMENT_METHOD_CD in ('PERRT', 'PERAMF')
and SERVICE_GROUP_CD <> ''
and SERVICE_GROUP_CHANGED_IND = 'N'
and MEMBER_SERVICE_TYPE_CD not in ( 'AEG', 'SPU' )
and MEMBER_SERVICE_CD <> 'DEFAULT'
and ro.RATE_SYSTEM_CD is not null
--AND POS.OWNER_PLACE_OF_SERVICE_TYPE_CD = 'HMO'
AND scm.in_scope_ind = 1
AND scm.trmn_dt > CURRENT_DATE()

union all

select distinct
 
rt2.RATE_SYSTEM_CD,
case when (length(trim(aff.MEMBER_SERVICE_CD))=3 and aff.MEMBER_SERVICE_TYPE_CD in ('REV','RC')) then concat('0',trim(aff.MEMBER_SERVICE_CD)) else aff.MEMBER_SERVICE_CD end as SERVICE_CD,
aff.MEMBER_SERVICE_TYPE_CD as SERVICE_TYPE_CD,
ld.SERVICE_GROUP_CD,
svcdtl.SERVICE_GROUPING_PRIORITY_NBR,
    ld.SERVICE_GROUP_CHANGED_IND as SERVICE_GROUP_CHANGED_IND,
    qd.PROVIDER_BUSINESS_GROUP_NBR as PROVIDER_BUSINESS_GROUP_NBR,
pbgnbr.PRODUCT_CD,
trim(scm.supporting_pos_cd) as PLACE_OF_SERVICE_CD,
rt2.GEOGRAPHIC_AREA_CD ,
rt2.EXTENSION_CD , -- applicable for only PERRT/PERAMF
rt2.EXTENSION_TYPE_CD as EXTENSION_TYPE, -- applicable for only PERRT/PERAMF
rt2.SPECIALTY_CD , -- applicable for only PERRT/PERAMF
rt2.SPECIALTY_TYPE_CD ,
ld.PAYMENT_METHOD_CD ,
case when ld.RATE_PERCENTAGE <>'1.0000' then cast(ld.RATE_PERCENTAGE as float64) * cast(rt2.RATE_AMT as float64) 
     when ld.RATE_PERCENTAGE = '1.0000' then cast(rt2.RATE_AMT as float64) 
end as RATE,
CAST(qd.CONTRACT_EFFECTIVE_DT AS STRING) AS CNT_EFFTV_DT,
    CAST(qd.CONTRACT_TERM_DT AS STRING) AS CNT_TERMN_DT,
    'C' AS CONTRACT_TYPE,
    'A1B_PERRT_PERAMF_ROR' AS LOGIC_TYPE

from
{{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_line_detail_view}} ld  

join {{ce_project}}.{{ce_dataset}}.{{cet_scsr_service_Affiliation_view}} aff
  on ld.SERVICE_GROUP_CD = aff.OWNER_SERVICE_CD
 and ld.SERVICE_GROUP_TYPE_CD = aff.OWNER_SERVICE_TYPE_CD
  JOIN
    {{ce_project}}.{{ce_dataset}}.{{ce_scm}} scm
ON
    trim(scm.primary_svc_cd) = aff.MEMBER_SERVICE_CD
    AND trim(scm.servc_type) = aff.MEMBER_SERVICE_TYPE_CD

 join {{ce_project}}.{{ce_dataset}}.{{cet_scsr_rate_override_view}} ro
   on ld.RATING_SYSTEM_CD = ro.RATE_SYSTEM_CD
  and ld.ZIP_CD = ro.GEOGRAPHIC_AREA_CD

left outer join {{ce_project}}.{{ce_dataset}}.{{cet_scsr_rate_detail_view}} rt
  on rt.SERVICE_CD = MEMBER_SERVICE_CD
 and rt.SERVICE_TYPE_CD = MEMBER_SERVICE_TYPE_CD
 and rt.RATE_SYSTEM_CD = ro.OVERRIDE_RATE_SYSTEM_CD
 and rt.GEOGRAPHIC_AREA_CD = 'NONE'

 join {{ce_project}}.{{ce_dataset}}.{{cet_scsr_rate_detail_view}} rt2
  on rt2.SERVICE_CD = MEMBER_SERVICE_CD
 and rt2.SERVICE_TYPE_CD = MEMBER_SERVICE_TYPE_CD
 and rt2.RATE_SYSTEM_CD = ro.OVERRIDE_RATE_SYSTEM_CD
 and rt2.GEOGRAPHIC_AREA_CD = 'NONE'

Join {{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_detail_view}} sd
  on SD.STRUCTURED_STATEMENT_ID = ld.STRUCTURED_STATEMENT_ID

 join {{ce_project}}.{{ce_dataset}}.{{cet_scsr_service_detail_view}} svcdtl
    ON svcdtl.SERVICE_CD = trim(scm.primary_svc_cd)
    AND svcdtl.SERVICE_TYPE_CD = trim(scm.servc_type)
  
join {{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_Qualifier_detail_view}} qd
  on qd.QUALIFIER_ID  = ld.QUALIFIER_ID 

join {{ce_project}}.{{ce_dataset}}.{{cet_business_group_view}} pbgnbr
    on pbgnbr.PROVIDER_BUSINESS_GROUP_NBR = qd.PROVIDER_BUSINESS_GROUP_NBR


where
ld.PAYMENT_METHOD_CD in ('PERRT', 'PERAMF')
and SERVICE_GROUP_CD <> ''
and SERVICE_GROUP_CHANGED_IND = 'N'
and MEMBER_SERVICE_TYPE_CD not in ( 'AEG', 'SPU' )
and MEMBER_SERVICE_CD <> 'DEFAULT'
and ro.RATE_SYSTEM_CD is not null
and rt.SERVICE_CD is null
and ld.DEFAULT_RATING_SYSTEM_IND='Y'
--  AND POS.OWNER_PLACE_OF_SERVICE_TYPE_CD = 'HMO'
  AND scm.in_scope_ind = 1
  AND scm.trmn_dt > CURRENT_DATE();
