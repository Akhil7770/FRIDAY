-- A1b With Combination INC and AND logic
-- No data after joining with SCM
INSERT INTO `{{ce_project}}.{{ce_dec_dataset}}.{{ce_rates_table}}` (
    
    RATE_SYSTEM_CD,
    SERVICE_CD,
    SERVICE_TYPE_CD,
    SERVICE_GROUP_CD,
    SERVICE_GROUPING_PRIORITY_NBR,
    SERVICE_GROUP_CHANGED_IND,
    PROVIDER_BUSINESS_GROUP_NBR,
    PRODUCT_CD,
    PLACE_OF_SERVICE_CD,
    GEOGRAPHIC_AREA_CD,
    EXTENSION_CD,
    EXTENSION_TYPE,
    SPECIALTY_CD,
    SPECIALTY_TYPE_CD,
    PAYMENT_METHOD_CD,
    RATE,
    CNT_EFFTV_DT,
    CNT_TERMN_DT,
    CONTRACT_TYPE,
    LOGIC_TYPE
)
WITH base_query AS (
select distinct
     
    '' as RATE_SYSTEM_CD,
    case when (length(trim(aff.MEMBER_SERVICE_CD))=3 and aff.MEMBER_SERVICE_TYPE_CD in ('REV','RC'))
    then concat('0',trim(aff.MEMBER_SERVICE_CD)) else aff.MEMBER_SERVICE_CD end as SERVICE_CD,
    aff.OWNER_SERVICE_CD as SERVICE_TYPE_CD,
    aff.SERVICE_AFFILIATION_RELATIONSHIP_TYPE_CD,
    ld.SERVICE_GROUP_CD as SERVICE_GROUP_CD,
    svcdtl.SERVICE_GROUPING_PRIORITY_NBR as SERVICE_GROUPING_PRIORITY_NBR,
    ld.SERVICE_GROUP_CHANGED_IND as SERVICE_GROUP_CHANGED_IND,
    qd.PROVIDER_BUSINESS_GROUP_NBR as PROVIDER_BUSINESS_GROUP_NBR,
    pbgnbr.PRODUCT_CD as PRODUCT_CD,
    trim(scm.supporting_pos_cd) as PLACE_OF_SERVICE_CD,
    '' as GEOGRAPHIC_AREA_CD,
    '' as EXTENSION_CD,
    '' as EXTENSION_TYPE,
    '' as SPECIALTY_CD,
    '' as SPECIALTY_TYPE_CD,
    ld.PAYMENT_METHOD_CD as PAYMENT_METHOD_CD,
    case when ld.PAYMENT_METHOD_CD='PDIEM' then cast(ld.RATE_PER_TYPE_CD as FLOAT64) else
    case when ld.PAYMENT_METHOD_CD='PERUNT' then cast(ld.RATE_PER_TYPE_CD as FLOAT64) else
    case when ld.PAYMENT_METHOD_CD='OPPDMC' then cast(ld.RATE_PER_TYPE_CD as FLOAT64) else
    case when ld.PAYMENT_METHOD_CD='OPTHYA' then cast(ld.RATE_PER_TYPE_CD as FLOAT64) else
    case when ld.PAYMENT_METHOD_CD='OPTHYI'  then cast(ld.RATE_PER_TYPE_CD as FLOAT64) else
 
    case when ld.PAYMENT_METHOD_CD='PERBIL' then (cast(ld.RATE_PERCENTAGE as FLOAT64) * 100) else
    case when ld.PAYMENT_METHOD_CD='PERBLX' then (cast(ld.RATE_PERCENTAGE as FLOAT64) * 100) else
    case when ld.PAYMENT_METHOD_CD='PERINV' then (cast(ld.RATE_PERCENTAGE as FLOAT64) * 100) else
    case when ld.PAYMENT_METHOD_CD='PBLXDL'  then (cast(ld.RATE_PERCENTAGE as FLOAT64) * 100) else
 
    case when ld.PAYMENT_METHOD_CD='FLAT' then cast(ld.FLAT_RATE_AMT as FLOAT64) else
    case when ld.PAYMENT_METHOD_CD='CASE' then cast(ld.FLAT_RATE_AMT as FLOAT64) else
    case when ld.PAYMENT_METHOD_CD='OPPDML' then cast(ld.FLAT_RATE_AMT as FLOAT64) else 0 end
    end end end end end end end end end end end RATE,
    qd.CONTRACT_EFFECTIVE_DT as CNT_EFFTV_DT,
    qd.CONTRACT_TERM_DT as CNT_TERMN_DT ,
     --added for combination logic
    count(aff.MEMBER_SERVICE_TYPE_CD) OVER (PARTITION BY aff.OWNER_SERVICE_CD, aff.MEMBER_SERVICE_TYPE_CD,ld.PAYMENT_METHOD_CD) AS REC_CNT

from  {{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_line_detail_hsq_view}} ld-- , unnest(split(PLACE_OF_SERVICE_KEY_CD,'')) as unnested
  join {{ce_project}}.{{ce_dataset}}.{{cet_scsr_service_Affiliation_view}} aff
    on ld.SERVICE_GROUP_CD = aff.OWNER_SERVICE_CD
   and ld.SERVICE_GROUP_TYPE_CD = aff.OWNER_SERVICE_TYPE_CD


  JOIN {{ce_project}}.{{ce_dataset}}.{{ce_scm}} scm
   ON trim(scm.primary_svc_cd) = aff.MEMBER_SERVICE_CD
   AND trim(scm.servc_type) = aff.MEMBER_SERVICE_TYPE_CD

   -- do we add this for seq no
   Join {{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_detail_hsq_view}} sd
    on SD.STRUCTURED_STATEMENT_ID = ld.STRUCTURED_STATEMENT_ID

join {{ce_project}}.{{ce_dataset}}.{{cet_scsr_service_detail_view}} svcdtl
    on svcdtl.SERVICE_CD = aff.MEMBER_SERVICE_CD
    and svcdtl.SERVICE_TYPE_CD= aff.MEMBER_SERVICE_TYPE_CD

join {{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_Qualifier_detail_hsq_view}} qd
    on qd.QUALIFIER_ID = cast(ld.QUALIFIER_ID AS int)

join (select distinct pbgnbr.PROVIDER_BUSINESS_GROUP_NBR ,pbgnbr.PRODUCT_CD
          from  {{ce_project}}.{{ce_dataset}}.{{cet_business_group_view}} pbgnbr) Pbgnbr
    on pbgnbr.PROVIDER_BUSINESS_GROUP_NBR = qd.PROVIDER_BUSINESS_GROUP_NBR

where
  ld.PAYMENT_METHOD_CD in ('FLAT','PDIEM','CASE','PERUNT','OPPDMC','OPTHYA','OPTHYI','PERBIL','PERBLX','PERINV','PBLXDL','OPPDML' )
  and ld.SERVICE_GROUP_CD <> ''
  and ld.SERVICE_GROUP_CHANGED_IND = 'N'
  and aff.MEMBER_SERVICE_TYPE_CD not in (  'CNTAND','AEG', 'SPU')
  and aff.MEMBER_SERVICE_CD <> 'DEFAULT'
  --adding logic for combination requirement.Then the codes in MEMBER_SERVICE_CD/mbr_servc_type will be populated as is with no service code groupings.
  and afF.SERVICE_AFFILIATION_RELATIONSHIP_TYPE_CD  in ( 'AND' , 'INC')
  AND scm.in_scope_ind = 1
  AND scm.trmn_dt > CURRENT_DATE()

)
SELECT
     
   RATE_SYSTEM_CD,
    SERVICE_CD,
    SERVICE_TYPE_CD,
    SERVICE_GROUP_CD,
    SERVICE_GROUPING_PRIORITY_NBR,
    SERVICE_GROUP_CHANGED_IND,
    PROVIDER_BUSINESS_GROUP_NBR,
    PRODUCT_CD,
    PLACE_OF_SERVICE_CD, -- NOT ADDED AT THIS POINT.
    GEOGRAPHIC_AREA_CD,
    EXTENSION_CD,
    EXTENSION_TYPE,
    SPECIALTY_CD,
    SPECIALTY_TYPE_CD,
    PAYMENT_METHOD_CD,
    RATE,
    CAST(CNT_EFFTV_DT AS STRING) AS CNT_EFFTV_DT,
    CAST(CNT_TERMN_DT AS STRING) AS CNT_TERMN_DT,
    'N' as CONTRACT_TYPE,
    'A1B_COMBINED' as LOGIC_TYPE
FROM base_query
WHERE (REC_CNT =2 and SERVICE_AFFILIATION_RELATIONSHIP_TYPE_CD in ('AND'))
      OR
      ((REC_CNT =1 OR REC_CNT =2) and SERVICE_AFFILIATION_RELATIONSHIP_TYPE_CD in ('INC'));
