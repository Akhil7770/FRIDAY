-- Below view is pulling data from the below tables
-- 434,535 RECORDS
-- 12063 after joined Service Code Master
-- can we comment 'HMO' in below query check with priya and jyoti
INSERT INTO `{{ce_project}}.{{ce_dec_dataset}}.{{ce_rates_table}}` (
    
    RATE_SYSTEM_CD,
    SERVICE_CD,
    SERVICE_TYPE_CD,
    SERVICE_GROUP_CD,
    SERVICE_GROUPING_PRIORITY_NBR,
    SERVICE_GROUP_CHANGED_IND,
    PROVIDER_BUSINESS_GROUP_NBR,
    PRODUCT_CD,
    PLACE_OF_SERVICE_CD,
    GEOGRAPHIC_AREA_CD,
    EXTENSION_CD,
    EXTENSION_TYPE,
    SPECIALTY_CD,
    SPECIALTY_TYPE_CD,
    PAYMENT_METHOD_CD,
    RATE,
    CNT_EFFTV_DT,
    CNT_TERMN_DT,
    CONTRACT_TYPE,
    LOGIC_TYPE
)
select distinct
 
rt.RATE_SYSTEM_CD,
case when (length(trim(svcdtl.SERVICE_CD))=3 and svcdtl.SERVICE_TYPE_CD in ('REV','RC')) then concat('0',trim(svcdtl.SERVICE_CD)) else svcdtl.SERVICE_CD end as SERVICE_CD,
svcdtl.SERVICE_TYPE_CD as SERVICE_TYPE_CD,
ld.SERVICE_GROUP_CD,
svcdtl.SERVICE_GROUPING_PRIORITY_NBR,
ld.SERVICE_GROUP_CHANGED_IND as SERVICE_GROUP_CHANGED_IND,
qd.PROVIDER_BUSINESS_GROUP_NBR as PROVIDER_BUSINESS_GROUP_NBR,
pbgnbr.PRODUCT_CD,
trim(scm.supporting_pos_cd) as PLACE_OF_SERVICE_CD,
rt.GEOGRAPHIC_AREA_CD ,
rt.EXTENSION_CD , -- applicable for only PERRT/PERAMF
rt.EXTENSION_TYPE_CD as EXTENSION_TYPE, -- applicable for only PERRT/PERAMF
rt.SPECIALTY_CD , -- applicable for only PERRT/PERAMF
rt.SPECIALTY_TYPE_CD ,
ld.PAYMENT_METHOD_CD,
cast(ld.RATE_PERCENTAGE as FLOAT64) * cast(rt.RATE_AMT as FLOAT64) as RATE,
   CAST(qd.CONTRACT_EFFECTIVE_DT AS STRING) AS CNT_EFFTV_DT,
    CAST(qd.CONTRACT_TERM_DT AS STRING) AS CNT_TERMN_DT,
    'C' AS CONTRACT_TYPE,
    'B3_PERRT_PERAMF_NON_ROR' AS LOGIC_TYPE

from {{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_line_detail_view}} ld



join {{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_detail_view}} sd
  on sd.STRUCTURED_STATEMENT_ID = ld.STRUCTURED_STATEMENT_ID

JOIN
    {{ce_project}}.{{ce_dataset}}.{{ce_scm}} scm
ON
   trim(scm.primary_svc_cd) between sd.LOW_VALUE_CD and sd.HIGH_VALUE_CD
 and trim(scm.servc_type) = sd.FACTOR_TYPE_CD


join {{ce_project}}.{{ce_dataset}}.{{cet_scsr_service_detail_view}} svcdtl
  on svcdtl.SERVICE_CD = trim(scm.primary_svc_cd)
 and svcdtl.SERVICE_TYPE_CD = trim(scm.servc_type)

join {{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_Qualifier_detail_view}} qd
  on qd.QUALIFIER_ID = ld.QUALIFIER_ID

left outer join {{ce_project}}.{{ce_dataset}}.{{cet_scsr_rate_override_view}} ro
  on ld.RATING_SYSTEM_CD = ro.RATE_SYSTEM_CD
 and ld.ZIP_CD = ro.GEOGRAPHIC_AREA_CD

join {{ce_project}}.{{ce_dataset}}.{{cet_scsr_rate_detail_view}} rt
  on rt.SERVICE_CD = trim(scm.primary_svc_cd)
 and rt.SERVICE_TYPE_CD = trim(scm.servc_type)
 and trim(rt.RATE_SYSTEM_CD) = trim(ld.RATING_SYSTEM_CD)
 and trim(rt.GEOGRAPHIC_AREA_CD) = trim(ld.GEOGRAPHIC_AREA_CD)

  join {{ce_project}}.{{ce_dataset}}.{{cet_business_group_view}} pbgnbr
    on pbgnbr.PROVIDER_BUSINESS_GROUP_NBR = qd.PROVIDER_BUSINESS_GROUP_NBR



where ld.PAYMENT_METHOD_CD in ('PERRT', 'PERAMF')
  and SERVICE_GROUP_CD <> ''
  and SERVICE_GROUP_CHANGED_IND = 'Y'
  and ro.RATE_SYSTEM_CD is null
  AND scm.in_scope_ind = 1
  AND scm.trmn_dt > CURRENT_DATE()
  --AND POS.OWNER_PLACE_OF_SERVICE_TYPE_CD = 'HMO'
union all

select distinct
 
rt.RATE_SYSTEM_CD,
case when (length(trim(svcdtl.SERVICE_CD))=3 and svcdtl.SERVICE_TYPE_CD in ('REV','RC')) then concat('0',trim(svcdtl.SERVICE_CD)) else svcdtl.SERVICE_CD end as SERVICE_CD,
svcdtl.SERVICE_TYPE_CD as SERVICE_TYPE_CD,
ld.SERVICE_GROUP_CD,
svcdtl.SERVICE_GROUPING_PRIORITY_NBR,
    ld.SERVICE_GROUP_CHANGED_IND as SERVICE_GROUP_CHANGED_IND,
qd.PROVIDER_BUSINESS_GROUP_NBR as PROVIDER_BUSINESS_GROUP_NBR,
pbgnbr.PRODUCT_CD,
trim(scm.supporting_pos_cd) as PLACE_OF_SERVICE_CD,
rt.GEOGRAPHIC_AREA_CD ,
rt.EXTENSION_CD , -- applicable for only PERRT/PERAMF
rt.EXTENSION_TYPE_CD as EXTENSION_TYPE, -- applicable for only PERRT/PERAMF
rt.SPECIALTY_CD , -- applicable for only PERRT/PERAMF
rt.SPECIALTY_TYPE_CD ,
ld.PAYMENT_METHOD_CD,
cast(ld.RATE_PERCENTAGE as FLOAT64) * cast(rt2.RATE_AMT as FLOAT64) as RATE,
   CAST(qd.CONTRACT_EFFECTIVE_DT AS STRING) AS CNT_EFFTV_DT,
    CAST(qd.CONTRACT_TERM_DT AS STRING) AS CNT_TERMN_DT,
    'C' AS CONTRACT_TYPE,
    'B3_PERRT_PERAMF_NON_ROR' AS LOGIC_TYPE

from {{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_line_detail_view}} ld

join {{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_detail_view}} sd
  on sd.STRUCTURED_STATEMENT_ID = ld.STRUCTURED_STATEMENT_ID

JOIN
    {{ce_project}}.{{ce_dataset}}.{{ce_scm}} scm
ON
   trim(scm.primary_svc_cd) between sd.LOW_VALUE_CD and sd.HIGH_VALUE_CD
 and trim(scm.servc_type) = sd.FACTOR_TYPE_CD

join {{ce_project}}.{{ce_dataset}}.{{cet_scsr_service_detail_view}} svcdtl
  on svcdtl.SERVICE_CD = trim(scm.primary_svc_cd)
 and svcdtl.SERVICE_TYPE_CD = trim(scm.servc_type)

join {{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_Qualifier_detail_view}} qd
  on qd.QUALIFIER_ID = ld.QUALIFIER_ID

left outer join {{ce_project}}.{{ce_dataset}}.{{cet_scsr_rate_override_view}} ro
  on ld.RATING_SYSTEM_CD = ro.RATE_SYSTEM_CD
 and ld.ZIP_CD = ro.GEOGRAPHIC_AREA_CD

left outer join {{ce_project}}.{{ce_dataset}}.{{cet_scsr_rate_detail_view}} rt
   on rt.SERVICE_CD = trim(scm.primary_svc_cd)
 and rt.SERVICE_TYPE_CD = trim(scm.servc_type)
 and trim(rt.RATE_SYSTEM_CD) = trim(ld.RATING_SYSTEM_CD)
 and trim(rt.GEOGRAPHIC_AREA_CD) = trim(ld.GEOGRAPHIC_AREA_CD)

join {{ce_project}}.{{ce_dataset}}.{{cet_scsr_rate_detail_view}} rt2
  on rt2.SERVICE_CD = trim(scm.primary_svc_cd)
 and rt2.SERVICE_TYPE_CD = trim(scm.servc_type)
 and trim(rt2.RATE_SYSTEM_CD) = trim(ld.RATING_SYSTEM_CD)
 and trim(rt2.GEOGRAPHIC_AREA_CD) = trim(ld.GEOGRAPHIC_AREA_CD)


  join {{ce_project}}.{{ce_dataset}}.{{cet_business_group_view}} pbgnbr
    on pbgnbr.PROVIDER_BUSINESS_GROUP_NBR = qd.PROVIDER_BUSINESS_GROUP_NBR


where ld.PAYMENT_METHOD_CD in ('PERRT', 'PERAMF')
  and SERVICE_GROUP_CD <> ''
  and SERVICE_GROUP_CHANGED_IND = 'Y'
  and ro.RATE_SYSTEM_CD is null
  and rt.SERVICE_CD is null
   AND scm.in_scope_ind = 1
  and ld.DEFAULT_RATING_SYSTEM_IND = 'Y'
  AND  scm.trmn_dt > CURRENT_DATE();
 --'  AND POS.OWNER_PLACE_OF_SERVICE_TYPE_CD = 'HMO'
