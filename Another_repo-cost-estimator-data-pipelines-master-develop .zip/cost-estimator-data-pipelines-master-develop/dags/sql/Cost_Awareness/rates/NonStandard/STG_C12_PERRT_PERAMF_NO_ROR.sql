--NO RECORDS
-- no data after joining with SCM
INSERT INTO `{{ce_project}}.{{ce_dec_dataset}}.{{ca_rates_table}}` (
    
    RATE_SYSTEM_CD,
    SERVICE_CD,
    SERVICE_TYPE_CD,
    SERVICE_GROUP_CD,
    SERVICE_GROUPING_PRIORITY_NBR,
    SERVICE_GROUP_CHANGED_IND,
    PROVIDER_BUSINESS_GROUP_NBR,
    PRODUCT_CD,
    PLACE_OF_SERVICE_CD,
    PLACE_OF_SERVICE_KEY_CD,
    GEOGRAPHIC_AREA_CD,
    EXTENSION_CD,
    EXTENSION_TYPE,
    SPECIALTY_CD,
    SPECIALTY_TYPE_CD,
    PAYMENT_METHOD_CD,
    RATE,
    CNT_EFFTV_DT,
    CNT_TERMN_DT,
    CONTRACT_TYPE,
    LOGIC_TYPE
)
with  `Service_code_table` as
 (SELECT distinct prcdr_cd, srv_cd_type,pos_cd FROM `{{ce_project}}.{{ce_dataset}}.{{ca_radiology_codes}}`),
SELECT DISTINCT
     ro.RATE_SYSTEM_CD as RATE_SYSTEM_CD,
    CASE
        WHEN LENGTH(TRIM(svcdtl.SERVICE_CD)) = 3 AND svcdtl.SERVICE_TYPE_CD IN ('REV', 'RC')
        THEN CONCAT('0', TRIM(svcdtl.SERVICE_CD))
        ELSE svcdtl.SERVICE_CD
    END AS SERVICE_CD,
    svcdtl.SERVICE_TYPE_CD,
    ld.SERVICE_GROUP_CD,
    svcdtl.SERVICE_GROUPING_PRIORITY_NBR,
    ld.SERVICE_GROUP_CHANGED_IND as SERVICE_GROUP_CHANGED_IND,
    qd.PROVIDER_BUSINESS_GROUP_NBR AS PROVIDER_BUSINESS_GROUP_NBR,
    pbgnbr.PRODUCT_CD,
    pos.MEMBER_PLACE_OF_SERVICE_CD AS PLACE_OF_SERVICE_CD,
    pos.OWNER_PLACE_OF_SERVICE_CD as PLACE_OF_SERVICE_KEY_CD,
    rt.GEOGRAPHIC_AREA_CD,
    rt.EXTENSION_CD,
    rt.EXTENSION_TYPE_CD AS EXTENSION_TYPE,
    rt.SPECIALTY_CD,
    rt.SPECIALTY_TYPE_CD,
    ld.PAYMENT_METHOD_CD,
    CAST(ld.RATE_PERCENTAGE AS FLOAT64) * CAST(rt.RATE_AMT AS FLOAT64) AS RATE,
    CAST(qd.CONTRACT_EFFECTIVE_DT AS STRING) AS CNT_EFFTV_DT,
    CAST(qd.CONTRACT_TERM_DT AS STRING) AS CNT_TERMN_DT,
    'C' AS CONTRACT_TYPE,
    'C12_PERRT_PERAMF_NO_ROR' AS LOGIC_TYPE
FROM
    {{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_line_detail_view}} ld
JOIN {{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_detail_view}} sd
    ON sd.STRUCTURED_STATEMENT_ID = ld.STRUCTURED_STATEMENT_ID

join Service_code_table cw
on  cw.prcdr_cd BETWEEN sd.LOW_SERVICE_CD AND sd.HIGH_SERVICE_CD
and cw.srv_cd_type = sd.SERVICE_TYPE_CD

JOIN {{ce_project}}.{{ce_dataset}}.{{cet_scsr_service_detail_view}} svcdtl
    on svcdtl.SERVICE_CD = trim(cw.prcdr_cd)
 and svcdtl.SERVICE_TYPE_CD = trim(cw.srv_cd_type)
JOIN {{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_Qualifier_detail_view}} qd
    ON qd.QUALIFIER_ID = ld.QUALIFIER_ID
LEFT JOIN {{ce_project}}.{{ce_dataset}}.{{cet_scsr_rate_override_view}} ro
    ON ld.RATE_PER_TYPE_CD = ro.RATE_SYSTEM_CD
    AND ld.ZIP_CD = ro.GEOGRAPHIC_AREA_CD
JOIN {{ce_project}}.{{ce_dataset}}.{{cet_scsr_rate_detail_view}} rt
    ON rt.SERVICE_CD = svcdtl.SERVICE_CD
    AND rt.SERVICE_TYPE_CD = svcdtl.SERVICE_TYPE_CD
    AND TRIM(rt.RATE_SYSTEM_CD) = TRIM(ld.RATE_PER_TYPE_CD)
    AND TRIM(rt.GEOGRAPHIC_AREA_CD) = TRIM(ld.GEOGRAPHIC_AREA_CD)
JOIN {{ce_project}}.{{ce_dataset}}.{{cet_business_group_view}} pbgnbr
    ON pbgnbr.PROVIDER_BUSINESS_GROUP_NBR = qd.PROVIDER_BUSINESS_GROUP_NBR
WHERE
    ld.PAYMENT_METHOD_CD IN ('PERRT', 'PERAMF')
    AND SERVICE_GROUP_CD = ''
    AND ro.RATE_SYSTEM_CD IS NULL
    and pos.OWNER_PLACE_OF_SERVICE_CD in ('E','F','I','O','S')

UNION ALL

SELECT DISTINCT
    
     ro.RATE_SYSTEM_CD as RATE_SYSTEM_CD,
    CASE
        WHEN LENGTH(TRIM(svcdtl.SERVICE_CD)) = 3 AND svcdtl.SERVICE_TYPE_CD IN ('REV', 'RC')
        THEN CONCAT('0', TRIM(svcdtl.SERVICE_CD))
        ELSE svcdtl.SERVICE_CD
    END AS SERVICE_CD,
    svcdtl.SERVICE_TYPE_CD,
    ld.SERVICE_GROUP_CD,
    svcdtl.SERVICE_GROUPING_PRIORITY_NBR,
    ld.SERVICE_GROUP_CHANGED_IND as SERVICE_GROUP_CHANGED_IND,
    qd.PROVIDER_BUSINESS_GROUP_NBR AS PROVIDER_BUSINESS_GROUP_NBR,
    pbgnbr.PRODUCT_CD,
    pos.MEMBER_PLACE_OF_SERVICE_CD AS PLACE_OF_SERVICE_CD,
    pos.OWNER_PLACE_OF_SERVICE_CD as PLACE_OF_SERVICE_KEY_CD,
    rt.GEOGRAPHIC_AREA_CD,
    rt.EXTENSION_CD,
    rt.EXTENSION_TYPE_CD AS EXTENSION_TYPE,
    rt.SPECIALTY_CD,
    rt.SPECIALTY_TYPE_CD,
    ld.PAYMENT_METHOD_CD,
    CAST(ld.RATE_PERCENTAGE AS FLOAT64) * CAST(rt.RATE_AMT AS FLOAT64) AS RATE,
    CAST(qd.CONTRACT_EFFECTIVE_DT AS STRING) AS CNT_EFFTV_DT,
    CAST(qd.CONTRACT_TERM_DT AS STRING) AS CNT_TERMN_DT,
    'C' AS CONTRACT_TYPE,
    'C12_PERRT_PERAMF_NO_ROR' AS LOGIC_TYPE
FROM
    {{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_line_detail_view}} ld
JOIN {{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_detail_view}} sd
    ON sd.STRUCTURED_STATEMENT_ID = ld.STRUCTURED_STATEMENT_ID
join Service_code_table cw
on  cw.prcdr_cd BETWEEN sd.LOW_SERVICE_CD AND sd.HIGH_SERVICE_CD
and cw.srv_cd_type = sd.SERVICE_TYPE_CD
JOIN {{ce_project}}.{{ce_dataset}}.{{cet_scsr_service_detail_view}} svcdtl
      on svcdtl.SERVICE_CD = trim(cw.prcdr_cd)
 and svcdtl.SERVICE_TYPE_CD = trim(cw.srv_cd_type)
JOIN {{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_Qualifier_detail_view}} qd
    ON qd.QUALIFIER_ID = ld.QUALIFIER_ID
LEFT JOIN {{ce_project}}.{{ce_dataset}}.{{cet_scsr_rate_override_view}} ro
    ON ld.RATE_PER_TYPE_CD = ro.RATE_SYSTEM_CD
    AND ld.ZIP_CD = ro.GEOGRAPHIC_AREA_CD
LEFT JOIN {{ce_project}}.{{ce_dataset}}.{{cet_scsr_rate_detail_view}} rt
    ON rt.SERVICE_CD = svcdtl.SERVICE_CD
    AND rt.SERVICE_TYPE_CD = svcdtl.SERVICE_TYPE_CD
    AND TRIM(rt.RATE_SYSTEM_CD) = TRIM(ld.RATE_PER_TYPE_CD)
    AND TRIM(rt.GEOGRAPHIC_AREA_CD) = TRIM(ld.GEOGRAPHIC_AREA_CD)
JOIN {{ce_project}}.{{ce_dataset}}.{{cet_scsr_rate_detail_view}} rt2
    ON rt2.SERVICE_CD = svcdtl.SERVICE_CD
    AND rt2.SERVICE_TYPE_CD = svcdtl.SERVICE_TYPE_CD
    AND TRIM(rt2.RATE_SYSTEM_CD) = TRIM(ld.RATE_PER_TYPE_CD)
    AND TRIM(rt2.GEOGRAPHIC_AREA_CD) = TRIM(ld.GEOGRAPHIC_AREA_CD)
JOIN {{ce_project}}.{{ce_dataset}}.{{cet_business_group_view}} pbgnbr
    ON pbgnbr.PROVIDER_BUSINESS_GROUP_NBR = qd.PROVIDER_BUSINESS_GROUP_NBR
JOIN  {{ce_project}}.{{ce_dataset}}.{{cet_scsr_place_of_service_affiliation_view}}  pos
     ON  pos.MEMBER_PLACE_OF_SERVICE_CD  = cw.pos_cd
WHERE
    ld.PAYMENT_METHOD_CD IN ('PERRT', 'PERAMF')
    AND SERVICE_GROUP_CD = ''
    AND ro.RATE_SYSTEM_CD IS NULL
    AND rt.SERVICE_CD IS NULL
    AND ld.DEFAULT_RATING_SYSTEM_IND = 'Y'
    and pos.OWNER_PLACE_OF_SERVICE_CD in ('E','F','I','O','S')
