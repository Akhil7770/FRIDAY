--B3 and C3  can be combined
--B3 SERVICE_GROUP_CD field is populated and the service grouping changed indicator is equal to ‘Y’ and sd.LOW_VALUE_CD <> ''  and sd.HIGH_VALUE_CD <> ''
--C3 SERVICE_GROUP_CD ='' and sd.LOW_VALUE_CD <> ''  and sd.HIGH_VALUE_CD <> ''
--49,545 row has been added after joinig with SCM
INSERT INTO `{{ce_project}}.{{ce_dec_dataset}}.{{ca_rates_table}}` (
    
    RATE_SYSTEM_CD,
    SERVICE_CD,
    SERVICE_TYPE_CD,
    SERVICE_GROUP_CD,
    SERVICE_GROUPING_PRIORITY_NBR,
    SERVICE_GROUP_CHANGED_IND,
    PROVIDER_BUSINESS_GROUP_NBR,
    PRODUCT_CD,
    PLACE_OF_SERVICE_CD,
    PLACE_OF_SERVICE_KEY_CD,
    GEOGRAPHIC_AREA_CD,
    EXTENSION_CD,
    EXTENSION_TYPE,
    SPECIALTY_CD,
    SPECIALTY_TYPE_CD,
    PAYMENT_METHOD_CD,
    RATE,
    CNT_EFFTV_DT,
    CNT_TERMN_DT,
    CONTRACT_TYPE,
    LOGIC_TYPE
)
with  `Service_code_table` as
 (SELECT distinct prcdr_cd, srv_cd_type,pos_cd FROM `{{ce_project}}.{{ce_dataset}}.{{ca_radiology_codes}}`),
  select distinct
  '' as RATE_SYSTEM_CD,
    case when (length(trim(svcdtl.SERVICE_CD))=3 and svcdtl.SERVICE_TYPE_CD in ('REV','RC'))
    then concat('0',trim(svcdtl.SERVICE_CD)) else svcdtl.SERVICE_CD end as SERVICE_CD,
    svcdtl.SERVICE_TYPE_CD as SERVICE_TYPE_CD,
    ld.SERVICE_GROUP_CD as SERVICE_GROUP_CD,
    svcdtl.SERVICE_GROUPING_PRIORITY_NBR as SERVICE_GROUPING_PRIORITY_NBR,
    ld.SERVICE_GROUP_CHANGED_IND as SERVICE_GROUP_CHANGED_IND,
    qd.PROVIDER_BUSINESS_GROUP_NBR as PROVIDER_BUSINESS_GROUP_NBR,
    pbgnbr.PRODUCT_CD as PRODUCT_CD,
    pos.MEMBER_PLACE_OF_SERVICE_CD AS PLACE_OF_SERVICE_CD,
    pos.OWNER_PLACE_OF_SERVICE_CD as PLACE_OF_SERVICE_KEY_CD,
    '' as GEOGRAPHIC_AREA_CD,
    '' as EXTENSION_CD,
    '' as EXTENSION_TYPE,
    '' as SPECIALTY_CD,
    '' as SPECIALTY_TYPE_CD,
    ld.PAYMENT_METHOD_CD as PAYMENT_METHOD_CD,
    case when ld.PAYMENT_METHOD_CD='PDIEM' then cast(ld.RATE_PER_TYPE_CD as FLOAT64) else
    case when ld.PAYMENT_METHOD_CD='PERUNT' then cast(ld.RATE_PER_TYPE_CD as FLOAT64) else
    case when ld.PAYMENT_METHOD_CD='OPPDMC' then cast(ld.RATE_PER_TYPE_CD as FLOAT64) else
    case when ld.PAYMENT_METHOD_CD='OPTHYA' then cast(ld.RATE_PER_TYPE_CD as FLOAT64) else
    case when ld.PAYMENT_METHOD_CD='OPTHYI'  then cast(ld.RATE_PER_TYPE_CD as FLOAT64) else
 
    case when ld.PAYMENT_METHOD_CD='PERBIL' then (cast(ld.RATE_PERCENTAGE as FLOAT64) * 100) else
    case when ld.PAYMENT_METHOD_CD='PERBLX' then (cast(ld.RATE_PERCENTAGE as FLOAT64) * 100) else
    case when ld.PAYMENT_METHOD_CD='PERINV' then (cast(ld.RATE_PERCENTAGE as FLOAT64) * 100) else
    case when ld.PAYMENT_METHOD_CD='PBLXDL'  then (cast(ld.RATE_PERCENTAGE as FLOAT64) * 100) else
 
    case when ld.PAYMENT_METHOD_CD='FLAT' then cast(ld.FLAT_RATE_AMT as FLOAT64) else
    case when ld.PAYMENT_METHOD_CD='CASE' then cast(ld.FLAT_RATE_AMT as FLOAT64) else
    case when ld.PAYMENT_METHOD_CD='OPPDML' then cast(ld.FLAT_RATE_AMT as FLOAT64) else 0 end
    end end end end end end end end end end end RATE,
    CAST(qd.CONTRACT_EFFECTIVE_DT AS STRING) AS CNT_EFFTV_DT,
    CAST(qd.CONTRACT_TERM_DT AS STRING) AS CNT_TERMN_DT,
    'N' AS CONTRACT_TYPE,
    'B3_C3' as LOGIC_TYPE
from
  `{{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_line_detail_hsq_view}}` ld
    Join `{{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_detail_hsq_view}}` sd
   on SD.STRUCTURED_STATEMENT_ID = ld.STRUCTURED_STATEMENT_ID

  join `{{ce_project}}.{{ce_dataset}}.{{cet_scsr_service_detail_view}}` svcdtl
   on svcdtl.SERVICE_CD between sd.LOW_VALUE_CD and sd.HIGH_VALUE_CD
   and svcdtl.SERVICE_TYPE_CD = sd.FACTOR_TYPE_CD

  join `{{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_Qualifier_detail_hsq_view}}` qd
    on qd.QUALIFIER_ID = ld.QUALIFIER_ID

join Service_code_table cw
on svcdtl.SERVICE_CD = cw.prcdr_cd
and svcdtl.SERVICE_TYPE_CD = cw.srv_cd_type


	join
  (select distinct pbgnbr.PROVIDER_BUSINESS_GROUP_NBR ,pbgnbr.PRODUCT_CD
  from  {{ce_project}}.{{ce_dataset}}.{{cet_business_group_view}} pbgnbr) Pbgnbr
   on pbgnbr.PROVIDER_BUSINESS_GROUP_NBR = qd.PROVIDER_BUSINESS_GROUP_NBR
  

JOIN select * from {{ce_project}}.{{ce_dataset}}.{{cet_scsr_place_of_service_affiliation_view}}  pos
    ON  pos.MEMBER_PLACE_OF_SERVICE_CD  = cw.pos_cd

  where
  ld.PAYMENT_METHOD_CD in ('FLAT','PDIEM','CASE','PERUNT','OPPDMC','OPTHYA','OPTHYI','PERBIL','PERBLX','PERINV','PBLXDL','OPPDML' )
  and ((ld.SERVICE_GROUP_CD <> '' and ld.SERVICE_GROUP_CHANGED_IND = 'Y') OR ld.SERVICE_GROUP_CD ='')
  and sd.LOW_VALUE_CD <> ''
  and sd.HIGH_VALUE_CD <> ''
  and sd.FACTOR_TYPE_CD <> ''
  and sd.OPERATOR_CD NOT IN ('AND','INC')
    and pos.OWNER_PLACE_OF_SERVICE_CD in ('E','F','I','O','S')
