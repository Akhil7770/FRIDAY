-- no data
INSERT INTO `{{ce_project}}.{{ce_dec_dataset}}.{{ca_rates_table}}` (
    
    RATE_SYSTEM_CD,
    SERVICE_CD,
    SERVICE_TYPE_CD,
    SERVICE_GROUP_CD,
    SERVICE_GROUPING_PRIORITY_NBR,
    SERVICE_GROUP_CHANGED_IND,
    PROVIDER_BUSINESS_GROUP_NBR,
    PRODUCT_CD,
    PLACE_OF_SERVICE_CD,
    PLACE_OF_SERVICE_KEY_CD,
    GEOGRAPHIC_AREA_CD,
    EXTENSION_CD,
    EXTENSION_TYPE,
    SPECIALTY_CD,
    SPECIALTY_TYPE_CD,
    PAYMENT_METHOD_CD,
    RATE,
    CNT_EFFTV_DT,
    CNT_TERMN_DT,
    CONTRACT_TYPE,
    LOGIC_TYPE
)
with  `Service_code_table` as
 (SELECT distinct prcdr_cd, srv_cd_type,pos_cd FROM `{{ce_project}}.{{ce_dataset}}.{{ca_radiology_codes}}`),
select distinct
 
 rv.RATE_SYSTEM_CD,
  case when (length(trim(svcdtl.SERVICE_CD))=3 and svcdtl.SERVICE_TYPE_CD in ('REV','RC')) then
  CONCAT('0',trim(svcdtl.SERVICE_CD))
   else svcdtl.SERVICE_CD end as SERVICE_CD,
  svcdtl.SERVICE_TYPE_CD as SERVICE_TYPE_CD,
   ld.SERVICE_GROUP_CD,
   svcdtl.SERVICE_GROUPING_PRIORITY_NBR,
   ld.SERVICE_GROUP_CHANGED_IND as SERVICE_GROUP_CHANGED_IND,
qd.PROVIDER_BUSINESS_GROUP_NBR as PROVIDER_BUSINESS_GROUP_NBR,
   pbgnbr.PRODUCT_CD,
  pos.MEMBER_PLACE_OF_SERVICE_CD AS PLACE_OF_SERVICE_CD,
  pos.OWNER_PLACE_OF_SERVICE_CD as PLACE_OF_SERVICE_KEY_CD,
  '' as GEOGRAPHIC_AREA_CD,
  '' as EXTENSION_CD ,
  '' as EXTENSION_TYPE ,
   '' as SPECIALTY_CD ,
  '' as SPECIALTY_TYPE_CD ,
   ld.PAYMENT_METHOD_CD ,
cast(ld.RATE_PER_TYPE_CD as float64) * cast(rv.RELATIVE_VALUE_AMT as float64) RATE,
     CAST(qd.CONTRACT_EFFECTIVE_DT AS STRING) AS CNT_EFFTV_DT,
    CAST(qd.CONTRACT_TERM_DT AS STRING) AS CNT_TERMN_DT,
    'C' AS CONTRACT_TYPE,
    'B3_APCWT_ASCWT' AS LOGIC_TYPE

from  {{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_line_detail_view}} ld

 join {{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_detail_view}} sd
   on ld.STRUCTURED_STATEMENT_ID =  sd.STRUCTURED_STATEMENT_ID

join Service_code_table cw
on cw.prcdr_cd between sd.LOW_SERVICE_CD and sd.HIGH_SERVICE_CD
and  cw.srv_cd_type = sd.FACTOR_TYPE_CD   
 

join {{ce_project}}.{{ce_dataset}}.{{cet_scsr_service_detail_view}} svcdtl
  on svcdtl.SERVICE_CD = cw.prcdr_cd
 and svcdtl.SERVICE_TYPE_CD = cw.srv_cd_type

 join {{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_Qualifier_detail_view}} qd
   on qd.QUALIFIER_ID = ld.QUALIFIER_ID

 join {{ce_project}}.{{ce_dataset}}.{{cet_scsr_service_Affiliation_view}} aff
   on aff.MEMBER_SERVICE_CD = svcdtl.SERVICE_CD
  and aff.MEMBER_SERVICE_TYPE_CD = svcdtl.SERVICE_TYPE_CD

   join {{ce_project}}.{{ce_dataset}}.{{cet_business_group_view}} pbgnbr
    on pbgnbr.PROVIDER_BUSINESS_GROUP_NBR = qd.PROVIDER_BUSINESS_GROUP_NBR

JOIN {{ce_project}}.{{ce_dataset}}.{{cet_scsr_place_of_service_affiliation_view}}  pos
    ON  pos.MEMBER_PLACE_OF_SERVICE_CD  = cw.pos_cd

 join {{ce_project}}.{{ce_dataset}}.{{cet_scsr_relative_value_view}} rv
   on rv.SERVICE_CD = svcdtl.SERVICE_CD
  and rv.SERVICE_TYPE_CD = svcdtl.SERVICE_TYPE_CD
where ld.PAYMENT_METHOD_CD  in ('APCWT', 'ASCWT')
  and SERVICE_GROUP_CD <> ''
  and SERVICE_GROUP_CHANGED_IND = 'Y'
  and rv.RATE_SYSTEM_CD = 'MCAREW'
    and pos.OWNER_PLACE_OF_SERVICE_CD in ('E','F','I','O','S')

