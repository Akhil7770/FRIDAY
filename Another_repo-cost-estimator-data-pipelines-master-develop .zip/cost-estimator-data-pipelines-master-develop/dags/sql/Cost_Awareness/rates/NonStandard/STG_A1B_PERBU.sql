-- 5,334,000 after joining with SCM
INSERT INTO `{{ce_project}}.{{ce_dec_dataset}}.{{ca_rates_table}}` (
    
    RATE_SYSTEM_CD,
    SERVICE_CD,
    SERVICE_TYPE_CD,
    SERVICE_GROUP_CD,
    SERVICE_GROUPING_PRIORITY_NBR,
    SERVICE_GROUP_CHANGED_IND,
    PROVIDER_BUSINESS_GROUP_NBR,
    PRODUCT_CD,
    PLACE_OF_SERVICE_CD,
    PLACE_OF_SERVICE_KEY_CD,
    GEOGRAPHIC_AREA_CD,
    EXTENSION_CD,
    EXTENSION_TYPE,
    SPECIALTY_CD,
    SPECIALTY_TYPE_CD,
    PAYMENT_METHOD_CD,
    RATE,
    CNT_EFFTV_DT,
    CNT_TERMN_DT,
    CONTRACT_TYPE,
    LOGIC_TYPE
)
with  `Service_code_table` as
 (SELECT distinct prcdr_cd, srv_cd_type,pos_cd FROM `{{ce_project}}.{{ce_dataset}}.{{ca_radiology_codes}}`),
SELECT DISTINCT
     
    '' AS RATE_SYSTEM_CD,
    CASE
        WHEN LENGTH(TRIM(aff.MEMBER_SERVICE_CD)) = 3 AND aff.MEMBER_SERVICE_TYPE_CD IN ('REV', 'RC')
        THEN CONCAT('0', TRIM(aff.MEMBER_SERVICE_CD))
        ELSE aff.MEMBER_SERVICE_CD
    END AS SERVICE_CD,
    aff.MEMBER_SERVICE_TYPE_CD AS SERVICE_TYPE_CD,
    ld.SERVICE_GROUP_CD,
    svcdtl.SERVICE_GROUPING_PRIORITY_NBR,
    ld.SERVICE_GROUP_CHANGED_IND as SERVICE_GROUP_CHANGED_IND,
    qd.PROVIDER_BUSINESS_GROUP_NBR AS PROVIDER_BUSINESS_GROUP_NBR,
    pbgnbr.PRODUCT_CD,
    pos.MEMBER_PLACE_OF_SERVICE_CD AS PLACE_OF_SERVICE_CD,
    pos.OWNER_PLACE_OF_SERVICE_CD as PLACE_OF_SERVICE_KEY_CD,
    '' AS GEOGRAPHIC_AREA_CD,
    '' AS EXTENSION_CD,
    '' AS EXTENSION_TYPE,
    '' AS SPECIALTY_CD,
    '' AS SPECIALTY_TYPE_CD,
    ld.PAYMENT_METHOD_CD,
     cast(ld.RATE_PER_TYPE_CD as FLOAT64)*cast((CAST(svcdtl.ANESTHESIA_UNIT_CNT AS FLOAT64)+1) as FLOAT64) as RATE,
    CAST(qd.CONTRACT_EFFECTIVE_DT AS STRING) AS CNT_EFFTV_DT,
    CAST(qd.CONTRACT_TERM_DT AS STRING) AS CNT_TERMN_DT,
    'C' AS CONTRACT_TYPE,
    'A1B_PERBU' AS LOGIC_TYPE
FROM
    {{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_line_detail_view}} ld
JOIN {{ce_project}}.{{ce_dataset}}.{{cet_scsr_service_Affiliation_view}} aff
    ON ld.SERVICE_GROUP_CD = aff.OWNER_SERVICE_CD
    AND ld.SERVICE_GROUP_TYPE_CD = aff.OWNER_SERVICE_TYPE_CD
join Service_code_table cw
on aff.MEMBER_SERVICE_CD = cw.prcdr_cd
and aff.MEMBER_SERVICE_TYPE_CD = cw.srv_cd_type
JOIN {{ce_project}}.{{ce_dataset}}.{{cet_scsr_service_detail_view}} svcdtl
    ON svcdtl.SERVICE_CD = cw.prcdr_cd
    AND svcdtl.SERVICE_TYPE_CD = cw.srv_cd_type
JOIN {{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_detail_view}} sd
    ON sd.STRUCTURED_STATEMENT_ID = ld.STRUCTURED_STATEMENT_ID
JOIN {{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_Qualifier_detail_view}} qd
    ON qd.QUALIFIER_ID = CAST(ld.QUALIFIER_ID AS INT)

   join {{ce_project}}.{{ce_dataset}}.{{cet_business_group_view}} pbgnbr
    on pbgnbr.PROVIDER_BUSINESS_GROUP_NBR = qd.PROVIDER_BUSINESS_GROUP_NBR
JOIN {{ce_project}}.{{ce_dataset}}.{{cet_scsr_place_of_service_affiliation_view}}  pos
    ON  pos.MEMBER_PLACE_OF_SERVICE_CD  = cw.pos_cd

WHERE
    ld.PAYMENT_METHOD_CD = 'PERBU'
    AND ld.SERVICE_GROUP_CD <> ''
    AND ld.SERVICE_GROUP_CHANGED_IND = 'N'
    AND aff.MEMBER_SERVICE_TYPE_CD NOT IN ('AEG', 'SPU')
    AND aff.MEMBER_SERVICE_CD <> 'DEFAULT'
    and pos.OWNER_PLACE_OF_SERVICE_CD in ('E','F','I','O','S')
