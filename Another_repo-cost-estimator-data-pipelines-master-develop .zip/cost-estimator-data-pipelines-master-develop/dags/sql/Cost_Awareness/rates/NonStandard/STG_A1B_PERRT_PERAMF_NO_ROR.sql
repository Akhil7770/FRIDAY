-- NEEDS TO BE FIXED: taking time to execute the query
-- can we comment 'HMO' in below query check with priya and jyoti
-- 75,705,971 records after joining with service code master
INSERT INTO `{{ce_project}}.{{ce_dec_dataset}}.{{ca_rates_table}}` (
    
    RATE_SYSTEM_CD,
    SERVICE_CD,
    SERVICE_TYPE_CD,
    SERVICE_GROUP_CD,
    SERVICE_GROUPING_PRIORITY_NBR,
    SERVICE_GROUP_CHANGED_IND,
    PROVIDER_BUSINESS_GROUP_NBR,
    PRODUCT_CD,
    PLACE_OF_SERVICE_CD,
    PLACE_OF_SERVICE_KEY_CD,
    GEOGRAPHIC_AREA_CD,
    EXTENSION_CD,
    EXTENSION_TYPE,
    SPECIALTY_CD,
    SPECIALTY_TYPE_CD,
    PAYMENT_METHOD_CD,
    RATE,
    CNT_EFFTV_DT,
    CNT_TERMN_DT,
    CONTRACT_TYPE,
    LOGIC_TYPE
)
with  `Service_code_table` as
 (SELECT distinct prcdr_cd, srv_cd_type,pos_cd FROM `{{ce_project}}.{{ce_dataset}}.{{ca_radiology_codes}}`),
select distinct

rv.RATE_SYSTEM_CD,
case when (length(trim(svcdtl.SERVICE_CD))=3 and svcdtl.SERVICE_TYPE_CD in ('REV','RC')) then CONCAT('0',trim(svcdtl.SERVICE_CD)) else svcdtl.SERVICE_CD end as SERVICE_CD,
 svcdtl.SERVICE_TYPE_CD as SERVICE_TYPE_CD,
ld.SERVICE_GROUP_CD,
svcdtl.SERVICE_GROUPING_PRIORITY_NBR,
ld.SERVICE_GROUP_CHANGED_IND as SERVICE_GROUP_CHANGED_IND,
qd.PROVIDER_BUSINESS_GROUP_NBR as PROVIDER_BUSINESS_GROUP_NBR,
pbgnbr.PRODUCT_CD,
pos.MEMBER_PLACE_OF_SERVICE_CD AS PLACE_OF_SERVICE_CD,
pos.OWNER_PLACE_OF_SERVICE_CD as PLACE_OF_SERVICE_KEY_CD,
rv.GEOGRAPHIC_AREA_CD ,
rv.EXTENSION_CD , -- applicable for only PERRT/PERAMF
rv.EXTENSION_TYPE_CD as EXTENSION_TYPE, -- applicable for only PERRT/PERAMF
rv.SPECIALTY_CD , -- applicable for only PERRT/PERAMF
rv.SPECIALTY_TYPE_CD , 
ld.PAYMENT_METHOD_CD ,
case when ld.RATE_PERCENTAGE <>'1.0000' then cast(RATE_PERCENTAGE as FLOAT64) * cast(RATE_AMT as FLOAT64)
     when RATE_PERCENTAGE = '1.0000' then cast(RATE_AMT as FLOAT64)
end as RATE,
CAST(qd.CONTRACT_EFFECTIVE_DT AS STRING) AS CNT_EFFTV_DT,
CAST(qd.CONTRACT_TERM_DT AS STRING) AS CNT_TERMN_DT,
'C' AS CONTRACT_TYPE,
'A1B_PERRT_PERAMF_NON_ROR' AS LOGIC_TYPE
-- select distinct  count_big(*)
from {{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_line_detail_view}} ld
join {{ce_project}}.{{ce_dataset}}.{{cet_scsr_service_Affiliation_view}} aff
  on ld.SERVICE_GROUP_CD = aff.OWNER_SERVICE_CD
 and ld.SERVICE_GROUP_TYPE_CD = aff.OWNER_SERVICE_TYPE_CD

join Service_code_table cw
on aff.MEMBER_SERVICE_CD = cw.prcdr_cd
and aff.MEMBER_SERVICE_TYPE_CD = cw.srv_cd_type

left outer join {{ce_project}}.{{ce_dataset}}.{{cet_scsr_rate_override_view}} ro
             on ld.RATING_SYSTEM_CD = ro.RATE_SYSTEM_CD
            and ld.ZIP_CD = ro.GEOGRAPHIC_AREA_CD

join {{ce_project}}.{{ce_dataset}}.{{cet_scsr_rate_detail_view}} rv
  on rv.SERVICE_CD = cw.prcdr_cd
 and rv.SERVICE_TYPE_CD = cw.srv_cd_type
 and rv.RATE_SYSTEM_CD = ld.RATING_SYSTEM_CD
 and rv.GEOGRAPHIC_AREA_CD = ld.GEOGRAPHIC_AREA_CD

Join {{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_detail_view}} sd
  on SD.STRUCTURED_STATEMENT_ID = ld.STRUCTURED_STATEMENT_ID

 -- added STG_SCSR_SVCCDDTL to identify valid codes

 join {{ce_project}}.{{ce_dataset}}.{{cet_scsr_service_detail_view}} svcdtl
    ON svcdtl.SERVICE_CD = cw.prcdr_cd
    AND svcdtl.SERVICE_TYPE_CD = cw.srv_cd_type

join {{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_Qualifier_detail_view}} qd
     on qd.QUALIFIER_ID = ld.QUALIFIER_ID


    join         {{ce_project}}.{{ce_dataset}}.{{cet_scsr_differentiation_criteria_view}} TSDC
on TSDC.DIFFERENTIATION_CRITERIA_ID =   rv.DIFFERENTIATION_CRITERIA_ID
and cw.pos_cd = TSDC.PLACE_OF_SERVICE_CD

join (select distinct pbgnbr.PROVIDER_BUSINESS_GROUP_NBR ,pbgnbr.PRODUCT_CD
          from  {{ce_project}}.{{ce_dataset}}.{{cet_business_group_view}} pbgnbr) Pbgnbr
    on pbgnbr.PROVIDER_BUSINESS_GROUP_NBR = qd.PROVIDER_BUSINESS_GROUP_NBR

JOIN {{ce_project}}.{{ce_dataset}}.{{cet_scsr_place_of_service_affiliation_view}}  pos
    ON  pos.MEMBER_PLACE_OF_SERVICE_CD  = cw.pos_cd

where ld.PAYMENT_METHOD_CD in ('PERRT', 'PERAMF')
and SERVICE_GROUP_CD <> ''
and SERVICE_GROUP_CHANGED_IND = 'N'
and MEMBER_SERVICE_TYPE_CD not in ( 'AEG', 'SPU' )
and MEMBER_SERVICE_CD <> 'DEFAULT'
and ro.RATE_SYSTEM_CD is null
and pos.OWNER_PLACE_OF_SERVICE_CD in ('E','F','I','O','S')

union all

select distinct

rt.RATE_SYSTEM_CD,
case when (length(trim(svcdtl.SERVICE_CD))=3 and svcdtl.SERVICE_TYPE_CD in ('REV','RC')) then CONCAT('0',trim(svcdtl.SERVICE_CD)) else svcdtl.SERVICE_CD end as SERVICE_CD,
svcdtl.SERVICE_TYPE_CD as SERVICE_TYPE_CD,
ld.SERVICE_GROUP_CD,
svcdtl.SERVICE_GROUPING_PRIORITY_NBR,
    ld.SERVICE_GROUP_CHANGED_IND as SERVICE_GROUP_CHANGED_IND,
    qd.PROVIDER_BUSINESS_GROUP_NBR as PROVIDER_BUSINESS_GROUP_NBR,
pbgnbr.PRODUCT_CD ,
pos.MEMBER_PLACE_OF_SERVICE_CD AS PLACE_OF_SERVICE_CD,
pos.OWNER_PLACE_OF_SERVICE_CD as PLACE_OF_SERVICE_KEY_CD,
rt.GEOGRAPHIC_AREA_CD ,
rt.EXTENSION_CD , -- applicable for only PERRT/PERAMF
rt.EXTENSION_TYPE_CD as EXTENSION_TYPE, -- applicable for only PERRT/PERAMF
rt.SPECIALTY_CD , -- applicable for only PERRT/PERAMF
rt.SPECIALTY_TYPE_CD , 
ld.PAYMENT_METHOD_CD,
cast(ld.RATE_PERCENTAGE  as FLOAT64) * cast(rt.RATE_AMT as FLOAT64) RATE,
CAST(qd.CONTRACT_EFFECTIVE_DT AS STRING) AS CNT_EFFTV_DT,
CAST(qd.CONTRACT_TERM_DT AS STRING) AS CNT_TERMN_DT,
'C' AS CONTRACT_TYPE,
'A1B_PERRT_PERAMF_NON_ROR' AS LOGIC_TYPE

-- select distinct  count_big(*)
from
{{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_line_detail_view}} ld

join {{ce_project}}.{{ce_dataset}}.{{cet_scsr_service_Affiliation_view}} aff
  on ld.SERVICE_GROUP_CD = aff.OWNER_SERVICE_CD
 and ld.SERVICE_GROUP_TYPE_CD = aff.OWNER_SERVICE_TYPE_CD

join Service_code_table cw
on aff.MEMBER_SERVICE_CD = cw.prcdr_cd
and aff.MEMBER_SERVICE_TYPE_CD = cw.srv_cd_type

left outer join {{ce_project}}.{{ce_dataset}}.{{cet_scsr_rate_override_view}} ro
             on ld.RATING_SYSTEM_CD = ro.RATE_SYSTEM_CD
            and ld.ZIP_CD = ro.GEOGRAPHIC_AREA_CD

left outer join {{ce_project}}.{{ce_dataset}}.{{cet_scsr_rate_detail_view}} rt
  on rt.SERVICE_CD = MEMBER_SERVICE_CD
 and rt.SERVICE_TYPE_CD = MEMBER_SERVICE_TYPE_CD
 and rt.RATE_SYSTEM_CD = ld.RATING_SYSTEM_CD
 and rt.GEOGRAPHIC_AREA_CD = ld.GEOGRAPHIC_AREA_CD

 join {{ce_project}}.{{ce_dataset}}.{{cet_scsr_rate_detail_view}} rt2
  on rt2.SERVICE_CD = MEMBER_SERVICE_CD
 and rt2.SERVICE_TYPE_CD = MEMBER_SERVICE_TYPE_CD
 and rt2.RATE_SYSTEM_CD = ld.RATING_SYSTEM_CD
 and rt2.GEOGRAPHIC_AREA_CD = ld.GEOGRAPHIC_AREA_CD


Join {{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_detail_view}} sd
  on SD.STRUCTURED_STATEMENT_ID = ld.STRUCTURED_STATEMENT_ID


 -- added STG_SCSR_SVCCDDTL to identify valid codes

 join {{ce_project}}.{{ce_dataset}}.{{cet_scsr_service_detail_view}} svcdtl
   ON svcdtl.SERVICE_CD = cw.prcdr_cd
    AND svcdtl.SERVICE_TYPE_CD = cw.srv_cd_type

join {{ce_project}}.{{ce_dataset}}.{{cet_scm_fee_service_Qualifier_detail_view}} qd
       on qd.QUALIFIER_ID = ld.QUALIFIER_ID


  join         {{ce_project}}.{{ce_dataset}}.{{cet_scsr_differentiation_criteria_view}} TSDC
on TSDC.DIFFERENTIATION_CRITERIA_ID =   rt2.DIFFERENTIATION_CRITERIA_ID
and cw.pos_cd = TSDC.PLACE_OF_SERVICE_CD

join (select distinct pbgnbr.PROVIDER_BUSINESS_GROUP_NBR ,pbgnbr.PRODUCT_CD
          from  {{ce_project}}.{{ce_dataset}}.{{cet_business_group_view}} pbgnbr) Pbgnbr
    on pbgnbr.PROVIDER_BUSINESS_GROUP_NBR = qd.PROVIDER_BUSINESS_GROUP_NBR

JOIN {{ce_project}}.{{ce_dataset}}.{{cet_scsr_place_of_service_affiliation_view}}  pos
    ON  pos.MEMBER_PLACE_OF_SERVICE_CD  = cw.pos_cd

where ld.PAYMENT_METHOD_CD in ('PERRT', 'PERAMF')
and SERVICE_GROUP_CD <> ''
and SERVICE_GROUP_CHANGED_IND = 'N'
and MEMBER_SERVICE_TYPE_CD not in ( 'AEG', 'SPU' )
and MEMBER_SERVICE_CD <> 'DEFAULT'
and ro.RATE_SYSTEM_CD is null
and rt.SERVICE_CD is null
and ld.DEFAULT_RATING_SYSTEM_IND='Y'
and pos.OWNER_PLACE_OF_SERVICE_CD in ('E','F','I','O','S')
