MERGE `{{ce_project}}.{{ce_dataset}}.{{cost_awareness_providers}}` AS t
USING (
WITH outreach_keys AS (SELECT DISTINCT
      srv_prvdr_id,
      TRIM(srv_location_nbr) AS srv_location_nbr,
      LPAD(CAST(ntwk_id AS STRING), 5, '0') AS ntwk_id,
      TRIM(prcdr_cd) AS prcdr_cd,
      TRIM(srv_cd_type) AS srv_cd_type,
      TRIM(pos_cd) AS pos_cd,
      TRIM(e_pos_cd) AS e_pos_cd,
      trim(specialty_cd) as specialty_cd
      FROM
      `{{ce_project}}.{{ce_dataset}}.{{cost_awareness_providers}}`
      where pbg_nbrs is null
      and e_pos_cd is not null
      and e_rate is null
  ), ranked_rates as 
  (SELECT DISTINCT
    r.Rate AS Rate,
    k.srv_prvdr_id,
    k.srv_location_nbr,
    k.ntwk_id,
    k.prcdr_cd,
    k.e_pos_cd,
    r.CONTRACT_TYPE,
    k.srv_cd_type,
    Payment_method_cd,
    k.specialty_cd,
    r.SPECIALTY_CD as rate_specialty_cd,
    dense_rank() over ( partition by k.srv_prvdr_id,
    k.srv_location_nbr,
    k.ntwk_id,
    k.prcdr_cd,
    k.e_pos_cd,
    k.srv_cd_type,
    k.specialty_cd
    order by 
    case when (r.SPECIALTY_CD is not null and trim(r.SPECIALTY_CD) != '') then 2 else 1 end desc
     ) as rnk
  FROM
    `{{ce_project}}.{{ce_dec_dataset}}.{{ce_provider_table}}` AS p
 
    JOIN outreach_keys AS k
      ON p.PROVIDER_IDENTIFICATION_NBR = k.srv_prvdr_id
     AND CAST(p.SERVICE_LOCATION_NBR AS STRING) = k.srv_location_nbr
     AND LPAD(CAST(p.network_id AS STRING), 5, '0') = k.ntwk_id  
 
    JOIN `{{ce_project}}.{{ce_dec_dataset}}.{{ce_rates_table}}` AS r
      ON  (p.PRODUCT_CD = r.PRODUCT_CD or r.PRODUCT_CD = 'ALL') 
      AND p.epdb_GEOGRAPHIC_AREA_CD = r.GEOGRAPHIC_AREA_CD 
      AND p.RATING_SYSTEM_CD = r.RATE_SYSTEM_CD     
      AND CAST(r.service_cd AS STRING)  = k.prcdr_cd 
      AND CAST(r.service_type_cd AS STRING)  = k.srv_cd_type
      AND CAST(r.place_of_service_cd AS STRING)= k.e_pos_cd 
      and (k.specialty_cd = trim(r.SPECIALTY_CD) or trim(r.SPECIALTY_CD) is null or trim(r.SPECIALTY_CD) = '')
      and r.PROVIDER_BUSINESS_GROUP_NBR is null
      and p.PROVIDER_BUSINESS_GROUP_NBR is null
      and r.CONTRACT_TYPE ='S') 
select distinct max(k.Rate) as Rate
  ,k.srv_prvdr_id,
            k.srv_location_nbr,
            k.ntwk_id,
            k.prcdr_cd,
            k.e_pos_cd ,
            k.srv_cd_type,
            k.specialty_cd,
            ARRAY_AGG(k.CONTRACT_TYPE ORDER BY k.Rate DESC LIMIT 1)[OFFSET(0)] as contract_type,
            ARRAY_AGG(k.PAYMENT_METHOD_CD ORDER BY k.Rate DESC LIMIT 1)[OFFSET(0)] as PAYMENT_METHOD_CD,
            case  
            when count(case when k.rnk = 1 then 1 end) >= 2 and  count(distinct case when k.rnk = 1 then k.Rate end) > 1
            then 'Y'
            else 'N'
            end as e_max_rate,
            case when ARRAY_AGG(K.rate_specialty_cd ORDER BY k.Rate DESC LIMIT 1)[OFFSET(0)] is not null 
                 and trim(ARRAY_AGG(K.rate_specialty_cd ORDER BY k.Rate DESC LIMIT 1)[OFFSET(0)]) != ''
            THEN 'SPECIFIC'
            ELSE 'GENERIC'
            END as specialty_flag,
       from ranked_rates k
            where k.rnk = 1 
            group by 
            k.srv_prvdr_id,
            k.srv_location_nbr,
            k.ntwk_id,
            k.prcdr_cd,
            k.e_pos_cd,
            k.srv_cd_type,
            k.specialty_cd
) AS s
ON
  t.srv_prvdr_id = s.srv_prvdr_id
  AND TRIM(t.srv_location_nbr) = s.srv_location_nbr
  AND LPAD(CAST(t.ntwk_id AS STRING), 5, '0') = s.ntwk_id  
  AND TRIM(t.prcdr_cd) = s.prcdr_cd
  AND TRIM(t.e_pos_cd) = s.e_pos_cd
  and trim(t.srv_cd_type) = trim(s.srv_cd_type)
  and trim(t.specialty_cd) = trim(s.specialty_cd)
  and t.e_rate is null
WHEN MATCHED THEN
  UPDATE SET t.e_rate = CAST(s.Rate AS STRING)
  , t.e_contract_type = s.CONTRACT_TYPE 
  ,t.Payment_method_cd=s.Payment_method_cd
  ,t.e_max_rate = s.e_max_rate,
  t.specialty_flag = s.specialty_flag; --283,321
