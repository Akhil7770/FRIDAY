# Importing necessary modules and classes
import os, sys
sys.path.insert(0,os.path.abspath(os.path.dirname(__file__)))

from airflow.utils.dates import days_ago
from airflow import models
from airflow.models import DAG
from google.auth import impersonated_credentials, default
from airflow.providers.google.cloud.operators.bigquery import BigQueryInsertJobOperator
from datetime import datetime, timedelta
import os
from google.cloud import bigquery
from google.auth import impersonated_credentials
from airflow.providers.google.cloud.sensors.dataflow import DataflowJobStatusSensor
from google.cloud import dataflow_v1beta3
#from google.cloud import storage_transfer
import logging
import email_context as ec
import calling_config as ct 
from airflow.operators.python_operator import PythonOperator, BranchPythonOperator
from google.cloud import storage
import json
import pandas as pd
import pandas_gbq
from google.auth import impersonated_credentials
# from airflow.providers.google.cloud.transfers.bigquery_to_spanner import BigQueryToCloudSpannerOperator
from google.cloud import spanner
import google.auth
from google.cloud.spanner_v1 import param_types
from decimal import Decimal
from airflow.providers.apache.beam.operators.beam import BeamRunPythonPipelineOperator
from airflow.providers.google.cloud.operators.dataflow import DataflowConfiguration
from airflow.utils.task_group import TaskGroup
import pendulum, requests, time
from airflow.operators.email import EmailOperator
from airflow.utils.trigger_rule import TriggerRule
from airflow.utils.email import send_email

# APP_NAME=ct.config['config']['labels']['APP_NAME']

PROJECT_ID = os.environ.get("GCP_PROJECT").replace("-hcb","")+'-prv-ps-ce' 
TENANT = 'prv-ps-ce'
connect_sa = f"prv-ps-ce-hcb-connect@{PROJECT_ID}.iam.gserviceaccount.com"
resource_sa = f"gchcb-prv-ps-ce-ontpd@{PROJECT_ID}.iam.gserviceaccount.com"
#resource_sa = f"gchcb-provider-genai-secure-ontpd@anbc-hcb-dev.iam.gserviceaccount.com"
decrypt_sa = f"gchcb-prv-ps-ce-dec-ontpd@{PROJECT_ID}.iam.gserviceaccount.com"

# REPO_NAME = ct.config['config']['REPO_NAME']
# CUR_DIR = os.path.abspath(os.path.dirname(__file__))
USER = 'schubertc1'
ENV = ct.config['config']['GCP_ENV']
DAG_ID = f"{TENANT}-cost-estimator-data-pipelines-bqtospanner-cet_prvflag"
owner_name = f"{USER}_aetna_com"
if ENV.lower() == 'dev':
      RUN_ENV = 'nonprod'
elif ENV.lower() == 'prod':
      RUN_ENV = 'prod'
subnetwork_uri = ct.config['config']['subnetwork_uri']

bq_dataset = ct.config['config']['bq_dataset']['ce_dataset']
bq_dec_dataset = ct.config['config']['bq_dataset']['ce_dec_dataset']
bq_project = ct.config['config']['bq_dataset']['ce_project']
bq_input_table = ct.config['config']['APP_READ_TABLES']['cet_prvflag']
spanner_instance_id = ct.config['config']['spanner_instance_id'] #
spanner_database_id = ct.config['config']['spanner_database_id']
spanner_table_name = ct.config['config']['spanner_tables']['spanner_prvflag_table']['table_name']
spanner_stg_table_name = ct.config['config']['spanner_tables']['spanner_prvflag_table']['stg_name']
spanner_bkp_table_name=ct.config['config']['spanner_tables']['spanner_prvflag_table']['bkp_name']
py_folder_path = f"{TENANT}-hcb/cost-estimator-data-pipelines/py" 
REGION = ct.config['config']['REGION']

if ENV == 'dev':
    py_requirements_var = ['pip==22.2.2', 'apache-beam[gcp]==2.61.0']
    py_interpreter_var = "python3.11"
else:
    py_requirements_var = ['pip==22.2.2', 'apache-beam[gcp]==2.46.0']
    py_interpreter_var = "python3.8"


databases  = ct.config['config']['bq_dataset']

db = f"provider_de_hcb_{ENV}"
project_specific = {
    "db": db
    
}
COSTCENTER=ct.config['config']['COSTCENTER']
LABELS_CALL=ct.config['config']['labels']['CREATE_TABLE_LABEL']
LABELS=LABELS_CALL.format(OWNER=owner_name,COSTCENTER=COSTCENTER)
app_read_tables  = ct.config['config']['APP_READ_TABLES']

# Merging different config parameters into a single dictionary
params = ec.merge(app_read_tables, databases, project_specific)
params['COSTCENTER']= COSTCENTER
params['LABELS']=LABELS
params["owner_name"] = owner_name
VAULT = ct.config['config']['VAULT'] 
KMS_KEYRING = ct.config['config']['KMS_KEYRING'] 
#Define timezone

cache_url=ct.config['config']['cache_url']


credential, project= google.auth.default()
target_credentials= impersonated_credentials.Credentials(credential, target_principal= decrypt_sa, target_scopes= ["https://www.googleapis.com/auth/cloud-platform"])


success_to_mail=["ayesha.kesharia@CVSHealth.com"]
success_cc_mail = ["Prananditha.Manchikatla@CVSHealth.com"]

if ENV == 'dev':
    to_mail=["ayesha.kesharia@CVSHealth.com"]
    cc_mail= ["Prananditha.Manchikatla@CVSHealth.com"]
if ENV == 'prod':
    to_mail=["ayesha.kesharia@CVSHealth.com"]
    cc_mail = ["Prananditha.Manchikatla@CVSHealth.com"]

date_timezone=str(pendulum.now('US/Eastern'))


def email_function(flag,**kwargs):
    
    task_id = kwargs["task_instance"].task_id
    DAG_ID = kwargs["task_instance"].dag_id
    logs_url = kwargs['task_instance'].log_url
    to_email = to_mail
    cc_email = cc_mail
    if flag == 'failure':
         msg = '''
         <tr>
                <p>Hi ,</p> 
                <p>Below are the details about the run</p>
                
                <p>Dag_id   : %s,</p> 
                <p>Task_id  : %s,</p>
                <p>Status   :  <b style="color:red;">%s</b>,</p>
                <p>Date_Time: %s,</p>
                <p>Log_URL  : %s,</p>
                <p>              </p>
                <p>Thanks,\n     </p>
                <p>IO-OPS       </p>
                </tr>
                '''% (DAG_ID,task_id,"Failure",date_timezone,logs_url)
    else:
            msg = '''
            <tr>
                   <p>Hi ,</p> 
                   <p>Below are the details about the run</p>
                   
                   <p>Dag_id   : %s,</p> 
                   <p>Task_id  : %s,</p>
                   <p>Status   :  <b style="color:green;">%s</b>,</p>
                   <p>Date_Time: %s,</p>
                   <p>Log_URL  : %s,</p>
                   <p>              </p>
                   <p>Thanks,\n     </p>
                   <p>IO-OPS       </p>
                   </tr>
                   '''% (DAG_ID,task_id,"Success",date_timezone,logs_url)
        
        
    subject = "Cost Estimator"+ " : Spanner Data Load "+ flag + "!!"  

    send_email(to=to_email,cc=cc_email, subject=subject, html_content=msg)

def task_fail():
     raise Exception("Spanner Data Not found> Hence, not deleting CACHE!")


def create_staging_table(staging_table_name,**kwargs):
        
        counter = 0
        spanner_client = spanner.Client(credentials= target_credentials)
        instance = spanner_client.instance(spanner_instance_id)
        database = instance.database(spanner_database_id)
        get_index_query = f"""SELECT INDEX_NAME FROM information_schema.indexes 
            WHERE 
            table_name LIKE  '{staging_table_name}'
            and INDEX_TYPE = 'INDEX'"""
        with database.snapshot() as snapshot:
            results = snapshot.execute_sql(get_index_query)
            index_name = [row[0] for row in results]
        if index_name:
            print(f"indexes are present in the table {spanner_table_name} are")
            for index in index_name:
                print(index)
            print(f"index name is {index_name[0]}")
            counter = index_name[0].split('_')[-1]
        kwargs['ti'].xcom_push(key='indexes', value=index_name)
        if index_name:
            ddl_stat= [
                    f"""DROP INDEX IF EXISTS {index_name[0]}""",
                f"""DROP TABLE IF EXISTS {staging_table_name}"""]
            op = database.update_ddl(ddl_stat)
            op.result()
        else:
            ddl_stat= [f"""DROP TABLE IF EXISTS {staging_table_name}"""]
            op = database.update_ddl(ddl_stat)
            op.result()
             

        ddl_stat = [
            # To ensure we are using stage table for data dump and not main table
            f"""CREATE table {staging_table_name} (
                STG_CET_PRVFLAG_RECORD_ID STRING(100) NOT NULL,
                PROVIDER_IDENTIFICATION_NBR STRING(100),
                FLAG_CD STRING(100),
                PRV_FLAG STRING(100),
                UPDATE_DTS STRING(100),
                INSERT_DTS STRING(100),
                INSERT_USER STRING(100)   
                ) PRIMARY KEY (STG_CET_PRVFLAG_RECORD_ID)""",
            f"""CREATE INDEX IF NOT EXISTS {staging_table_name}_INDEX_{int(counter)+1} ON {staging_table_name} (PROVIDER_IDENTIFICATION_NBR)""",
             ]
        op = database.update_ddl(ddl_stat)
        op.result()
        print(f"Staging table {staging_table_name} created successfully")
        

def spanner_count_query(spanner_instance_id, spanner_database_id, table_name):
        

        client = spanner.Client(credentials= target_credentials)
        instance = client.instance(spanner_instance_id)
        database = instance.database(spanner_database_id)

        with database.snapshot() as snapshot:
              results = snapshot.execute_sql(f'select count(*) from {table_name}')

              for row in results:
                  count = row[0]
                  # row = next(results)
                  count = row[0]
                  print(f"Provider Smartcompare Flag : {count}")
                  return count


def branch_based_on_count(ti):
      count = ti.xcom_pull(task_ids='spanner_count')
      if count > 0:
            return 'swap_tables'
      else:
            return 'send_failure_email'


def swapping_tables(table_name, staging_table_name, backup_table_name,**kwargs):
      # Appended timestamp to backup table name
      timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
      backup_table_name_with_timestamp = f"""{backup_table_name}_{timestamp}"""
      
      spanner_client = spanner.Client(credentials= target_credentials)
      instance = spanner_client.instance(spanner_instance_id)
      database = instance.database(spanner_database_id)
      if database.table(table_name).exists():
           ddl_statement = [
           # To make sure main table has latest data dump from staging
           f"""ALTER TABLE {table_name} RENAME TO {backup_table_name_with_timestamp}""",
           f"""ALTER TABLE {staging_table_name} RENAME TO {table_name}"""
           ]
      else:
           ddl_statement = [
           # To make sure main table has latest data dump from staging
           f"""ALTER TABLE {staging_table_name} RENAME TO {table_name}"""
           ]
           
      
      operation = database.update_ddl(ddl_statement)
      operation.result()
      print(f"Tables swapped successfully")
      kwargs['ti'].xcom_push(key='backup_table_name', value=backup_table_name_with_timestamp)
      return backup_table_name_with_timestamp

# To delete all backup tables
def delete_all_old_backup_tables(spanner_instance_id, spanner_database_id,staging_table_name, **Kwargs):
      ti=Kwargs['ti']
      client = spanner.Client(credentials= target_credentials)
      instance = client.instance(spanner_instance_id)
      database = instance.database(spanner_database_id)
      backup_table_name_with_timestamp = ti.xcom_pull(task_ids='swap_tables',key='backup_table_name')
      query = f"""SELECT table_name FROM information_schema.tables 
            WHERE 
            table_name LIKE '{spanner_bkp_table_name}_%'"""
           #and not table_name = '{backup_table_name_with_timestamp}'"""
      with database.snapshot() as snapshot:
        results = snapshot.execute_sql(query)
        backup_tables = [row[0] for row in results]
      if  backup_tables:
           for backup_table in backup_tables:
                print(f"Deleting old backup table: {backup_table}")
                indexes = ti.xcom_pull(task_ids='create_staging_table', key='indexes')
                if indexes:
                    for index in indexes:
                        print(f"Deleting index {index} from backup table {backup_table}")
                        drop_index_statement = [f"""DROP INDEX IF EXISTS {index}"""]
                        operation = database.update_ddl(drop_index_statement)
                drop_statement = [f"""DROP TABLE {backup_table}"""]
                operation = database.update_ddl(drop_statement)
                operation.result()  # Wait for the operation to complete
                print(f"Old Backup table {backup_table} deleted successfully")
def fetch_and_push_dataflow_job_id(ti, project_id, location, job_name):
    job_name = job_name.replace('_', '-')
    base_credentials, _ = default()
    # Impersonate connect_sa
    impersonated_creds = impersonated_credentials.Credentials(
        source_credentials=base_credentials,
        target_principal=connect_sa,
        target_scopes=["https://www.googleapis.com/auth/cloud-platform"]
    )
    client = dataflow_v1beta3.JobsV1Beta3Client(credentials=impersonated_creds)
    request = dataflow_v1beta3.ListJobsRequest(project_id=project_id, location=location)
    jobs = client.list_jobs(request=request)
    for job in jobs.jobs:
        print(job)
        if job.current_state.name in ("JOB_STATE_RUNNING", "JOB_STATE_STARTING","JOB_STATE_PENDING") and job.name.startswith(job_name):
            ti.xcom_push(key='dataflow_job', value=job.id)
            print(f"Pushed Dataflow job ID: {job.id}")
            return job.id

    raise Exception(f"No Dataflow job found with name: {job_name}") 

default_args = {
    "start_date": days_ago(1),
    "project_id": PROJECT_ID,
    "retries": 0,
    "email_on_failure": False,
    "depends_on_past": False,
    "email_on_retry": False,
    "schedule_interval": "@once",
    "on_success_callback": ec.success_call,
    "on_failure_callback": ec.fail_call,
    "dataflow_kms_key": f"projects/anbc-mgmt/locations/{REGION}/keyRings/{KMS_KEYRING}/cryptoKeys/{PROJECT_ID}"  #need to check
}

with DAG(DAG_ID,
        schedule_interval=  None,  # Every 1 hr
        default_args=default_args,
        is_paused_upon_creation=True,
        catchup=False,
        user_defined_macros=params,
        tags=ct.DAG_TAGS # has to be included as per ANBC
        ) as dag:
    
    
    spanner_count = PythonOperator(

            task_id='spanner_count',
            python_callable = spanner_count_query,
            op_kwargs={
                  'spanner_instance_id': spanner_instance_id,
                  "spanner_database_id": spanner_database_id,
                  'table_name': spanner_stg_table_name
            }
      )

    branching = BranchPythonOperator(
            task_id = 'check_for_spanner',
            python_callable = branch_based_on_count,
            provide_context = True,
      )

    send_success_email = PythonOperator(
            task_id ='send_success_email',
            python_callable = email_function,
            op_kwargs={
                  'flag': 'success'
            },
            provide_context = True
      )

    send_failure_email = PythonOperator(
            task_id ='send_failure_email',
            python_callable = email_function,
            op_kwargs={
                  'flag': 'failure'
            },
            provide_context = True
      )

    failure_task = PythonOperator(

            task_id='failing_DAG_no_spanner_data',
            python_callable = task_fail
      )
    
    

    
    swap_tables = PythonOperator (
           task_id ='swap_tables',
           python_callable = swapping_tables,
            op_kwargs={
                  'spanner_instance_id': spanner_instance_id,
                  "spanner_database_id": spanner_database_id,
                  'table_name': spanner_table_name,
                  'staging_table_name': spanner_stg_table_name,
                  'backup_table_name' : spanner_bkp_table_name
            }
      )
    
    delete_old_backup_tables = PythonOperator(
           task_id ='delete_old_backup_tables',
           python_callable = delete_all_old_backup_tables,
           op_kwargs={
                'spanner_instance_id': spanner_instance_id,
                'spanner_database_id': spanner_database_id,
                'staging_table_name': spanner_stg_table_name
            }
    )

    with TaskGroup(group_id= 'e2e_spanner_case_volume') as e2e_spanner_case_volume:
      staging_table_create = PythonOperator(
            task_id ='staging_table_create',
            python_callable = create_staging_table,
            op_kwargs={
                  'staging_table_name': spanner_stg_table_name
            }
      )

      bq_spanner_convert_hourly_inv = BeamRunPythonPipelineOperator(
            task_id=f"{spanner_stg_table_name}_bq_tables_to_spanner",
            runner="DataflowRunner",
            py_file=f"{os.path.join(os.environ.get('DAGS_FOLDER'),py_folder_path)}/dataflow-bq-spanner.py",
            pipeline_options={ #need to check
                "tempLocation": f"gs://prv-ps-ce-dec-data-hcb-{ENV}/stg-temp-dataflow", 
                "maxNumWorkers": "55",
                "workerMachineType":"n2-standard-4",
               # "subnetwork": f"regions/us-east4/subnetworks/{subnetwork_uri}",
		        "subnetwork": "https://www.googleapis.com/compute/v1/projects/insurance-vpc/regions/us-east4/subnetworks/sn-aa-use4-anbc-dev-share",
                "experiments": ["use_network_tags=zsccnpuse4"],
                "no_use_public_ips": None,
                "worker_zone": "us-east4-a",
                "impersonate_service_account": connect_sa,
                "service_account_email": decrypt_sa,
                "staging_location": f"gs://prv-ps-ce-dec-data-hcb-{ENV}/stg-temp-dataflow",
		        "input_query": f"select STG_CET_PRVFLAG_RECORD_ID,TRIM(PROVIDER_IDENTIFICATION_NBR) AS PROVIDER_IDENTIFICATION_NBR,TRIM(FLAG_CD) AS FLAG_CD,PRV_FLAG,UPDATE_DTS,INSERT_DTS,INSERT_USER from `{bq_project}.{bq_dec_dataset}.{bq_input_table}`",
                "bq_project_id": f"{bq_project}",
                "bq_dataset_id": f"{bq_dec_dataset}",
                "bq_table_id": f"{bq_input_table}",
                "spanner_project_id": f"anbc-hcb-{ENV}",
                "spanner_instance_id": f"{spanner_instance_id}",
                "spanner_database_id": f"{spanner_database_id}",
                "spanner_table_id": f"{spanner_stg_table_name}",
                "dataflow_kms_key": f"projects/{VAULT}/locations/us-east4/keyRings/{KMS_KEYRING}/cryptoKeys/gk-{PROJECT_ID}-us-east4",
                "min_batch_size":"10000",
                "max_batch_size":"15000"
            },
            py_options=[],
            py_requirements=py_requirements_var,
            py_interpreter=py_interpreter_var,
            py_system_site_packages=False,
            dataflow_config=DataflowConfiguration(
                job_name=f'{spanner_stg_table_name}_spanner',
                location='us-east4',
                project_id=PROJECT_ID,
                impersonation_chain=decrypt_sa,
                drain_pipeline=False,
                cancel_timeout=5 * 60,
                wait_until_finished=True,
                )
      )

      push_job_id = PythonOperator(
           task_id='push_dataflow_job_id',
           python_callable=fetch_and_push_dataflow_job_id,
           op_kwargs={
                'project_id': PROJECT_ID,
                'location': 'us-east4',
                'job_name': spanner_stg_table_name,  # match your Dataflow job_name
                },
                provide_context=True,
                )

      wait_for_dataflow = DataflowJobStatusSensor(
           task_id='wait_for_dataflow',
           project_id=PROJECT_ID,
           location='us-east4',
           job_id="{{task_instance.xcom_pull(task_ids='e2e_spanner_case_volume.push_dataflow_job_id', key='dataflow_job')}}",
           expected_statuses=['JOB_STATE_DONE'],
           timeout=60*60*2,  # 2 hours
           poke_interval=60,
           impersonation_chain=connect_sa
      )      


    staging_table_create >> bq_spanner_convert_hourly_inv >> push_job_id >> wait_for_dataflow
#     truncate_table_spanner >> bq_spanner_convert

    e2e_spanner_case_volume >> spanner_count >> branching >> [swap_tables,send_failure_email] 
    swap_tables >> delete_old_backup_tables >> send_success_email 
    send_failure_email >> failure_task