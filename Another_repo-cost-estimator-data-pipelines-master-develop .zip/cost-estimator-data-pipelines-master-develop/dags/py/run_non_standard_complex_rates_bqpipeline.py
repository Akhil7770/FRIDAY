from airflow.utils.dates import days_ago
from airflow import models
from airflow.models import DAG
from airflow.providers.google.cloud.operators.bigquery import BigQueryInsertJobOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy_operator import DummyOperator
from datetime import datetime, timedelta
import os
import json
import os, sys

sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))
from google.cloud import bigquery
from google.cloud import storage
from google.auth import impersonated_credentials
import logging
import email_context as ec
import calling_config as ct
from datetime import datetime
from dateutil.relativedelta import relativedelta
from airflow.operators.python import PythonVirtualenvOperator
from airflow.operators.dagrun_operator import TriggerDagRunOperator

PROJECT_ID = os.environ.get("GCP_PROJECT").replace("-hcb", "") + "-prv-ps-ce"
# constant vars
resource_sa = f"gchcb-prv-ps-ce-ontpd@{PROJECT_ID}.iam.gserviceaccount.com"
decrypt_sa = f"gchcb-prv-ps-ce-dec-ontpd@{PROJECT_ID}.iam.gserviceaccount.com"
TENANT = "prv-ps-ce"
sql_folder_path = f"{TENANT}-hcb/cost-estimator-data-pipelines/sql/rates_table/nonstandard_complex_rates" 
USER = ct.config["config"]["USER"]
GCP_ENV = ct.config["config"]["GCP_ENV"]
DAG_ID = f"{TENANT}-cost-estimator-data-pipelines-nonstandard_complex_rates"
owner_name = f"{USER}_aetna_com"
DAGS_FOLDER = os.environ["DAGS_FOLDER"]
gcs_bucket = ct.config["config"]["CODE_BUCKET"]
user_low = f"{USER}".lower()
code_bucket = ct.config["config"]["CODE_BUCKET"]
data_bucket = ct.config["config"]["DATA_BUCKET"]
TRIGGER_DAG_ID = f"{TENANT}-cost-estimator-data-pipelines-cet_audit_logs"
COSTCENTER = ct.config["config"]["COSTCENTER"]
LABELS_CALL = ct.config["config"]["labels"]["CREATE_TABLE_LABEL"]
LABELS = LABELS_CALL.format(OWNER=owner_name, COSTCENTER=COSTCENTER)
print(f"""dag folder : {DAGS_FOLDER}""")
print("dag folder2 : ", os.environ.get("DAGS_FOLDER"), sql_folder_path)
db = f"provider_de_rfl_hcb_{GCP_ENV}"
ce_dec_dataset = ct.config["config"]["bq_dataset"]["ce_dec_dataset"]
ce_rates_table = ct.config["config"]["APP_READ_TABLES"]["ce_rates_table"]

project_specific = {"db": db}

app_read_tables = ct.config["config"]["APP_READ_TABLES"]
databases = ct.config["config"]["bq_dataset"]
params = ec.merge(app_read_tables, databases, project_specific)

params["COSTCENTER"] = COSTCENTER
params["LABELS"] = LABELS
params["owner_name"] = owner_name


default_args = {
    "start_date": days_ago(1),
    "project_id": PROJECT_ID,
    "retries": 0,
    "email_on_failure": False,
    "depends_on_past": False,
    "email_on_retry": False,
    "on_success_callback": ec.success_call,
    "on_failure_callback": ec.fail_call,
}

with DAG(
    DAG_ID,
    schedule_interval=None,
    default_args=default_args,
    is_paused_upon_creation=True,
    catchup=False,
    template_searchpath=os.path.join(
        os.environ.get("DAGS_FOLDER"), sql_folder_path
    ),  # this ensure that Airflow checks the files in Composer DAG bucket for SQL files
    user_defined_macros=params,
    tags=ct.DAG_TAGS,  # has to be included as per ANBC
) as dag:
    nonstd_a1a_scm = BigQueryInsertJobOperator(
        task_id="nonstd_a1a_scm",
        impersonation_chain=decrypt_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "labels": {
                "owner": owner_name,  # has to be included as per ANBC
                "application": "rates",
                "sub-application": "cost-estimator-data-pipelines",
                "dag-name": "cost-estimator-data-pipelines",
                "task-name": "nonstd_a1a_scm",
                "sequence": "1",
            },
            "query": {
                "query": "{% include 'NonStd_A1A_scm.sql' %}",  # referencing the file via templates
                "useLegacySql": False,  # uses standard SQL as dialect.
            },
        },
    )

    nonstd_a1b_combinationlogic = BigQueryInsertJobOperator(
        task_id="nonstd_a1b_combinationlogic",
        impersonation_chain=decrypt_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "labels": {
                "owner": owner_name,  # has to be included as per ANBC
                "application": "rates",
                "sub-application": "cost-estimator-data-pipelines",
                "dag-name": "cost-estimator-data-pipelines",
                "task-name": "nonstd_a1b_combinationlogic",
                "sequence": "1",
            },
            "query": {
                "query": "{% include 'NonStd_A1B_CombinationLogic.sql' %}",  # referencing the file via templates
                "useLegacySql": False,  # uses standard SQL as dialect.
            },
        },
    )

    nonstd_a1b_scm = BigQueryInsertJobOperator(
        task_id="nonstd_a1b_scm",
        impersonation_chain=decrypt_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "labels": {
                "owner": owner_name,  # has to be included as per ANBC
                "application": "rates",
                "sub-application": "cost-estimator-data-pipelines",
                "dag-name": "cost-estimator-data-pipelines",
                "task-name": "nonstd_a1b_scm",
                "sequence": "1",
            },
            "query": {
                "query": "{% include 'NonStd_A1B_scm.sql' %}",  # referencing the file via templates
                "useLegacySql": False,  # uses standard SQL as dialect.
            },
        },
    )

    nonstd_b12_b3_c12_c3_combinationlogic = BigQueryInsertJobOperator(
        task_id="nonstd_b12_b3_c12_c3_combinationlogic",
        impersonation_chain=decrypt_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "labels": {
                "owner": owner_name,  # has to be included as per ANBC
                "application": "rates",
                "sub-application": "cost-estimator-data-pipelines",
                "dag-name": "cost-estimator-data-pipelines",
                "task-name": "nonstd_b12_b3_c12_c3_combinationlogic",
                "sequence": "1",
            },
            "query": {
                "query": "{% include 'NonStd_B12_B3_C12_C3_CombinationLogic.sql' %}",  # referencing the file via templates
                "useLegacySql": False,  # uses standard SQL as dialect.
            },
        },
    )

    nonstd_b12_c12_1 = BigQueryInsertJobOperator(
        task_id="nonstd_b12_c12_1",
        impersonation_chain=decrypt_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "labels": {
                "owner": owner_name,  # has to be included as per ANBC
                "application": "rates",
                "sub-application": "cost-estimator-data-pipelines",
                "dag-name": "cost-estimator-data-pipelines",
                "task-name": "nonstd_b12_c12_1",
                "sequence": "1",
            },
            "query": {
                "query": "{% include 'NonStd_B12_C12_1.sql' %}",  # referencing the file via templates
                "useLegacySql": False,  # uses standard SQL as dialect.
            },
        },
    )

    nonstd_b12_c12_2 = BigQueryInsertJobOperator(
        task_id="nonstd_b12_c12_2",
        impersonation_chain=decrypt_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "labels": {
                "owner": owner_name,  # has to be included as per ANBC
                "application": "rates",
                "sub-application": "cost-estimator-data-pipelines",
                "dag-name": "cost-estimator-data-pipelines",
                "task-name": "nonstd_b12_c12_2",
                "sequence": "1",
            },
            "query": {
                "query": "{% include 'NonStd_B12_C12_2.sql' %}",  # referencing the file via templates
                "useLegacySql": False,  # uses standard SQL as dialect.
            },
        },
    )

    nonstd_b12_c12_3 = BigQueryInsertJobOperator(
        task_id="nonstd_b12_c12_3",
        impersonation_chain=decrypt_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "labels": {
                "owner": owner_name,  # has to be included as per ANBC
                "application": "rates",
                "sub-application": "cost-estimator-data-pipelines",
                "dag-name": "cost-estimator-data-pipelines",
                "task-name": "nonstd_b12_c12_3",
                "sequence": "1",
            },
            "query": {
                "query": "{% include 'NonStd_B12_C12_3.sql' %}",  # referencing the file via templates
                "useLegacySql": False,  # uses standard SQL as dialect.
            },
        },
    )

    
    

    nonstd_b3_c3 = BigQueryInsertJobOperator(
        task_id="nonstd_b3_c3",
        impersonation_chain=decrypt_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "labels": {
                "owner": owner_name,  # has to be included as per ANBC
                "application": "rates",
                "sub-application": "cost-estimator-data-pipelines",
                "dag-name": "cost-estimator-data-pipelines",
                "task-name": "nonstd_b3_c3",
                "sequence": "1",
            },
            "query": {
                "query": "{% include 'NonStd_B3_C3.sql' %}",  # referencing the file via templates
                "useLegacySql": False,  # uses standard SQL as dialect.
            },
        },
    )

    stg_a1a_apcwt_ascwt = BigQueryInsertJobOperator(
        task_id="stg_a1a_apcwt_ascwt",
        impersonation_chain=decrypt_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "labels": {
                "owner": owner_name,  # has to be included as per ANBC
                "application": "rates",
                "sub-application": "cost-estimator-data-pipelines",
                "dag-name": "cost-estimator-data-pipelines",
                "task-name": "stg_a1a_apcwt_ascwt",
                "sequence": "1",
            },
            "query": {
                "query": "{% include 'STG_A1A_APCWT_ASCWT.sql' %}",  # referencing the file via templates
                "useLegacySql": False,  # uses standard SQL as dialect.
            },
        },
    )

    stg_a1a_drgwt = BigQueryInsertJobOperator(
        task_id="stg_a1a_drgwt",
        impersonation_chain=decrypt_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "labels": {
                "owner": owner_name,  # has to be included as per ANBC
                "application": "rates",
                "sub-application": "cost-estimator-data-pipelines",
                "dag-name": "cost-estimator-data-pipelines",
                "task-name": "stg_a1a_drgwt",
                "sequence": "1",
            },
            "query": {
                "query": "{% include 'STG_A1A_DRGWT.sql' %}",  # referencing the file via templates
                "useLegacySql": False,  # uses standard SQL as dialect.
            },
        },
    )

    stg_a1a_perbu = BigQueryInsertJobOperator(
        task_id="stg_a1a_perbu",
        impersonation_chain=decrypt_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "labels": {
                "owner": owner_name,  # has to be included as per ANBC
                "application": "rates",
                "sub-application": "cost-estimator-data-pipelines",
                "dag-name": "cost-estimator-data-pipelines",
                "task-name": "stg_a1a_perbu",
                "sequence": "1",
            },
            "query": {
                "query": "{% include 'STG_A1A_PERBU.sql' %}",  # referencing the file via templates
                "useLegacySql": False,  # uses standard SQL as dialect.
            },
        },
    )

    stg_a1a_perrt_peramf_no_ror = BigQueryInsertJobOperator(
        task_id="stg_a1a_perrt_peramf_no_ror",
        impersonation_chain=decrypt_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "labels": {
                "owner": owner_name,  # has to be included as per ANBC
                "application": "rates",
                "sub-application": "cost-estimator-data-pipelines",
                "dag-name": "cost-estimator-data-pipelines",
                "task-name": "stg_a1a_perrt_peramf_no_ror",
                "sequence": "1",
            },
            "query": {
                "query": "{% include 'STG_A1A_PERRT_PERAMF_NO_ROR.sql' %}",  # referencing the file via templates
                "useLegacySql": False,  # uses standard SQL as dialect.
            },
        },
    )

    stg_a1a_perrt_peramf_ror = BigQueryInsertJobOperator(
        task_id="stg_a1a_perrt_peramf_ror",
        impersonation_chain=decrypt_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "labels": {
                "owner": owner_name,  # has to be included as per ANBC
                "application": "rates",
                "sub-application": "cost-estimator-data-pipelines",
                "dag-name": "cost-estimator-data-pipelines",
                "task-name": "stg_a1a_perrt_peramf_ror",
                "sequence": "1",
            },
            "query": {
                "query": "{% include 'STG_A1A_PERRT_PERAMF_ROR.sql' %}",  # referencing the file via templates
                "useLegacySql": False,  # uses standard SQL as dialect.
            },
        },
    )

    stg_a1b_apcwt_ascwt = BigQueryInsertJobOperator(
        task_id="stg_a1b_apcwt_ascwt",
        impersonation_chain=decrypt_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "labels": {
                "owner": owner_name,  # has to be included as per ANBC
                "application": "rates",
                "sub-application": "cost-estimator-data-pipelines",
                "dag-name": "cost-estimator-data-pipelines",
                "task-name": "stg_a1b_apcwt_ascwt",
                "sequence": "1",
            },
            "query": {
                "query": "{% include 'STG_A1B_APCWT_ASCWT.sql' %}",  # referencing the file via templates
                "useLegacySql": False,  # uses standard SQL as dialect.
            },
        },
    )

    stg_a1b_drgwt = BigQueryInsertJobOperator(
        task_id="stg_a1b_drgwt",
        impersonation_chain=decrypt_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "labels": {
                "owner": owner_name,  # has to be included as per ANBC
                "application": "rates",
                "sub-application": "cost-estimator-data-pipelines",
                "dag-name": "cost-estimator-data-pipelines",
                "task-name": "stg_a1b_drgwt",
                "sequence": "1",
            },
            "query": {
                "query": "{% include 'STG_A1B_DRGWT.sql' %}",  # referencing the file via templates
                "useLegacySql": False,  # uses standard SQL as dialect.
            },
        },
    )

    stg_a1b_perbu = BigQueryInsertJobOperator(
        task_id="stg_a1b_perbu",
        impersonation_chain=decrypt_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "labels": {
                "owner": owner_name,  # has to be included as per ANBC
                "application": "rates",
                "sub-application": "cost-estimator-data-pipelines",
                "dag-name": "cost-estimator-data-pipelines",
                "task-name": "stg_a1b_perbu",
                "sequence": "1",
            },
            "query": {
                "query": "{% include 'STG_A1B_PERBU.sql' %}",  # referencing the file via templates
                "useLegacySql": False,  # uses standard SQL as dialect.
            },
        },
    )

    stg_a1b_perrt_peramf_no_ror = BigQueryInsertJobOperator(
        task_id="stg_a1b_perrt_peramf_no_ror",
        impersonation_chain=decrypt_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "labels": {
                "owner": owner_name,  # has to be included as per ANBC
                "application": "rates",
                "sub-application": "cost-estimator-data-pipelines",
                "dag-name": "cost-estimator-data-pipelines",
                "task-name": "stg_a1b_perrt_peramf_no_ror",
                "sequence": "1",
            },
            "query": {
                "query": "{% include 'STG_A1B_PERRT_PERAMF_NO_ROR.sql' %}",  # referencing the file via templates
                "useLegacySql": False,  # uses standard SQL as dialect.
            },
        },
    )

    stg_a1b_perrt_peramf_ror = BigQueryInsertJobOperator(
        task_id="stg_a1b_perrt_peramf_ror",
        impersonation_chain=decrypt_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "labels": {
                "owner": owner_name,  # has to be included as per ANBC
                "application": "rates",
                "sub-application": "cost-estimator-data-pipelines",
                "dag-name": "cost-estimator-data-pipelines",
                "task-name": "stg_a1b_perrt_peramf_ror",
                "sequence": "1",
            },
            "query": {
                "query": "{% include 'STG_A1B_PERRT_PERAMF_ROR.sql' %}",  # referencing the file via templates
                "useLegacySql": False,  # uses standard SQL as dialect.
            },
        },
    )

    stg_b12_apcwt_ascwt = BigQueryInsertJobOperator(
        task_id="stg_b12_apcwt_ascwt",
        impersonation_chain=decrypt_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "labels": {
                "owner": owner_name,  # has to be included as per ANBC
                "application": "rates",
                "sub-application": "cost-estimator-data-pipelines",
                "dag-name": "cost-estimator-data-pipelines",
                "task-name": "stg_b12_apcwt_ascwt",
                "sequence": "1",
            },
            "query": {
                "query": "{% include 'STG_B12_APCWT_ASCWT.sql' %}",  # referencing the file via templates
                "useLegacySql": False,  # uses standard SQL as dialect.
            },
        },
    )

    stg_b12_drgwt = BigQueryInsertJobOperator(
        task_id="stg_b12_drgwt",
        impersonation_chain=decrypt_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "labels": {
                "owner": owner_name,  # has to be included as per ANBC
                "application": "rates",
                "sub-application": "cost-estimator-data-pipelines",
                "dag-name": "cost-estimator-data-pipelines",
                "task-name": "stg_b12_drgwt",
                "sequence": "1",
            },
            "query": {
                "query": "{% include 'STG_B12_DRGWT.sql' %}",  # referencing the file via templates
                "useLegacySql": False,  # uses standard SQL as dialect.
            },
        },
    )

    stg_b12_perbu = BigQueryInsertJobOperator(
        task_id="stg_b12_perbu",
        impersonation_chain=decrypt_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "labels": {
                "owner": owner_name,  # has to be included as per ANBC
                "application": "rates",
                "sub-application": "cost-estimator-data-pipelines",
                "dag-name": "cost-estimator-data-pipelines",
                "task-name": "stg_b12_perbu",
                "sequence": "1",
            },
            "query": {
                "query": "{% include 'STG_B12_PERBU.sql' %}",  # referencing the file via templates
                "useLegacySql": False,  # uses standard SQL as dialect.
            },
        },
    )

    stg_b12_perrt_peramf_no_ror = BigQueryInsertJobOperator(
        task_id="stg_b12_perrt_peramf_no_ror",
        impersonation_chain=decrypt_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "labels": {
                "owner": owner_name,  # has to be included as per ANBC
                "application": "rates",
                "sub-application": "cost-estimator-data-pipelines",
                "dag-name": "cost-estimator-data-pipelines",
                "task-name": "stg_b12_perrt_peramf_no_ror",
                "sequence": "1",
            },
            "query": {
                "query": "{% include 'STG_B12_PERRT_PERAMF_NO_ROR.sql' %}",  # referencing the file via templates
                "useLegacySql": False,  # uses standard SQL as dialect.
            },
        },
    )

    stg_b12_perrt_peramf_ror = BigQueryInsertJobOperator(
        task_id="stg_b12_perrt_peramf_ror",
        impersonation_chain=decrypt_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "labels": {
                "owner": owner_name,  # has to be included as per ANBC
                "application": "rates",
                "sub-application": "cost-estimator-data-pipelines",
                "dag-name": "cost-estimator-data-pipelines",
                "task-name": "stg_b12_perrt_peramf_ror",
                "sequence": "1",
            },
            "query": {
                "query": "{% include 'STG_B12_PERRT_PERAMF_ROR.sql' %}",  # referencing the file via templates
                "useLegacySql": False,  # uses standard SQL as dialect.
            },
        },
    )

    stg_b3_apcwt_ascwt = BigQueryInsertJobOperator(
        task_id="stg_b3_apcwt_ascwt",
        impersonation_chain=decrypt_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "labels": {
                "owner": owner_name,  # has to be included as per ANBC
                "application": "rates",
                "sub-application": "cost-estimator-data-pipelines",
                "dag-name": "cost-estimator-data-pipelines",
                "task-name": "stg_b3_apcwt_ascwt",
                "sequence": "1",
            },
            "query": {
                "query": "{% include 'STG_B3_APCWT_ASCWT.sql' %}",  # referencing the file via templates
                "useLegacySql": False,  # uses standard SQL as dialect.
            },
        },
    )

    stg_b3_drgwt = BigQueryInsertJobOperator(
        task_id="stg_b3_drgwt",
        impersonation_chain=decrypt_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "labels": {
                "owner": owner_name,  # has to be included as per ANBC
                "application": "rates",
                "sub-application": "cost-estimator-data-pipelines",
                "dag-name": "cost-estimator-data-pipelines",
                "task-name": "stg_b3_drgwt",
                "sequence": "1",
            },
            "query": {
                "query": "{% include 'STG_B3_DRGWT.sql' %}",  # referencing the file via templates
                "useLegacySql": False,  # uses standard SQL as dialect.
            },
        },
    )

    stg_b3_perbu = BigQueryInsertJobOperator(
        task_id="stg_b3_perbu",
        impersonation_chain=decrypt_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "labels": {
                "owner": owner_name,  # has to be included as per ANBC
                "application": "rates",
                "sub-application": "cost-estimator-data-pipelines",
                "dag-name": "cost-estimator-data-pipelines",
                "task-name": "stg_b3_perbu",
                "sequence": "1",
            },
            "query": {
                "query": "{% include 'STG_B3_PERBU.sql' %}",  # referencing the file via templates
                "useLegacySql": False,  # uses standard SQL as dialect.
            },
        },
    )

    stg_b3_perrt_peramf_no_ror = BigQueryInsertJobOperator(
        task_id="stg_b3_perrt_peramf_no_ror",
        impersonation_chain=decrypt_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "labels": {
                "owner": owner_name,  # has to be included as per ANBC
                "application": "rates",
                "sub-application": "cost-estimator-data-pipelines",
                "dag-name": "cost-estimator-data-pipelines",
                "task-name": "stg_b3_perrt_peramf_no_ror",
                "sequence": "1",
            },
            "query": {
                "query": "{% include 'STG_B3_PERRT_PERAMF_NO_ROR.sql' %}",  # referencing the file via templates
                "useLegacySql": False,  # uses standard SQL as dialect.
            },
        },
    )

    stg_b3_perrt_peramf_ror = BigQueryInsertJobOperator(
        task_id="stg_b3_perrt_peramf_ror",
        impersonation_chain=decrypt_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "labels": {
                "owner": owner_name,  # has to be included as per ANBC
                "application": "rates",
                "sub-application": "cost-estimator-data-pipelines",
                "dag-name": "cost-estimator-data-pipelines",
                "task-name": "stg_b3_perrt_peramf_ror",
                "sequence": "1",
            },
            "query": {
                "query": "{% include 'STG_B3_PERRT_PERAMF_ROR.sql' %}",  # referencing the file via templates
                "useLegacySql": False,  # uses standard SQL as dialect.
            },
        },
    )

    stg_c12_apcwt_ascwt = BigQueryInsertJobOperator(
        task_id="stg_c12_apcwt_ascwt",
        impersonation_chain=decrypt_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "labels": {
                "owner": owner_name,  # has to be included as per ANBC
                "application": "rates",
                "sub-application": "cost-estimator-data-pipelines",
                "dag-name": "cost-estimator-data-pipelines",
                "task-name": "stg_c12_apcwt_ascwt",
                "sequence": "1",
            },
            "query": {
                "query": "{% include 'STG_C12_APCWT_ASCWT.sql' %}",  # referencing the file via templates
                "useLegacySql": False,  # uses standard SQL as dialect.
            },
        },
    )

    stg_c12_drgwt = BigQueryInsertJobOperator(
        task_id="stg_c12_drgwt",
        impersonation_chain=decrypt_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "labels": {
                "owner": owner_name,  # has to be included as per ANBC
                "application": "rates",
                "sub-application": "cost-estimator-data-pipelines",
                "dag-name": "cost-estimator-data-pipelines",
                "task-name": "stg_c12_drgwt",
                "sequence": "1",
            },
            "query": {
                "query": "{% include 'STG_C12_DRGWT.sql' %}",  # referencing the file via templates
                "useLegacySql": False,  # uses standard SQL as dialect.
            },
        },
    )

    stg_c12_perbu = BigQueryInsertJobOperator(
        task_id="stg_c12_perbu",
        impersonation_chain=decrypt_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "labels": {
                "owner": owner_name,  # has to be included as per ANBC
                "application": "rates",
                "sub-application": "cost-estimator-data-pipelines",
                "dag-name": "cost-estimator-data-pipelines",
                "task-name": "stg_c12_perbu",
                "sequence": "1",
            },
            "query": {
                "query": "{% include 'STG_C12_PERBU.sql' %}",  # referencing the file via templates
                "useLegacySql": False,  # uses standard SQL as dialect.
            },
        },
    )

    stg_c12_perrt_peramf_no_ror = BigQueryInsertJobOperator(
        task_id="stg_c12_perrt_peramf_no_ror",
        impersonation_chain=decrypt_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "labels": {
                "owner": owner_name,  # has to be included as per ANBC
                "application": "rates",
                "sub-application": "cost-estimator-data-pipelines",
                "dag-name": "cost-estimator-data-pipelines",
                "task-name": "stg_c12_perrt_peramf_no_ror",
                "sequence": "1",
            },
            "query": {
                "query": "{% include 'STG_C12_PERRT_PERAMF_NO_ROR.sql' %}",  # referencing the file via templates
                "useLegacySql": False,  # uses standard SQL as dialect.
            },
        },
    )

    stg_c12_perrt_peramf_ror = BigQueryInsertJobOperator(
        task_id="stg_c12_perrt_peramf_ror",
        impersonation_chain=decrypt_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "labels": {
                "owner": owner_name,  # has to be included as per ANBC
                "application": "rates",
                "sub-application": "cost-estimator-data-pipelines",
                "dag-name": "cost-estimator-data-pipelines",
                "task-name": "stg_c12_perrt_peramf_ror",
                "sequence": "1",
            },
            "query": {
                "query": "{% include 'STG_C12_PERRT_PERAMF_ROR.sql' %}",  # referencing the file via templates
                "useLegacySql": False,  # uses standard SQL as dialect.
            },
        },
    )

    stg_c3_apcwt_ascwt = BigQueryInsertJobOperator(
        task_id="stg_c3_apcwt_ascwt",
        impersonation_chain=decrypt_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "labels": {
                "owner": owner_name,  # has to be included as per ANBC
                "application": "rates",
                "sub-application": "cost-estimator-data-pipelines",
                "dag-name": "cost-estimator-data-pipelines",
                "task-name": "stg_c3_apcwt_ascwt",
                "sequence": "1",
            },
            "query": {
                "query": "{% include 'STG_C3_APCWT_ASCWT.sql' %}",  # referencing the file via templates
                "useLegacySql": False,  # uses standard SQL as dialect.
            },
        },
    )

    stg_c3_drgwt = BigQueryInsertJobOperator(
        task_id="stg_c3_drgwt",
        impersonation_chain=decrypt_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "labels": {
                "owner": owner_name,  # has to be included as per ANBC
                "application": "rates",
                "sub-application": "cost-estimator-data-pipelines",
                "dag-name": "cost-estimator-data-pipelines",
                "task-name": "stg_c3_drgwt",
                "sequence": "1",
            },
            "query": {
                "query": "{% include 'STG_C3_DRGWT.sql' %}",  # referencing the file via templates
                "useLegacySql": False,  # uses standard SQL as dialect.
            },
        },
    )

    stg_c3_perbu = BigQueryInsertJobOperator(
        task_id="stg_c3_perbu",
        impersonation_chain=decrypt_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "labels": {
                "owner": owner_name,  # has to be included as per ANBC
                "application": "rates",
                "sub-application": "cost-estimator-data-pipelines",
                "dag-name": "cost-estimator-data-pipelines",
                "task-name": "stg_c3_perbu",
                "sequence": "1",
            },
            "query": {
                "query": "{% include 'STG_C3_PERBU.sql' %}",  # referencing the file via templates
                "useLegacySql": False,  # uses standard SQL as dialect.
            },
        },
    )

    stg_c3_perrt_peramf_no_ror = BigQueryInsertJobOperator(
        task_id="stg_c3_perrt_peramf_no_ror",
        impersonation_chain=decrypt_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "labels": {
                "owner": owner_name,  # has to be included as per ANBC
                "application": "rates",
                "sub-application": "cost-estimator-data-pipelines",
                "dag-name": "cost-estimator-data-pipelines",
                "task-name": "stg_c3_perrt_peramf_no_ror",
                "sequence": "1",
            },
            "query": {
                "query": "{% include 'STG_C3_PERRT_PERAMF_NO_ROR.sql' %}",  # referencing the file via templates
                "useLegacySql": False,  # uses standard SQL as dialect.
            },
        },
    )

    stg_c3_perrt_peramf_ror = BigQueryInsertJobOperator(
        task_id="stg_c3_perrt_peramf_ror",
        impersonation_chain=decrypt_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "labels": {
                "owner": owner_name,  # has to be included as per ANBC
                "application": "rates",
                "sub-application": "cost-estimator-data-pipelines",
                "dag-name": "cost-estimator-data-pipelines",
                "task-name": "stg_c3_perrt_peramf_ror",
                "sequence": "1",
            },
            "query": {
                "query": "{% include 'STG_C3_PERRT_PERAMF_ROR.sql' %}",  # referencing the file via templates
                "useLegacySql": False,  # uses standard SQL as dialect.
            },
        },
    )


    cet_audit_logs = TriggerDagRunOperator(
                task_id="cet_audit_logs",
                trigger_dag_id=TRIGGER_DAG_ID,  #entrypoint
                conf={"dataset_id":ce_dec_dataset, "table_name":ce_rates_table},
                dag=dag,
                wait_for_completion = True
    )

    create_split_table = BigQueryInsertJobOperator(
        task_id='create_split_table',
        impersonation_chain=decrypt_sa,
        configuration={
            "labels": {
                "owner": owner_name,  # has to be included as per ANBC
                "application": "rates",
                "sub-application": "cost-estimator-data-pipelines",
                "dag-name": "cost-estimator-data-pipelines",
                "task-name": "create_split_table",
                "sequence": "1",
            },
            "query": {
                "query": "{% include 'Create_Rates_split.sql' %}",  # referencing the file via templates
                "useLegacySql": False,  # uses standard SQL as dialect.
            },
        },
    )




start = DummyOperator(task_id="start",dag=dag)
set1 = DummyOperator(task_id="set1",dag=dag)
set2 = DummyOperator(task_id="set2",dag=dag)
set3 = DummyOperator(task_id="set3",dag=dag) 
set4 = DummyOperator(task_id="set4",dag=dag)
set5 = DummyOperator(task_id="set5",dag=dag) 
set6 = DummyOperator(task_id="set6",dag=dag)
set7 = DummyOperator(task_id="set7",dag=dag)
set8 = DummyOperator(task_id="set8",dag=dag)  
end = DummyOperator(task_id="end",dag=dag)

start >> set1 >> [nonstd_a1a_scm,nonstd_a1b_combinationlogic,nonstd_a1b_scm,nonstd_b12_b3_c12_c3_combinationlogic,nonstd_b12_c12_1] >> set2 >>[nonstd_b12_c12_2,nonstd_b12_c12_3,nonstd_b3_c3,stg_a1a_apcwt_ascwt,stg_a1a_drgwt] >> set3 >> [stg_a1a_perbu,stg_a1a_perrt_peramf_no_ror,stg_a1a_perrt_peramf_ror,stg_a1b_apcwt_ascwt,stg_a1b_drgwt] >> set4 >> [stg_a1b_perbu,stg_a1b_perrt_peramf_no_ror,stg_a1b_perrt_peramf_ror,stg_b12_apcwt_ascwt,stg_b12_drgwt] >> set5 >> [stg_b12_perbu,stg_b12_perrt_peramf_no_ror,stg_b12_perrt_peramf_ror,stg_b3_apcwt_ascwt,stg_b3_drgwt] >> set6 >> [stg_b3_perbu,stg_b3_perrt_peramf_no_ror,stg_b3_perrt_peramf_ror,stg_c12_apcwt_ascwt,stg_c12_drgwt] >> set7 >> [stg_c12_perbu,stg_c12_perrt_peramf_no_ror,stg_c12_perrt_peramf_ror,stg_c3_apcwt_ascwt,stg_c3_drgwt]>> set8 >> [stg_c3_perbu,stg_c3_perrt_peramf_no_ror,stg_c3_perrt_peramf_ror] >>cet_audit_logs >> create_split_table >> end
