from airflow.utils.dates import days_ago
from airflow import models
from airflow.models import DAG
from airflow.providers.google.cloud.operators.bigquery import BigQueryInsertJobOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy_operator import DummyOperator
from datetime import datetime, timedelta
import os
import json
import os, sys

sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))
from google.cloud import bigquery
from google.cloud import storage
from google.auth import impersonated_credentials
import logging
import email_context as ec
import calling_config as ct
from datetime import datetime
from dateutil.relativedelta import relativedelta
from airflow.operators.python import PythonVirtualenvOperator
from airflow.operators.dagrun_operator import TriggerDagRunOperator

PROJECT_ID = os.environ.get("GCP_PROJECT").replace("-hcb", "") + "-prv-ps-ce"
# constant vars
resource_sa = f"gchcb-prv-ps-ce-ontpd@{PROJECT_ID}.iam.gserviceaccount.com"
decrypt_sa = f"gchcb-prv-ps-ce-dec-ontpd@{PROJECT_ID}.iam.gserviceaccount.com"
TENANT = "prv-ps-ce"
sql_folder_path = f"{TENANT}-hcb/cost-estimator-data-pipelines/sql/rates_table/default_rates" 
USER = ct.config["config"]["USER"]
GCP_ENV = ct.config["config"]["GCP_ENV"]
DAG_ID = f"{TENANT}-cost-estimator-data-pipelines-default_contract_rates"
owner_name = f"{USER}_aetna_com"
DAGS_FOLDER = os.environ["DAGS_FOLDER"]
gcs_bucket = ct.config["config"]["CODE_BUCKET"]
user_low = f"{USER}".lower()
code_bucket = ct.config["config"]["CODE_BUCKET"]
data_bucket = ct.config["config"]["DATA_BUCKET"]
TRIGGER_DAG_ID = f"{TENANT}-cost-estimator-data-pipelines-cet_audit_logs"
COSTCENTER = ct.config["config"]["COSTCENTER"]
LABELS_CALL = ct.config["config"]["labels"]["CREATE_TABLE_LABEL"]
LABELS = LABELS_CALL.format(OWNER=owner_name, COSTCENTER=COSTCENTER)
print(f"""dag folder : {DAGS_FOLDER}""")
print("dag folder2 : ", os.environ.get("DAGS_FOLDER"), sql_folder_path)
ce_dec_dataset = ct.config["config"]["bq_dataset"]["ce_dec_dataset"]
ce_rates_table = ct.config["config"]["APP_READ_TABLES"]["ce_rates_table"]

app_read_tables = ct.config["config"]["APP_READ_TABLES"]
databases = ct.config["config"]["bq_dataset"]
params = ec.merge(app_read_tables, databases)

params["COSTCENTER"] = COSTCENTER
params["LABELS"] = LABELS
params["owner_name"] = owner_name


default_args = {
    "start_date": days_ago(1),
    "project_id": PROJECT_ID,
    "retries": 0,
    "email_on_failure": False,
    "depends_on_past": False,
    "email_on_retry": False,
    "on_success_callback": ec.success_call,
    "on_failure_callback": ec.fail_call,
}

with DAG(
    DAG_ID,
    schedule_interval=None,
    default_args=default_args,
    is_paused_upon_creation=True,
    catchup=False,
    template_searchpath=os.path.join(
        os.environ.get("DAGS_FOLDER"), sql_folder_path
    ),  # this ensure that Airflow checks the files in Composer DAG bucket for SQL files
    user_defined_macros=params,
    tags=ct.DAG_TAGS,  # has to be included as per ANBC
) as dag:
    non_standard_default_rates = BigQueryInsertJobOperator(
        task_id="non_standard_default_rates",
        impersonation_chain=decrypt_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "labels": {
                "owner": owner_name,  # has to be included as per ANBC
                "application": "rates",
                "sub-application": "cost-estimator-data-pipelines",
                "dag-name": "cost-estimator-data-pipelines",
                "task-name": "non_standard_default_rates",
                "sequence": "1",
            },
            "query": {
                "query": "{% include 'non_std_default_rates.sql' %}",  # referencing the file via templates
                "useLegacySql": False,  # uses standard SQL as dialect.
            },
        },
    )

    complex_pay_default_rates = BigQueryInsertJobOperator(
        task_id="complex_pay_default_rates",
        impersonation_chain=decrypt_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "labels": {
                "owner": owner_name,  # has to be included as per ANBC
                "application": "rates",
                "sub-application": "cost-estimator-data-pipelines",
                "dag-name": "cost-estimator-data-pipelines",
                "task-name": "complex_pay_default_rates",
                "sequence": "2",
            },
            "query": {
                "query": "{% include 'complex_pay_default_rates.sql' %}",  # referencing the file via templates
                "useLegacySql": False,  # uses standard SQL as dialect.
            },
        },
    )

    cet_audit_logs = TriggerDagRunOperator(
                task_id="cet_audit_logs",
                trigger_dag_id=TRIGGER_DAG_ID,  #entrypoint
                conf={"dataset_id":ce_dec_dataset, "table_name":ce_rates_table},
                dag=dag,
                wait_for_completion = True
    )


non_standard_default_rates >> complex_pay_default_rates >> cet_audit_logs

