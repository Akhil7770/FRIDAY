import pandas as pd
from google.cloud import bigquery
from datetime import datetime
import email_context as ec
import calling_config as ct
from datetime import datetime, timedelta,timezone
import os
import os, sys
import uuid
import pandas as pd
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))
from google.cloud import bigquery
from google.cloud import storage
from google.auth import impersonated_credentials
import logging
import email_context as ec
import calling_config as ct
from datetime import datetime
from dateutil.relativedelta import relativedelta
import google
from google.auth import impersonated_credentials
from google.api_core.exceptions import NotFound 


log = logging.getLogger(__name__)

job_start_load_dts = datetime.now()
log.info("\nJob Start Time : {}".format(job_start_load_dts))

PROJECT_ID = os.environ.get("GCP_PROJECT").replace("-hcb","")+'-prv-ps-ce'
# constant vars
resource_sa = f"gchcb-prv-ps-ce-ontpd@{PROJECT_ID}.iam.gserviceaccount.com"
decrypt_sa = f"gchcb-prv-ps-ce-dec-ontpd@{PROJECT_ID}.iam.gserviceaccount.com"
# Initialize BigQuery client
credential, project = google.auth.default()
target_credentials = impersonated_credentials.Credentials(credential, target_principal=decrypt_sa, target_scopes=["https://www.googleapis.com/auth/cloud-platform"])
bq_client = bigquery.Client(project=PROJECT_ID, credentials=target_credentials) # EngX Compute


# Define variables
project_id_ce = ct.config['config']['bq_dataset']['ce_project']
dataset_id = ct.config['config']['bq_dataset']['ce_dec_dataset']
ce_scm = ct.config["config"]["APP_READ_TABLES"]["ce_scm"]
archive_table_id = "service_code_master_archive"
current_year_month = datetime.now().strftime("%Y%m")
current_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def service_code_master_archival():
    # Query to fetch the current service_code_master data
    query = f"""SELECT  primary_svc_cd,
                        servc_type,
                        svc_name,
                        svc_desc,
                        user_friendly_title,
                        user_friendly_desc,
                        min_age,
                        max_age,
                        efftv_dt,
                        trmn_dt,
                        benefit_types,
                        in_scope_ind,
                        supporting_pos_cd,
                        specialty_codes, 
                        '{current_year_month}' AS year_month,
                        CURRENT_TIMESTAMP() AS archived_timestamp
                FROM `{project_id_ce}.{dataset_id}.{ce_scm}`;"""

    log.info('Executing query to fetch data from BigQuery service code master table')
    # Fetch data into a DataFrame
    service_master_df = bq_client.query(query).to_dataframe()

    # Reference to the archive table
    archive_table_ref = f"{project_id_ce}.{dataset_id}.{archive_table_id}"

    # Check if the archive table exists
    try:
        bq_client.get_table(archive_table_ref)  # Try to fetch the table
        table_exists = True
        log.info("Archival Table present {}".format(archive_table_id))
    except NotFound:
        table_exists = False
        log.info("Archival Table Not Found {}".format(archive_table_id))

    # Load data into the archive table
    if table_exists:
        check_query = f"""SELECT COUNT(*) AS record_count
                            FROM `{archive_table_ref}`
                        WHERE year_month = '{current_year_month}';"""
        log.info(f"Checking if data for year_month {current_year_month} exists in the archive table")
        result = bq_client.query(check_query).to_dataframe()
        record_count = result['record_count'][0]

        if record_count > 0:
            log.info(f"Data for year_month {current_year_month} already exists in the archive table. Skipping insertion.")
            return
        else:
            log.info(f"No data for year_month {current_year_month} found in the archive table. Proceeding with insertion.")

        # Append records if the table exists
        job_config = bigquery.LoadJobConfig(write_disposition="WRITE_APPEND")
        log.info("Archival Table {} is loaded.".format(archive_table_id))
    else:
        # Create the table and write records if it does not exist
        job_config = bigquery.LoadJobConfig(write_disposition="WRITE_EMPTY")
        log.info("Archival Table {} is created and table loaded.".format(archive_table_id))

    load_job = bq_client.load_table_from_dataframe(service_master_df, archive_table_ref, job_config=job_config)
    load_job.result()  # Wait for the job to complete

    print(f"Data archived successfully for {current_year_month} into {archive_table_id}.")
    log.info("Data archived successfully for {} into {}".format(current_year_month, archive_table_id))
