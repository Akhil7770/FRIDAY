from airflow.utils.dates import days_ago
from airflow import models
from airflow.models import DAG
from airflow.providers.google.cloud.operators.bigquery import BigQueryInsertJobOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy_operator import DummyOperator
from datetime import datetime, timedelta
import os
import json
import os, sys
from airflow.utils.task_group import TaskGroup

sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))
from google.cloud import bigquery
from google.cloud import storage
from google.auth import impersonated_credentials
import logging
import email_context as ec
import calling_config as ct
from datetime import datetime
from dateutil.relativedelta import relativedelta
from airflow.operators.python import PythonVirtualenvOperator
from airflow.operators.dagrun_operator import TriggerDagRunOperator


PROJECT_ID = os.environ.get("GCP_PROJECT").replace("-hcb","")+'-prv-ps-ce'
# constant vars
resource_sa = f"gchcb-prv-ps-ce-ontpd@{PROJECT_ID}.iam.gserviceaccount.com"
decrypt_sa = f"gchcb-prv-ps-ce-dec-ontpd@{PROJECT_ID}.iam.gserviceaccount.com"
TENANT = 'prv-ps-ce'
sql_folder_path = f"{TENANT}-hcb/cost-estimator-data-pipelines/sql/Cost_Awareness" 
USER = ct.config["config"]["USER"]
GCP_ENV = ct.config["config"]["GCP_ENV"]
DAG_ID = f"{TENANT}-cost-estimator-data-pipelines-cost-awareness"
owner_name = f"{USER}_aetna_com"
DAGS_FOLDER = os.environ["DAGS_FOLDER"]
gcs_bucket = ct.config["config"]["CODE_BUCKET"]
user_low = f"{USER}".lower()
code_bucket = ct.config["config"]["CODE_BUCKET"]
data_bucket = ct.config["config"]["DATA_BUCKET"]
TRIGGER_DAG_ID = f"{TENANT}-cost-estimator-data-pipelines-cet_audit_logs"
COSTCENTER = ct.config["config"]["COSTCENTER"]
LABELS_CALL = ct.config["config"]["labels"]["CREATE_TABLE_LABEL"]
LABELS = LABELS_CALL.format(OWNER=owner_name, COSTCENTER=COSTCENTER)
dataset_id = ct.config['config']['bq_dataset']['ce_dec_dataset']
cet_providers = ct.config["config"]["APP_READ_TABLES"]["ce_dec_provider_table"]
cost_awareness_providers = ct.config["config"]["APP_READ_TABLES"]["cost_awareness_providers"]


db = f"cost_awareness_hcb_{GCP_ENV}"


project_specific = {
    "db": db
    
}

app_read_tables = ct.config["config"]["APP_READ_TABLES"]
databases = ct.config["config"]["bq_dataset"]
params = ec.merge(app_read_tables, databases, project_specific)

params["COSTCENTER"] = COSTCENTER
params["LABELS"] = LABELS
params["owner_name"] = owner_name


default_args = {
    "start_date": days_ago(1),
    "project_id": PROJECT_ID,
    "retries": 0,
    "email_on_failure": False,
    "depends_on_past": False,
    "email_on_retry": False,
    "on_success_callback": ec.success_call,
    "on_failure_callback": ec.fail_call,
}

with DAG(
    DAG_ID,
    schedule_interval=None,
    default_args=default_args,
    is_paused_upon_creation=True,
    catchup=False,
    template_searchpath=os.path.join(
        os.environ.get("DAGS_FOLDER"), sql_folder_path
    ),  # this ensure that Airflow checks the files in Composer DAG bucket for SQL files
    user_defined_macros=params,
    tags=ct.DAG_TAGS,  # has to be included as per ANBC
) as dag:

    with TaskGroup(group_id= 'pos_pbg_cost_awareness') as pos_pbg_cost_awareness:
        script_cost_awareness_place_of_service = BigQueryInsertJobOperator(
        task_id="script_cost_awareness_place_of_service",
        impersonation_chain=resource_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "labels": {
                "owner": owner_name,  # has to be included as per ANBC
                "application": "cost-awareness",
                "task-name": "script_cost_awareness_place_of_service",
                "sequence": "1",
            },
            "query": {
                "query": "{% include 'insert_pos.sql'%}",  # referencing the file via templates
                "useLegacySql": False,  # uses standard SQL as dialect.
            },
        },
    )
        script_cost_awareness_provider_business_group_nbrs = BigQueryInsertJobOperator(
        task_id="script_cost_awareness_provider_business_group_nbrs",
        impersonation_chain=resource_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "labels": {
                "owner": owner_name,  # has to be included as per ANBC
                "application": "cost-awareness",
                "task-name": "script_cost_awareness_provider_business_group_nbrs",
                "sequence": "2",
            },
            "query": {
                "query": "{% include 'insert_pbg_nbrs.sql'%}",  # referencing the file via templates
                "useLegacySql": False,  # uses standard SQL as dialect.
            },
        },
    )
    script_cost_awareness_place_of_service >> script_cost_awareness_provider_business_group_nbrs

    with TaskGroup(group_id= 'rates_cost_awareness') as rates_cost_awareness:
        script_cost_awareness_claims_rates = BigQueryInsertJobOperator(
        task_id="script_cost_awareness_claims_rates",
        impersonation_chain=resource_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "labels": {
                "owner": owner_name,  # has to be included as per ANBC
                "application": "cost-awareness",
                "task-name": "script_cost_awareness_claims_rates",
                "sequence": "3",
            },
            "query": {
                "query": "{% include 'Claims_rates.sql'%}",  # referencing the file via templates
                "useLegacySql": False,  # uses standard SQL as dialect.
            },
        },
        )
        script_cost_awareness_standard_rates = BigQueryInsertJobOperator(
        task_id="script_cost_awareness_standard_rates",
        impersonation_chain=resource_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "labels": {
                "owner": owner_name,  # has to be included as per ANBC
                "application": "cost-awareness",
                "task-name": "script_cost_awareness_standard_rates",
                "sequence": "4",
            },
            "query": {
                "query": "{% include 'Standard_rates.sql'%}",  # referencing the file via templates
                "useLegacySql": False,  # uses standard SQL as dialect.
            },
        },
        )
        script_cost_awareness_non_standard_rates = BigQueryInsertJobOperator(
        task_id="script_cost_awareness_non_standard_rates",
        impersonation_chain=resource_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "labels": {
                "owner": owner_name,  # has to be included as per ANBC
                "application": "cost-awareness",
                "task-name": "script_cost_awareness_non_standard_rates",
                "sequence": "5",
            },
            "query": {
                "query": "{% include 'NonStandard_rates.sql'%}",  # referencing the file via templates
                "useLegacySql": False,  # uses standard SQL as dialect.
            },
        },
        )
    script_cost_awareness_claims_rates >> script_cost_awareness_standard_rates >> script_cost_awareness_non_standard_rates

    with TaskGroup(group_id= 'update_comments') as update_comments:
        script_update_comments = BigQueryInsertJobOperator(
        task_id="script_update_comments",
        impersonation_chain=resource_sa,  # SA Airflow uses to impersonate while interacting with BQ
        configuration={
            "labels": {
                "owner": owner_name,  # has to be included as per ANBC
                "application": "cost-awareness",
                "task-name": "script_update_comments",
                "sequence": "6",
            },
            "query": {
                "query": "{% include 'Update_comments.sql'%}",  # referencing the file via templates
                "useLegacySql": False,  # uses standard SQL as dialect.
            },
        },
    )
    script_update_comments  
    

    pos_pbg_cost_awareness >> rates_cost_awareness >> update_comments


    
    