# OpenTelemetry Traces and Metrics Integration - Cost Estimator Calc Service

## Table of Contents
1. [Overview](#overview)
2. [Architecture](#architecture)
3. [Implementation Details](#implementation-details)
4. [Metrics](#metrics)
5. [Tracing](#tracing)
6. [Configuration](#configuration)
7. [Deployment](#deployment)
8. [Monitoring and Observability](#monitoring-and-observability)
9. [Troubleshooting](#troubleshooting)
10. [Best Practices](#best-practices)

---

## Overview

The Cost Estimator Calc Service implements comprehensive OpenTelemetry integration for both **traces** and **metrics** to provide full observability into the cost estimation process. This integration enables monitoring, debugging, and performance analysis of the service.

### Key Features
- **Distributed Tracing**: Complete request flow tracking from API endpoint to business logic
- **Custom Metrics**: Response times, error rates, and business-specific metrics
- **Request/Response Capture**: Full payload capture for debugging
- **Automatic Instrumentation**: FastAPI and HTTP client instrumentation
- **GCP Integration**: Direct export to Google Cloud Monitoring and Cloud Trace

---

## Architecture

### System Architecture

```mermaid
graph TB
    Client[Client Application] --> LB[Load Balancer]
    LB --> API[Cost Estimator API]
    API --> Service[Cost Estimation Service]
    Service --> Benefit[Benefit Service]
    Service --> Accumulator[Accumulator Service]
    Service --> Spanner[Spanner Database]
    
    API --> OTEL[OpenTelemetry Collector]
    Service --> OTEL
    Benefit --> OTEL
    Accumulator --> OTEL
    Spanner --> OTEL
    
    OTEL --> GCP[Google Cloud Monitoring]
    OTEL --> GCPTrace[Google Cloud Trace]
    
    subgraph "Observability Stack"
        OTEL
        GCP
        GCPTrace
    end
```

### Complete Observability Architecture

```mermaid
graph TB
    subgraph "Application Layer"
        CalcService[Cost Estimator Calc Service]
        FastAPI[FastAPI Application]
        BusinessLogic[Business Logic Services]
        ExternalAPIs[External APIs<br/>Benefit, Accumulator, Spanner]
    end
    
    subgraph "OpenTelemetry Sidecar"
        OTELCollector[OpenTelemetry Collector<br/>otel/opentelemetry-collector-contrib:0.88.0]
        OTLPReceiver[OTLP Receiver<br/>Port 4318/4317]
        BatchProcessor[Batch Processor]
        ResourceProcessor[Resource Processor]
        OTLPExporter[OTLP Exporter]
    end
    
    subgraph "Google Cloud Platform"
        GCPMetrics[Google Cloud Monitoring<br/>Metrics Collection]
        GCPTraces[Google Cloud Trace<br/>Distributed Tracing]
        GCPLogs[Google Cloud Logging<br/>Centralized Logs]
    end
    
    subgraph "Metrics Pipeline"
        Prometheus[Prometheus<br/>Metrics Storage & Query]
        PromQL[PromQL Queries]
        MetricsRules[Alerting Rules]
    end
    
    subgraph "Traces Pipeline"
        Tempo[Tempo<br/>Distributed Tracing Backend]
        TraceQuery[Trace Query API]
        TraceStorage[Trace Storage]
    end
    
    subgraph "Visualization Layer"
        Grafana[Grafana<br/>Observability Platform]
        Dashboards[Custom Dashboards]
        Alerts[Alerting & Notifications]
    end
    
    subgraph "Data Flow"
        MetricsFlow[Metrics Flow]
        TracesFlow[Traces Flow]
        LogsFlow[Logs Flow]
    end
    
    %% Application to Sidecar
    CalcService --> OTELCollector
    FastAPI --> OTELCollector
    BusinessLogic --> OTELCollector
    ExternalAPIs --> OTELCollector
    
    %% Sidecar Processing
    OTELCollector --> OTLPReceiver
    OTLPReceiver --> BatchProcessor
    BatchProcessor --> ResourceProcessor
    ResourceProcessor --> OTLPExporter
    
    %% Sidecar to GCP
    OTLPExporter --> GCPMetrics
    OTLPExporter --> GCPTraces
    OTLPExporter --> GCPLogs
    
    %% GCP to Storage
    GCPMetrics --> Prometheus
    GCPTraces --> Tempo
    GCPLogs --> Tempo
    
    %% Storage to Visualization
    Prometheus --> Grafana
    Tempo --> Grafana
    
    %% Grafana Components
    Grafana --> Dashboards
    Grafana --> Alerts
    Prometheus --> PromQL
    Tempo --> TraceQuery
    Tempo --> TraceStorage
    
    %% Data Flow Labels
    MetricsFlow -.-> Prometheus
    TracesFlow -.-> Tempo
    LogsFlow -.-> GCPLogs
    
    %% Styling
    classDef appLayer fill:#e1f5fe
    classDef sidecarLayer fill:#f3e5f5
    classDef gcpLayer fill:#e8f5e8
    classDef storageLayer fill:#fff3e0
    classDef vizLayer fill:#fce4ec
    
    class CalcService,FastAPI,BusinessLogic,ExternalAPIs appLayer
    class OTELCollector,OTLPReceiver,BatchProcessor,ResourceProcessor,OTLPExporter sidecarLayer
    class GCPMetrics,GCPTraces,GCPLogs gcpLayer
    class Prometheus,Tempo,PromQL,TraceQuery,TraceStorage storageLayer
    class Grafana,Dashboards,Alerts vizLayer
```

### Component Architecture

```mermaid
graph LR
    subgraph "Application Layer"
        FastAPI[FastAPI App]
        Routes[API Routes]
        Services[Business Services]
    end
    
    subgraph "OpenTelemetry Layer"
        AutoInst[Auto Instrumentation]
        CustomDec[Custom Decorators]
        Metrics[Custom Metrics]
        Traces[Custom Traces]
    end
    
    subgraph "Export Layer"
        OTLP[OTLP Exporter]
        Sidecar[Collector Sidecar]
        GCP[GCP Services]
    end
    
    FastAPI --> AutoInst
    Routes --> CustomDec
    Services --> CustomDec
    CustomDec --> Metrics
    CustomDec --> Traces
    AutoInst --> OTLP
    Metrics --> OTLP
    Traces --> OTLP
    OTLP --> Sidecar
    Sidecar --> GCP
```

### Data Flow Architecture

```mermaid
sequenceDiagram
    participant CS as Cost Estimator Service
    participant SC as OpenTelemetry Sidecar
    participant GCP as Google Cloud Platform
    participant P as Prometheus
    participant T as Tempo
    participant G as Grafana
    
    Note over CS,G: Complete Observability Data Flow
    
    %% Application generates telemetry
    CS->>CS: Generate Metrics & Traces
    Note right of CS: Custom decorators capture<br/>request/response data
    
    %% Send to sidecar
    CS->>SC: OTLP gRPC/HTTP (Port 4318/4317)
    Note right of SC: Batch processing<br/>Resource enrichment
    
    %% Sidecar processes and forwards
    SC->>GCP: OTLP Export to GCP
    Note right of GCP: Metrics → Cloud Monitoring<br/>Traces → Cloud Trace<br/>Logs → Cloud Logging
    
    %% GCP to storage systems
    GCP->>P: Metrics Export
    GCP->>T: Traces Export
    
    %% Storage to visualization
    P->>G: PromQL Queries
    T->>G: Trace Queries
    
    %% Visualization and alerting
    G->>G: Render Dashboards
    G->>G: Evaluate Alert Rules
    G->>G: Send Notifications
```

### Detailed Component Flow

```mermaid
graph LR
    subgraph "1. Application Layer"
        A1[FastAPI Endpoint]
        A2[Business Services]
        A3[External API Calls]
        A4[Database Queries]
    end
    
    subgraph "2. OpenTelemetry Sidecar"
        B1[OTLP Receiver<br/>:4318/:4317]
        B2[Batch Processor]
        B3[Resource Processor]
        B4[Memory Limiter]
        B5[OTLP Exporter]
    end
    
    subgraph "3. Google Cloud Platform"
        C1[Cloud Monitoring<br/>Metrics]
        C2[Cloud Trace<br/>Distributed Traces]
        C3[Cloud Logging<br/>Structured Logs]
    end
    
    subgraph "4. Metrics Storage"
        D1[Prometheus<br/>Time Series DB]
        D2[PromQL<br/>Query Language]
        D3[Alert Manager<br/>Alerting Rules]
    end
    
    subgraph "5. Traces Storage"
        E1[Tempo<br/>Trace Backend]
        E2[Trace Query API]
        E3[Trace Storage<br/>Object Storage]
    end
    
    subgraph "6. Visualization"
        F1[Grafana<br/>Observability Platform]
        F2[Custom Dashboards]
        F3[Alert Notifications]
        F4[Trace Explorer]
    end
    
    %% Data Flow
    A1 --> B1
    A2 --> B1
    A3 --> B1
    A4 --> B1
    
    B1 --> B2
    B2 --> B3
    B3 --> B4
    B4 --> B5
    
    B5 --> C1
    B5 --> C2
    B5 --> C3
    
    C1 --> D1
    C2 --> E1
    C3 --> E1
    
    D1 --> F1
    E1 --> F1
    D2 --> F1
    E2 --> F1
    
    F1 --> F2
    F1 --> F3
    F1 --> F4
    D3 --> F3
    
    %% Styling
    classDef app fill:#e3f2fd
    classDef sidecar fill:#f3e5f5
    classDef gcp fill:#e8f5e8
    classDef metrics fill:#fff3e0
    classDef traces fill:#fce4ec
    classDef viz fill:#f1f8e9
    
    class A1,A2,A3,A4 app
    class B1,B2,B3,B4,B5 sidecar
    class C1,C2,C3 gcp
    class D1,D2,D3 metrics
    class E1,E2,E3 traces
    class F1,F2,F3,F4 viz
```

### Current Trace Data Analysis

```mermaid
graph TB
    subgraph "Current Trace Structure"
        A[Trace ID: 72eaff88d7d6791720fa2d3c384576a7]
        B[Span ID: 1fe7c9b6744f5cb8]
        C[Span Name: cost_estimation_endpoint]
        
        subgraph "Current Attributes"
            D[request.num_args: 0]
            E[request.num_kwargs: 10]
            F[response.type: CostEstimatorResponse]
            G[response.body: Full JSON Response]
            H[operation: cost_estimation_request]
            I[service.name: cost-estimator-calc-service]
        end
        
        subgraph "Missing Request Data"
            J[❌ request.membership_id]
            K[❌ request.service_code]
            L[❌ request.benefit_product_type]
            M[❌ request.num_providers]
            N[❌ request.body]
            O[❌ request.headers]
        end
        
        subgraph "Missing Header Data"
            P[❌ x-global-transaction-id]
            Q[❌ x-clientrefid]
            R[❌ content-type]
            S[❌ eieheaderaction]
            T[❌ eieheaderapplicationidentifier]
            U[❌ eieheaderorchestratingapplicationidentifier]
            V[❌ eieheaderusercontext]
            W[❌ eieheaderversion]
            X[❌ eieheadertransactionid]
        end
    end
    
    A --> B
    B --> C
    C --> D
    C --> E
    C --> F
    C --> G
    C --> H
    C --> I
    
    %% Missing data connections
    C -.-> J
    C -.-> K
    C -.-> L
    C -.-> M
    C -.-> N
    C -.-> O
    
    C -.-> P
    C -.-> Q
    C -.-> R
    C -.-> S
    C -.-> T
    C -.-> U
    C -.-> V
    C -.-> W
    C -.-> X
    
    %% Styling
    classDef current fill:#e8f5e8,stroke:#4caf50,stroke-width:2px
    classDef missing fill:#ffebee,stroke:#f44336,stroke-width:2px,stroke-dasharray: 5 5
    
    class A,B,C,D,E,F,G,H,I current
    class J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X missing
```

### Trace Data Flow Diagram

```mermaid
sequenceDiagram
    participant Client as Client Request
    participant API as FastAPI Endpoint
    participant Decorator as @trace_request_response
    participant Span as OpenTelemetry Span
    participant Storage as In-Memory Storage
    
    Note over Client,Storage: Current Trace Capture Flow
    
    Client->>API: POST /rate with Headers & Body
    Note right of Client: Headers: x-global-transaction-id,<br/>x-clientrefid, eieheaderaction, etc.<br/>Body: CostEstimatorRequest
    
    API->>Decorator: Call estimate_cost()
    Note right of API: Headers as individual parameters<br/>Body as CostEstimatorRequest object
    
    Decorator->>Span: Start Span "cost_estimation_endpoint"
    
    Note over Decorator: ❌ ISSUE: Headers not captured
    Note over Decorator: Decorator looks for kwargs["headers"]<br/>but headers are individual parameters
    
    Note over Decorator: ❌ ISSUE: Request body not captured
    Note over Decorator: Decorator looks for args with membershipId<br/>but CostEstimatorRequest is in args[0]
    
    Decorator->>Span: Set Basic Attributes
    Note right of Span: ✅ request.num_args: 0<br/>✅ request.num_kwargs: 10<br/>✅ response.type: CostEstimatorResponse<br/>✅ response.body: Full JSON<br/>❌ Missing: request.membership_id<br/>❌ Missing: request.service_code<br/>❌ Missing: request.headers
    
    API->>API: Process Request
    API->>Decorator: Return Response
    
    Decorator->>Span: Set Response Attributes
    Decorator->>Span: End Span
    
    Span->>Storage: Store Trace Data
    
    Note over Client,Storage: Result: Incomplete trace data<br/>Missing request context and headers
```

### Expected vs Actual Trace Attributes

```mermaid
graph LR
    subgraph "Expected Trace Attributes"
        A1[✅ request.num_args: 0]
        A2[✅ request.num_kwargs: 10]
        A3[✅ response.type: CostEstimatorResponse]
        A4[✅ response.body: Full JSON]
        A5[✅ operation: cost_estimation_request]
        A6[✅ service.name: cost-estimator-calc-service]
        
        B1[❌ request.membership_id: "12345"]
        B2[❌ request.service_code: "96203"]
        B3[❌ request.benefit_product_type: "PPO"]
        B4[❌ request.num_providers: 3]
        B5[❌ request.body: Request JSON]
        
        C1[❌ request.headers.x-global-transaction-id]
        C2[❌ request.headers.x-clientrefid]
        C3[❌ request.headers.content-type]
        C4[❌ request.headers.eieheaderaction]
        C5[❌ request.headers.eieheaderapplicationidentifier]
        C6[❌ request.headers.eieheaderorchestratingapplicationidentifier]
        C7[❌ request.headers.eieheaderusercontext]
        C8[❌ request.headers.eieheaderversion]
        C9[❌ request.headers.eieheadertransactionid]
    end
    
    subgraph "Current Trace Attributes"
        D1[✅ request.num_args: 0]
        D2[✅ request.num_kwargs: 10]
        D3[✅ response.type: CostEstimatorResponse]
        D4[✅ response.body: Full JSON]
        D5[✅ operation: cost_estimation_request]
        D6[✅ service.name: cost-estimator-calc-service]
        
        E1[❌ Missing: request.membership_id]
        E2[❌ Missing: request.service_code]
        E3[❌ Missing: request.benefit_product_type]
        E4[❌ Missing: request.num_providers]
        E5[❌ Missing: request.body]
        
        F1[❌ Missing: All headers]
        F2[❌ Missing: All headers]
        F3[❌ Missing: All headers]
        F4[❌ Missing: All headers]
        F5[❌ Missing: All headers]
        F6[❌ Missing: All headers]
        F7[❌ Missing: All headers]
        F8[❌ Missing: All headers]
        F9[❌ Missing: All headers]
    end
    
    %% Styling
    classDef present fill:#e8f5e8,stroke:#4caf50,stroke-width:2px
    classDef missing fill:#ffebee,stroke:#f44336,stroke-width:2px,stroke-dasharray: 5 5
    
    class A1,A2,A3,A4,A5,A6,D1,D2,D3,D4,D5,D6 present
    class B1,B2,B3,B4,B5,C1,C2,C3,C4,C5,C6,C7,C8,C9,E1,E2,E3,E4,E5,F1,F2,F3,F4,F5,F6,F7,F8,F9 missing
```

---

## Implementation Details

### 1. OpenTelemetry Setup

#### Automatic Instrumentation
```python
# app/main.py
from app.core.metrics.opentelemetry_auto_instrumentation import setup_automatic_instrumentation

# Initialize before FastAPI app creation
setup_automatic_instrumentation()

# FastAPI instrumentation with exclusions
FastAPIInstrumentor().instrument_app(
    app,
    excluded_urls="/health,/metrics,/favicon.ico,/traces,/traces/search,/trace-info,/trace-debug,/trace-test,/trace-test-simple"
)
```

#### Configuration
```python
# app/core/metrics/opentelemetry_auto_instrumentation.py
def setup_automatic_instrumentation():
    resource = Resource.create({
        "service.name": os.getenv("OTEL_SERVICE_NAME", "cost-estimator-calc-service"),
        "service.version": "1.0.0",
        "deployment.environment": os.getenv("ENVIRONMENT", "unknown"),
    })
    
    tracer_provider = TracerProvider(resource=resource)
    trace.set_tracer_provider(tracer_provider)
    
    otlp_exporter = OTLPSpanExporter(
        endpoint=os.getenv("OTEL_EXPORTER_OTLP_TRACES_ENDPOINT"),
        insecure=os.getenv("OTEL_EXPORTER_OTLP_INSECURE", "true").lower() == "true",
    )
    
    span_processor = BatchSpanProcessor(otlp_exporter)
    tracer_provider.add_span_processor(span_processor)
    
    AioHttpClientInstrumentor().instrument()
```

### 2. Custom Decorators

#### Request/Response Tracing Decorator
```python
# app/core/metrics/tracing_decorators.py
@trace_request_response(
    span_name="cost_estimation_endpoint",
    capture_request=True,
    capture_response=True,
    max_request_size=4096,
    max_response_size=4096,
    include_headers=True,
    sensitive_fields=["authorization", "token", "password"],
)
async def estimate_cost(request: CostEstimatorRequest, ...):
    # Endpoint implementation
```

#### Response Time Metrics Decorator
```python
# app/core/metrics/decorators.py
@response_time("cost_estimation_service", "estimate_cost")
async def estimate_cost(self, request: CostEstimatorRequest, ...):
    # Service implementation
```

#### Exception Handling Decorator
```python
@exception_handler("cost_estimation_service_exception", "RateNotFoundException")
async def estimate_cost(self, request: CostEstimatorRequest, ...):
    # Service implementation
```

### Data Flow Configuration

#### 1. Application → Sidecar
```yaml
# Application configuration
OTEL_EXPORTER_OTLP_METRICS_ENDPOINT: http://localhost:4318
OTEL_EXPORTER_OTLP_TRACES_ENDPOINT: http://localhost:4318
OTEL_EXPORTER_OTLP_PROTOCOL: grpc
OTEL_EXPORTER_OTLP_INSECURE: "true"
```

#### 2. Sidecar → GCP
```yaml
# Sidecar configuration
OTEL_EXPORTER_OTLP_METRICS_ENDPOINT: https://otelc-gmp-collector-grpc.{{ environment }}.aig.aetna.com
OTEL_EXPORTER_OTLP_TRACES_ENDPOINT: https://otelc-traces-collector-grpc.{{ environment }}.aig.aetna.com
OTEL_EXPORTER_OTLP_INSECURE: "false"
```

#### 3. GCP → Storage Systems
```yaml
# Prometheus configuration
prometheus:
  config:
    scrape_configs:
      - job_name: 'gcp-metrics'
        static_configs:
          - targets: ['gcp-monitoring-endpoint']

# Tempo configuration
tempo:
  config:
    distributors:
      receivers:
        otlp:
          protocols:
            grpc:
              endpoint: 0.0.0.0:4317
            http:
              endpoint: 0.0.0.0:4318
```

#### 4. Storage → Grafana
```yaml
# Grafana datasources
datasources:
  - name: Prometheus
    type: prometheus
    url: http://prometheus:9090
    access: proxy
    
  - name: Tempo
    type: tempo
    url: http://tempo:3200
    access: proxy
```

### Port Configuration

| Component | Port | Protocol | Purpose |
|-----------|------|----------|---------|
| **Application** | 8000 | HTTP | Main API |
| **Sidecar OTLP** | 4318 | HTTP | Metrics/Traces receive |
| **Sidecar OTLP** | 4317 | gRPC | Metrics/Traces receive |
| **Sidecar Health** | 13133 | HTTP | Health checks |
| **Sidecar Metrics** | 8888 | HTTP | Sidecar metrics |
| **Prometheus** | 9090 | HTTP | Metrics query |
| **Tempo** | 3200 | HTTP | Trace query |
| **Grafana** | 3000 | HTTP | Visualization |

---

## Metrics

### 1. Custom Metrics

#### Histograms (Response Times)
| Metric Name | Description | Labels |
|-------------|-------------|---------|
| `cost_estimator_response_time_seconds` | Main service response time | `api`, `operation`, `success` |
| `cost_estimator_benefit_response_time_seconds` | Benefit API response time | `api_type`, `operation`, `success` |
| `cost_estimator_accumulator_response_time_seconds` | Accumulator API response time | `api_type`, `operation`, `success` |
| `cost_estimator_spanner_response_time_seconds` | Database response time | `api_type`, `operation`, `success` |
| `api_response_time_seconds` | Generic API response time | `api_type`, `operation`, `success` |

#### Counters
| Metric Name | Description | Labels |
|-------------|-------------|---------|
| `cost_estimator_requests_total` | Total requests | `api`, `operation` |
| `cost_estimator_errors_total` | Total errors | `api`, `operation` |
| `cost_estimator_exception_total` | Total exceptions | `api`, `operation` |

### 2. Metric Collection Patterns

#### Automatic Collection
```python
# Decorator automatically collects metrics
@api_timer('benefit_api', 'get_benefit')
async def get_benefit(self, request):
    # Metrics automatically recorded
    pass
```

#### Manual Collection
```python
# Manual metric recording
if response_time_histogram is not None:
    response_time_histogram.record(
        duration,
        {"api": "custom_api", "operation": "custom_operation", "success": "true"}
    )
```

### 3. Metric Labels

#### Standard Labels
- **`api`**: API type (e.g., "benefit_api", "accumulator_api")
- **`operation`**: Operation name (e.g., "get_benefit", "estimate_cost")
- **`success`**: Success status ("true" or "false")
- **`api_type`**: Generic API type for unified metrics

#### Business Labels
- **`membership_id`**: Member identifier
- **`service_code`**: CPT4 service code
- **`provider_type`**: Provider type (PH, CP, etc.)
- **`benefit_product_type`**: Medical, Dental, etc.

---

## Tracing

### 1. Trace Structure

#### Span Hierarchy
```
POST /costestimator/v1/rate (FastAPI automatic)
├── cost_estimation_endpoint (Custom decorator)
│   ├── Request validation
│   ├── Header processing
│   ├── cost_estimation_service.estimate_cost (Service decorator)
│   │   ├── build_cost_estimator_response
│   │   ├── External API calls
│   │   │   ├── GET /benefits (Benefit API)
│   │   │   ├── POST /accumulator (Accumulator API)
│   │   │   └── Spanner queries
│   │   └── Business logic processing
│   └── Response formatting
└── HTTP Response (FastAPI automatic)
```

### 2. Trace Attributes

#### Request Attributes
```json
{
  "request.num_args": 0,
  "request.num_kwargs": 10,
  "request.membership_id": "5~265637301+10+717+20250101+798355+X+23",
  "request.benefit_product_type": "Medical",
  "request.num_providers": 1,
  "request.service_code": "99214",
  "request.body": "{...full request JSON...}",
  "request.header.x_correlation_id": "int-cermemxcft3zw8ejwegg",
  "request.headers_count": 9
}
```

#### Response Attributes
```json
{
  "response.type": "CostEstimatorResponse",
  "response.body": "{...full response JSON...}",
  "response.num_estimates": 3,
  "response.has_estimates": true,
  "response.truncated": false
}
```

#### Function Attributes
```json
{
  "function.duration_ms": 774.15,
  "function.name": "estimate_cost",
  "function.module": "app.services.impl.cost_estimation_service_impl",
  "operation": "cost_estimation_request",
  "service.name": "cost-estimator-calc-service"
}
```

### 3. Trace Storage and Querying

#### In-Memory Storage
```python
# app/api/routes/index.py
trace_storage: Dict[str, Dict[str, Any]] = {}

def store_trace_info(trace_id, span_id, span_name, attributes, operation):
    trace_key = f"{trace_id}:{span_id}"
    trace_storage[trace_key] = {
        "trace_id": trace_id,
        "span_id": span_id,
        "span_name": span_name,
        "attributes": attributes,
        "operation": operation,
        "timestamp": datetime.now().isoformat(),
        "stored_at": time.time(),
    }
```

#### Query Endpoints
- **`GET /traces`**: List all stored traces
- **`GET /traces/search`**: Search traces by criteria
- **`GET /trace-info`**: Current trace information
- **`GET /trace-debug`**: Detailed trace debugging info

---

## Configuration

### 1. Environment Variables

#### Required Variables
```bash
# Service identification
OTEL_SERVICE_NAME=APM0016344
OTEL_RESOURCE_ATTRIBUTES=service.name=APM0016344,service.version=1.0.0,deployment.environment=hcb-dev

# Export endpoints
OTEL_EXPORTER_OTLP_METRICS_ENDPOINT=http://localhost:4318
OTEL_EXPORTER_OTLP_TRACES_ENDPOINT=http://localhost:4318

# Protocol configuration
OTEL_EXPORTER_OTLP_PROTOCOL=grpc
OTEL_EXPORTER_OTLP_INSECURE=true

# Sampling and propagation
OTEL_TRACES_SAMPLER=always_on
OTEL_PROPAGATORS=tracecontext,baggage

# Instrumentation
OTEL_PYTHON_DISABLED_INSTRUMENTATIONS=aws-lambda
OTEL_LOGS_EXPORTER=none
```

#### Optional Variables
```bash
# Custom endpoints (if not using sidecar)
OTEL_EXPORTER_OTLP_METRICS_ENDPOINT=https://otelc-gmp-collector-grpc.hcb-dev.aig.aetna.com
OTEL_EXPORTER_OTLP_TRACES_ENDPOINT=https://otelc-traces-collector-grpc.hcb-dev.aig.aetna.com
OTEL_EXPORTER_OTLP_INSECURE=false

# Resource attributes
OTEL_RESOURCE_ATTRIBUTES=service.name=APM0016344,service.version=1.0.0,deployment.environment=hcb-dev,team=platform
```

### 2. Helm Values Configuration

```yaml
# pipeline/values.yaml
deploy:
  env:
    # OpenTelemetry configuration
    OTEL_EXPORTER_OTLP_METRICS_ENDPOINT: http://localhost:4318
    OTEL_EXPORTER_OTLP_TRACES_ENDPOINT: http://localhost:4318
    OTEL_METRICS_EXPORTER: otlp
    OTEL_TRACES_EXPORTER: otlp
    OTEL_EXPORTER_OTLP_PROTOCOL: grpc
    OTEL_EXPORTER_OTLP_INSECURE: "true"
    OTEL_LOGS_EXPORTER: none
    OTEL_TRACES_SAMPLER: always_on
    OTEL_PYTHON_DISABLED_INSTRUMENTATIONS: aws-lambda
    OTEL_PROPAGATORS: tracecontext,baggage
    OTEL_SERVICE_NAME: APM0016344
    OTEL_RESOURCE_ATTRIBUTES: service.name=APM0016344,service.version=1.0.0,deployment.environment={{ environment }}

  sideCar:
    image:
      name: otel/opentelemetry-collector-contrib:0.88.0
      pullPolicy: Always
    
    ports:
      - name: otlp-grpc
        containerPort: 4317
        protocol: TCP
      - name: otlp-http
        containerPort: 4318
        protocol: TCP
      - name: metrics
        containerPort: 8888
        protocol: TCP
      - name: health
        containerPort: 13133
        protocol: TCP
    
    env:
      - name: OTEL_EXPORTER_OTLP_METRICS_ENDPOINT
        value: "https://otelc-gmp-collector-grpc.{{ environment }}.aig.aetna.com"
      - name: OTEL_EXPORTER_OTLP_TRACES_ENDPOINT
        value: "https://otelc-traces-collector-grpc.{{ environment }}.aig.aetna.com"
      - name: OTEL_EXPORTER_OTLP_INSECURE
        value: "false"
```

---

## Deployment

### 1. Sidecar Pattern

#### Benefits
- **Centralized Configuration**: All OpenTelemetry config in one place
- **Data Processing**: Batch, filter, and process data before sending
- **Resilience**: Handle retries and buffering
- **Security**: Handle authentication and encryption
- **Flexibility**: Easy to change collectors or add processing logic

#### Data Flow
```
Application → Sidecar (localhost:4318) → Aetna Collectors (HTTPS)
     ↓              ↓                           ↓
  Generates    Processes &              Stores & 
  Telemetry    Batches Data            Monitors
```

### 2. Direct Export Pattern

#### Configuration
```yaml
deploy:
  env:
    OTEL_EXPORTER_OTLP_METRICS_ENDPOINT: https://otelc-gmp-collector-grpc.{{ environment }}.aig.aetna.com
    OTEL_EXPORTER_OTLP_TRACES_ENDPOINT: https://otelc-traces-collector-grpc.{{ environment }}.aig.aetna.com
    OTEL_EXPORTER_OTLP_INSECURE: "false"
```

### 3. Health Checks

#### Application Health
```python
@router.get("/health", status_code=status.HTTP_200_OK)
def health(response: Response):
    return {"health": "ok"}
```

#### Sidecar Health
```yaml
readinessProbe:
  httpGet:
    path: /
    port: 13133
  initialDelaySeconds: 5
  periodSeconds: 10

livenessProbe:
  httpGet:
    path: /
    port: 13133
  initialDelaySeconds: 10
  periodSeconds: 30
```

---

## Monitoring and Observability

### 1. Key Metrics to Monitor

#### Performance Metrics
- **Response Time**: `cost_estimator_response_time_seconds`
- **Throughput**: `cost_estimator_requests_total`
- **Error Rate**: `cost_estimator_errors_total / cost_estimator_requests_total`
- **External API Performance**: `api_response_time_seconds`

#### Business Metrics
- **Service Code Usage**: Track by `request.service_code` label
- **Provider Performance**: Track by `request.provider_type` label
- **Membership Patterns**: Track by `request.membership_id` patterns
- **Success Rate by Operation**: Track by `operation` and `success` labels

### 2. Alerting Rules

#### Critical Alerts
```yaml
# High error rate
- alert: HighErrorRate
  expr: rate(cost_estimator_errors_total[5m]) / rate(cost_estimator_requests_total[5m]) > 0.05
  for: 2m
  labels:
    severity: critical
  annotations:
    summary: "High error rate detected"

# High response time
- alert: HighResponseTime
  expr: histogram_quantile(0.95, rate(cost_estimator_response_time_seconds_bucket[5m])) > 5
  for: 5m
  labels:
    severity: warning
  annotations:
    summary: "High response time detected"
```

#### Warning Alerts
```yaml
# External API issues
- alert: ExternalAPISlow
  expr: histogram_quantile(0.95, rate(api_response_time_seconds_bucket[5m])) > 10
  for: 5m
  labels:
    severity: warning
  annotations:
    summary: "External API response time is high"
```

### 3. Dashboards

#### Service Overview Dashboard
- **Request Rate**: Requests per minute
- **Response Time**: P50, P95, P99 percentiles
- **Error Rate**: Error percentage over time
- **External Dependencies**: Response times for benefit and accumulator APIs

#### Business Metrics Dashboard
- **Service Code Distribution**: Most requested CPT4 codes
- **Provider Performance**: Response times by provider type
- **Geographic Distribution**: Requests by region
- **Member Patterns**: Request patterns by membership type

### 4. Trace Analysis

#### Common Trace Patterns
1. **Successful Request Flow**:
   - API endpoint → Service method → External APIs → Response
2. **Error Scenarios**:
   - API endpoint → Service method → Exception → Error response
3. **Performance Issues**:
   - Long external API calls
   - Database query bottlenecks
   - Business logic processing delays

#### Trace Search Examples
```bash
# Search by operation
GET /traces/search?operation=cost_estimation_request

# Search by service code
GET /traces/search?span_name=cost_estimation_service&limit=10

# Search by trace ID
GET /traces/search?trace_id=abc123def456

# Search by membership ID (in request body)
GET /traces/search?span_name=cost_estimation_service&limit=10
```

---

## Troubleshooting

### 1. Common Issues

#### Metrics Not Appearing
**Symptoms**: No metrics in monitoring dashboard
**Causes**:
- Incorrect OTLP endpoint configuration
- Network connectivity issues
- Authentication problems
- Sidecar not running

**Solutions**:
```bash
# Check sidecar logs
kubectl logs <pod-name> -c cost-estimator-calc-service-side-car

# Verify endpoint configuration
kubectl exec <pod-name> -c cost-estimator-calc-service -- env | grep OTEL

# Test connectivity
kubectl exec <pod-name> -c cost-estimator-calc-service-side-car -- curl http://localhost:4318
```

#### Traces Not Appearing
**Symptoms**: No traces in trace dashboard
**Causes**:
- Sampling configuration
- Trace export issues
- Span processor problems

**Solutions**:
```bash
# Check trace configuration
kubectl exec <pod-name> -c cost-estimator-calc-service -- env | grep OTEL_TRACES

# Test trace generation
curl http://your-app-url/trace-test-simple

# Check trace storage
curl http://your-app-url/traces
```

#### High Memory Usage
**Symptoms**: Pod memory usage increasing
**Causes**:
- In-memory trace storage growing
- Large request/response capture
- Memory leaks in decorators

**Solutions**:
```python
# Limit trace storage
if len(trace_storage) > 1000:
    # Remove oldest traces
    oldest_keys = sorted(trace_storage.keys(), key=lambda k: trace_storage[k]["stored_at"])[:100]
    for key in oldest_keys:
        del trace_storage[key]

# Limit response size
max_response_size: int = 1024  # Reduce if needed
```

### 2. Debugging Tools

#### Trace Debug Endpoint
```bash
# Get current trace information
curl http://your-app-url/trace-info

# Get detailed debug information
curl http://your-app-url/trace-debug

# Generate test traces
curl http://your-app-url/trace-test
```

#### Log Analysis
```bash
# Check OpenTelemetry logs
kubectl logs <pod-name> -c cost-estimator-calc-service | grep -i "otel\|trace\|metric"

# Check for errors
kubectl logs <pod-name> -c cost-estimator-calc-service | grep -i "error\|failed\|timeout"
```

### 3. Performance Optimization

#### Reduce Overhead
```python
# Exclude health checks from tracing
FastAPIInstrumentor().instrument_app(
    app,
    excluded_urls="/health,/metrics,/favicon.ico"
)

# Limit captured data size
@trace_request_response(
    max_request_size=1024,  # Reduce if needed
    max_response_size=1024,  # Reduce if needed
)
```

#### Optimize Metrics
```python
# Use batch processing for metrics
metric_reader = PeriodicExportingMetricReader(
    otlp_exporter,
    export_interval_millis=30000,  # Increase if needed
    export_timeout_millis=30000,
)
```

---

## Best Practices

### 1. Trace Design

#### Span Naming
- **Use descriptive names**: `cost_estimation_endpoint` vs `endpoint`
- **Include operation context**: `get_benefit`, `calculate_cost`
- **Be consistent**: Use same naming pattern across services

#### Attribute Design
- **Use standard attributes**: `http.method`, `http.url`, `service.name`
- **Add business context**: `membership_id`, `service_code`, `provider_type`
- **Avoid sensitive data**: Use labels instead of attribute values for PII

#### Span Hierarchy
- **Keep spans focused**: One span per logical operation
- **Maintain parent-child relationships**: Use proper span context
- **Limit span depth**: Avoid overly deep nesting

### 2. Metrics Design

#### Metric Naming
- **Use consistent prefixes**: `cost_estimator_*`
- **Include units**: `_seconds`, `_total`, `_bytes`
- **Be descriptive**: `response_time_seconds` vs `time`

#### Label Design
- **Use high-cardinality labels sparingly**: Avoid user IDs as labels
- **Group related metrics**: Use same label names across related metrics
- **Keep labels stable**: Avoid changing label names frequently

#### Collection Frequency
- **Batch metrics**: Use periodic export instead of immediate
- **Sample appropriately**: Don't collect every single operation
- **Monitor collection overhead**: Ensure metrics don't impact performance

### 3. Configuration Management

#### Environment-Specific Settings
```yaml
# Development
OTEL_TRACES_SAMPLER: always_on
OTEL_EXPORTER_OTLP_INSECURE: "true"

# Production
OTEL_TRACES_SAMPLER: traceidratio
OTEL_TRACES_SAMPLER_ARG: "0.1"  # 10% sampling
OTEL_EXPORTER_OTLP_INSECURE: "false"
```

#### Resource Management
```python
# Set appropriate resource limits
resource = Resource.create({
    "service.name": "cost-estimator-calc-service",
    "service.version": "1.0.0",
    "deployment.environment": environment,
    "team": "platform",
    "component": "api"
})
```

### 4. Security Considerations

#### Sensitive Data Handling
```python
# Mask sensitive fields
sensitive_fields = ["authorization", "token", "password", "ssn"]

# Use labels instead of attribute values for PII
span.set_attribute("user.type", "premium")  # Good
span.set_attribute("user.id", "12345")      # Avoid if sensitive
```

#### Network Security
- **Use HTTPS**: Always use secure connections for production
- **Authenticate**: Use proper authentication for collectors
- **Encrypt**: Ensure data is encrypted in transit

### 5. Monitoring and Alerting

#### Set Up Comprehensive Monitoring
- **SLIs**: Service Level Indicators (availability, latency, error rate)
- **SLOs**: Service Level Objectives (99.9% availability, <2s response time)
- **SLAs**: Service Level Agreements with business stakeholders

#### Create Meaningful Alerts
- **Alert on symptoms, not causes**: Alert on high error rate, not specific exceptions
- **Use appropriate thresholds**: Set realistic alert thresholds
- **Include context**: Add relevant information to alert messages

#### Regular Review
- **Review metrics weekly**: Check for trends and anomalies
- **Update dashboards**: Keep dashboards relevant to current needs
- **Tune alerting**: Adjust thresholds based on historical data

---

## Conclusion

This OpenTelemetry integration provides comprehensive observability for the Cost Estimator Calc Service, enabling:

- **Full request tracing** from API to business logic
- **Detailed performance metrics** for all operations
- **Business context** in both traces and metrics
- **Easy debugging** with request/response capture
- **Production monitoring** with proper alerting

The implementation follows OpenTelemetry best practices and integrates seamlessly with Google Cloud Monitoring and Cloud Trace, providing a robust foundation for monitoring and debugging the cost estimation service.

---

## Appendix

### A. Environment Variables Reference

| Variable | Description | Default | Required |
|----------|-------------|---------|----------|
| `OTEL_SERVICE_NAME` | Service name for identification | `cost-estimator-calc-service` | Yes |
| `OTEL_EXPORTER_OTLP_METRICS_ENDPOINT` | Metrics export endpoint | - | Yes |
| `OTEL_EXPORTER_OTLP_TRACES_ENDPOINT` | Traces export endpoint | - | Yes |
| `OTEL_EXPORTER_OTLP_PROTOCOL` | Export protocol (grpc/http) | `grpc` | No |
| `OTEL_EXPORTER_OTLP_INSECURE` | Use insecure connection | `false` | No |
| `OTEL_TRACES_SAMPLER` | Trace sampling strategy | `always_on` | No |
| `OTEL_PROPAGATORS` | Trace context propagators | `tracecontext,baggage` | No |
| `OTEL_RESOURCE_ATTRIBUTES` | Resource attributes | - | No |

### B. Metric Labels Reference

| Label | Description | Values | Example |
|-------|-------------|--------|---------|
| `api` | API type | `benefit_api`, `accumulator_api`, `cost_estimation_service` | `benefit_api` |
| `operation` | Operation name | Function/method name | `get_benefit` |
| `success` | Success status | `true`, `false` | `true` |
| `api_type` | Generic API type | Same as `api` | `benefit_api` |

### C. Trace Attributes Reference

| Attribute | Description | Type | Example |
|-----------|-------------|------|---------|
| `request.membership_id` | Member identifier | String | `5~265637301+10+717+20250101+798355+X+23` |
| `request.service_code` | CPT4 service code | String | `99214` |
| `request.benefit_product_type` | Product type | String | `Medical` |
| `response.type` | Response type | String | `CostEstimatorResponse` |
| `function.duration_ms` | Function duration | Number | `774.15` |
| `operation` | Operation identifier | String | `cost_estimation_request` |

### D. Troubleshooting Checklist

- [ ] Check environment variables are set correctly
- [ ] Verify sidecar is running and healthy
- [ ] Check network connectivity to collectors
- [ ] Review application logs for OpenTelemetry errors
- [ ] Test trace generation with debug endpoints
- [ ] Verify metrics are being exported
- [ ] Check sampling configuration
- [ ] Review resource limits and memory usage
- [ ] Test with different request patterns
- [ ] Verify authentication and security settings
