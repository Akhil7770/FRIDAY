# Cost Estimator Service

A FastAPI-based microservice for calculating healthcare cost estimates using benefit and accumulator data.

## 🚀 Features

- **Cost Estimation**: Calculate healthcare service costs based on member benefits
- **Parallel Processing**: Concurrent calls to benefit and accumulator services
- **Accumulator Integration**: Real-time accumulator data retrieval
- **Benefit Service Integration**: Member benefit information processing
- **Rate Calculation**: Database-driven rate lookups
- **Chain of Responsibility**: Sophisticated calculation logic using handler pattern
- **Error Handling**: Comprehensive error management and logging
- **Request Validation**: Pydantic-based input validation

## 🏗️ Architecture

### System Overview

```
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│   FastAPI App   │    │  Cost Estimation │    │   Repository    │
│                 │    │     Service      │    │                 │
└─────────────────┘    └──────────────────┘    └─────────────────┘
         │                       │                       │
         │                       │                       │
         ▼                       ▼                       ▼
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│   Request       │    │  Calculation     │    │   Spanner DB    │
│  Validation     │    │     Chain        │    │                 │
└─────────────────┘    └──────────────────┘    └─────────────────┘
         │                       │
         │              ┌────────┴────────┐
         │              │                 │
         ▼              ▼                 ▼
┌─────────────────┐ ┌─────────────┐ ┌─────────────┐
│   Response      │ │  Benefit    │ │ Accumulator │
│   Mapping       │ │  Service    │ │  Service    │
└─────────────────┘ └─────────────┘ └─────────────┘
```

### Calculation Chain Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    Calculation Chain                            │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ServiceCoverageHandler                                         │
│  └──► BenefitLimitationHandler                                 │
│       ├──► OOPMaxHandler                                       │
│       │    ├──► DeductibleHandler                              │
│       │    │    ├──► DeductibleOOPMaxHandler                   │
│       │    │    │    ├──► DeductibleCoPayHandler               │
│       │    │    │    └──► DeductibleCoInsuranceHandler         │
│       │    │    └──► CostShareCoPayHandler                     │
│       │    └──► OOPMaxCopayHandler                             │
│       └──► DeductibleCostShareCoPayHandler                     │
│            ├──► DeductibleCoPayHandler                         │
│            └──► DeductibleCoInsuranceHandler                   │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Class Diagram

```mermaid
classDiagram
    %% API Layer
    class APIRouter {
        +POST /api/v1/rate
    }
    
    class CostEstimatorRequest {
        +membershipId: str
        +zipCode: str
        +benefitProductType: str
        +languageCode: str
        +service: Service
        +providerInfo: List[ProviderInfo]
    }
    
    class Service {
        +code: str
        +type: str
        +description: str
        +supportingService: SupportingService
        +modifier: Modifier
        +diagnosisCode: str
        +placeOfService: PlaceOfService
    }
    
    class ProviderInfo {
        +serviceLocation: str
        +providerType: str
        +specialty: Specialty
        +taxIdentificationNumber: str
        +taxIdQualifier: str
        +providerNetworks: ProviderNetworks
        +providerIdentificationNumber: str
        +nationalProviderIdentifier: NationalProviderIdentifier
        +providerNetworkParticipation: ProviderNetworkParticipation
    }
    
    %% Service Layer
    class CostEstimationServiceInterface {
        <<interface>>
        +estimate_cost(request: CostEstimatorRequest)
    }
    
    class CostEstimationServiceImpl {
        -repository: CostEstimatorRepositoryImpl
        +estimate_cost(request: CostEstimatorRequest)
    }
    
    class CalculationServiceInterface {
        <<interface>>
        +find_highest_member_pay(service_amount: float, benefits: List[Benefit])
    }
    
    class CalculationServiceImpl {
        -chain: Handler
        +find_highest_member_pay(service_amount: float, benefits: List[Benefit])
        +create_calculation_chain()
    }
    
    class BenefitServiceInterface {
        <<interface>>
        +get_benefit(request: BenefitRequest)
    }
    
    class BenefitServiceImpl {
        -ssl_context: SSLContext
        -token_service: TokenService
        +get_benefit(request: BenefitRequest)
    }
    
    class AccumulatorServiceInterface {
        <<interface>>
        +get_accumulator(request: CostEstimatorRequest)
    }
    
    class AccumulatorServiceImpl {
        -ssl_context: SSLContext
        -token_service: TokenService
        +get_accumulator(request: CostEstimatorRequest)
    }
    
    class TokenService {
        -ssl_context: SSLContext
        +get_new_token()
    }
    
    %% Handler Chain Layer
    class Handler {
        <<abstract>>
        -_next_handler: Handler
        +set_next(handler: Handler)
        +handle(context: InsuranceContext)
        +process(context: InsuranceContext)*
    }
    
    class ServiceCoverageHandler {
        +process(context: InsuranceContext)
        -_apply_no_coverage(context: InsuranceContext)
    }
    
    class BenefitLimitationHandler {
        -_deductible_cost_share_co_handler: Handler
        -_oopmax_handler: Handler
        +set_deductible_cost_share_co_handler(handler: Handler)
        +set_oopmax_handler(handler: Handler)
        +process(context: InsuranceContext)
        -_apply_limitation(context: InsuranceContext)
        -_apply_partial_limit(context: InsuranceContext)
        -_apply_within_limit(context: InsuranceContext)
    }
    
    class OOPMaxHandler {
        -_deductible_handler: Handler
        -_oopmax_copay_handler: Handler
        +set_deductible_handler(handler: Handler)
        +set_oopmax_copay_handler(handler: Handler)
        +process(context: InsuranceContext)
    }
    
    class DeductibleHandler {
        -_deductible_oopmax_handler: Handler
        -_cost_share_co_pay_handler: Handler
        -_deductible_cost_share_co_pay_handler: Handler
        +set_deductible_oopmax_handler(handler: Handler)
        +set_cost_share_co_pay_handler(handler: Handler)
        +set_deductible_cost_share_co_pay_handler(handler: Handler)
        +process(context: InsuranceContext)
    }
    
    class CostShareCoPayHandler {
        +process(context: InsuranceContext)
        -_apply_copay_only(context: InsuranceContext)
        -_apply_coinsurance_only(context: InsuranceContext)
        -_apply_copay_and_coinsurance(context: InsuranceContext)
    }
    
    class DeductibleOOPMaxHandler {
        -_deductible_co_pay_handler: Handler
        -_deductible_co_insurance_handler: Handler
        +set_deductible_co_pay_handler(handler: Handler)
        +set_deductible_co_insurance_handler(handler: Handler)
        +process(context: InsuranceContext)
        -_apply_member_pays_full_and_deductible_and_oopmax_updated(context: InsuranceContext)
        -_apply_deductible_met_and_oopmax_updated(context: InsuranceContext)
    }
    
    class DeductibleCoPayHandler {
        +process(context: InsuranceContext)
        -_apply_copay_only(context: InsuranceContext)
        -_apply_coinsurance_only(context: InsuranceContext)
        -_apply_copay_and_coinsurance(context: InsuranceContext)
    }
    
    class DeductibleCoInsuranceHandler {
        +process(context: InsuranceContext)
        -_apply_coinsurance_calculation(context: InsuranceContext)
    }
    
    class OOPMaxCopayHandler {
        +process(context: InsuranceContext)
        -_apply_oopmax_copay_logic(context: InsuranceContext)
    }
    
    class DeductibleCostShareCoPayHandler {
        -_deductible_co_pay_handler: Handler
        -_deductible_co_insurance_handler: Handler
        +set_deductible_co_pay_handler(handler: Handler)
        +set_deductible_co_insurance_handler(handler: Handler)
        +process(context: InsuranceContext)
    }
    
    %% Repository Layer
    class CostEstimatorRepositoryInterface {
        <<interface>>
        +get_rate(rate_criteria: CostEstimatorRateCriteria)
    }
    
    class CostEstimatorRepositoryImpl {
        -db: SpannerClient
        +get_rate(rate_criteria: CostEstimatorRateCriteria)
        -_get_claim_based_rate(params)
        -_get_provider_info(params)
        -_get_standard_rate(params)
        -_get_non_standard_rate(params)
    }
    
    class SpannerClient {
        +execute_query(query: str, params: dict)
    }
    
    %% Mapper Layer
    class CostEstimatorMapper {
        <<static>>
        +to_benefit_request(request: CostEstimatorRequest)
        +to_rate_criteria(request: CostEstimatorRequest)
    }
    
    %% Data Models
    class InsuranceContext {
        +service_amount: float
        +is_service_covered: bool
        +cost_share_copay: float
        +cost_share_coinsurance: float
        +copay_applies_oop: bool
        +coins_applies_oop: bool
        +deductible_applies_oop: bool
        +is_deductible_before_copay: bool
        +has_benefit_limitation: bool
        +benefit_code: set[str]
        +benefit_level: set[str]
        +oopmax_family_calculated: float
        +oopmax_individual_calculated: float
        +deductible_individual_calculated: float
        +deductible_family_calculated: float
        +limit_calculated: float
        +limit_type: str
        +member_pays: float
        +insurance_pays: float
        +calculation_complete: bool
        +trace_entries: List[TraceEntry]
        +trace_enabled: bool
        +error_code: str
        +error_message: str
        +populate_from_benefit(benefit: Benefit, service_amount: float)
        +trace(step: str, description: str, **kwargs)
        +trace_decision(step: str, condition: str, decision: bool, **kwargs)
        +get_trace_summary()
    }
    
    class Benefit {
        +benefitName: str
        +benefitCode: int
        +isInitialBenefit: str
        +benefitTier: BenefitTier
        +networkCategory: str
        +prerequisites: List[Prerequisite]
        +benefitProvider: str
        +serviceProvider: List[ServiceProvider]
        +coverage: Coverage
    }
    
    class Coverage {
        +sequenceNumber: int
        +benefitDescription: str
        +costShareCopay: float
        +costShareCoinsurance: float
        +copayAppliesOutOfPocket: str
        +coinsAppliesOutOfPocket: str
        +deductibleAppliesOutOfPocket: str
        +isDeductibleBeforeCopay: str
        +hasBenefitLimitation: str
        +isServiceCovered: str
        +matchedAccumulators: List[MatchedAccumulator]
    }
    
    class MatchedAccumulator {
        +level: str
        +deductibleCode: str
        +frequency: str
        +relationshipToSubscriber: str
        +suffix: str
        +benefitProductType: str
        +description: str
        +currentValue: str
        +limitValue: float
        +code: str
        +effectivePeriod: EffectivePeriod
        +calculatedValue: float
        +savingsLevel: str
        +networkIndicator: str
        +networkIndicatorCode: str
        +limitType: str
    }
    
    class BenefitRequest {
        +benefitProductType: str
        +membershipID: str
        +planIdentifier: str
        +serviceInfo: List[ServiceInfo]
    }
    
    class CostEstimatorRateCriteria {
        +providerIdentificationNumber: str
        +serviceCode: str
        +serviceType: str
        +serviceLocationNumber: str
        +networkId: str
        +placeOfService: str
        +zipCode: str
        +isOutofNetwork: bool
    }
    
    class BenefitApiResponse {
        +serviceInfo: List[ServiceInfoItem]
    }
    
    class AccumulatorResponse {
        +memberships: List[Membership]
        +filter_by_network(network_type: str)
        +filter_by_code(code: str)
    }
    
    %% Relationships
    APIRouter --> CostEstimatorRequest
    APIRouter --> CostEstimationServiceImpl
    CostEstimationServiceImpl ..|> CostEstimationServiceInterface
    CostEstimationServiceImpl --> CalculationServiceImpl
    CostEstimationServiceImpl --> BenefitServiceImpl
    CostEstimationServiceImpl --> AccumulatorServiceImpl
    CostEstimationServiceImpl --> CostEstimatorRepositoryImpl
    CostEstimationServiceImpl --> CostEstimatorMapper
    
    CalculationServiceImpl ..|> CalculationServiceInterface
    CalculationServiceImpl --> ServiceCoverageHandler
    
    ServiceCoverageHandler --|> Handler
    BenefitLimitationHandler --|> Handler
    OOPMaxHandler --|> Handler
    DeductibleHandler --|> Handler
    CostShareCoPayHandler --|> Handler
    DeductibleOOPMaxHandler --|> Handler
    DeductibleCoPayHandler --|> Handler
    DeductibleCoInsuranceHandler --|> Handler
    OOPMaxCopayHandler --|> Handler
    DeductibleCostShareCoPayHandler --|> Handler
    
    ServiceCoverageHandler --> BenefitLimitationHandler
    BenefitLimitationHandler --> OOPMaxHandler
    BenefitLimitationHandler --> DeductibleCostShareCoPayHandler
    OOPMaxHandler --> DeductibleHandler
    OOPMaxHandler --> OOPMaxCopayHandler
    DeductibleHandler --> DeductibleOOPMaxHandler
    DeductibleHandler --> CostShareCoPayHandler
    DeductibleOOPMaxHandler --> DeductibleCoPayHandler
    DeductibleOOPMaxHandler --> DeductibleCoInsuranceHandler
    DeductibleCostShareCoPayHandler --> DeductibleCoPayHandler
    DeductibleCostShareCoPayHandler --> DeductibleCoInsuranceHandler
    
    CalculationServiceImpl --> InsuranceContext
    InsuranceContext --> Benefit
    Benefit --> Coverage
    Coverage --> MatchedAccumulator
    
    BenefitServiceImpl ..|> BenefitServiceInterface
    AccumulatorServiceImpl ..|> AccumulatorServiceInterface
    CostEstimatorRepositoryImpl ..|> CostEstimatorRepositoryInterface
    CostEstimatorRepositoryImpl --> SpannerClient
    
    CostEstimatorMapper --> BenefitRequest
    CostEstimatorMapper --> CostEstimatorRateCriteria
    
    BenefitServiceImpl --> TokenService
    AccumulatorServiceImpl --> TokenService
```

### Sequence Diagram

```mermaid
sequenceDiagram
    participant Client
    participant API as FastAPI Router
    participant CES as CostEstimationService
    participant CalcSvc as CalculationService
    participant Mapper as CostEstimatorMapper
    participant BS as BenefitService
    participant AS as AccumulatorService
    participant Repo as Repository
    participant Spanner as Spanner DB
    participant TokenSvc as TokenService
    participant ExtBenefit as External Benefit API
    participant ExtAccum as External Accumulator API
    participant Chain as Calculation Chain
    participant Handler1 as ServiceCoverageHandler
    participant Handler2 as BenefitLimitationHandler
    participant Handler3 as OOPMaxHandler
    participant Handler4 as DeductibleHandler
    participant Handler5 as CostShareCoPayHandler
    
    Client->>API: POST /api/v1/rate (CostEstimatorRequest)
    API->>CES: estimate_cost(request)
    
    CES->>Mapper: to_benefit_request(request)
    CES->>Mapper: to_rate_criteria(request)
    
    par Parallel Execution
        CES->>BS: get_benefit(benefit_request)
        BS->>TokenSvc: get_new_token() [if needed]
        TokenSvc-->>BS: token
        BS->>ExtBenefit: HTTP GET /benefits
        ExtBenefit-->>BS: BenefitApiResponse
        BS-->>CES: benefit_response
    and
        CES->>AS: get_accumulator(request)
        AS->>TokenSvc: get_new_token() [if needed]
        TokenSvc-->>AS: token
        AS->>ExtAccum: HTTP GET /accumulators
        ExtAccum-->>AS: AccumulatorResponse
        AS-->>CES: accumulator_response
    and
        CES->>Repo: get_rate(rate_criteria)
        Repo->>Spanner: execute_query(claim_based_rate)
        alt Claim-based rate found
            Spanner-->>Repo: rate
            Repo-->>CES: rate
        else No claim-based rate
            Repo->>Spanner: execute_query(provider_info)
            Spanner-->>Repo: provider_info
            Repo->>Spanner: execute_query(standard_rate | non_standard_rate)
            Spanner-->>Repo: rate
            Repo-->>CES: rate
        end
    end
    
    CES->>CalcSvc: find_highest_member_pay(service_amount, benefits)
    
    loop For each benefit
        CalcSvc->>CalcSvc: Create InsuranceContext from benefit
        CalcSvc->>Chain: handle(context)
        Chain->>Handler1: handle(context)
        Handler1->>Handler1: process(context)
        alt Service not covered
            Handler1-->>Chain: context with no coverage
        else Service covered
            Handler1->>Handler2: handle(context)
            Handler2->>Handler2: process(context)
            alt Has benefit limitation
                Handler2-->>Chain: context with limitation applied
            else No limitation
                Handler2->>Handler3: handle(context)
                Handler3->>Handler3: process(context)
                alt OOPMax met
                    Handler3->>Handler3: Apply OOPMax logic
                    Handler3-->>Chain: context with OOPMax applied
                else OOPMax not met
                    Handler3->>Handler4: handle(context)
                    Handler4->>Handler4: process(context)
                    alt Deductible met
                        Handler4->>Handler5: handle(context)
                        Handler5->>Handler5: process(context)
                        Handler5-->>Chain: context with cost share applied
                    else Deductible not met
                        Handler4-->>Chain: context with deductible applied
                    end
                end
            end
        end
        Chain-->>CalcSvc: processed context
    end
    
    CalcSvc->>CalcSvc: Find context with highest member_pays
    CalcSvc-->>CES: highest_member_pay_context
    
    CES-->>API: {status, rate, benefit_response, accumulator_response, calculation_result}
    API-->>Client: JSON Response
```

### Calculation Flow Diagram

```mermaid
flowchart TD
    A[Start: InsuranceContext] --> B{Service Covered?}
    B -->|No| C[Apply No Coverage<br/>member_pays = service_amount<br/>insurance_pays = 0]
    B -->|Yes| D{Has Benefit Limitation?}
    
    D -->|Yes| E{Limit Reached?}
    E -->|Yes| F[Apply Limitation<br/>member_pays = service_amount<br/>insurance_pays = 0]
    E -->|No| G{Service Amount > Remaining Limit?}
    G -->|Yes| H[Apply Partial Limit<br/>insurance_pays = remaining_limit<br/>member_pays = excess]
    G -->|No| I[Apply Within Limit<br/>insurance_pays = service_amount]
    
    D -->|No| J{OOPMax Met?}
    J -->|Yes| K[Apply OOPMax Logic<br/>member_pays = 0]
    J -->|No| L{Deductible Met?}
    
    L -->|Yes| M{Has Copay?}
    M -->|Yes| N[Apply Copay Logic<br/>member_pays = copay_amount]
    M -->|No| O{Has Coinsurance?}
    O -->|Yes| P[Apply Coinsurance<br/>member_pays = service_amount * coinsurance%]
    O -->|No| Q[No Cost Share<br/>member_pays = 0]
    
    L -->|No| R{Service Amount < Deductible?}
    R -->|Yes| S[Apply Full Deductible<br/>member_pays = service_amount]
    R -->|No| T[Apply Partial Deductible<br/>member_pays = remaining_deductible]
    
    C --> U[End: Return Context]
    F --> U
    H --> U
    I --> U
    K --> U
    N --> U
    P --> U
    Q --> U
    S --> U
    T --> U
```

## 📋 Prerequisites

- Python 3.10+
- Google Cloud Spanner
- External Benefit Service API
- External Accumulator Service API

## 🛠️ Installation

### 1. Clone the Repository

```bash
git clone <repository-url>
cd cost-estimator-calc-service
```

### 2. Install Dependencies

```bash
pipenv install
```

### 3. Environment Configuration

Create a `.env` file with the following variables:

```env
# Database Configuration
# Need create dofferent configuraion file for each environment
SPANNER_PROJECT_ID=your-project-id
SPANNER_INSTANCE_ID=your-instance-id
SPANNER_DATABASE_ID=your-database-id

# API Configuration
ACCUMULATOR_URL=[https://your-accumulator-api.com/](https://qaapi10.cvshealth.com/healthcare/qapath3/hcb/v3/healthsparq_memberships/5~265642286+34+44+20250101+784461+AM+39/accumulators)
BENEFIT_URL=[https://your-benefit-api.com/](https://qaapi10.int.cvshealth.com/hcb/qapath3/hcb/v3/servicesbenefits/retrieve)


### 4. Run the Application

```bash
# Development mode
pipenv run uvicorn app.main:app --reload --host 0.0.0.0 --port 8000

# Production mode
pipenv run uvicorn app.main:app --host 0.0.0.0 --port 8000
```

## 📚 API Documentation

Once the service is running, you can access:

- **Interactive API Docs**:https://cost-estimator-calc-service.hcb-dev.aig.aetna.com/docs
- **ReDoc Documentation**: https://cost-estimator-calc-service.hcb-dev.aig.aetna.com/redoc

  

## 🔧 API Endpoints

### POST /api/v1/rate

Calculate cost estimate for a healthcare service.

**Request Body:**
```json
{
  "membershipId": "5~186103331+10+7+20240101+793854+8A+829",
  "zipCode": "85305",
  "benefitProductType": "Medical",
  "languageCode": "11",
  "service": {
    "code": "99214",
    "type": "CPT4",
    "description": "Adult Office visit Age 30-39",
    "supportingService": {"code": "470", "type": "DRG"},
    "modifier": {"modifierCode": "E1"},
    "diagnosisCode": "F33 40",
    "placeOfService": {"code": "11"}
  },
  "providerInfo": [
    {
      "serviceLocation": "000761071",
      "providerType": "HO",
      "specialty": {"code": "91017"},
      "taxIdentificationNumber": "0000431173518",
      "taxIdQualifier": "SN",
      "providerNetworks": {"networkID": "58921"},
      "providerIdentificationNumber": "0004000317",
      "nationalProviderIdentifier": {"nationalProviderId": "1386660504"},
      "providerNetworkParticipation": {"providerTier": "1"}
    }
  ]
}
```

**Benefit Request Body:**
```json
{
  "benefitProductType": "Medical",
  "membershipID": "5~186103331+10+7+20240101+793854+8A+829",
  "planIdentifier": "3~",
  "serviceInfo": [
    {
      "serviceCodeInfo": {
        "code": "99214",
        "type": "CPT4",
        "providerType": [{"code": "HO"}],
        "placeOfService": [{"code": "11"}],
        "providerSpecialty": [{"code": "91017"}]
      }
    }
  ]
}
```

**Benefit Response Body:**
```json
{
  "status": "success",
  "data": {
    "benefitResponse": {
      "memberships": [
        {
          "membershipIdentifier": {
            "idSource": "5",
            "idValue": "265642286+34+44+20250101+784461+AM+39",
            "idType": "memberships",
            "resourceId": "5~265642286+34+44+20250101+784461+AM+39"
          },
          "benefits": [
            {
              "benefitProductType": "Medical",
              "serviceCode": "99214",
              "serviceType": "CPT4",
              "description": "Office/outpatient visit established patient",
              "isCovered": "Y",
              "coverageLevel": "Individual",
              "networkIndicator": "InNetwork",
              "costSharing": {
                "copay": {
                  "amount": "25.00",
                  "appliesToDeductible": "N",
                  "appliesToOutOfPocket": "Y"
                },
                "coinsurance": {
                  "percentage": "0.00",
                  "appliesToDeductible": "N",
                  "appliesToOutOfPocket": "N"
                },
                "deductible": {
                  "amount": "0.00",
                  "appliesToOutOfPocket": "Y"
                }
              },
              "limitations": {
                "frequency": "Unlimited",
                "priorAuthorization": "N",
                "referralRequired": "N"
              }
            }
          ]
        }
      ]
    }
  }
}
```

**Accumulator Request:**
```
GET https://qaapi10.cvshealth.com/healthcare/qapath3/hcb/v3/healthsparq_memberships/{membershipId}/accumulators?benefitProductType=Medical
```

**Headers:**
```
Content-Type: application/json
Authorization: Bearer {access_token}
id_token: {id_token}
```

**Accumulator Response Body:**
```json
{
  "readAccumulatorsResponse": {
    "memberships": {
      "dependents": [
        {
          "privacyRestriction": "false",
          "membershipIdentifier": {
            "idSource": "5",
            "idValue": "265642286+34+44+20250101+784461+AM+39",
            "idType": "memberships",
            "resourceId": "5~265642286+34+44+20250101+784461+AM+39"
          },
          "accumulators": [
            {
              "level": "Individual",
              "frequency": "Calendar Year",
              "relationshipToSubscriber": "W",
              "suffix": "784461",
              "benefitProductType": "Medical",
              "description": "Share of Amount Remaining (Coinsurance)",
              "currentValue": "161.08",
              "limitValue": "9999999.99",
              "code": "OOP Max",
              "effectivePeriod": {
                "datetimeBegin": "2025-01-01",
                "datetimeEnd": "2025-12-31"
              },
              "calculatedValue": "9999838.91",
              "savingsLevel": "In Network",
              "networkIndicator": "InNetwork",
              "accumExCode": "L03",
              "networkIndicatorCode": "I"
            },
            {
              "level": "Individual",
              "frequency": "Calendar Year",
              "relationshipToSubscriber": "W",
              "suffix": "784461",
              "benefitProductType": "Medical",
              "description": "Upfront Dollar Benefit",
              "currentValue": "490.00",
              "limitValue": "500.00",
              "code": "Annual Maximum",
              "effectivePeriod": {
                "datetimeBegin": "2025-01-01",
                "datetimeEnd": "2025-12-31"
              },
              "calculatedValue": "10.00",
              "savingsLevel": "In Network",
              "networkIndicator": "InNetwork",
              "accumExCode": "LA%",
              "limitType": "Dollar",
              "networkIndicatorCode": "I"
            },
            {
              "level": "Individual",
              "frequency": "12 Floating Months",
              "relationshipToSubscriber": "W",
              "suffix": "784461",
              "benefitProductType": "Medical",
              "description": "Routine Adult Exam Tier 1",
              "currentValue": "0",
              "limitValue": "1",
              "code": "Limit",
              "effectivePeriod": {
                "datetimeBegin": "2025-01-01",
                "datetimeEnd": "2025-12-31"
              },
              "calculatedValue": "1",
              "savingsLevel": "In Network",
              "networkIndicator": "InNetwork",
              "accumExCode": "L$P",
              "limitType": "Counter",
              "networkIndicatorCode": "I"
            }
          ]
        }
      ]
    }
  }
}
```

**Response:**
```json
{
  "status": "success",
  "rate": 100.0,
  "benefit_response": {...},
  "accumulator_response": {...}
}
```



### HTTP Status Codes

| Status Code | Description | When Used |
|-------------|-------------|-----------|
| 200 | OK | Successful cost estimation |
| 400 | Bad Request | Invalid input data or validation errors |
| 401 | Unauthorized | Authentication/authorization failures |
| 422 | Unprocessable Entity | Pydantic validation errors |
| 500 | Internal Server Error | Database errors or unexpected exceptions |
| 502 | Bad Gateway | External service failures |
| 503 | Service Unavailable | Service temporarily unavailable |
| 504 | Gateway Timeout | External service timeouts |




#### 3. Health Checks
```bash
# Basic health check
curl http://localhost:8000/health

# Detailed health check
curl http://localhost:8000/health/detailed
```




## 🧪 Testing

### Run Tests

```bash
# Run all tests
pipenv run pytest

#Run unit tests
pipenv run pytest 

#Run behave tests
pipenv run behave 

# Run with coverage
pipenv run pytest --cov=app

# Run specific test file
pipenv run pytest app/tests/api/test_estimate_cost_route.py

# Run tests for API Mock Testing
pytest tests/api/api_mock_test.py -v
```

### Test Structure

```
app/tests/
├── api/
│   ├── test_cost_estimator_model.py
│   └── test_estimate_cost_route.py
├── services/
│   └── test_benefit_services.py
└── test_main.py
```

## 🏗️ Project Structure

```
cost-estimator-calc-service/
├── app/
│   ├── api/
│   │   ├── router.py
│   │   ├── routes/
│   │   │   └── index.py
│   │   └── v1/
│   │       └── routes/
│   │           └── requests.py
│   ├── config/
│   │   ├── database_config.py
│   │   └── queries.py
│   ├── core/
│   │   ├── constants.py
│   │   ├── exception_handler.py
│   │   ├── exception_responses.py
│   │   ├── exceptions.py
│   │   └── logger.py
│   ├── database/
│   │   └── spanner_client.py
│   ├── mappers/
│   │   └── cost_estimator_mapper.py
│   ├── models/
│   │   ├── rate_criteria.py
│   │   └── request_models.py
│   ├── repository/
│   │   ├── cost_estimator_repository.py
│   │   └── impl/
│   │       └── cost_estimator_repository_impl.py
│   ├── schemas/
│   │   ├── accumulator_request.py
│   │   ├── accumulator_response.py
│   │   ├── benefit_request.py
│   │   ├── benefit_response.py
│   │   └── cost_estimator_request_model.py
│   ├── services/
│   │   ├── accumulator_service.py
│   │   ├── benefit_service.py
│   │   ├── cost_estimation_service.py
│   │   ├── token_service.py
│   │   └── impl/
│   │       ├── accumulator_service_impl.py
│   │       ├── benefit_service_impl.py
│   │       └── cost_estimation_service_impl.py
│   ├── tests/
│   │   ├── api/
│   │   ├── services/
│   │   └── test_main.py
│   └── main.py
├── utils/
│   ├── ClassicCopay.py
│   └── CostShareCalculator.py
├── Dockerfile
├── Pipfile
├── README.md
└── requirements.txt
```

## 🐳 Docker

### Build Image

```bash
docker build -t cost-estimator-service .
```

### Run Container

```bash
docker run -p 8000:8000 cost-estimator-service
```




# cost-estimator-calc-service
# cost-estimator-calc-service
