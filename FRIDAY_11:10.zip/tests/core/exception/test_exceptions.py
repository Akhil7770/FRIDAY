import pytest
from app.exception.exceptions import (
    RateNotFoundException,
    ProviderNotFoundException,
    BenefitsNotFoundException,
    BenefitsMemberNotFoundException,
    BenefitsNotMatchingException,
    AccumulatorNotFoundException,
    AccumulatorMemberNotFoundException,
    InsuranceContextException,
    CircuitBreakerOpenException,
)


def test_rate_not_found_exception_default():
    """Test RateNotFoundException with default message"""
    with pytest.raises(RateNotFoundException) as exc_info:
        raise RateNotFoundException()

    assert str(exc_info.value) == "Rate not found for the given criteria"
    assert exc_info.value.rate_criteria == {}


def test_rate_not_found_exception_custom():
    """Test RateNotFoundException with custom message and criteria"""
    rate_criteria = {"serviceCode": "99214", "providerId": "123453334"}

    with pytest.raises(RateNotFoundException) as exc_info:
        raise RateNotFoundException("Custom rate not found", rate_criteria)

    assert str(exc_info.value) == "Custom rate not found"
    assert exc_info.value.rate_criteria == rate_criteria


def test_provider_not_found_exception_default():
    """Test ProviderNotFoundException with default message"""
    with pytest.raises(ProviderNotFoundException) as exc_info:
        raise ProviderNotFoundException()

    assert str(exc_info.value) == "Provider not found for the given criteria"
    assert exc_info.value.provider_criteria == {}


def test_provider_not_found_exception_custom():
    """Test ProviderNotFoundException with custom message and criteria"""
    provider_criteria = {"providerId": "12345", "networkId": "58921"}

    with pytest.raises(ProviderNotFoundException) as exc_info:
        raise ProviderNotFoundException("Custom provider not found", provider_criteria)

    assert str(exc_info.value) == "Custom provider not found"
    assert exc_info.value.provider_criteria == provider_criteria


def test_benefits_not_found_exception_default():
    """Test BenefitsNotFoundException with default message"""
    with pytest.raises(BenefitsNotFoundException) as exc_info:
        raise BenefitsNotFoundException()

    assert str(exc_info.value) == "Benefits not found for the given request"
    assert exc_info.value.benefit_request == {}


def test_benefits_not_found_exception_custom():
    """Test BenefitsNotFoundException with custom message and request"""
    benefit_request = {"membershipId": "12345", "serviceCode": "99214"}

    with pytest.raises(BenefitsNotFoundException) as exc_info:
        raise BenefitsNotFoundException("Custom benefits not found", benefit_request)

    assert str(exc_info.value) == "Custom benefits not found"
    assert exc_info.value.benefit_request == benefit_request


def test_benefits_member_not_found_exception_default():
    """Test BenefitsMemberNotFoundException with default message"""
    with pytest.raises(BenefitsMemberNotFoundException) as exc_info:
        raise BenefitsMemberNotFoundException()

    assert str(exc_info.value) == "Member not found by benefits api"


def test_benefits_member_not_found_exception_custom():
    """Test BenefitsMemberNotFoundException with custom message"""
    with pytest.raises(BenefitsMemberNotFoundException) as exc_info:
        raise BenefitsMemberNotFoundException("Custom member not found")

    assert str(exc_info.value) == "Custom member not found"


def test_benefits_not_matching_exception_default():
    """Test BenefitsNotMatchingException with default message"""
    with pytest.raises(BenefitsNotMatchingException) as exc_info:
        raise BenefitsNotMatchingException()

    assert str(exc_info.value) == "No matching selected benefits or accumulators"
    assert exc_info.value.benefit_request == {}


def test_benefits_not_matching_exception_custom():
    """Test BenefitsNotMatchingException with custom message and request"""
    benefit_request = {"membershipId": "12345", "serviceCode": "99214"}

    with pytest.raises(BenefitsNotMatchingException) as exc_info:
        raise BenefitsNotMatchingException(
            "Custom no matching benefits", benefit_request
        )

    assert str(exc_info.value) == "Custom no matching benefits"
    assert exc_info.value.benefit_request == benefit_request


def test_accumulator_not_found_exception_default():
    """Test AccumulatorNotFoundException with default message"""
    with pytest.raises(AccumulatorNotFoundException) as exc_info:
        raise AccumulatorNotFoundException()

    assert str(exc_info.value) == "Accumulator not found for the given request"
    assert exc_info.value.accumulator_request == {}


def test_accumulator_not_found_exception_custom():
    """Test AccumulatorNotFoundException with custom message and request"""
    accumulator_request = {"membershipId": "12345", "accumulatorCode": "Deductible"}

    with pytest.raises(AccumulatorNotFoundException) as exc_info:
        raise AccumulatorNotFoundException(
            "Custom accumulator not found", accumulator_request
        )

    assert str(exc_info.value) == "Custom accumulator not found"
    assert exc_info.value.accumulator_request == accumulator_request


def test_accumulator_member_not_found_exception_default():
    """Test AccumulatorMemberNotFoundException with default message"""
    with pytest.raises(AccumulatorMemberNotFoundException) as exc_info:
        raise AccumulatorMemberNotFoundException()

    assert str(exc_info.value) == "Member not found by accumulator api"
    assert exc_info.value.accumulator_request == {}


def test_accumulator_member_not_found_exception_custom():
    """Test AccumulatorMemberNotFoundException with custom message and request"""
    accumulator_request = {"membershipId": "12345", "accumulatorCode": "Deductible"}

    with pytest.raises(AccumulatorMemberNotFoundException) as exc_info:
        raise AccumulatorMemberNotFoundException(
            "Custom member not found by accumulator", accumulator_request
        )

    assert str(exc_info.value) == "Custom member not found by accumulator"
    assert exc_info.value.accumulator_request == accumulator_request


def test_insurance_context_exception_default():
    """Test InsuranceContextException with default message"""
    with pytest.raises(InsuranceContextException) as exc_info:
        raise InsuranceContextException()

    assert str(exc_info.value) == "Insurance context error for the given request"
    assert exc_info.value.error_code is None
    assert exc_info.value.error_message is None


def test_insurance_context_exception_custom():
    """Test InsuranceContextException with custom message, error code, and error message"""
    with pytest.raises(InsuranceContextException) as exc_info:
        raise InsuranceContextException(
            "Custom insurance context error",
            error_code="IC001",
            error_message="Invalid benefit configuration",
        )

    assert str(exc_info.value) == "Custom insurance context error"
    assert exc_info.value.error_code == "IC001"
    assert exc_info.value.error_message == "Invalid benefit configuration"


def test_circuit_breaker_open_exception_default():
    """Test CircuitBreakerOpenException with default message"""
    with pytest.raises(CircuitBreakerOpenException) as exc_info:
        raise CircuitBreakerOpenException()

    assert (
        str(exc_info.value)
        == "Service temporarily unavailable due to circuit breaker being open"
    )
    assert exc_info.value.service_name is None
    assert exc_info.value.circuit_breaker_state == "open"
    assert exc_info.value.service_type is None


def test_circuit_breaker_open_exception_custom():
    """Test CircuitBreakerOpenException with custom parameters"""
    with pytest.raises(CircuitBreakerOpenException) as exc_info:
        raise CircuitBreakerOpenException(
            "Custom circuit breaker error",
            service_name="benefits-service",
            circuit_breaker_state="half-open",
            service_type="external-api",
        )

    assert str(exc_info.value) == "Custom circuit breaker error"
    assert exc_info.value.service_name == "benefits-service"
    assert exc_info.value.circuit_breaker_state == "half-open"
    assert exc_info.value.service_type == "external-api"


def test_exception_inheritance():
    """Test that all custom exceptions inherit from Exception"""
    exceptions = [
        RateNotFoundException,
        ProviderNotFoundException,
        BenefitsNotFoundException,
        BenefitsMemberNotFoundException,
        BenefitsNotMatchingException,
        AccumulatorNotFoundException,
        AccumulatorMemberNotFoundException,
        InsuranceContextException,
        CircuitBreakerOpenException,
    ]

    for exception_class in exceptions:
        assert issubclass(
            exception_class, Exception
        ), f"{exception_class.__name__} should inherit from Exception"


def test_exception_attributes():
    """Test that exceptions have the expected attributes"""
    # Test RateNotFoundException attributes
    with pytest.raises(RateNotFoundException) as exc_info:
        raise RateNotFoundException("test", {"key": "value"})

    assert hasattr(exc_info.value, "message")
    assert hasattr(exc_info.value, "rate_criteria")
    assert exc_info.value.message == "test"
    assert exc_info.value.rate_criteria == {"key": "value"}

    # Test InsuranceContextException attributes
    with pytest.raises(InsuranceContextException) as exc_info:
        raise InsuranceContextException("test", "IC001", "error")

    assert hasattr(exc_info.value, "message")
    assert hasattr(exc_info.value, "error_code")
    assert hasattr(exc_info.value, "error_message")
    assert exc_info.value.message == "test"
    assert exc_info.value.error_code == "IC001"
    assert exc_info.value.error_message == "error"
