from behave import given, when, then  # type: ignore
from app.services.handlers.service_coverage_handler import ServiceCoverageHandler
from app.core.base import InsuranceContext


@given("a ServiceCoverageHandler is created")
def step_create_handler(context):
    context.handler = ServiceCoverageHandler()


# Note: This step is now defined in benefit_limitation_handler_steps.py to avoid conflicts
# and provide a version that doesn't depend on service coverage handler mocks


@then("benefit limitation is checked")
def step_benefit_limitation_checked(context):
    """Verify that the service is covered and ready for next processing step"""
    assert context.result.is_service_covered is True
    # The handler now just returns the context when service is covered
    # The benefit limitation handler will be called by the higher-level service


@given("an insurance context with service not covered")
def step_given_service_not_covered(context):
    context.insurance_context = InsuranceContext()
    context.insurance_context.is_service_covered = False


@given("an insurance context with service covered for service coverage")
def step_given_service_covered(context):
    context.insurance_context = InsuranceContext()
    context.insurance_context.is_service_covered = True
