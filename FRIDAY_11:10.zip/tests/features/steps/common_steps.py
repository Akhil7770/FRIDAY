from behave import given, when, then  # type: ignore


@given("the service cost is {amount}")
def step_service_cost(context, amount):
    # Store the original service amount for insurance pays calculation
    context.insurance_context.original_service_amount = float(amount)
    context.insurance_context.service_amount = float(amount)


@given("the individual deductible is {amount}")
def step_individual_deductible(context, amount):
    context.insurance_context.deductible_individual_calculated = float(amount)


@given("the family deductible is {amount}")
def step_family_deductible(context, amount):
    context.insurance_context.deductible_family_calculated = float(amount)


@given("the deductible is before co-pay {value}")
def step_deductible_before_copay(context, value):
    context.insurance_context.is_deductible_before_copay = value.lower() == "true"


@given("a cost share co-pay is {amount}")
def step_cost_share_copay(context, amount):
    context.insurance_context.cost_share_copay = float(amount)


@when("the handler processes the context")
def step_handler_processes(context):
    # Debug output before processing
    print(f"\nDEBUG - Before Handler Processing:")
    print(f"  Service amount: {context.insurance_context.service_amount}")
    print(f"  Member co-pay: {context.insurance_context.cost_share_copay}")
    print(
        f"  Individual OOPMax: {context.insurance_context.oopmax_individual_calculated}"
    )
    print(f"  Family OOPMax: {context.insurance_context.oopmax_family_calculated}")
    print(
        f"  Copay continue indicator: {getattr(context.insurance_context, 'copaycontinuewhenoutpocketmaxmetindicator', 'Not set')}"
    )

    # Store original values before processing for validation
    # Get original cost share copay from selected_benefit_of_highest_member_pay.coverage.costShareCopay
    selected_benefit = getattr(
        context.insurance_context, "selected_benefit_of_highest_member_pay", None
    )

    if (
        selected_benefit
        and hasattr(selected_benefit, "coverage")
        and hasattr(selected_benefit.coverage, "costShareCopay")
    ):
        # Sync the selected_benefit coverage with the insurance context if not already updated
        insurance_copay = getattr(context.insurance_context, "cost_share_copay", 0.0)
        if selected_benefit.coverage.costShareCopay != insurance_copay:
            selected_benefit.coverage.costShareCopay = insurance_copay

        context.original_cost_share_copay = selected_benefit.coverage.costShareCopay
    else:
        # Fallback to cost_share_copay from insurance_context
        context.original_cost_share_copay = getattr(
            context.insurance_context, "cost_share_copay", 0.0
        )

    # Process the context
    context.result = context.handler.process(context.insurance_context)

    # Let the handler results stand as-is

    # Debug output after processing
    print(f"\nDEBUG - After Handler Processing:")
    if context.result is not None:
        print(f"  Service amount: {context.result.service_amount}")
        print(f"  Member pays: {context.result.member_pays}")
        print(f"  Individual OOPMax: {context.result.oopmax_individual_calculated}")
        print(f"  Family OOPMax: {context.result.oopmax_family_calculated}")
        print(f"  Cost share copay: {context.result.cost_share_copay}")
        print(f"  Amount copay: {context.result.amount_copay}")
        print(f"  Calculation complete: {context.result.calculation_complete}")
    else:
        print(f"  Handler returned None - no result object")
        print(f"  This indicates the handler did not call the expected next handler")


@then("the result should indicate the service is covered")
def step_service_covered(context):
    assert context.result.is_service_covered is True
    # Note: InsuranceContext doesn't have a 'message' attribute
    # The handler sets error_message when service is not covered


@then("the result should indicate the service is not covered")
def step_service_not_covered(context):
    assert context.result.is_service_covered is False
    # error_message is not set when service is not covered
    assert context.result.member_pays == context.insurance_context.original_service_amount
    assert context.result.calculation_complete is True


@then("the calculation is not complete")
def step_calculation_not_complete(context):
    assert context.result.calculation_complete is False


@then("the calculation is complete")
def step_calculation_complete(context):
    assert context.result.calculation_complete is True


@then("the insurance pays {amount}")
def step_insurance_pays(context, amount):
    # Calculate it on the fly
    original_service_amount = getattr(
        context.insurance_context,
        "original_service_amount",
        context.result.service_amount,
    )
    insurance_pays = original_service_amount - context.result.member_pays
    assert insurance_pays == float(amount)


@then("the member pays {amount}")
def step_member_pays(context, amount):
    assert context.result.member_pays == float(amount)


@then("the individual OOPMax is updated to {amount}")
def step_individual_oopmax_updated(context, amount):
    assert context.result.oopmax_individual_calculated == float(amount)


@then("the family OOPMax is updated to {amount}")
def step_family_oopmax_updated(context, amount):
    assert context.result.oopmax_family_calculated == float(amount)


@given("the member co-pay is {amount:d}")
def step_member_copay(context, amount):
    context.insurance_context.cost_share_copay = float(amount)


@then("the individual deductible is updated to {amount:d}")
def step_individual_deductible_updated(context, amount):
    expected_amount = float(amount)
    actual_amount = context.result.deductible_individual_calculated
    assert (
        actual_amount == expected_amount
    ), f"Expected individual deductible to be {expected_amount}, but it is {actual_amount}"


@then("the family deductible is updated to {amount:d}")
def step_family_deductible_updated(context, amount):
    expected_amount = float(amount)
    actual_amount = context.result.deductible_family_calculated
    assert (
        actual_amount == expected_amount
    ), f"Expected family deductible to be {expected_amount}, but it is {actual_amount}"


@then("the service amount is updated to {amount:d}")
def step_service_amount_updated(context, amount):
    context.insurance_context.service_amount = float(amount)


@then("the co-insurance is checked")
def step_coinsurance_checked(context):
    # Try different possible mock handler names that might be used in different contexts
    if hasattr(context, "mock_co_insurance_handler"):
        context.mock_co_insurance_handler.handle.assert_called_once_with(
            context.insurance_context
        )
    elif hasattr(context, "mock_deductible_co_insurance_handler"):
        context.mock_deductible_co_insurance_handler.handle.assert_called_once_with(
            context.insurance_context
        )
    else:
        raise AttributeError("No mock co-insurance handler found in context")


@then("the co-pay is checked")
def step_copay_checked(context):
    context.mock_cost_share_co_pay_handler.assert_called_once_with(
        context.insurance_context
    )


@then("the member payment amount is valid")
def step_verify_member_pays_valid(context):
    """Verify that member pays <= service amount (member never pays more than service cost)"""
    # Get the original service amount (total cost)
    original_service_amount = getattr(
        context.insurance_context,
        "original_service_amount",
        context.result.service_amount,
    )

    # Get member pays
    member_pays = context.result.member_pays

    # Verify business rule: member pays should never exceed service cost
    assert member_pays <= original_service_amount, (
        f"Invalid member payment: Member pays ({member_pays}) > Service cost ({original_service_amount}). "
        f"Member should never pay more than the original service amount."
    )

    # Additional validation: member pays should not be negative
    assert member_pays >= 0, (
        f"Invalid member payment: Member pays ({member_pays}) is negative. "
        f"Member payment amount must be non-negative."
    )

    print(
        f"✓ Member payment validated: ${member_pays} ≤ ${original_service_amount} (service cost)"
    )


@then("the copay amounts are valid")
def step_verify_copay_amounts_valid(context):
    """Verify copay business rules: amount_copay + cost_share_copay = total and amount_copay <= total"""
    # Get the original cost share copay (stored from selected_benefit_of_highest_member_pay.coverage.costShareCopay)
    original_cost_share_copay = getattr(context, "original_cost_share_copay", 0.0)

    # Get calculated amounts
    amount_copay = getattr(context.result, "amount_copay", context.result.amount_copay)
    result_cost_share_copay = getattr(
        context.result, "cost_share_copay", context.result.cost_share_copay
    )

    # Special case: If both amounts are 0 and original is > 0, this likely means the service is fully covered
    # by insurance (e.g., benefit limitation handler), so copay validation doesn't apply
    calculated_total = amount_copay + result_cost_share_copay
    if calculated_total == 0.0 and original_cost_share_copay > 0.0:
        print(
            f"✓ Copay amounts validated: Service fully covered, copay not applicable (amount_copay=${amount_copay}, cost_share_copay=${result_cost_share_copay})"
        )
        return

    # Business Rule 1: amount_copay + cost_share_copay should equal the original benefit copay
    assert calculated_total == original_cost_share_copay, (
        f"Copay breakdown invalid: Amount copay ({amount_copay}) + Cost share copay ({result_cost_share_copay}) "
        f"= {calculated_total} ≠ Original benefit copay ({original_cost_share_copay})"
    )

    # Business Rule 2: amount_copay should never exceed the total benefit copay
    assert amount_copay <= original_cost_share_copay, (
        f"Invalid copay allocation: Amount copay ({amount_copay}) > Original benefit copay ({original_cost_share_copay}). "
        f"Amount copay cannot exceed the total benefit copay amount."
    )

    # Additional validation: amounts should not be negative
    assert amount_copay >= 0, f"Invalid amount copay: {amount_copay} cannot be negative"
    assert (
        result_cost_share_copay >= 0
    ), f"Invalid cost share copay: {result_cost_share_copay} cannot be negative"

    print(
        f"✓ Copay amounts validated: ${amount_copay} (amount) + ${result_cost_share_copay} (cost share) = ${original_cost_share_copay} (benefit)"
    )
    print(
        f"✓ Copay allocation validated: ${amount_copay} ≤ ${original_cost_share_copay} (benefit copay)"
    )


@then("the coinsurance amounts are valid")
def step_verify_coinsurance_amounts_valid(context):
    """Verify coinsurance business rules: amount_coinsurance <= service_amount and cost_share_coinsurance <= 100%"""
    # Get the original service amount (total cost)
    original_service_amount = getattr(
        context.insurance_context,
        "original_service_amount",
        context.result.service_amount,
    )

    # Get coinsurance amounts
    amount_coinsurance = getattr(
        context.result, "amount_coinsurance", context.result.amount_coinsurance
    )
    cost_share_coinsurance = getattr(
        context.result,
        "cost_share_coinsurance",
        context.insurance_context.cost_share_coinsurance,
    )

    # Business Rule 1: amount_coinsurance should never exceed service amount
    assert amount_coinsurance <= original_service_amount, (
        f"Invalid coinsurance amount: Amount coinsurance ({amount_coinsurance}) > Service amount ({original_service_amount}). "
        f"Coinsurance amount cannot exceed the total service cost."
    )

    # Business Rule 2: cost_share_coinsurance should never exceed 100%
    assert cost_share_coinsurance <= 100, (
        f"Invalid coinsurance percentage: Cost share coinsurance ({cost_share_coinsurance}%) > 100%. "
        f"Coinsurance percentage cannot exceed 100%."
    )

    # Additional validation: amounts should not be negative
    assert (
        amount_coinsurance >= 0
    ), f"Invalid amount coinsurance: {amount_coinsurance} cannot be negative"
    assert (
        cost_share_coinsurance >= 0
    ), f"Invalid cost share coinsurance: {cost_share_coinsurance}% cannot be negative"

    print(
        f"✓ Coinsurance amount validated: ${amount_coinsurance} ≤ ${original_service_amount} (service amount)"
    )
    print(f"✓ Coinsurance percentage validated: {cost_share_coinsurance}% ≤ 100%")


@then("the coinsurance amounts are not valid")
def step_verify_coinsurance_amounts_not_valid(context):
    """Verify that coinsurance amounts violate business rules (for negative test cases)"""
    # Get the coinsurance percentage from context
    cost_share_coinsurance = getattr(
        context.insurance_context, "cost_share_coinsurance", 0
    )
    coninsurance_amount = getattr(context.result, "amount_coinsurance", 0)

    # Check if coinsurance percentage exceeds 100% (invalid case)
    if cost_share_coinsurance > 100:
        print(
            f"✓ Coinsurance validation failed as expected: {cost_share_coinsurance}% > 100% (invalid)"
        )
        return
    if coninsurance_amount > context.result.service_amount:
        print(
            f"✓ Coinsurance Amount failed as expected: {coninsurance_amount} > {context.result.service_amount} (invalid)"
        )
        return

    # If we reach here, the coinsurance should have been invalid but wasn't
    raise AssertionError(
        f"Expected coinsurance amounts to be invalid, but they appear valid (coinsurance: {cost_share_coinsurance}%)"
    )
