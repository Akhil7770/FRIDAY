import pytest
from unittest.mock import AsyncMock, patch
from app.repository.impl.cost_estimator_repository_impl import (
    CostEstimatorRepositoryImpl,
)
from app.models.rate_criteria import CostEstimatorRateCriteria
from app.models.rate_criteria import NegotiatedRate
from app.config.queries import RATE_QUERIES


@pytest.fixture
def sample_rate_criteria():
    return CostEstimatorRateCriteria(
        serviceCode="99214",
        placeOfService="11",
        serviceType="CPT4",
        zipCode="85305",
        providerIdentificationNumber="0004000317",
        networkId="58921",
        serviceLocationNumber="000761071",
        isOutofNetwork=False,
        providerSpecialtyCode="91017",
        providerType="HO",
    )


@pytest.mark.asyncio
@patch("app.repository.impl.cost_estimator_repository_impl.SpannerClient")
@patch("app.repository.impl.cost_estimator_repository_impl.spanner_config")
async def test_get_rate_claim_based_success(
    mock_config, mock_client_class, sample_rate_criteria
):
    mock_config.is_valid.return_value = True
    mock_client = AsyncMock()
    mock_client.execute_query.return_value = [
        {"RATE": "250.00", "payment_method_cd": "FIXED"}
    ]
    mock_client_class.return_value = mock_client

    repo = CostEstimatorRepositoryImpl()
    result = await repo.get_rate(sample_rate_criteria)

    assert isinstance(result, NegotiatedRate)
    assert result.rate == 250.00
    assert result.paymentMethod == "FIXED"
    assert result.isRateFound == True
    assert result.rateType == "AMOUNT"


@pytest.mark.asyncio
@patch("app.repository.impl.cost_estimator_repository_impl.SpannerClient")
@patch("app.repository.impl.cost_estimator_repository_impl.spanner_config")
async def test_get_rate_all_na_fallback_to_na(
    mock_config, mock_client_class, sample_rate_criteria
):
    mock_config.is_valid.return_value = True
    mock_client = AsyncMock()
    mock_client.execute_query.side_effect = [
        [],  # Claim-based
        [],  # Provider Info
        [],  # Standard
    ]
    mock_client_class.return_value = mock_client

    repo = CostEstimatorRepositoryImpl()
    repo.db = mock_client

    result = await repo.get_rate(sample_rate_criteria)
    assert isinstance(result, NegotiatedRate)
    assert result.paymentMethod == ""
    assert result.rate == 0.0
    assert not result.isRateFound
    assert result.rateType == ""

    # # Expect RateNotFoundException when no rate is found
    # from app.exception.exceptions import RateNotFoundException

    # with pytest.raises(RateNotFoundException) as exc_info:
    #     await repo.get_rate(sample_rate_criteria)

    # assert "Rate not found for the given parameters." in str(exc_info.value)


@pytest.mark.asyncio
@patch("app.repository.impl.cost_estimator_repository_impl.SpannerClient")
@patch("app.repository.impl.cost_estimator_repository_impl.spanner_config")
async def test_get_rate_out_of_network_success(
    mock_config, mock_client_class, sample_rate_criteria
):
    mock_config.is_valid.return_value = True
    sample_rate_criteria.isOutofNetwork = True

    mock_client = AsyncMock()
    mock_client.execute_query.return_value = [
        {"RATE": "300.00", "payment_method_cd": "PERBIL"}
    ]
    mock_client_class.return_value = mock_client

    repo = CostEstimatorRepositoryImpl()
    result = await repo.get_rate(sample_rate_criteria)

    assert isinstance(result, NegotiatedRate)
    assert result.rate == 300.00
    assert result.paymentMethod == "PERBIL"
    assert result.isRateFound == True
    assert result.rateType == "PERCENTAGE"


@pytest.mark.asyncio
@patch("app.repository.impl.cost_estimator_repository_impl.SpannerClient")
@patch("app.repository.impl.cost_estimator_repository_impl.spanner_config")
async def test_get_rate_provider_info_to_standard_rate(
    mock_config, mock_client_class, sample_rate_criteria
):
    mock_config.is_valid.return_value = True
    mock_client = AsyncMock()
    mock_client.execute_query.side_effect = [
        [],  # Claim-based
        [
            {
                "PROVIDER_BUSINESS_GROUP_NBR": "None",
                "PRODUCT_CD": "PROD1",
                "RATING_SYSTEM_CD": "RS1",
                "EPDB_GEOGRAPHIC_AREA_CD": "GA1",
            }
        ],  # Provider info -> contract_type = S
        [{"RATE": "200.00", "payment_method_cd": "FIXED"}],  # Standard rate
    ]
    mock_client_class.return_value = mock_client
    repo = CostEstimatorRepositoryImpl()
    result = await repo.get_rate(sample_rate_criteria)

    assert isinstance(result, NegotiatedRate)
    assert result.rate == 200.00
    assert result.paymentMethod == "FIXED"
    assert result.isRateFound == True
    assert result.rateType == "AMOUNT"


@pytest.mark.asyncio
@patch("app.repository.impl.cost_estimator_repository_impl.SpannerClient")
@patch("app.repository.impl.cost_estimator_repository_impl.spanner_config")
async def test_get_provider_info(mock_config, mock_client_class):
    mock_config.is_valid.return_value = True
    mock_client = AsyncMock()

    # Scenario 1: Different PROVIDER_BUSINESS_GROUP_SCORE_NBR values
    mock_client.execute_query.return_value = [
        {
            "PROVIDER_BUSINESS_GROUP_NBR": "PBG001",
            "PROVIDER_BUSINESS_GROUP_SCORE_NBR": 100,
            "PROVIDER_IDENTIFICATION_NBR": "0004000317",
            "PRODUCT_CD": "PROD1",
            "SERVICE_LOCATION_NBR": "000761071",
            "NETWORK_ID": "58921",
            "RATING_SYSTEM_CD": "RS1",
            "EPDB_GEOGRAPHIC_AREA_CD": "GA1",
        },
        {
            "PROVIDER_BUSINESS_GROUP_NBR": "PBG002",
            "PROVIDER_BUSINESS_GROUP_SCORE_NBR": 200,
            "PROVIDER_IDENTIFICATION_NBR": "0004000317",
            "PRODUCT_CD": "PROD2",
            "SERVICE_LOCATION_NBR": "000761071",
            "NETWORK_ID": "58921",
            "RATING_SYSTEM_CD": "RS2",
            "EPDB_GEOGRAPHIC_AREA_CD": "GA2",
        },
    ]
    mock_client_class.return_value = mock_client

    repo = CostEstimatorRepositoryImpl()
    params = {}

    result = await repo._get_provider_info(params)
    assert isinstance(result, list)
    assert len(result) == 1
    assert result[0]["PROVIDER_BUSINESS_GROUP_NBR"] == "PBG002"
    assert result[0]["PROVIDER_BUSINESS_GROUP_SCORE_NBR"] == 200

    # Scenario 2: Multiple records share the highest PROVIDER_BUSINESS_GROUP_SCORE_NBR
    mock_client.execute_query.return_value = [
        {
            "PROVIDER_BUSINESS_GROUP_NBR": "PBG001",
            "PROVIDER_BUSINESS_GROUP_SCORE_NBR": 100,
            "PROVIDER_IDENTIFICATION_NBR": "0004000317",
            "PRODUCT_CD": "PROD1",
            "SERVICE_LOCATION_NBR": "000761071",
            "NETWORK_ID": "58921",
            "RATING_SYSTEM_CD": "RS1",
            "EPDB_GEOGRAPHIC_AREA_CD": "GA1",
        },
        {
            "PROVIDER_BUSINESS_GROUP_NBR": "PBG002",
            "PROVIDER_BUSINESS_GROUP_SCORE_NBR": 100,
            "PROVIDER_IDENTIFICATION_NBR": "0004000317",
            "PRODUCT_CD": "PROD2",
            "SERVICE_LOCATION_NBR": "000761071",
            "NETWORK_ID": "58921",
            "RATING_SYSTEM_CD": "RS2",
            "EPDB_GEOGRAPHIC_AREA_CD": "GA2",
        },
        {
            "PROVIDER_BUSINESS_GROUP_NBR": "PBG003",
            "PROVIDER_BUSINESS_GROUP_SCORE_NBR": 200,
            "PROVIDER_IDENTIFICATION_NBR": "0004000317",
            "PRODUCT_CD": "PROD2",
            "SERVICE_LOCATION_NBR": "000761071",
            "NETWORK_ID": "58921",
            "RATING_SYSTEM_CD": "RS2",
            "EPDB_GEOGRAPHIC_AREA_CD": "GA2",
        },
        {
            "PROVIDER_BUSINESS_GROUP_NBR": "PBG004",
            "PROVIDER_BUSINESS_GROUP_SCORE_NBR": 200,
            "PROVIDER_IDENTIFICATION_NBR": "0004000317",
            "PRODUCT_CD": "PROD3",
            "SERVICE_LOCATION_NBR": "000761071",
            "NETWORK_ID": "58921",
            "RATING_SYSTEM_CD": "RS3",
            "EPDB_GEOGRAPHIC_AREA_CD": "GA3",
        },
    ]
    mock_client_class.return_value = mock_client

    repo = CostEstimatorRepositoryImpl()
    params = {}

    result = await repo._get_provider_info(params)
    assert isinstance(result, list)
    assert len(result) == 2
    assert {row["PROVIDER_BUSINESS_GROUP_NBR"] for row in result} == {
        "PBG003",
        "PBG004",
    }
    assert all(row["PROVIDER_BUSINESS_GROUP_SCORE_NBR"] == 200 for row in result)

    # Scenario 3: All have the same PROVIDER_BUSINESS_GROUP_SCORE_NBR
    mock_client.execute_query.return_value = [
        {
            "PROVIDER_BUSINESS_GROUP_NBR": "PBG001",
            "PROVIDER_BUSINESS_GROUP_SCORE_NBR": 100,
            "PROVIDER_IDENTIFICATION_NBR": "0004000317",
            "PRODUCT_CD": "PROD1",
            "SERVICE_LOCATION_NBR": "000761071",
            "NETWORK_ID": "58921",
            "RATING_SYSTEM_CD": "RS1",
            "EPDB_GEOGRAPHIC_AREA_CD": "GA1",
        },
        {
            "PROVIDER_BUSINESS_GROUP_NBR": "PBG002",
            "PROVIDER_BUSINESS_GROUP_SCORE_NBR": 100,
            "PROVIDER_IDENTIFICATION_NBR": "0004000317",
            "PRODUCT_CD": "PROD2",
            "SERVICE_LOCATION_NBR": "000761071",
            "NETWORK_ID": "58921",
            "RATING_SYSTEM_CD": "RS2",
            "EPDB_GEOGRAPHIC_AREA_CD": "GA2",
        },
        {
            "PROVIDER_BUSINESS_GROUP_NBR": "PBG003",
            "PROVIDER_BUSINESS_GROUP_SCORE_NBR": 100,
            "PROVIDER_IDENTIFICATION_NBR": "0004000317",
            "PRODUCT_CD": "PROD2",
            "SERVICE_LOCATION_NBR": "000761071",
            "NETWORK_ID": "58921",
            "RATING_SYSTEM_CD": "RS2",
            "EPDB_GEOGRAPHIC_AREA_CD": "GA2",
        },
        {
            "PROVIDER_BUSINESS_GROUP_NBR": "PBG004",
            "PROVIDER_BUSINESS_GROUP_SCORE_NBR": 100,
            "PROVIDER_IDENTIFICATION_NBR": "0004000317",
            "PRODUCT_CD": "PROD3",
            "SERVICE_LOCATION_NBR": "000761071",
            "NETWORK_ID": "58921",
            "RATING_SYSTEM_CD": "RS3",
            "EPDB_GEOGRAPHIC_AREA_CD": "GA3",
        },
    ]
    mock_client_class.return_value = mock_client

    repo = CostEstimatorRepositoryImpl()
    params = {}

    result = await repo._get_provider_info(params)
    assert isinstance(result, list)
    assert len(result) == 4
    assert {row["PROVIDER_BUSINESS_GROUP_NBR"] for row in result} == {
        "PBG001",
        "PBG002",
        "PBG003",
        "PBG004",
    }
    assert all(row["PROVIDER_BUSINESS_GROUP_SCORE_NBR"] == 100 for row in result)

    # Scenario 4: Some records have PROVIDER_BUSINESS_GROUP_SCORE_NBR as None
    mock_client.execute_query.return_value = [
        {
            "PROVIDER_BUSINESS_GROUP_NBR": "PBG001",
            "PROVIDER_BUSINESS_GROUP_SCORE_NBR": None,
            "PROVIDER_IDENTIFICATION_NBR": "0004000317",
            "PRODUCT_CD": "PROD1",
            "SERVICE_LOCATION_NBR": "000761071",
            "NETWORK_ID": "58921",
            "RATING_SYSTEM_CD": "RS1",
            "EPDB_GEOGRAPHIC_AREA_CD": "GA1",
        },
        {
            "PROVIDER_BUSINESS_GROUP_NBR": "PBG002",
            "PROVIDER_BUSINESS_GROUP_SCORE_NBR": None,
            "PROVIDER_IDENTIFICATION_NBR": "0004000317",
            "PRODUCT_CD": "PROD2",
            "SERVICE_LOCATION_NBR": "000761071",
            "NETWORK_ID": "58921",
            "RATING_SYSTEM_CD": "RS2",
            "EPDB_GEOGRAPHIC_AREA_CD": "GA2",
        },
        {
            "PROVIDER_BUSINESS_GROUP_NBR": "PBG003",
            "PROVIDER_BUSINESS_GROUP_SCORE_NBR": 10,
            "PROVIDER_IDENTIFICATION_NBR": "0004000317",
            "PRODUCT_CD": "PROD2",
            "SERVICE_LOCATION_NBR": "000761071",
            "NETWORK_ID": "58921",
            "RATING_SYSTEM_CD": "RS2",
            "EPDB_GEOGRAPHIC_AREA_CD": "GA2",
        },
        {
            "PROVIDER_BUSINESS_GROUP_NBR": "PBG004",
            "PROVIDER_BUSINESS_GROUP_SCORE_NBR": 7,
            "PROVIDER_IDENTIFICATION_NBR": "0004000317",
            "PRODUCT_CD": "PROD3",
            "SERVICE_LOCATION_NBR": "000761071",
            "NETWORK_ID": "58921",
            "RATING_SYSTEM_CD": "RS3",
            "EPDB_GEOGRAPHIC_AREA_CD": "GA3",
        },
    ]
    mock_client_class.return_value = mock_client

    repo = CostEstimatorRepositoryImpl()
    params = {}

    result = await repo._get_provider_info(params)
    assert isinstance(result, list)
    assert len(result) == 1
    assert result[0]["PROVIDER_BUSINESS_GROUP_NBR"] == "PBG003"
    assert result[0]["PROVIDER_BUSINESS_GROUP_SCORE_NBR"] == 10

    # Scenario 5:  All records have PROVIDER_BUSINESS_GROUP_SCORE_NBR as None
    mock_client.execute_query.return_value = [
        {
            "PROVIDER_BUSINESS_GROUP_NBR": "PBG001",
            "PROVIDER_BUSINESS_GROUP_SCORE_NBR": None,
            "PROVIDER_IDENTIFICATION_NBR": "0004000317",
            "PRODUCT_CD": "PROD1",
            "SERVICE_LOCATION_NBR": "000761071",
            "NETWORK_ID": "58921",
            "RATING_SYSTEM_CD": "RS1",
            "EPDB_GEOGRAPHIC_AREA_CD": "GA1",
        },
        {
            "PROVIDER_BUSINESS_GROUP_NBR": "PBG002",
            "PROVIDER_BUSINESS_GROUP_SCORE_NBR": None,
            "PROVIDER_IDENTIFICATION_NBR": "0004000317",
            "PRODUCT_CD": "PROD2",
            "SERVICE_LOCATION_NBR": "000761071",
            "NETWORK_ID": "58921",
            "RATING_SYSTEM_CD": "RS2",
            "EPDB_GEOGRAPHIC_AREA_CD": "GA2",
        },
        {
            "PROVIDER_BUSINESS_GROUP_NBR": "PBG003",
            "PROVIDER_BUSINESS_GROUP_SCORE_NBR": None,
            "PROVIDER_IDENTIFICATION_NBR": "0004000317",
            "PRODUCT_CD": "PROD2",
            "SERVICE_LOCATION_NBR": "000761071",
            "NETWORK_ID": "58921",
            "RATING_SYSTEM_CD": "RS2",
            "EPDB_GEOGRAPHIC_AREA_CD": "GA2",
        },
        {
            "PROVIDER_BUSINESS_GROUP_NBR": "PBG004",
            "PROVIDER_BUSINESS_GROUP_SCORE_NBR": None,
            "PROVIDER_IDENTIFICATION_NBR": "0004000317",
            "PRODUCT_CD": "PROD3",
            "SERVICE_LOCATION_NBR": "000761071",
            "NETWORK_ID": "58921",
            "RATING_SYSTEM_CD": "RS3",
            "EPDB_GEOGRAPHIC_AREA_CD": "GA3",
        },
    ]
    mock_client_class.return_value = mock_client

    repo = CostEstimatorRepositoryImpl()
    params = {}

    result = await repo._get_provider_info(params)
    assert isinstance(result, list)
    assert len(result) == 4
    assert {row["PROVIDER_BUSINESS_GROUP_NBR"] for row in result} == {
        "PBG001",
        "PBG002",
        "PBG003",
        "PBG004",
    }
    assert all(row["PROVIDER_BUSINESS_GROUP_SCORE_NBR"] is None for row in result)


@pytest.mark.asyncio
@patch("app.repository.impl.cost_estimator_repository_impl.SpannerClient")
@patch("app.repository.impl.cost_estimator_repository_impl.spanner_config")
async def test_select_payment_method(mock_config, mock_client_class):
    mock_config.is_valid.return_value = True
    mock_client = AsyncMock()

    mock_client.execute_query.return_value = [
        {"payment_method_cd": "FIXED", "score": 10},
        {"payment_method_cd": "PERBIL", "score": 8},
        {"payment_method_cd": "PERCNT", "score": 6},
        {"payment_method_cd": "OTHER", "score": 4},
    ]
    mock_client_class.return_value = mock_client
    repo = CostEstimatorRepositoryImpl()
    repo.db = mock_client
    repo._cache = {}

    # Scenario 1: Only one record with service_group_changed_ind = N
    rows_obtained_from_cet_rates = [
        {
            "payment_method_cd": "FIXED",
            "service_group_changed_ind": "N",
            "service_grouping_priority_nbr": 5,
            "rate": 80.00,
        }
    ]
    result = await repo._select_payment_method(rows_obtained_from_cet_rates)
    assert result["payment_method_cd"] == "FIXED"
    assert result["rate"] == 80.00
    assert result["service_group_changed_ind"] == "N"
    assert result["service_grouping_priority_nbr"] == 5

    # Scenario 2: Only one record with service_group_changed_ind = Y
    rows_obtained_from_cet_rates = [
        {
            "payment_method_cd": "FIXED",
            "service_group_changed_ind": "Y",
            "service_grouping_priority_nbr": 3,
            "rate": 90.00,
        }
    ]
    result = await repo._select_payment_method(rows_obtained_from_cet_rates)
    assert result["payment_method_cd"] == "FIXED"
    assert result["rate"] == 90.00
    assert result["service_group_changed_ind"] == "Y"
    assert result["service_grouping_priority_nbr"] == 3

    # Scenario 3: All Rows have service_group_changed_ind as 'N' and different service_grouping_priority_nbr
    rows_obtained_from_cet_rates = [
        {
            "payment_method_cd": "FIXED",
            "service_group_changed_ind": "N",
            "service_grouping_priority_nbr": 1,
            "rate": 150.00,
        },
        {
            "payment_method_cd": "PERBIL",
            "service_group_changed_ind": "N",
            "service_grouping_priority_nbr": 2,
            "rate": 120.00,
        },
        {
            "payment_method_cd": "PERCNT",
            "service_group_changed_ind": "Y",
            "service_grouping_priority_nbr": 1,
            "rate": 130.00,
        },
        {
            "payment_method_cd": "FIXED",
            "service_group_changed_ind": "N",
            "service_grouping_priority_nbr": 3,
            "rate": 110.00,
        },
    ]
    result = await repo._select_payment_method(rows_obtained_from_cet_rates)
    assert result["payment_method_cd"] == "FIXED"
    assert result["rate"] == 110.00
    assert result["service_group_changed_ind"] == "N"
    assert result["service_grouping_priority_nbr"] == 3

    # Scenario 4: N-N with same service_grouping_priority_nbr but different rate
    rows_obtained_from_cet_rates = [
        {
            "payment_method_cd": "FIXED",
            "service_group_changed_ind": "N",
            "service_grouping_priority_nbr": 1,
            "rate": 150.00,
        },
        {
            "payment_method_cd": "PERBIL",
            "service_group_changed_ind": "N",
            "service_grouping_priority_nbr": 2,
            "rate": 120.00,
        },
        {
            "payment_method_cd": "PERCNT",
            "service_group_changed_ind": "N",
            "service_grouping_priority_nbr": 1,
            "rate": 130.00,
        },
        {
            "payment_method_cd": "FIXED",
            "service_group_changed_ind": "N",
            "service_grouping_priority_nbr": 1,
            "rate": 110.00,
        },
    ]
    result = await repo._select_payment_method(rows_obtained_from_cet_rates)
    assert result["payment_method_cd"] == "FIXED"
    assert result["rate"] == 150.00
    assert result["service_group_changed_ind"] == "N"
    assert result["service_grouping_priority_nbr"] == 1

    # Scenario 5: Y-Y with different rate
    rows_obtained_from_cet_rates = [
        {
            "payment_method_cd": "FIXED",
            "service_group_changed_ind": "Y",
            "service_grouping_priority_nbr": 4,
            "rate": 100.00,
        },
        {
            "payment_method_cd": "PERBIL",
            "service_group_changed_ind": "N",
            "service_grouping_priority_nbr": 5,
            "rate": 110.00,
        },
        {
            "payment_method_cd": "PERCNT",
            "service_group_changed_ind": "Y",
            "service_grouping_priority_nbr": 1,
            "rate": 120.00,
        },
        {
            "payment_method_cd": "FIXED",
            "service_group_changed_ind": "Y",
            "service_grouping_priority_nbr": 2,
            "rate": 130.00,
        },
    ]
    result = await repo._select_payment_method(rows_obtained_from_cet_rates)
    assert result["payment_method_cd"] == "FIXED"
    assert result["rate"] == 130.00
    assert result["service_group_changed_ind"] == "Y"
    assert result["service_grouping_priority_nbr"] == 2

    # Scenario 6: Y-N Records
    rows_obtained_from_cet_rates = [
        {
            "payment_method_cd": "FIXED",
            "service_group_changed_ind": "Y",
            "service_grouping_priority_nbr": 3,
            "rate": 140.00,
        },
        {
            "payment_method_cd": "PERBIL",
            "service_group_changed_ind": "N",
            "service_grouping_priority_nbr": 2,
            "rate": 150.00,
        },
        {
            "payment_method_cd": "PERCNT",
            "service_group_changed_ind": "Y",
            "service_grouping_priority_nbr": 1,
            "rate": 160.00,
        },
        {
            "payment_method_cd": "FIXED",
            "service_group_changed_ind": "N",
            "service_grouping_priority_nbr": 4,
            "rate": 170.00,
        },
    ]
    result = await repo._select_payment_method(rows_obtained_from_cet_rates)
    assert result["payment_method_cd"] == "FIXED"
    assert result["rate"] == 140.00
    assert result["service_group_changed_ind"] == "Y"
    assert result["service_grouping_priority_nbr"] == 3


# Predefined queries for comparison in tests
non_standard_query = RATE_QUERIES["get_non_standard_rate"]
non_standard_query_with_specialty_cd = RATE_QUERIES[
    "get_non_standard_rate_with_specialty_cd"
]
non_standard_query_with_provider_type_cd = RATE_QUERIES[
    "get_non_standard_rate_with_provider_type_cd"
]
default_rate = RATE_QUERIES["get_default_rate"]
default_rate_with_specialty_cd = RATE_QUERIES["get_default_rate_with_specialty_cd"]
default_rate_with_provider_type_cd = RATE_QUERIES[
    "get_default_rate_with_provider_type_cd"
]


def test_select_rate_query():

    # Scenario-1: params has both providerspecialtycode and providertype and contract_type is N or C
    params = {
        "providerspecialtycode": "91017",
        "providertype": "HO",
    }
    repo = CostEstimatorRepositoryImpl()
    modified_query = repo.select_rate_query("N", params)
    assert modified_query == non_standard_query_with_specialty_cd

    # Scenario-2: params has only providerspecialtycode and contract_type is N or C
    params = {
        "providerspecialtycode": "91017",
    }
    modified_query = repo.select_rate_query("N", params)
    assert modified_query == non_standard_query_with_specialty_cd

    # Scenario-3: params has only providertype
    params = {
        "providertype": "HO",
    }
    modified_query = repo.select_rate_query("N", params)
    assert modified_query == non_standard_query_with_provider_type_cd

    # Scenario-4: neither providerspecialtycode nor providertype in params and contract_type is N or C
    params = {}
    modified_query = repo.select_rate_query("N", params)
    assert modified_query == non_standard_query

    # Scenario-5: params has both providerspecialtycode and providertype but contract_type is D
    params = {
        "providerspecialtycode": "91017",
        "providertype": "HO",
    }
    modified_query = repo.select_rate_query("D", params)
    assert modified_query == default_rate_with_specialty_cd

    # Scenario-6: params has only providerspecialtycode and contract_type is D
    params = {
        "providerspecialtycode": "91017",
    }
    modified_query = repo.select_rate_query("D", params)
    assert modified_query == default_rate_with_specialty_cd

    # Scenario-7: params has only providertype and contract_type is D
    params = {
        "providertype": "HO",
    }
    modified_query = repo.select_rate_query("D", params)
    assert modified_query == default_rate_with_provider_type_cd

    # Scenario-8: neither providerspecialtycode nor providertype in params and contract_type is D
    params = {}
    modified_query = repo.select_rate_query("D", params)
    assert modified_query == default_rate


@pytest.mark.asyncio
@patch("app.repository.impl.cost_estimator_repository_impl.SpannerClient")
@patch("app.repository.impl.cost_estimator_repository_impl.spanner_config")
async def test_non_standard_rate_query_execution_based_on_optional_parameters(
    mock_config, mock_client_class
):
    mock_config.is_valid.return_value = True
    mock_client = AsyncMock()
    mock_client_class.return_value = mock_client

    repo = CostEstimatorRepositoryImpl()

    # Scenario-1: params has both providerspecialtycode and providertype and contract_type is N or C
    params = {"providerspecialtycode": "91017", "providertype": "HO"}
    result = await repo._get_non_standard_rate(params)

    mock_client.execute_query.assert_awaited_once()
    executed_query = mock_client.execute_query.call_args[0][0]
    assert executed_query == non_standard_query_with_specialty_cd

    # Scenario-2: params has only providertype and contract_type is N or C
    params = {
        "providertype": "HO",
    }
    mock_client.execute_query.reset_mock()
    result = await repo._get_non_standard_rate(params)
    mock_client.execute_query.assert_awaited_once()
    executed_query = mock_client.execute_query.call_args[0][0]
    assert executed_query == non_standard_query_with_provider_type_cd

    # Scenario-3: params has only providerspecialtycode and contract_type is N or C
    params = {
        "providerspecialtycode": "91017",
    }
    mock_client.execute_query.reset_mock()
    result = await repo._get_non_standard_rate(params)
    mock_client.execute_query.assert_awaited_once()
    executed_query = mock_client.execute_query.call_args[0][0]
    assert executed_query == non_standard_query_with_specialty_cd

    # Scenario-4: params has neither providerspecialtycode nor providertype and contract_type is N or C
    params = {}
    mock_client.execute_query.reset_mock()
    result = await repo._get_non_standard_rate(params)
    mock_client.execute_query.assert_awaited_once()
    executed_query = mock_client.execute_query.call_args[0][0]
    assert executed_query == non_standard_query


@pytest.mark.asyncio
@patch("app.repository.impl.cost_estimator_repository_impl.SpannerClient")
@patch("app.repository.impl.cost_estimator_repository_impl.spanner_config")
async def test_get_default_rate_query_execution_based_on_optional_parameters(
    mock_config, mock_client_class
):
    mock_config.is_valid.return_value = True
    mock_client = AsyncMock()
    mock_client_class.return_value = mock_client

    repo = CostEstimatorRepositoryImpl()

    # Scenario-1: params has both providerspecialtycode and providertype and contract_type is D
    params = {"providerspecialtycode": "91017", "providertype": "HO"}
    result = await repo._get_default_rate(params)
    mock_client.execute_query.assert_awaited_once()
    executed_query = mock_client.execute_query.call_args[0][0]
    assert executed_query == default_rate_with_specialty_cd

    # Scenario-2: params has only providertype and contract_type is D
    params = {"providertype": "HO"}
    mock_client.execute_query.reset_mock()
    result = await repo._get_default_rate(params)
    mock_client.execute_query.assert_awaited_once()
    executed_query = mock_client.execute_query.call_args[0][0]
    assert executed_query == default_rate_with_provider_type_cd

    # Scenario-3: params has only providerspecialtycode and contract_type is D
    params = {"providerspecialtycode": "91017"}
    mock_client.execute_query.reset_mock()
    result = await repo._get_default_rate(params)
    mock_client.execute_query.assert_awaited_once()
    executed_query = mock_client.execute_query.call_args[0][0]
    assert executed_query == default_rate_with_specialty_cd

    # Scenario-4: params has neither providerspecialtycode nor providertype and contract_type is D
    params = {}
    mock_client.execute_query.reset_mock()
    result = await repo._get_default_rate(params)
    mock_client.execute_query.assert_awaited_once()
    executed_query = mock_client.execute_query.call_args[0][0]
    assert executed_query == default_rate
