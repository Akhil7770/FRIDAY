#!/usr/bin/env python3
"""
Tests for the CalculationService class and interface.
"""

import sys
import os
from unittest.mock import Mock

import pytest
from app.services.impl.calculation_service_impl import CalculationServiceImpl
from app.services.calculation_service import (
    CalculationServiceInterface,
)
from tests.services.handlers.test_data import (
    mock_matched_accumulator_individual_oopmax,
    mock_matched_accumulator_family_oopmax,
    MockBenefit,
    MockCoverage,
    assert_insurance_context,
    mock_handle,
)

from app.services.handlers.cost_share_co_pay_handler import CostShareCoPayHandler
from app.schemas.cost_estimator_response import CostEstimatorResponse


@pytest.fixture
def mock_oopmax_copay_handler() -> Mock:
    return Mock()


@pytest.fixture
def mock_co_insurance_handler() -> Mock:
    return Mock()


@pytest.fixture
def cost_share_co_pay_handler_fixture(
    mock_oopmax_copay_handler: Mock, mock_co_insurance_handler: Mock
) -> CostShareCoPayHandler:
    cost_share_co_pay_handler = CostShareCoPayHandler()
    cost_share_co_pay_handler.set_oopmax_copay_handler(mock_oopmax_copay_handler)
    cost_share_co_pay_handler.set_deductible_co_insurance_handler(
        mock_co_insurance_handler
    )
    return cost_share_co_pay_handler


# Add the project root to Python path
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, project_root)


class TestCalculationService:
    """Test the CalculationService implementation"""

    def setup_method(self):
        """Set up test fixtures"""
        self.calculation_service = CalculationServiceImpl()

    def test_calculation_service_implements_interface(self):
        """Test that CalculationService implements the interface"""
        assert isinstance(self.calculation_service, CalculationServiceInterface)

    def test_calculation_service_has_chain(self):
        """Test that CalculationService has a calculation chain"""
        assert hasattr(self.calculation_service, "chain")
        assert self.calculation_service.chain is not None

    def test_ind_find_highest_member_pay_copay_greater_than_service_amount_lesser_than_oopmax(
        self,
        cost_share_co_pay_handler_fixture: CostShareCoPayHandler,
        mock_oopmax_copay_handler: Mock,
        mock_co_insurance_handler: Mock,
    ):  # revisit later
        """Test find_highest_member_pay with benefit that has OOP max > service amount and copay > service amount"""
        # Create a benefit with OOP max accumulator

        service_amount = 200
        # Create accumulator for testing
        matched_accum = mock_matched_accumulator_individual_oopmax(calculatedValue=500)

        insurance_context = mock_handle(
            handler=cost_share_co_pay_handler_fixture,
            service_amount=service_amount,
            mock_benefit=MockBenefit(
                benefitName="Test benefit with OOP max", benefitCode=1001
            ),
            mock_coverage=MockCoverage(
                benefitDescription="Test benefit with OOP max", costShareCopay=300.0
            ),
            matched_accumulators=[matched_accum],
        )
        assert_insurance_context(
            insurance_context=insurance_context,
            service_amount=service_amount,
            expected_values={
                "service_amount": 0,  # Handler processed the full service amount
                "member_pays": 200,  # Member pays the full amount
                "amount_copay": 0,  # No copay applied yet
                "calculation_complete": True,  # Handler completed processing
            },
            show=True,
        )

        # Assert that the handler processed the request and updated the insurance context
        # This verifies that _apply_member_pays_service_amount or similar logic was executed
        assert (
            insurance_context.member_pays >= 0
        ), "Expected handler to process the request and update member_pays"
        assert (
            insurance_context.amount_copay >= 0
        ), "Expected handler to process the request and update amount_copay"

        # Verify the handler chain worked correctly by checking if the context was modified
        assert (
            insurance_context.calculation_complete or insurance_context.member_pays > 0
        ), "Expected handler to process the request and complete calculation or update member_pays"

        mock_oopmax_copay_handler.handle.assert_not_called()
        mock_co_insurance_handler.handle.assert_not_called()

        print("Test completed successfully. Insurance context processed by handler.")

    def test_find_highest_member_pay_copay_greater_than_service_amount_lesser_than_oopmax(
        self,
        cost_share_co_pay_handler_fixture: CostShareCoPayHandler,
        mock_oopmax_copay_handler: Mock,
        mock_co_insurance_handler: Mock,
    ):  # revisit later
        """Test find_highest_member_pay with benefit that has OOP max > service amount and copay > service amount"""
        # Create a benefit with OOP max accumulator

        service_amount = 200
        # Create accumulator for testing
        matched_accum = mock_matched_accumulator_individual_oopmax(calculatedValue=500)
        matched_accum2 = mock_matched_accumulator_family_oopmax(calculatedValue=1000)

        insurance_context = mock_handle(
            handler=cost_share_co_pay_handler_fixture,
            service_amount=service_amount,
            mock_benefit=MockBenefit(
                benefitName="Test benefit with OOP max", benefitCode=1001
            ),
            mock_coverage=MockCoverage(
                benefitDescription="Test benefit with OOP max", costShareCopay=300.0
            ),
            matched_accumulators=[matched_accum, matched_accum2],
        )
        assert_insurance_context(
            insurance_context=insurance_context,
            service_amount=service_amount,
            expected_values={
                "service_amount": 0,  # Handler processed the full service amount
                "member_pays": 200,  # Member pays the full amount
                "amount_copay": 0,  # No copay applied yet
                "oopmax_individual_calculated": 300,  # OOP max individual should be 300
                "oopmax_family_calculated": 800,  # OOP max family should be 800
                "calculation_complete": True,  # Handler completed processing
            },
            show=True,
        )

        # Assert that the handler processed the request and updated the insurance context
        # This verifies that _apply_member_pays_service_amount or similar logic was executed
        assert (
            insurance_context.member_pays >= 0
        ), "Expected handler to process the request and update member_pays"
        assert (
            insurance_context.amount_copay >= 0
        ), "Expected handler to process the request and update amount_copay"

        # Verify the handler chain worked correctly by checking if the context was modified
        assert (
            insurance_context.calculation_complete or insurance_context.member_pays > 0
        ), "Expected handler to process the request and complete calculation or update member_pays"

        mock_oopmax_copay_handler.handle.assert_not_called()
        mock_co_insurance_handler.handle.assert_not_called()

        print("Test completed successfully. Insurance context processed by handler.")

    def test_find_highest_member_pay_copay_greater_than_service_amount_greater_than_oopmax(
        self,
        cost_share_co_pay_handler_fixture: CostShareCoPayHandler,
        mock_oopmax_copay_handler: Mock,
        mock_co_insurance_handler: Mock,
    ):  # revisit later
        """Test find_highest_member_pay with benefit that has OOP max < service amount and copay > service amount"""
        # Create a benefit with OOP max accumulator

        service_amount = 200
        # Create accumulator for testing
        matched_accum = mock_matched_accumulator_individual_oopmax(calculatedValue=50)
        matched_accum2 = mock_matched_accumulator_family_oopmax(calculatedValue=100)

        insurance_context = mock_handle(
            handler=cost_share_co_pay_handler_fixture,
            service_amount=service_amount,
            mock_benefit=MockBenefit(
                benefitName="Test benefit with OOP max", benefitCode=1001
            ),
            mock_coverage=MockCoverage(
                benefitDescription="Test benefit with OOP max", costShareCopay=300.0,copayContinueWhenOutOfPocketMaxMetIndicator="Y"
            ),
            matched_accumulators=[matched_accum, matched_accum2],
        )
        assert_insurance_context(
            insurance_context=insurance_context,
            service_amount=service_amount,
            expected_values={
                "service_amount": 150,  # Handler processed part of the service amount (200 - 50 OOP max)
                "member_pays": 50,  # Member pays the OOP max amount
                "amount_copay": 50,  # OOP max applied as copay
                "cost_share_copay": 250,  # Cost share copay should be 250
                "oopmax_individual_calculated": 0,  # OOP max individual should be 0
                "oopmax_family_calculated": 50,  # OOP max family should be 50
            },
            show=True,
        )

        # Assert that the handler processed the request and updated the insurance context
        # This verifies that _apply_member_pays_full_amount or similar logic was executed
        assert (
            insurance_context.member_pays >= 0
        ), "Expected handler to process the request and update member_pays"
        assert (
            insurance_context.amount_copay >= 0
        ), "Expected handler to process the request and update amount_copay"

        # Verify the handler chain worked correctly by checking if the context was modified
        assert (
            insurance_context.calculation_complete or insurance_context.member_pays > 0
        ), "Expected handler to process the request and complete calculation or update member_pays"

        mock_oopmax_copay_handler.handle.assert_called()
        mock_co_insurance_handler.handle.assert_not_called()

        print("Test completed successfully. Insurance context processed by handler.")

    def test_find_highest_member_pay_copay_lesser_than_service_amount_copay_lesser_than_oopmax(
        self,
        cost_share_co_pay_handler_fixture: CostShareCoPayHandler,
        mock_oopmax_copay_handler: Mock,
        mock_co_insurance_handler: Mock,
    ):  # revisit later
        """Test find_highest_member_pay with benefit that has OOP max > copay and copay < service amount"""
        # Create a benefit with OOP max accumulator

        service_amount = 200
        # Create accumulator for testing
        matched_accum = mock_matched_accumulator_individual_oopmax(calculatedValue=500)
        matched_accum2 = mock_matched_accumulator_family_oopmax(calculatedValue=1000)

        insurance_context = mock_handle(
            handler=cost_share_co_pay_handler_fixture,
            service_amount=service_amount,
            mock_benefit=MockBenefit(
                benefitName="Test benefit with OOP max", benefitCode=1001
            ),
            mock_coverage=MockCoverage(
                benefitDescription="Test benefit with OOP max", costShareCopay=100.0
            ),
            matched_accumulators=[matched_accum, matched_accum2],
        )
        assert_insurance_context(
            insurance_context=insurance_context,
            service_amount=service_amount,
            expected_values={
                "service_amount": 100,  # Handler does NOT modify service_amount in this path
                "member_pays": 100,     # Member pays the copay amount
                "amount_copay": 100,    # Copay amount applied
                "cost_share_copay": 0, # Cost share copay should be 0
                "oopmax_individual_calculated": 400, # OOP max individual should be 400
                "oopmax_family_calculated": 900 # OOP max family should be 900
            },
            show=True,
        )

        # Assert that the handler processed the request and updated the insurance context
        # This verifies that _apply_member_pays_cost_share_copay or similar logic was executed
        assert (
            insurance_context.member_pays >= 0
        ), "Expected handler to process the request and update member_pays"
        assert (
            insurance_context.amount_copay >= 0
        ), "Expected handler to process the request and update amount_copay"

        # Verify the handler chain worked correctly by checking if the context was modified
        assert (
            insurance_context.calculation_complete or insurance_context.member_pays > 0
        ), "Expected handler to process the request and complete calculation or update member_pays"

        mock_oopmax_copay_handler.handle.assert_not_called()
        mock_co_insurance_handler.handle.assert_called_once()

        print("Test completed successfully. Insurance context processed by handler.")

    def test_find_highest_member_pay_copay_lesser_than_service_amount_and_copay_greater_than_oopmax(
        self,
        cost_share_co_pay_handler_fixture: CostShareCoPayHandler,
        mock_oopmax_copay_handler: Mock,
        mock_co_insurance_handler: Mock,
    ):  # revisit later
        """Test find_highest_member_pay with benefit that has OOP max < copay and copay < service amount"""
        # Create a benefit with OOP max accumulator

        service_amount = 200
        # Create accumulator for testing
        matched_accum = mock_matched_accumulator_individual_oopmax(calculatedValue=50)
        matched_accum2 = mock_matched_accumulator_family_oopmax(calculatedValue=100)

        insurance_context = mock_handle(
            handler=cost_share_co_pay_handler_fixture,
            service_amount=service_amount,
            mock_benefit=MockBenefit(
                benefitName="Test benefit with OOP max", benefitCode=1001
            ),
            mock_coverage=MockCoverage(
                benefitDescription="Test benefit with OOP max", costShareCopay=150.0, copayContinueWhenOutOfPocketMaxMetIndicator="N"
            ),
            matched_accumulators=[matched_accum, matched_accum2],
        )
        assert_insurance_context(
            insurance_context=insurance_context,
            service_amount=service_amount,
            expected_values={
                "service_amount": 150,  # Handler processed part of the service amount
                "member_pays": 50,  # Member pays the oopmax amount
                "amount_copay": 50,  # OOP max applied as copay
                "cost_share_copay": 100,  # Cost share copay should be 100
                "oopmax_individual_calculated": 0,  # OOP max individual should be 0
                "oopmax_family_calculated": 50,  # OOP max family should be 50
            },
            show=True,
        )

        # Assert that the handler processed the request and updated the insurance context
        # This verifies that _apply_member_pays_cost_share_amount or similar logic was executed
        assert (
            insurance_context.member_pays >= 0
        ), "Expected handler to process the request and update member_pays"
        assert (
            insurance_context.amount_copay >= 0
        ), "Expected handler to process the request and update amount_copay"

        # Verify the handler chain worked correctly by checking if the context was modified
        assert (
            insurance_context.calculation_complete or insurance_context.member_pays > 0
        ), "Expected handler to process the request and complete calculation or update member_pays"

        mock_oopmax_copay_handler.handle.assert_not_called()
        mock_co_insurance_handler.handle.assert_not_called()

        print("Test completed successfully. Insurance context processed by handler.")
