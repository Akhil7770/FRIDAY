import http from 'k6/http';
import { check, sleep } from 'k6';
import { Rate, Trend } from 'k6/metrics';

// Custom metrics
export const errorRate = new Rate('errors');
export const responseTime = new Trend('response_time');

// Test configuration
export const options = {
  stages: [
    { duration: '1m', target: 100 }//,   // Ramp up to 100 users over 1 minute
    // { duration: '5m', target: 100 },    // Stay at 100 users for 5 minutes
    // { duration: '2m', target: 500 },   // Ramp up to 500 users over 2 minutes
    // { duration: '3m', target: 500 },    // Stay at 500 users for 3 minutes
    // { duration: '2m', target: 0 },   // Ramp down to 0 users over 2 minutes
  ],
  thresholds: {
    http_req_duration: ['p(90)<15000'], // 90% of requests must complete below 15s (more lenient)
    http_req_failed: ['rate<0.5'],     // Error rate must be below 50% (more lenient)
    errors: ['rate<0.5'],              // Custom error rate must be below 50%
  },
};

// Test data
const BASE_URL = __ENV.BASE_URL || 'https://cost-estimator-calc-service.hcb-dev.aig.aetna.com/costestimator/v1';
const JWT_TOKEN = __ENV.JWT_TOKEN || ''; // JWT not required for this service

// Sample test data for cost estimation requests
const SAMPLE_REQUESTS = [
  {
    "membershipId": "5~265639891+19+102+20250101+798547+J+10",
    "zipCode": "",
    "benefitProductType": "Medical",
    "languageCode": "11",
    "service": {
      "code": "87530",
      "type": "CPT4",
      "description": "",
      "supportingService": {
        "code": "",
        "type": ""
      },
      "modifier": {
        "modifierCode": ""
      },
      "diagnosisCode": "",
      "placeOfService": {
        "code": "81"
      }
    },
    "providerInfo": [
      {
        "serviceLocation": "6103770",
        "providerType": "LB",
        "speciality": {
          "code": ""
        },
        "taxIdentificationNumber": "",
        "taxIdQualifier": "",
        "providerNetworks": {
          "networkID": "04494"
        },
        "providerIdentificationNumber": "5063559",
        "nationalProviderId": "",
        "providerNetworkParticipation": {
          "providerTier": "1"
        }
      },
      {
        "serviceLocation": "8944757",
        "providerType": "LB",
        "speciality": {
          "code": ""
        },
        "taxIdentificationNumber": "",
        "taxIdQualifier": "",
        "providerNetworks": {
          "networkID": "12818"
        },
        "providerIdentificationNumber": "9752378",
        "nationalProviderId": "",
        "providerNetworkParticipation": {
          "providerTier": "1"
        }
      },
      {
        "serviceLocation": "9726537",
        "providerType": "LB",
        "speciality": {
          "code": ""
        },
        "taxIdentificationNumber": "",
        "taxIdQualifier": "",
        "providerNetworks": {
          "networkID": "01352"
        },
        "providerIdentificationNumber": "8453190",
        "nationalProviderId": "",
        "providerNetworkParticipation": {
          "providerTier": "1"
        }
      }
    ]
  },
  {
    "membershipId": "5~265644547+24+2+20250101+791273+EA+501",
    "zipCode": "",
    "benefitProductType": "Medical",
    "languageCode": "11",
    "service": {
      "code": "77300",
      "type": "CPT4",
      "description": "",
      "supportingService": {
        "code": "",
        "type": ""
      },
      "modifier": {
        "modifierCode": ""
      },
      "diagnosisCode": "",
      "placeOfService": {
        "code": "22"
      }
    },
    "providerInfo": [
      {
        "serviceLocation": "4315233",
        "providerType": "PH",
        "speciality": {
          "code": ""
        },
        "taxIdentificationNumber": "",
        "taxIdQualifier": "",
        "providerNetworks": {
          "networkID": "09613"
        },
        "providerIdentificationNumber": "4414062",
        "nationalProviderId": "",
        "providerNetworkParticipation": {
          "providerTier": "1"
        }
      },
      {
        "serviceLocation": "29217",
        "providerType": "PH",
        "speciality": {
          "code": ""
        },
        "taxIdentificationNumber": "",
        "taxIdQualifier": "",
        "providerNetworks": {
          "networkID": "00024"
        },
        "providerIdentificationNumber": "9016063",
        "nationalProviderId": "",
        "providerNetworkParticipation": {
          "providerTier": "1"
        }
      },
      {
        "serviceLocation": "2442195",
        "providerType": "PH",
        "speciality": {
          "code": ""
        },
        "taxIdentificationNumber": "",
        "taxIdQualifier": "",
        "providerNetworks": {
          "networkID": "09737"
        },
        "providerIdentificationNumber": "9594085",
        "nationalProviderId": "",
        "providerNetworkParticipation": {
          "providerTier": "1"
        }
      }
    ]
  },
  {
    "membershipId": "5~265642220+12+2+20250101+782215+CB+302",
    "zipCode": "",
    "benefitProductType": "Medical",
    "languageCode": "11",
    "service": {
      "code": "20551",
      "type": "CPT4",
      "description": "",
      "supportingService": {
        "code": "",
        "type": ""
      },
      "modifier": {
        "modifierCode": ""
      },
      "diagnosisCode": "",
      "placeOfService": {
        "code": "11"
      }
    },
    "providerInfo": [
      {
        "serviceLocation": "860897",
        "providerType": "PH",
        "speciality": {
          "code": ""
        },
        "taxIdentificationNumber": "",
        "taxIdQualifier": "",
        "providerNetworks": {
          "networkID": "01465"
        },
        "providerIdentificationNumber": "6012619",
        "nationalProviderId": "",
        "providerNetworkParticipation": {
          "providerTier": ""
        }
      },
      {
        "serviceLocation": "6473373",
        "providerType": "PH",
        "speciality": {
          "code": ""
        },
        "taxIdentificationNumber": "",
        "taxIdQualifier": "",
        "providerNetworks": {
          "networkID": "00224"
        },
        "providerIdentificationNumber": "7939330",
        "nationalProviderId": "",
        "providerNetworkParticipation": {
          "providerTier": ""
        }
      },
      {
        "serviceLocation": "9112115",
        "providerType": "PH",
        "speciality": {
          "code": ""
        },
        "taxIdentificationNumber": "",
        "taxIdQualifier": "",
        "providerNetworks": {
          "networkID": "12426"
        },
        "providerIdentificationNumber": "9806622",
        "nationalProviderId": "",
        "providerNetworkParticipation": {
          "providerTier": ""
        }
      }
    ]
  }
];

// Helper function to get random request data
function getRandomRequestData() {
  return SAMPLE_REQUESTS[Math.floor(Math.random() * SAMPLE_REQUESTS.length)];
}

// Helper function to generate request ID
function generateRequestId() {
  return `k6_test_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

// Helper function to create unique member ID
function generateMemberId() {
  return `test-member-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`;
}

// Helper function to generate service code
function generateServiceCode() {
  return `${Date.now()}${Math.random().toString(36).substr(2, 6)}`;
}

// Helper function to generate place of service
function generatePlaceOfService() {
  return `${Date.now()}${Math.random().toString(36).substr(2, 6)}`;
}

// Helper function to generate provider type
function generateProviderType() {
  return `${Date.now()}${Math.random().toString(36).substr(2, 6)}`;
}

// Setup function - runs once before all VUs
export function setup() {
  console.log('Starting k6 tests for Cost Estimator Calc Service API');
  console.log(`Base URL: ${BASE_URL}`);
  console.log('Note: This service does not require JWT authentication');
  return { baseUrl: BASE_URL };
}

// Test 1: Health Check
function testHealthCheck(baseUrl) {
  const response = http.get(`${baseUrl}/health`);
  
  const statusOk = response.status === 200;
  const responseTimeOk = response.timings.duration < 2000; // More lenient timing
  let contentOk = false;
  
  try {
    const body = JSON.parse(response.body);
    contentOk = body.health === 'ok';
  } catch (e) {
    contentOk = false;
  }
  
  const success = statusOk && responseTimeOk && contentOk;
  
  const checksResult = check(response, {
    'health check status is 200': (r) => r.status === 200,
    'health check response time < 2000ms': (r) => r.timings.duration < 2000,
    'health check has correct content': (r) => {
      try {
        const body = JSON.parse(r.body);
        return body.health === 'ok';
      } catch (e) {
        return false;
      }
    }
  });
  
  if (!success) {
    console.error(`Health check FAILED - Status: ${response.status}, Time: ${response.timings.duration}ms, Content: ${contentOk ? 'OK' : 'FAILED'} - ${response.body}`);
  } else {
    console.log(`Health check PASSED: ${response.timings.duration}ms`);
  }
  
  errorRate.add(!success);
  responseTime.add(response.timings.duration);
}

// Test 2: Cost Estimation - Valid Request
function testCostEstimationValid(baseUrl) {
  const requestData = JSON.parse(JSON.stringify(getRandomRequestData()));
  const requestId = generateRequestId();
  
  console.log(`Testing Cost Estimation for Member: ${requestData.membershipId}`);
  console.log(`Testing Service Code: ${requestData.service.code}`);
  
  const headers = {
    'Content-Type': 'application/json',
    'x-global-transaction-id': requestId,
    'x-clientrefid': 'k6-load-test',
  };
  
  const response = http.post(`${baseUrl}/rate`, JSON.stringify(requestData), {
    headers: headers,
  });
  
  const success = check(response, {
    'cost estimation status is 200': (r) => r.status === 200,
    'cost estimation response time < 3000ms': (r) => r.timings.duration < 3000,
    'cost estimation has response structure': (r) => {
      try {
        const body = JSON.parse(r.body);
        return body.hasOwnProperty('costEstimateResponse');
      } catch (e) {
        return false;
      }
    },
    'cost estimation has service info': (r) => {
      try {
        const body = JSON.parse(r.body);
        return body.costEstimateResponse && body.costEstimateResponse.hasOwnProperty('service');
      } catch (e) {
        return false;
      }
    },
    'cost estimation has response info array': (r) => {
      try {
        const body = JSON.parse(r.body);
        return body.costEstimateResponse && 
               body.costEstimateResponse.hasOwnProperty('costEstimateResponseInfo') &&
               Array.isArray(body.costEstimateResponse.costEstimateResponseInfo);
      } catch (e) {
        return false;
      }
    }
  });
  
  if (!success) {
    const responseTime = response.timings.duration;
    const status = response.status;
    
    if (status === 200) {
      console.error(`Cost estimation API working but SLOW for Member ${requestData.membershipId}: ${responseTime}ms (should be <3000ms)`);
    } else {
      console.error(`Cost estimation API ERROR for Member ${requestData.membershipId}: ${status} - ${response.body}`);
    }
  } else {
    console.log(`Cost estimation test PASSED for Member ${requestData.membershipId}: ${response.timings.duration}ms`);
    
    // Log the actual response to see rates
    try {
      const responseBody = JSON.parse(response.body);
      if (responseBody.costEstimateResponse && responseBody.costEstimateResponse.costEstimateResponseInfo) {
        responseBody.costEstimateResponse.costEstimateResponseInfo.forEach((info, index) => {
          if (info.cost) {
            console.log(`Provider ${index + 1} - In-Network Cost: $${info.cost.inNetworkCosts} (${info.cost.inNetworkCostsType})`);
            if (info.healthClaimLine) {
              console.log(`  - Member Responsibility: $${info.healthClaimLine.amountResponsibility}`);
              console.log(`  - Copay: $${info.healthClaimLine.amountCopay}`);
              console.log(`  - Coinsurance: $${info.healthClaimLine.amountCoinsurance}`);
              console.log(`  - Amount Payable: $${info.healthClaimLine.amountpayable}`);
            }
          }
        });
      }
    } catch (e) {
      console.log(`Response parsing error: ${e.message}`);
    }
  }
  
  errorRate.add(!success);
  responseTime.add(response.timings.duration);
}

// Test 3: Cost Estimation - Invalid Request (Missing Fields)
function testCostEstimationInvalid(baseUrl) {
  const requestId = generateRequestId();
  
  // Create invalid request with missing required fields
  const invalidRequest = {
    "membershipId": "",  // Empty membership ID
    "zipCode": "12345",
    "benefitProductType": "Medical",
    "languageCode": "en"
    // Missing service and providerInfo fields
  };
  
  const headers = {
    'Content-Type': 'application/json',
    'x-global-transaction-id': requestId,
    'x-clientrefid': 'k6-load-test',
  };
  
  const response = http.post(`${baseUrl}/rate`, JSON.stringify(invalidRequest), {
    headers: headers,
  });

  const success = check(response, {
    'invalid request returns error status': (r) => r.status === 400 || r.status === 422,
    'invalid request response time < 2000ms': (r) => r.timings.duration < 2000,
    'invalid request has error detail': (r) => {
      try {
        const body = JSON.parse(r.body);
        return body.hasOwnProperty('detail') || body.hasOwnProperty('message') || body.hasOwnProperty('error');
      } catch (e) {
        return false;
      }
    }
  });
  
  if (!success) {
    console.error(`Cost estimation API ERROR for invalid request: ${response.status} - ${response.body}`);
  } else {
    console.log(`Cost estimation invalid request test PASSED: ${response.timings.duration}ms`);
  }
  
  errorRate.add(!success);
  responseTime.add(response.timings.duration);
}

// Test 4: Cost Estimation - Basic Headers Only
function testCostEstimationNoAuth(baseUrl) {
  const requestData = JSON.parse(JSON.stringify(getRandomRequestData()));
  
  const headers = {
    'Content-Type': 'application/json',
    'x-global-transaction-id': generateRequestId(),
  };
  
  const response = http.post(`${baseUrl}/rate`, JSON.stringify(requestData), {
    headers: headers,
  });
  
  const success = check(response, {
    'basic headers request succeeds': (r) => r.status === 200,
    'basic headers response time < 3000ms': (r) => r.timings.duration < 3000,
    'basic headers has valid response': (r) => {
      try {
        const body = JSON.parse(r.body);
        return body.hasOwnProperty('costEstimateResponse');
      } catch (e) {
        return false;
      }
    }
  });
  
  if (!success) {
    console.error(`Cost estimation basic headers test ERROR: ${response.status} - ${response.body}`);
  } else {
    console.log(`Cost estimation basic headers test PASSED: ${response.timings.duration}ms`);
  }
  
  errorRate.add(!success);
  responseTime.add(response.timings.duration);
}

// Test 5: Cost Estimation - With Additional Headers
function testCostEstimationWithAllHeaders(baseUrl) {
  const requestData = JSON.parse(JSON.stringify(getRandomRequestData()));
  const requestId = generateRequestId();
  
  const headers = {
    'Content-Type': 'application/json',
    'x-global-transaction-id': requestId,
    'x-clientrefid': 'k6-load-test',
    'eieheaderaction': 'cost-estimation',
    'eieheaderapplicationidentifier': 'k6-test-app',
    'eieheaderversion': '1.0',
  };
  
  const response = http.post(`${baseUrl}/rate`, JSON.stringify(requestData), {
    headers: headers,
  });
  
  const success = check(response, {
    'cost estimation with headers status is 200': (r) => r.status === 200,
    'cost estimation with headers response time < 3000ms': (r) => r.timings.duration < 3000,
    'cost estimation with headers has correct response': (r) => {
      try {
        const body = JSON.parse(r.body);
        return body.hasOwnProperty('costEstimateResponse');
      } catch (e) {
        return false;
      }
    }
  });
  
  if (!success) {
    console.error(`Cost estimation with headers test ERROR: ${response.status} - ${response.body}`);
  } else {
    console.log(`Cost estimation with headers test PASSED: ${response.timings.duration}ms`);
  }
  
  errorRate.add(!success);
  responseTime.add(response.timings.duration);
}

// Test 6: Cost Estimation - Minimal Headers
function testCostEstimationMinimalHeaders(baseUrl) {
  const requestData = JSON.parse(JSON.stringify(getRandomRequestData()));
  
  // Test with minimal headers - just Content-Type
  const headers = {
    'Content-Type': 'application/json',
  };

  const response = http.post(`${baseUrl}/rate`, JSON.stringify(requestData), {
    headers: headers,
  });
  
  const success = check(response, {
    'minimal headers request succeeds': (r) => r.status === 200,
    'minimal headers response time < 3000ms': (r) => r.timings.duration < 3000,
    'minimal headers has valid response': (r) => {
      try {
        const body = JSON.parse(r.body);
        return body.hasOwnProperty('costEstimateResponse');
      } catch (e) {
        return false;
      }
    }
  });
  
  if (!success) {
    console.error(`Cost estimation minimal headers test ERROR: ${response.status} - ${response.body}`);
  } else {
    console.log(`Cost estimation minimal headers test PASSED: ${response.timings.duration}ms`);
  }
  
  errorRate.add(!success);
  responseTime.add(response.timings.duration);
}

// Test 7: Cost Estimation - Dynamic Invalid Member ID
function testCostEstimationDynamicInvalid(baseUrl) {
  // Use the generateMemberId function to create a dynamic invalid member ID
  const dynamicInvalidMemberId = generateMemberId();
  
  // Create request with dynamic invalid member ID
  const requestData = {
    "membershipId": dynamicInvalidMemberId,
    "zipCode": "12345",
    "benefitProductType": "Medical",
    "languageCode": "en",
    "service": {
      "code": "99214",
      "type": "CPT4",
      "description": "Office visit",
      "supportingService": {
        "code": "470",
        "type": "DRG"
      },
      "modifier": {
        "modifierCode": "E1"
      },
      "diagnosisCode": "F33 40",
      "placeOfService": {
        "code": "11"
      }
    },
    "providerInfo": [
      {
        "serviceLocation": "123456",
        "providerType": "HO",
        "speciality": {
          "code": "91017"
        },
        "taxIdentificationNumber": "123456789",
        "taxIdQualifier": "SN",
        "providerNetworks": {
          "networkID": "NET001"
        },
        "providerIdentificationNumber": "PROV001",
        "nationalProviderId": "1234567890",
        "providerNetworkParticipation": {
          "providerTier": "1"
        }
      }
    ]
  };

  console.log(`Testing Cost Estimation with Dynamic Invalid Member: ${dynamicInvalidMemberId}`);

  const headers = {
    'Content-Type': 'application/json',
    'x-global-transaction-id': generateRequestId(),
    'x-clientrefid': generateRequestId(),
  };

  const response = http.post(`${baseUrl}/rate`, JSON.stringify(requestData), {
    headers: headers,
  });

  // Checks for dynamic invalid member ID - should return error
  const success = check(response, {
    'dynamic invalid member returns error': (r) => r.status >= 400,
    'dynamic invalid member response time < 2000ms': (r) => r.timings.duration < 2000,
    'dynamic invalid member has error detail': (r) => {
      try {
        const body = JSON.parse(r.body);
        return body && (body.message || body.detail || body.title);
      } catch (e) {
        return false;
      }
    },
  });

  if (!success) {
    console.error(`Dynamic invalid member test ERROR: Expected error but got ${response.status} - ${response.body}`);
  } else {
    console.log(`Dynamic invalid member test PASSED: ${response.timings.duration}ms (Member: ${dynamicInvalidMemberId})`);
  }
  
  errorRate.add(!success);
  responseTime.add(response.timings.duration);
}

// Test 8: Cost Estimation - Dynamic Invalid Service Code and Place Of Service
function testCostEstimationDynamicInvalidServiceCode(baseUrl) {
  // Use the generateServiceCode function to create a dynamic invalid service code and place of service
  const dynamicInvalidServiceCode = generateServiceCode();
  const dynamicInvalidPlaceOfService = generatePlaceOfService();
  
   // Create request with dynamic invalid service code and place of service
   const requestData = {
     "membershipId": "test-member-service-validation",
     "zipCode": "12345",
    "benefitProductType": "Medical",
    "languageCode": "en",
    "service": {
      "code": dynamicInvalidServiceCode,
      "type": "CPT4",
      "description": "Office visit",
      "supportingService": {
        "code": "470",
        "type": "DRG"
      },
      "modifier": {
        "modifierCode": "E1"
      },
      "diagnosisCode": "F33 40",
      "placeOfService": {
        "code": dynamicInvalidPlaceOfService
      }
    },
    "providerInfo": [
      {
        "serviceLocation": "123456",
        "providerType": "HO",
        "speciality": {
          "code": "91017"
        },
        "taxIdentificationNumber": "123456789",
        "taxIdQualifier": "SN",
        "providerNetworks": {
          "networkID": "NET001"
        },
        "providerIdentificationNumber": "PROV001",
        "nationalProviderId": "1234567890",
        "providerNetworkParticipation": {
          "providerTier": "1"
        }
      }
    ]
  };

  console.log(`Testing Cost Estimation with Dynamic Invalid Service Code: ${dynamicInvalidServiceCode}`);
  console.log(`Testing Cost Estimation with Dynamic Invalid Place Of Service: ${dynamicInvalidPlaceOfService}`);

  const headers = {
    'Content-Type': 'application/json',
    'x-global-transaction-id': generateRequestId(),
    'x-clientrefid': generateRequestId(),
  };

  const response = http.post(`${baseUrl}/rate`, JSON.stringify(requestData), {
    headers: headers,
  });

  // Checks for dynamic invalid service code and place of service - should return error
  const success = check(response, {
    'dynamic invalid service code returns error': (r) => r.status >= 400,
    'dynamic invalid service code response time < 2000ms': (r) => r.timings.duration < 2000,
    'dynamic invalid service code has error detail': (r) => {
      try {
        const body = JSON.parse(r.body);
        return body && (body.message || body.detail || body.title);
      } catch (e) {
        return false;
      }
    },
  });
  console.log(`Dynamic invalid service code and place of service test response: ${response.body}`);
  if (!success) {
    console.error(`Dynamic invalid service code and place of service test ERROR: Expected error but got ${response.status} - ${response.body}`);
  } else {
    console.log(`Dynamic invalid service code and place of service test PASSED: ${response.timings.duration}ms (Service Code: ${dynamicInvalidServiceCode}) (Place Of Service: ${dynamicInvalidPlaceOfService})`);
  }
  
  errorRate.add(!success);
  responseTime.add(response.timings.duration);
}

// Test 9: Cost Estimation - Dynamic Invalid Provider Type
function testCostEstimationDynamicInvalidProviderType(baseUrl) {
  // Use the generateProviderType function to create a dynamic invalid provider type
  const dynamicInvalidProviderType = generateProviderType();
  
  // Create request with dynamic invalid provider type
  const requestData = {
    "membershipId": "test-member-provider-type-validation",
    "zipCode": "12345",
    "benefitProductType": "Medical",
    "languageCode": "en",
    "service": {
      "code": "99214",
      "type": "CPT4",
      "description": "Office visit",
      "supportingService": {
        "code": "470",
        "type": "DRG"
      },
      "modifier": {
        "modifierCode": "E1"
      },
      "diagnosisCode": "F33 40",
      "placeOfService": {
        "code": "11"
      }
    },
    "providerInfo": [
      {
        "serviceLocation": "123456",
        "providerType": dynamicInvalidProviderType,
        "speciality": {
          "code": "91017"
        },
        "taxIdentificationNumber": "123456789",
        "taxIdQualifier": "SN",
        "providerNetworks": {
          "networkID": "NET001"
        },
        "providerIdentificationNumber": "PROV001",
        "nationalProviderId": "1234567890",
        "providerNetworkParticipation": {
          "providerTier": "1"
        }
      }
    ]
  };

  console.log(`Testing Cost Estimation with Dynamic Invalid Provider Type: ${dynamicInvalidProviderType}`);

  const headers = {
    'Content-Type': 'application/json',
    'x-global-transaction-id': generateRequestId(),
    'x-clientrefid': generateRequestId(),
  };

  const response = http.post(`${baseUrl}/rate`, JSON.stringify(requestData), {
    headers: headers,
  });

  // Checks for dynamic invalid provider type - should return error
  const success = check(response, {
    'dynamic invalid provider type returns error': (r) => r.status >= 400,
    'dynamic invalid provider type response time < 2000ms': (r) => r.timings.duration < 2000,
    'dynamic invalid provider type has error detail': (r) => {
      try {
        const body = JSON.parse(r.body);
        return body && (body.message || body.detail || body.title);
      } catch (e) {
        return false;
      }
    },
  });

  if (!success) {
    console.error(`Dynamic invalid provider type test ERROR: Expected error but got ${response.status} - ${response.body}`);
  } else {
    console.log(`Dynamic invalid provider type test PASSED: ${response.timings.duration}ms (Provider Type: ${dynamicInvalidProviderType})`);
  }
  
  errorRate.add(!success);
  responseTime.add(response.timings.duration);
}


// Main test function
export default function(data) {
  const { baseUrl } = data;
  
  // Run all tests
  testHealthCheck(baseUrl);
  testCostEstimationValid(baseUrl);
  // testCostEstimationInvalid(baseUrl);
  // testCostEstimationNoAuth(baseUrl);
  // testCostEstimationWithAllHeaders(baseUrl);
  // testCostEstimationMinimalHeaders(baseUrl);
  // testCostEstimationDynamicInvalid(baseUrl);
  // testCostEstimationDynamicInvalidServiceCode(baseUrl);
  // testCostEstimationDynamicInvalidProviderType(baseUrl);
  sleep(1); // Wait 1 second between iterations
}

// Teardown function
export function teardown(data) {
  console.log('k6 tests completed for Cost Estimator Calc Service API');
}
