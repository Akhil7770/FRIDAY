import concurrent.futures
import asyncio
from typing import Optional, Dict
from app.models.rate_criteria import NegotiatedRate
from app.services.cost_estimation_service import CostEstimationServiceInterface
from app.services.impl.benefit_service_impl import BenefitServiceImpl
from app.services.impl.accumulator_service_impl import AccumulatorServiceImpl
from app.services.impl.benefit_accumulator_matcher_service_impl import (
    BenefitAccumulatorMatcherServiceImpl,
)
from app.schemas.cost_estimator_request import CostEstimatorRequest
from app.schemas.cost_estimator_response import (
    CostEstimatorResponse,
    CostEstimateResponseInfo,
)
from app.repository.impl.cost_estimator_repository_impl import (
    CostEstimatorRepositoryImpl,
)
from app.mappers.cost_estimator_mapper import CostEstimatorMapper
from app.core.logger import logger
from app.services.impl.calculation_service_impl import CalculationServiceImpl
from app.core.base import InsuranceContext
from app.exception.exceptions import (
    BenefitsNotFoundException,
)
from app.schemas.accumulator_response import AccumulatorResponse
from app.schemas.benefit_response import BenefitApiResponse
from app.schemas.cost_estimator_request import ProviderInfo
from typing import List, Dict, Union, Optional
from app.schemas.cost_estimator_response import CostEstimateResponseInfoError
from app.exception.exception_handler import benefits_not_found_exception_handler_logic
from app.core.observability.metrics.metrics_decorators import response_time
from app.services.token_service import TokenService


class CostEstimationServiceImpl(CostEstimationServiceInterface):
    def __init__(
        self,
        repository=None,
        matcher_service=None,
        benefit_service=None,
        accumulator_service=None,
        calculation_service=None,
    ):
        self.repository: CostEstimatorRepositoryImpl = (
            repository or CostEstimatorRepositoryImpl()
        )
        self.matcher_service: BenefitAccumulatorMatcherServiceImpl = (
            matcher_service or BenefitAccumulatorMatcherServiceImpl()
        )
        self.benefit_service: BenefitServiceImpl = (
            benefit_service or BenefitServiceImpl()
        )
        self.accumulator_service: AccumulatorServiceImpl = (
            accumulator_service or AccumulatorServiceImpl()
        )
        self.calculation_service: CalculationServiceImpl = (
            calculation_service or CalculationServiceImpl()
        )
        self.token_service = TokenService()

    async def estimate_cost(
        self, request: CostEstimatorRequest, headers: Optional[Dict[str, str]] = None
    ) -> Union[CostEstimatorResponse, dict]:
        benefit_request_list = CostEstimatorMapper.to_benefit_request(request)
        rate_criteria_list = CostEstimatorMapper.to_rate_criteria(request)
        highest_member_pay_context = InsuranceContext()  # start with empty context
        token = await self.token_service.get_token()
        num_providers = len(request.providerInfo)
        gathered_result = await asyncio.gather(
            *[
                self.repository.get_rate(rate_criteria=rate_criteria)
                for rate_criteria in rate_criteria_list
            ],
            *[
                self.benefit_service.get_benefit(
                    benefit_request, token, num_providers == 1
                )
                for benefit_request in benefit_request_list
            ],
            self.accumulator_service.get_accumulator(request, token, headers),
        )
        rate_list: List[NegotiatedRate] = gathered_result[:num_providers]  # type: ignore
        rate_dict: Dict[str, NegotiatedRate] = {
            p.hash(): r for p, r in zip(request.providerInfo, rate_list)
        }

        benefit_response_list: List[Union[BenefitApiResponse, BenefitsNotFoundException]] = gathered_result[num_providers:-1]  # type: ignore
        benefit_response_dict: Dict[
            str, Union[BenefitApiResponse, BenefitsNotFoundException]
        ] = {p.hash(): r for p, r in zip(request.providerInfo, benefit_response_list)}

        accumulator_response: AccumulatorResponse = gathered_result[-1]  # type: ignore

        # Call the pure processing method with decorator
        cost_estimator_response = await self.build_cost_estimator_response(
            request,
            gathered_result,
            rate_criteria_list,
            num_providers,
            benefit_response_dict,
            accumulator_response,
            rate_dict,
            highest_member_pay_context,
        )

        return cost_estimator_response

    @response_time("cost_estimation_service", "build_cost_estimation_response")
    async def build_cost_estimator_response(
        self,
        request: CostEstimatorRequest,
        gathered_result: List,
        rate_criteria_list: List,
        num_providers: int,
        benefit_response_dict: Dict[
            str, Union[BenefitApiResponse, BenefitsNotFoundException]
        ],
        accumulator_response: AccumulatorResponse,
        rate_dict: Dict[str, NegotiatedRate],
        highest_member_pay_context: InsuranceContext,
    ) -> CostEstimatorResponse:
        """
        Process cost estimation data after external services have completed.
        This method contains only the pure processing logic.
        """
        pcp_specialty_codes: List[str] = (
            self.repository.get_cached_pcp_specialty_codes()
        )

        def build_ce_info_list_from_providers_wrapper(provider: ProviderInfo):
            return self.build_ce_info_list_from_providers(
                membershipId=request.membershipId,
                benefit_response_dict=benefit_response_dict,
                accumulator_response=accumulator_response,
                rate_dict=rate_dict,
                isOutofNetwork=rate_criteria_list[0].isOutofNetwork,
                highest_member_pay_context=highest_member_pay_context,
                raise_exception=num_providers == 1,
                pcp_specialty_codes=pcp_specialty_codes,
                provider=provider,
            )

        with concurrent.futures.ThreadPoolExecutor() as executor:
            cost_estimator_info_list = list(
                executor.map(
                    build_ce_info_list_from_providers_wrapper, request.providerInfo
                )
            )

        cost_estimator_info_list = [
            info for info in cost_estimator_info_list if info is not None
        ]
        cost_estimator_response = (
            CostEstimatorResponse.build_cost_estimator_response_from_info_objects(
                request, cost_estimator_info_list
            )
        )

        return cost_estimator_response

    def build_ce_info_list_from_providers(
        self,
        membershipId: str,
        benefit_response_dict: Dict[
            str, Union[BenefitApiResponse, BenefitsNotFoundException]
        ],
        accumulator_response: AccumulatorResponse,
        rate_dict: Dict[str, NegotiatedRate],
        isOutofNetwork: bool,
        highest_member_pay_context: InsuranceContext,
        raise_exception: bool,
        pcp_specialty_codes: List[str],
        provider: ProviderInfo,
    ) -> Optional[Union[CostEstimateResponseInfo, CostEstimateResponseInfoError]]:

        benefit_response = benefit_response_dict[provider.hash()]
        negotiated_rate = rate_dict[provider.hash()]
        highest_member_pay_context_fn = highest_member_pay_context

        if type(benefit_response) is BenefitsNotFoundException:
            cost_estimator_info = CostEstimateResponseInfoError(
                providerInfo=provider,
                exc=benefit_response,
                handler_logic=benefits_not_found_exception_handler_logic,
            )
        else:
            selected_benefits = self.matcher_service.get_selected_benefits(
                membershipId,
                benefit_response,  # type: ignore
                accumulator_response,
                provider,
                isOutofNetwork,
                pcp_specialty_codes,
            )
            logger.info(f"Selected benefits: {selected_benefits}")

            if (
                selected_benefits is not None
                and len(selected_benefits) > 0
                and negotiated_rate.isRateFound
                and negotiated_rate.rateType == "AMOUNT"
            ):

                highest_member_pay_context_fn = (
                    self.calculation_service.find_highest_member_pay(
                        float(negotiated_rate.rate), selected_benefits
                    )
                )

            cost_estimator_info = (
                CostEstimatorResponse.build_cost_estimate_response_info(
                    provider,
                    selected_benefits,
                    highest_member_pay_context_fn,
                    negotiated_rate,
                    raise_exception=raise_exception,
                )
            )  # checks for rate not found, matching benefits not found, ic error

        return cost_estimator_info

    async def load_payment_method_hierarchy(self) -> None:
        await self.repository.load_payment_method_hierarchy()

    async def load_pcp_specialty_codes(self) -> None:
        await self.repository.load_pcp_specialty_codes()

    async def get_rate_only(
        self, request: CostEstimatorRequest
    ) -> List[NegotiatedRate]:
        rate_criteria_list = CostEstimatorMapper.to_rate_criteria(request)
        rates = await asyncio.gather(
            *[
                self.repository.get_rate(rate_criteria=rate_criteria)
                for rate_criteria in rate_criteria_list
            ]
        )
        return rates
