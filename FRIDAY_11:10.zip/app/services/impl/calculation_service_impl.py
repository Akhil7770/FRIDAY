import concurrent.futures
from typing import List
from app.core.base import InsuranceContext
from app.models.selected_benefit import SelectedBenefit
from app.services.calculation_service import (
    CalculationServiceInterface,
)

from app.services.handlers.service_coverage_handler import ServiceCoverageHandler
from app.services.handlers.benefit_limitation_handler import BenefitLimitationHandler
from app.services.handlers.oopmax_handler import OOPMaxHandler
from app.services.handlers.oopmax_co_pay_handler import OOPMaxCopayHandler
from app.services.handlers.deductible_handler import DeductibleHandler
from app.services.handlers.cost_share_co_pay_handler import CostShareCoPayHandler
from app.services.handlers.deductible_cost_share_co_pay import (
    DeductibleCostShareCoPayHandler,
)
from app.services.handlers.deductible_oopmax_handler import DeductibleOOPMaxHandler
from app.services.handlers.deductible_co_pay_handler import DeductibleCoPayHandler
from app.services.handlers.deductible_co_insurance_handler import (
    DeductibleCoInsuranceHandler,
)


class CalculationServiceImpl(CalculationServiceInterface):
    """Implementation of the calculation service that processes insurance benefits"""

    def __init__(self):
        """Initialize the calculation service with a calculation chain"""
        self.chain = self.create_calculation_chain()

    def find_highest_member_pay(
        self, service_amount: float, benefits: List[SelectedBenefit]
    ) -> InsuranceContext:
        """
        Find the insurance context with the highest member pay from a list of benefits.

        Args:
            service_amount: The service amount to calculate for
            benefits: List of benefits to process

        Returns:
            InsuranceContext: The context with the highest member_pays value
        """
        # Create contexts from benefits and calculate for each
        results = []
        contexts = []

        for benefit in benefits:
            try:
                # Cast SelectedBenefit to Benefit since SelectedBenefit inherits from Benefit
                benefit_obj: SelectedBenefit = benefit
                context = InsuranceContext().populate_from_benefit(
                    benefit_obj, service_amount
                )
                contexts.append(context)
            except Exception as e:
                # If there's an error creating contexts, return default context
                return InsuranceContext()

        def handle_context(context):
            try:
                return self.chain.handle(context)
            except Exception:
                # If there's an error processing a context, return the context as-is
                return context

        with concurrent.futures.ThreadPoolExecutor() as executor:
            results = list(executor.map(handle_context, contexts))

        # Find the InsuranceContext with the highest member_pays
        if results:
            highest_member_pay_context = max(
                results, key=lambda ctx: getattr(ctx, "member_pays", 0)
            )
        else:
            highest_member_pay_context = (
                InsuranceContext()
            )  # Return default context instead of None

        return highest_member_pay_context

    def create_calculation_chain(self):
        """Create and connect the chain of handlers with branches based on logic tree"""

        # Create handlers
        coverage_handler = ServiceCoverageHandler()
        benefit_limitation_handler = BenefitLimitationHandler()
        oopmax_handler = OOPMaxHandler()
        oopmax_co_pay_handler = OOPMaxCopayHandler()
        deductible_handler = DeductibleHandler()
        cost_share_co_pay_handler = CostShareCoPayHandler()
        deductible_cost_share_co_pay_handler = DeductibleCostShareCoPayHandler()
        deductible_oopmax_handler = DeductibleOOPMaxHandler()
        deductible_co_pay_handler = DeductibleCoPayHandler()
        deductible_co_insurance_handler = DeductibleCoInsuranceHandler()

        # Setup chain
        coverage_handler.set_next(benefit_limitation_handler)
        benefit_limitation_handler.set_deductible_cost_share_co_handler(
            deductible_cost_share_co_pay_handler
        )
        benefit_limitation_handler.set_oopmax_handler(oopmax_handler)
        benefit_limitation_handler.set_next(oopmax_handler)  # default path

        # Setup branch path for OOPMax Handler
        oopmax_handler.set_deductible_handler(deductible_handler)
        oopmax_handler.set_oopmax_copay_handler(oopmax_co_pay_handler)
        oopmax_handler.set_next(deductible_handler)

        # Setup branch path for Deductible Handler
        deductible_handler.set_deductible_oopmax_handler(deductible_oopmax_handler)
        deductible_handler.set_cost_share_co_pay_handler(cost_share_co_pay_handler)
        deductible_handler.set_deductible_co_pay_handler(deductible_co_pay_handler)
        deductible_handler.set_deductible_cost_share_co_pay_handler(
            deductible_cost_share_co_pay_handler
        )
        deductible_handler.set_next(cost_share_co_pay_handler)

        # Setup branch path for Cost Share Co-pay Handler
        cost_share_co_pay_handler.set_oopmax_copay_handler(oopmax_co_pay_handler)
        cost_share_co_pay_handler.set_deductible_co_insurance_handler(
            deductible_co_insurance_handler
        )

        # Setup branch path for Deductible Co-pay Handler
        deductible_co_pay_handler.set_oopmax_copay_handler(oopmax_co_pay_handler)
        deductible_co_pay_handler.set_deductible_co_insurance_handler(
            deductible_co_insurance_handler
        )
        deductible_co_pay_handler.set_deductible_oopmax_handler(
            deductible_oopmax_handler
        )

        # Setup branch path for Deductible OOPMax Handler
        deductible_oopmax_handler.set_deductible_cost_share_co_pay_handler(
            deductible_cost_share_co_pay_handler
        )
        deductible_oopmax_handler.set_deductible_co_insurance_handler(
            deductible_co_insurance_handler
        )

        # Setup branch path for Deductible Cost Share Co-pay Handler
        deductible_cost_share_co_pay_handler.set_deductible_co_pay_handler(
            deductible_co_pay_handler
        )
        deductible_cost_share_co_pay_handler.set_deductible_co_insurance_handler(
            deductible_co_insurance_handler
        )
        # deductible_cost_share_co_pay_handler.set_next(None)

        # Continue to add the rest of our handlers
        deductible_co_insurance_handler.set_next(deductible_co_insurance_handler)

        return coverage_handler  # Return first handler
