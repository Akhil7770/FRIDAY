import aiohttp
import json
import os
import ssl
from typing import Union, Dict, Any
from tenacity import (
    retry,
    stop_after_attempt,
    wait_exponential,
    retry_if_not_exception_type,
)
from app.core.logger import logger
from app.core.circuitbreaker.circuit_breaker import circuit_breaker
from app.core.observability.metrics.metrics_decorators import response_time
from app.schemas.benefit_request import BenefitRequest
from app.schemas.benefit_response import BenefitApiResponse
from app.services.benefit_service import BenefitServiceInterface
from app.services.token_service import TokenService
from app.exception.exceptions import (
    BenefitsNotFoundException,
    BenefitsMemberNotFoundException,
)
from typing import Optional, Union
from app.core import constants


class BenefitServiceImpl(BenefitServiceInterface):
    """Service implementation for handling benefit-related operations."""

    def __init__(self):
        # Create SSL context that doesn't verify certificates
        self.ssl_context = ssl.create_default_context()
        self.ssl_context.check_hostname = False
        self.ssl_context.verify_mode = ssl.CERT_NONE
        self.token_service = TokenService()

    @circuit_breaker("benefit_service")
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=4, max=10),
        retry=retry_if_not_exception_type(
            (BenefitsNotFoundException, BenefitsMemberNotFoundException, ValueError)
        ),
    )
    @response_time("benefit_api", "get_benefit")
    async def get_benefit(
        self,
        benefit_request: BenefitRequest,
        token: Dict[str, Any],
        raise_exception: Optional[bool] = False,
    ) -> Union[BenefitApiResponse, BenefitsNotFoundException]:
        """
        Optimized and refactored method to get benefit information for the given request.

        Args:
            benefit_request (BenefitRequest): The benefit request object

        Returns:
            BenefitApiResponse: The benefit response data

        Raises:
            BenefitsNotFoundException: If the benefit request fails
        """
        try:
            BENEFITS_URL = os.getenv("BENEFITS_URL")
            if not BENEFITS_URL:
                raise ValueError("BENEFITS_URL environment variable is not set")

            headers_data = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {token['access_token']}",
                "app_name": constants.APP_NAME,
            }

            benefit_request_json = json.loads(benefit_request.model_dump_json())
            logger.info(f"Benefit Request JSON: {benefit_request_json}")

            connector = aiohttp.TCPConnector(ssl=self.ssl_context)
            async with aiohttp.ClientSession(connector=connector) as session:
                async with session.post(
                    url=BENEFITS_URL, json=benefit_request_json, headers=headers_data
                ) as response:
                    response_text = await response.text()

                    if response.status == 400:
                        try:
                            response_json = await response.json()
                            error_msg = (
                                f"Benefit request failed with status 400: "
                                f"{response_json.get('httpMessage', 'Bad Request')} - "
                                f"{response_json.get('moreInformation', 'Invalid request data')}"
                            )
                        except Exception:
                            error_msg = f"Benefit request failed with status 400: {response_text}"
                        logger.error(error_msg)
                        if "ACTIVE MEMBER COVERAGE NOT FOUND" in response_text.upper():
                            raise BenefitsMemberNotFoundException(
                                message=f"Status {response.status}: {error_msg}",
                            )
                        raise BenefitsNotFoundException(
                            message=f"Status {response.status}: {error_msg}",
                            benefit_request=benefit_request.model_dump(),
                        )

                    if response.status == 500:
                        try:
                            response_json = await response.json()
                            error_msg = (
                                f"Benefit service error with status 500: "
                                f"{response_json.get('httpMessage', 'Internal Server Error')} - "
                                f"{response_json.get('moreInformation', 'Service temporarily unavailable')}"
                            )
                        except Exception:
                            error_msg = f"Benefit service error with status 500: {response_text}"
                        logger.error(error_msg)
                        raise BenefitsNotFoundException(
                            message=f"Status {response.status}: {error_msg}",
                            benefit_request=benefit_request.model_dump(),
                        )

                    if response.status != 200:
                        try:
                            response_json = await response.json()
                            error_msg = (
                                f"Benefit request failed with status {response.status}: "
                                f"{response_json.get('httpMessage', 'Request failed')} - "
                                f"{response_json.get('moreInformation', 'Unknown error')}"
                            )
                        except Exception:
                            error_msg = f"Benefit request failed with status {response.status}: {response_text}"
                        logger.error(error_msg)
                        raise BenefitsNotFoundException(
                            message=f"Status {response.status}: {error_msg}",
                            benefit_request=benefit_request.model_dump(),
                        )

                    # Success
                    response_data = await response.json()
                    logger.info(f"Response Data: {response_data}")
                    return BenefitApiResponse(**response_data)

        except BenefitsNotFoundException as e:
            if raise_exception:
                raise e
            return e
        except BenefitsMemberNotFoundException:
            raise
        except Exception as e:
            logger.error(f"Error in get_benefit: {str(e)}")
            raise e
