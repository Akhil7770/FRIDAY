from app.core.base import Handler, InsuranceContext


class DeductibleHandler(Handler):
    """Calculates member costs based on accumulated deductible"""

    def set_deductible_oopmax_handler(self, handler):
        self._deductible_oopmax_handler = handler
        return handler

    def set_cost_share_co_pay_handler(self, handler):
        self._cost_share_co_pay_handler = handler
        return handler

    def set_deductible_cost_share_co_pay_handler(self, handler):
        self._deductible_cost_share_co_pay_handler = handler
        return handler

    def set_deductible_co_pay_handler(self, handler):
        self._deductible_co_pay_handler = handler
        return handler

    def process(self, context: InsuranceContext):
        # Check if deductible accumulators exist - if not, go to cost share
        if "deductible" not in context.accum_code:
            context.trace_decision(
                "Process",
                "No deductible accumulators found - going to cost share copay handler",
                True,
            )
            return self._cost_share_co_pay_handler.handle(context)

        if context.deductible_family_calculated == 0:
            context.trace_decision("Process", "The family deductible is zero", True)
            return self._deductible_cost_share_co_pay_handler.handle(context)

        if (
            context.numOfIndividualsMet is not None
            and context.numOfIndividualsNeededToMeet is not None
            and context.numOfIndividualsMet == context.numOfIndividualsNeededToMeet
        ):
            context.trace_decision("Process", "The family deductible is zero", True)
            return self._deductible_cost_share_co_pay_handler.handle(context)

        if context.deductible_individual_calculated == 0:
            context.trace_decision("Process", "The individual deductible is zero", True)
            return self._deductible_cost_share_co_pay_handler.handle(context)

        if not context.is_deductible_before_copay:
            context.trace_decision("Process", "The deductible is after co-pay", False)
            if context.cost_share_copay > 0:
                return self._deductible_co_pay_handler.handle(context)
            else:
                return self._deductible_oopmax_handler.handle(context)

        else:
            context.trace_decision("Process", "The deductible is before co-pay", False)
            return self._deductible_oopmax_handler.handle(context)
