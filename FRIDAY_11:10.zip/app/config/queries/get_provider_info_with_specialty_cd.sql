SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM CET_PROVIDERS
WHERE
    PROVIDER_IDENTIFICATION_NBR = @provideridentificationnumber
    AND NETWORK_ID = @networkid
    AND SERVICE_LOCATION_NBR = @servicelocationnumber
    AND SPECIALTY_CD = 
    (       SELECT CASE WHEN EXISTS 
                (SELECT 1 
                FROM CET_PROVIDERS 
                WHERE PROVIDER_IDENTIFICATION_NBR = @provideridentificationnumber 
                    AND NETWORK_ID = @networkid 
                    AND SERVICE_LOCATION_NBR = @servicelocationnumber  
                    AND SPECIALTY_CD = @providerspecialtycode
                ) 
                THEN @providerspecialtycode ELSE '' END
    )