
-- Row number: 254

-- OON
SELECT MAX(RATE) AS RATE
FROM CET_OON
WHERE
    SERVICE_CD = "90460"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "11"
    AND ZIP_CODE_UN = "2476";

-- Claim Based
SELECT MAX(RATE) AS RATE
FROM `prv_ps_ce_dec_hcb_dev.CET_CLAIM_BASED_AMOUNTS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 9326579
    AND NETWORK_ID = "00339"
    AND PLACE_OF_SERVICE_CD = "11"
    AND SERVICE_CD = "90460"
    AND SERVICE_TYPE_CD = "CPT4";

-- provider table (if specialty_cd)
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 9326579
    AND NETWORK_ID = "00339"
    AND SERVICE_LOCATION_NBR = 6570038
    AND SPECIALTY_CD = 
    (       SELECT CASE WHEN EXISTS 
                (SELECT 1 
                FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS` 
                WHERE PROVIDER_IDENTIFICATION_NBR = 9326579 
                    AND NETWORK_ID = "00339" 
                    AND SERVICE_LOCATION_NBR = 6570038  
                    AND SPECIALTY_CD = "10401"
                ) 
                THEN "10401" ELSE '' END
    );

-- provider table (if provider_type_cd)
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 9326579
    AND NETWORK_ID = "00339"
    AND SERVICE_LOCATION_NBR = 6570038
    AND PROVIDER_TYPE_CD = "PH";

-- else
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 9326579
    AND NETWORK_ID = "00339"
    AND SERVICE_LOCATION_NBR = 6570038;

-- standard rate 
SELECT Max(RATE) AS RATE
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    RATE_SYSTEM_CD = "N}Toz(Euk"
    AND SERVICE_CD = "90460"
    AND SERVICE_TYPE_CD = "CPT4"
    AND GEOGRAPHIC_AREA_CD = "2476"
    AND PLACE_OF_SERVICE_CD = "11"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND CONTRACT_TYPE = 'S';

-- non standard rate (if specialty_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "90460"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "11"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE IN ('C', 'N')
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "90460"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "11"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE IN ('C', 'N')
                    AND SPECIALTY_CD = "10401"
            )
            THEN "10401"
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- non standard rate (if provider_type_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "90460"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "11"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE IN ('C', 'N')
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "90460"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "11"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE IN ('C', 'N')
                    AND SPECIALTY_CD = "10401"
            )
            THEN "10401"
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- else 
SELECT
  payment_method_cd,
  service_group_changed_ind,
  service_grouping_priority_nbr,
  max(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
  SERVICE_CD = "90460"
  AND SERVICE_TYPE_CD = "CPT4"
  AND PLACE_OF_SERVICE_CD = "11"
  AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
  AND PROVIDER_BUSINESS_GROUP_NBR = 
  AND CONTRACT_TYPE IN ('C', 'N')
GROUP BY payment_method_cd, service_group_changed_ind, service_grouping_priority_nbr;

-- Default rate (if specialty_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "90460"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "11"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE = 'D'
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "90460"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "11"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE = 'D'
                    AND SPECIALTY_CD = "10401"
            )
            THEN "10401"
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- default_rate (if provider_type_cd) 
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "90460"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "11"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE = 'D'
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "90460"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "11"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE = 'D'
                    AND SPECIALTY_CD = "PH"
            )
            THEN "PH"
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- else 
SELECT
  payment_method_cd,
  service_group_changed_ind,
  service_grouping_priority_nbr,
  max(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
  SERVICE_CD = "90460"
  AND SERVICE_TYPE_CD = "CPT4"
  AND PLACE_OF_SERVICE_CD = "11"
  AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
  AND PROVIDER_BUSINESS_GROUP_NBR = 
  AND CONTRACT_TYPE = 'D' 
GROUP BY payment_method_cd, service_group_changed_ind, service_grouping_priority_nbr;


-- Row number: 263

-- OON
SELECT MAX(RATE) AS RATE
FROM CET_OON
WHERE
    SERVICE_CD = "J0665"
    AND SERVICE_TYPE_CD = "HCPC"
    AND PLACE_OF_SERVICE_CD = "22"
    AND ZIP_CODE_UN = "28655";

-- Claim Based
SELECT MAX(RATE) AS RATE
FROM `prv_ps_ce_dec_hcb_dev.CET_CLAIM_BASED_AMOUNTS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 6380595
    AND NETWORK_ID = "00454"
    AND PLACE_OF_SERVICE_CD = "22"
    AND SERVICE_CD = "J0665"
    AND SERVICE_TYPE_CD = "HCPC";

-- provider table (if specialty_cd)
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 6380595
    AND NETWORK_ID = "00454"
    AND SERVICE_LOCATION_NBR = 158015
    AND SPECIALTY_CD = 
    (       SELECT CASE WHEN EXISTS 
                (SELECT 1 
                FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS` 
                WHERE PROVIDER_IDENTIFICATION_NBR = 6380595 
                    AND NETWORK_ID = "00454" 
                    AND SERVICE_LOCATION_NBR = 158015  
                    AND SPECIALTY_CD = ""
                ) 
                THEN "" ELSE '' END
    );

-- provider table (if provider_type_cd)
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 6380595
    AND NETWORK_ID = "00454"
    AND SERVICE_LOCATION_NBR = 158015
    AND PROVIDER_TYPE_CD = "HO";

-- else
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 6380595
    AND NETWORK_ID = "00454"
    AND SERVICE_LOCATION_NBR = 158015;

-- standard rate 
SELECT Max(RATE) AS RATE
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    RATE_SYSTEM_CD = "I/yXFnVF-"
    AND SERVICE_CD = "J0665"
    AND SERVICE_TYPE_CD = "HCPC"
    AND GEOGRAPHIC_AREA_CD = "28655"
    AND PLACE_OF_SERVICE_CD = "22"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND CONTRACT_TYPE = 'S';

-- non standard rate (if specialty_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "J0665"
    AND SERVICE_TYPE_CD = "HCPC"
    AND PLACE_OF_SERVICE_CD = "22"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE IN ('C', 'N')
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "J0665"
                    AND SERVICE_TYPE_CD = "HCPC"
                    AND PLACE_OF_SERVICE_CD = "22"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE IN ('C', 'N')
                    AND SPECIALTY_CD = ""
            )
            THEN ""
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- non standard rate (if provider_type_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "J0665"
    AND SERVICE_TYPE_CD = "HCPC"
    AND PLACE_OF_SERVICE_CD = "22"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE IN ('C', 'N')
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "J0665"
                    AND SERVICE_TYPE_CD = "HCPC"
                    AND PLACE_OF_SERVICE_CD = "22"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE IN ('C', 'N')
                    AND SPECIALTY_CD = ""
            )
            THEN ""
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- else 
SELECT
  payment_method_cd,
  service_group_changed_ind,
  service_grouping_priority_nbr,
  max(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
  SERVICE_CD = "J0665"
  AND SERVICE_TYPE_CD = "HCPC"
  AND PLACE_OF_SERVICE_CD = "22"
  AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
  AND PROVIDER_BUSINESS_GROUP_NBR = 
  AND CONTRACT_TYPE IN ('C', 'N')
GROUP BY payment_method_cd, service_group_changed_ind, service_grouping_priority_nbr;

-- Default rate (if specialty_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "J0665"
    AND SERVICE_TYPE_CD = "HCPC"
    AND PLACE_OF_SERVICE_CD = "22"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE = 'D'
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "J0665"
                    AND SERVICE_TYPE_CD = "HCPC"
                    AND PLACE_OF_SERVICE_CD = "22"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE = 'D'
                    AND SPECIALTY_CD = ""
            )
            THEN ""
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- default_rate (if provider_type_cd) 
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "J0665"
    AND SERVICE_TYPE_CD = "HCPC"
    AND PLACE_OF_SERVICE_CD = "22"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE = 'D'
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "J0665"
                    AND SERVICE_TYPE_CD = "HCPC"
                    AND PLACE_OF_SERVICE_CD = "22"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE = 'D'
                    AND SPECIALTY_CD = "HO"
            )
            THEN "HO"
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- else 
SELECT
  payment_method_cd,
  service_group_changed_ind,
  service_grouping_priority_nbr,
  max(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
  SERVICE_CD = "J0665"
  AND SERVICE_TYPE_CD = "HCPC"
  AND PLACE_OF_SERVICE_CD = "22"
  AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
  AND PROVIDER_BUSINESS_GROUP_NBR = 
  AND CONTRACT_TYPE = 'D' 
GROUP BY payment_method_cd, service_group_changed_ind, service_grouping_priority_nbr;


-- Row number: 280

-- OON
SELECT MAX(RATE) AS RATE
FROM CET_OON
WHERE
    SERVICE_CD = "97112"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "11"
    AND ZIP_CODE_UN = "27614";

-- Claim Based
SELECT MAX(RATE) AS RATE
FROM `prv_ps_ce_dec_hcb_dev.CET_CLAIM_BASED_AMOUNTS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 9772264
    AND NETWORK_ID = "00606"
    AND PLACE_OF_SERVICE_CD = "11"
    AND SERVICE_CD = "97112"
    AND SERVICE_TYPE_CD = "CPT4";

-- provider table (if specialty_cd)
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 9772264
    AND NETWORK_ID = "00606"
    AND SERVICE_LOCATION_NBR = 6876720
    AND SPECIALTY_CD = 
    (       SELECT CASE WHEN EXISTS 
                (SELECT 1 
                FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS` 
                WHERE PROVIDER_IDENTIFICATION_NBR = 9772264 
                    AND NETWORK_ID = "00606" 
                    AND SERVICE_LOCATION_NBR = 6876720  
                    AND SPECIALTY_CD = ""
                ) 
                THEN "" ELSE '' END
    );

-- provider table (if provider_type_cd)
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 9772264
    AND NETWORK_ID = "00606"
    AND SERVICE_LOCATION_NBR = 6876720
    AND PROVIDER_TYPE_CD = "PT";

-- else
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 9772264
    AND NETWORK_ID = "00606"
    AND SERVICE_LOCATION_NBR = 6876720;

-- standard rate 
SELECT Max(RATE) AS RATE
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    RATE_SYSTEM_CD = "dj9w@?+et"
    AND SERVICE_CD = "97112"
    AND SERVICE_TYPE_CD = "CPT4"
    AND GEOGRAPHIC_AREA_CD = "27614"
    AND PLACE_OF_SERVICE_CD = "11"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND CONTRACT_TYPE = 'S';

-- non standard rate (if specialty_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "97112"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "11"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE IN ('C', 'N')
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "97112"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "11"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE IN ('C', 'N')
                    AND SPECIALTY_CD = ""
            )
            THEN ""
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- non standard rate (if provider_type_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "97112"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "11"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE IN ('C', 'N')
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "97112"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "11"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE IN ('C', 'N')
                    AND SPECIALTY_CD = ""
            )
            THEN ""
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- else 
SELECT
  payment_method_cd,
  service_group_changed_ind,
  service_grouping_priority_nbr,
  max(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
  SERVICE_CD = "97112"
  AND SERVICE_TYPE_CD = "CPT4"
  AND PLACE_OF_SERVICE_CD = "11"
  AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
  AND PROVIDER_BUSINESS_GROUP_NBR = 
  AND CONTRACT_TYPE IN ('C', 'N')
GROUP BY payment_method_cd, service_group_changed_ind, service_grouping_priority_nbr;

-- Default rate (if specialty_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "97112"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "11"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE = 'D'
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "97112"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "11"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE = 'D'
                    AND SPECIALTY_CD = ""
            )
            THEN ""
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- default_rate (if provider_type_cd) 
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "97112"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "11"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE = 'D'
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "97112"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "11"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE = 'D'
                    AND SPECIALTY_CD = "PT"
            )
            THEN "PT"
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- else 
SELECT
  payment_method_cd,
  service_group_changed_ind,
  service_grouping_priority_nbr,
  max(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
  SERVICE_CD = "97112"
  AND SERVICE_TYPE_CD = "CPT4"
  AND PLACE_OF_SERVICE_CD = "11"
  AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
  AND PROVIDER_BUSINESS_GROUP_NBR = 
  AND CONTRACT_TYPE = 'D' 
GROUP BY payment_method_cd, service_group_changed_ind, service_grouping_priority_nbr;


-- Row number: 363

-- OON
SELECT MAX(RATE) AS RATE
FROM CET_OON
WHERE
    SERVICE_CD = "J1885"
    AND SERVICE_TYPE_CD = "HCPC"
    AND PLACE_OF_SERVICE_CD = "22"
    AND ZIP_CODE_UN = "31201";

-- Claim Based
SELECT MAX(RATE) AS RATE
FROM `prv_ps_ce_dec_hcb_dev.CET_CLAIM_BASED_AMOUNTS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 6210745
    AND NETWORK_ID = "01812"
    AND PLACE_OF_SERVICE_CD = "22"
    AND SERVICE_CD = "J1885"
    AND SERVICE_TYPE_CD = "HCPC";

-- provider table (if specialty_cd)
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 6210745
    AND NETWORK_ID = "01812"
    AND SERVICE_LOCATION_NBR = 7490153
    AND SPECIALTY_CD = 
    (       SELECT CASE WHEN EXISTS 
                (SELECT 1 
                FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS` 
                WHERE PROVIDER_IDENTIFICATION_NBR = 6210745 
                    AND NETWORK_ID = "01812" 
                    AND SERVICE_LOCATION_NBR = 7490153  
                    AND SPECIALTY_CD = ""
                ) 
                THEN "" ELSE '' END
    );

-- provider table (if provider_type_cd)
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 6210745
    AND NETWORK_ID = "01812"
    AND SERVICE_LOCATION_NBR = 7490153
    AND PROVIDER_TYPE_CD = "HO";

-- else
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 6210745
    AND NETWORK_ID = "01812"
    AND SERVICE_LOCATION_NBR = 7490153;

-- standard rate 
SELECT Max(RATE) AS RATE
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    RATE_SYSTEM_CD = "4ZOaT0u.u"
    AND SERVICE_CD = "J1885"
    AND SERVICE_TYPE_CD = "HCPC"
    AND GEOGRAPHIC_AREA_CD = "31201"
    AND PLACE_OF_SERVICE_CD = "22"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND CONTRACT_TYPE = 'S';

-- non standard rate (if specialty_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "J1885"
    AND SERVICE_TYPE_CD = "HCPC"
    AND PLACE_OF_SERVICE_CD = "22"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE IN ('C', 'N')
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "J1885"
                    AND SERVICE_TYPE_CD = "HCPC"
                    AND PLACE_OF_SERVICE_CD = "22"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE IN ('C', 'N')
                    AND SPECIALTY_CD = ""
            )
            THEN ""
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- non standard rate (if provider_type_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "J1885"
    AND SERVICE_TYPE_CD = "HCPC"
    AND PLACE_OF_SERVICE_CD = "22"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE IN ('C', 'N')
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "J1885"
                    AND SERVICE_TYPE_CD = "HCPC"
                    AND PLACE_OF_SERVICE_CD = "22"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE IN ('C', 'N')
                    AND SPECIALTY_CD = ""
            )
            THEN ""
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- else 
SELECT
  payment_method_cd,
  service_group_changed_ind,
  service_grouping_priority_nbr,
  max(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
  SERVICE_CD = "J1885"
  AND SERVICE_TYPE_CD = "HCPC"
  AND PLACE_OF_SERVICE_CD = "22"
  AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
  AND PROVIDER_BUSINESS_GROUP_NBR = 
  AND CONTRACT_TYPE IN ('C', 'N')
GROUP BY payment_method_cd, service_group_changed_ind, service_grouping_priority_nbr;

-- Default rate (if specialty_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "J1885"
    AND SERVICE_TYPE_CD = "HCPC"
    AND PLACE_OF_SERVICE_CD = "22"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE = 'D'
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "J1885"
                    AND SERVICE_TYPE_CD = "HCPC"
                    AND PLACE_OF_SERVICE_CD = "22"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE = 'D'
                    AND SPECIALTY_CD = ""
            )
            THEN ""
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- default_rate (if provider_type_cd) 
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "J1885"
    AND SERVICE_TYPE_CD = "HCPC"
    AND PLACE_OF_SERVICE_CD = "22"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE = 'D'
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "J1885"
                    AND SERVICE_TYPE_CD = "HCPC"
                    AND PLACE_OF_SERVICE_CD = "22"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE = 'D'
                    AND SPECIALTY_CD = "HO"
            )
            THEN "HO"
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- else 
SELECT
  payment_method_cd,
  service_group_changed_ind,
  service_grouping_priority_nbr,
  max(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
  SERVICE_CD = "J1885"
  AND SERVICE_TYPE_CD = "HCPC"
  AND PLACE_OF_SERVICE_CD = "22"
  AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
  AND PROVIDER_BUSINESS_GROUP_NBR = 
  AND CONTRACT_TYPE = 'D' 
GROUP BY payment_method_cd, service_group_changed_ind, service_grouping_priority_nbr;


-- Row number: 543

-- OON
SELECT MAX(RATE) AS RATE
FROM CET_OON
WHERE
    SERVICE_CD = "99051"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "11"
    AND ZIP_CODE_UN = "27511";

-- Claim Based
SELECT MAX(RATE) AS RATE
FROM `prv_ps_ce_dec_hcb_dev.CET_CLAIM_BASED_AMOUNTS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 6578077
    AND NETWORK_ID = "00606"
    AND PLACE_OF_SERVICE_CD = "11"
    AND SERVICE_CD = "99051"
    AND SERVICE_TYPE_CD = "CPT4";

-- provider table (if specialty_cd)
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 6578077
    AND NETWORK_ID = "00606"
    AND SERVICE_LOCATION_NBR = 5540878
    AND SPECIALTY_CD = 
    (       SELECT CASE WHEN EXISTS 
                (SELECT 1 
                FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS` 
                WHERE PROVIDER_IDENTIFICATION_NBR = 6578077 
                    AND NETWORK_ID = "00606" 
                    AND SERVICE_LOCATION_NBR = 5540878  
                    AND SPECIALTY_CD = "10401"
                ) 
                THEN "10401" ELSE '' END
    );

-- provider table (if provider_type_cd)
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 6578077
    AND NETWORK_ID = "00606"
    AND SERVICE_LOCATION_NBR = 5540878
    AND PROVIDER_TYPE_CD = "PH";

-- else
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 6578077
    AND NETWORK_ID = "00606"
    AND SERVICE_LOCATION_NBR = 5540878;

-- standard rate 
SELECT Max(RATE) AS RATE
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    RATE_SYSTEM_CD = "%B+Pl@3ae"
    AND SERVICE_CD = "99051"
    AND SERVICE_TYPE_CD = "CPT4"
    AND GEOGRAPHIC_AREA_CD = "27511"
    AND PLACE_OF_SERVICE_CD = "11"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND CONTRACT_TYPE = 'S';

-- non standard rate (if specialty_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "99051"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "11"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE IN ('C', 'N')
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "99051"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "11"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE IN ('C', 'N')
                    AND SPECIALTY_CD = "10401"
            )
            THEN "10401"
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- non standard rate (if provider_type_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "99051"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "11"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE IN ('C', 'N')
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "99051"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "11"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE IN ('C', 'N')
                    AND SPECIALTY_CD = "10401"
            )
            THEN "10401"
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- else 
SELECT
  payment_method_cd,
  service_group_changed_ind,
  service_grouping_priority_nbr,
  max(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
  SERVICE_CD = "99051"
  AND SERVICE_TYPE_CD = "CPT4"
  AND PLACE_OF_SERVICE_CD = "11"
  AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
  AND PROVIDER_BUSINESS_GROUP_NBR = 
  AND CONTRACT_TYPE IN ('C', 'N')
GROUP BY payment_method_cd, service_group_changed_ind, service_grouping_priority_nbr;

-- Default rate (if specialty_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "99051"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "11"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE = 'D'
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "99051"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "11"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE = 'D'
                    AND SPECIALTY_CD = "10401"
            )
            THEN "10401"
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- default_rate (if provider_type_cd) 
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "99051"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "11"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE = 'D'
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "99051"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "11"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE = 'D'
                    AND SPECIALTY_CD = "PH"
            )
            THEN "PH"
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- else 
SELECT
  payment_method_cd,
  service_group_changed_ind,
  service_grouping_priority_nbr,
  max(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
  SERVICE_CD = "99051"
  AND SERVICE_TYPE_CD = "CPT4"
  AND PLACE_OF_SERVICE_CD = "11"
  AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
  AND PROVIDER_BUSINESS_GROUP_NBR = 
  AND CONTRACT_TYPE = 'D' 
GROUP BY payment_method_cd, service_group_changed_ind, service_grouping_priority_nbr;


-- Row number: 621

-- OON
SELECT MAX(RATE) AS RATE
FROM CET_OON
WHERE
    SERVICE_CD = "77067"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "22"
    AND ZIP_CODE_UN = "28105";

-- Claim Based
SELECT MAX(RATE) AS RATE
FROM `prv_ps_ce_dec_hcb_dev.CET_CLAIM_BASED_AMOUNTS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 4497126
    AND NETWORK_ID = "00454"
    AND PLACE_OF_SERVICE_CD = "22"
    AND SERVICE_CD = "77067"
    AND SERVICE_TYPE_CD = "CPT4";

-- provider table (if specialty_cd)
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 4497126
    AND NETWORK_ID = "00454"
    AND SERVICE_LOCATION_NBR = 4861139
    AND SPECIALTY_CD = 
    (       SELECT CASE WHEN EXISTS 
                (SELECT 1 
                FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS` 
                WHERE PROVIDER_IDENTIFICATION_NBR = 4497126 
                    AND NETWORK_ID = "00454" 
                    AND SERVICE_LOCATION_NBR = 4861139  
                    AND SPECIALTY_CD = ""
                ) 
                THEN "" ELSE '' END
    );

-- provider table (if provider_type_cd)
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 4497126
    AND NETWORK_ID = "00454"
    AND SERVICE_LOCATION_NBR = 4861139
    AND PROVIDER_TYPE_CD = "HO";

-- else
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 4497126
    AND NETWORK_ID = "00454"
    AND SERVICE_LOCATION_NBR = 4861139;

-- standard rate 
SELECT Max(RATE) AS RATE
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    RATE_SYSTEM_CD = "@pb/xMLL-"
    AND SERVICE_CD = "77067"
    AND SERVICE_TYPE_CD = "CPT4"
    AND GEOGRAPHIC_AREA_CD = "28105"
    AND PLACE_OF_SERVICE_CD = "22"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND CONTRACT_TYPE = 'S';

-- non standard rate (if specialty_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "77067"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "22"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE IN ('C', 'N')
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "77067"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "22"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE IN ('C', 'N')
                    AND SPECIALTY_CD = ""
            )
            THEN ""
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- non standard rate (if provider_type_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "77067"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "22"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE IN ('C', 'N')
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "77067"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "22"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE IN ('C', 'N')
                    AND SPECIALTY_CD = ""
            )
            THEN ""
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- else 
SELECT
  payment_method_cd,
  service_group_changed_ind,
  service_grouping_priority_nbr,
  max(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
  SERVICE_CD = "77067"
  AND SERVICE_TYPE_CD = "CPT4"
  AND PLACE_OF_SERVICE_CD = "22"
  AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
  AND PROVIDER_BUSINESS_GROUP_NBR = 
  AND CONTRACT_TYPE IN ('C', 'N')
GROUP BY payment_method_cd, service_group_changed_ind, service_grouping_priority_nbr;

-- Default rate (if specialty_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "77067"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "22"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE = 'D'
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "77067"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "22"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE = 'D'
                    AND SPECIALTY_CD = ""
            )
            THEN ""
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- default_rate (if provider_type_cd) 
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "77067"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "22"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE = 'D'
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "77067"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "22"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE = 'D'
                    AND SPECIALTY_CD = "HO"
            )
            THEN "HO"
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- else 
SELECT
  payment_method_cd,
  service_group_changed_ind,
  service_grouping_priority_nbr,
  max(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
  SERVICE_CD = "77067"
  AND SERVICE_TYPE_CD = "CPT4"
  AND PLACE_OF_SERVICE_CD = "22"
  AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
  AND PROVIDER_BUSINESS_GROUP_NBR = 
  AND CONTRACT_TYPE = 'D' 
GROUP BY payment_method_cd, service_group_changed_ind, service_grouping_priority_nbr;


-- Row number: 692

-- OON
SELECT MAX(RATE) AS RATE
FROM CET_OON
WHERE
    SERVICE_CD = "J2704"
    AND SERVICE_TYPE_CD = "HCPC"
    AND PLACE_OF_SERVICE_CD = "22"
    AND ZIP_CODE_UN = "28105";

-- Claim Based
SELECT MAX(RATE) AS RATE
FROM `prv_ps_ce_dec_hcb_dev.CET_CLAIM_BASED_AMOUNTS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 4497126
    AND NETWORK_ID = "00454"
    AND PLACE_OF_SERVICE_CD = "22"
    AND SERVICE_CD = "J2704"
    AND SERVICE_TYPE_CD = "HCPC";

-- provider table (if specialty_cd)
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 4497126
    AND NETWORK_ID = "00454"
    AND SERVICE_LOCATION_NBR = 4861139
    AND SPECIALTY_CD = 
    (       SELECT CASE WHEN EXISTS 
                (SELECT 1 
                FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS` 
                WHERE PROVIDER_IDENTIFICATION_NBR = 4497126 
                    AND NETWORK_ID = "00454" 
                    AND SERVICE_LOCATION_NBR = 4861139  
                    AND SPECIALTY_CD = ""
                ) 
                THEN "" ELSE '' END
    );

-- provider table (if provider_type_cd)
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 4497126
    AND NETWORK_ID = "00454"
    AND SERVICE_LOCATION_NBR = 4861139
    AND PROVIDER_TYPE_CD = "HO";

-- else
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 4497126
    AND NETWORK_ID = "00454"
    AND SERVICE_LOCATION_NBR = 4861139;

-- standard rate 
SELECT Max(RATE) AS RATE
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    RATE_SYSTEM_CD = "@pb/xMLL-"
    AND SERVICE_CD = "J2704"
    AND SERVICE_TYPE_CD = "HCPC"
    AND GEOGRAPHIC_AREA_CD = "28105"
    AND PLACE_OF_SERVICE_CD = "22"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND CONTRACT_TYPE = 'S';

-- non standard rate (if specialty_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "J2704"
    AND SERVICE_TYPE_CD = "HCPC"
    AND PLACE_OF_SERVICE_CD = "22"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE IN ('C', 'N')
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "J2704"
                    AND SERVICE_TYPE_CD = "HCPC"
                    AND PLACE_OF_SERVICE_CD = "22"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE IN ('C', 'N')
                    AND SPECIALTY_CD = ""
            )
            THEN ""
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- non standard rate (if provider_type_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "J2704"
    AND SERVICE_TYPE_CD = "HCPC"
    AND PLACE_OF_SERVICE_CD = "22"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE IN ('C', 'N')
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "J2704"
                    AND SERVICE_TYPE_CD = "HCPC"
                    AND PLACE_OF_SERVICE_CD = "22"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE IN ('C', 'N')
                    AND SPECIALTY_CD = ""
            )
            THEN ""
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- else 
SELECT
  payment_method_cd,
  service_group_changed_ind,
  service_grouping_priority_nbr,
  max(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
  SERVICE_CD = "J2704"
  AND SERVICE_TYPE_CD = "HCPC"
  AND PLACE_OF_SERVICE_CD = "22"
  AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
  AND PROVIDER_BUSINESS_GROUP_NBR = 
  AND CONTRACT_TYPE IN ('C', 'N')
GROUP BY payment_method_cd, service_group_changed_ind, service_grouping_priority_nbr;

-- Default rate (if specialty_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "J2704"
    AND SERVICE_TYPE_CD = "HCPC"
    AND PLACE_OF_SERVICE_CD = "22"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE = 'D'
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "J2704"
                    AND SERVICE_TYPE_CD = "HCPC"
                    AND PLACE_OF_SERVICE_CD = "22"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE = 'D'
                    AND SPECIALTY_CD = ""
            )
            THEN ""
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- default_rate (if provider_type_cd) 
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "J2704"
    AND SERVICE_TYPE_CD = "HCPC"
    AND PLACE_OF_SERVICE_CD = "22"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE = 'D'
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "J2704"
                    AND SERVICE_TYPE_CD = "HCPC"
                    AND PLACE_OF_SERVICE_CD = "22"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE = 'D'
                    AND SPECIALTY_CD = "HO"
            )
            THEN "HO"
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- else 
SELECT
  payment_method_cd,
  service_group_changed_ind,
  service_grouping_priority_nbr,
  max(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
  SERVICE_CD = "J2704"
  AND SERVICE_TYPE_CD = "HCPC"
  AND PLACE_OF_SERVICE_CD = "22"
  AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
  AND PROVIDER_BUSINESS_GROUP_NBR = 
  AND CONTRACT_TYPE = 'D' 
GROUP BY payment_method_cd, service_group_changed_ind, service_grouping_priority_nbr;


-- Row number: 732

-- OON
SELECT MAX(RATE) AS RATE
FROM CET_OON
WHERE
    SERVICE_CD = "90461"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "11"
    AND ZIP_CODE_UN = "75070";

-- Claim Based
SELECT MAX(RATE) AS RATE
FROM `prv_ps_ce_dec_hcb_dev.CET_CLAIM_BASED_AMOUNTS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 6347355
    AND NETWORK_ID = "08158"
    AND PLACE_OF_SERVICE_CD = "11"
    AND SERVICE_CD = "90461"
    AND SERVICE_TYPE_CD = "CPT4";

-- provider table (if specialty_cd)
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 6347355
    AND NETWORK_ID = "08158"
    AND SERVICE_LOCATION_NBR = 8646357
    AND SPECIALTY_CD = 
    (       SELECT CASE WHEN EXISTS 
                (SELECT 1 
                FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS` 
                WHERE PROVIDER_IDENTIFICATION_NBR = 6347355 
                    AND NETWORK_ID = "08158" 
                    AND SERVICE_LOCATION_NBR = 8646357  
                    AND SPECIALTY_CD = "10401"
                ) 
                THEN "10401" ELSE '' END
    );

-- provider table (if provider_type_cd)
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 6347355
    AND NETWORK_ID = "08158"
    AND SERVICE_LOCATION_NBR = 8646357
    AND PROVIDER_TYPE_CD = "PH";

-- else
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 6347355
    AND NETWORK_ID = "08158"
    AND SERVICE_LOCATION_NBR = 8646357;

-- standard rate 
SELECT Max(RATE) AS RATE
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    RATE_SYSTEM_CD = "ObuQ.6bh_"
    AND SERVICE_CD = "90461"
    AND SERVICE_TYPE_CD = "CPT4"
    AND GEOGRAPHIC_AREA_CD = "75070"
    AND PLACE_OF_SERVICE_CD = "11"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND CONTRACT_TYPE = 'S';

-- non standard rate (if specialty_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "90461"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "11"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE IN ('C', 'N')
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "90461"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "11"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE IN ('C', 'N')
                    AND SPECIALTY_CD = "10401"
            )
            THEN "10401"
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- non standard rate (if provider_type_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "90461"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "11"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE IN ('C', 'N')
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "90461"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "11"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE IN ('C', 'N')
                    AND SPECIALTY_CD = "10401"
            )
            THEN "10401"
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- else 
SELECT
  payment_method_cd,
  service_group_changed_ind,
  service_grouping_priority_nbr,
  max(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
  SERVICE_CD = "90461"
  AND SERVICE_TYPE_CD = "CPT4"
  AND PLACE_OF_SERVICE_CD = "11"
  AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
  AND PROVIDER_BUSINESS_GROUP_NBR = 
  AND CONTRACT_TYPE IN ('C', 'N')
GROUP BY payment_method_cd, service_group_changed_ind, service_grouping_priority_nbr;

-- Default rate (if specialty_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "90461"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "11"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE = 'D'
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "90461"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "11"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE = 'D'
                    AND SPECIALTY_CD = "10401"
            )
            THEN "10401"
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- default_rate (if provider_type_cd) 
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "90461"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "11"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE = 'D'
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "90461"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "11"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE = 'D'
                    AND SPECIALTY_CD = "PH"
            )
            THEN "PH"
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- else 
SELECT
  payment_method_cd,
  service_group_changed_ind,
  service_grouping_priority_nbr,
  max(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
  SERVICE_CD = "90461"
  AND SERVICE_TYPE_CD = "CPT4"
  AND PLACE_OF_SERVICE_CD = "11"
  AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
  AND PROVIDER_BUSINESS_GROUP_NBR = 
  AND CONTRACT_TYPE = 'D' 
GROUP BY payment_method_cd, service_group_changed_ind, service_grouping_priority_nbr;


-- Row number: 774

-- OON
SELECT MAX(RATE) AS RATE
FROM CET_OON
WHERE
    SERVICE_CD = "G0136"
    AND SERVICE_TYPE_CD = "HCPC"
    AND PLACE_OF_SERVICE_CD = "11"
    AND ZIP_CODE_UN = "27030";

-- Claim Based
SELECT MAX(RATE) AS RATE
FROM `prv_ps_ce_dec_hcb_dev.CET_CLAIM_BASED_AMOUNTS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 7243170
    AND NETWORK_ID = "03200"
    AND PLACE_OF_SERVICE_CD = "11"
    AND SERVICE_CD = "G0136"
    AND SERVICE_TYPE_CD = "HCPC";

-- provider table (if specialty_cd)
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 7243170
    AND NETWORK_ID = "03200"
    AND SERVICE_LOCATION_NBR = 7896102
    AND SPECIALTY_CD = 
    (       SELECT CASE WHEN EXISTS 
                (SELECT 1 
                FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS` 
                WHERE PROVIDER_IDENTIFICATION_NBR = 7243170 
                    AND NETWORK_ID = "03200" 
                    AND SERVICE_LOCATION_NBR = 7896102  
                    AND SPECIALTY_CD = "10201"
                ) 
                THEN "10201" ELSE '' END
    );

-- provider table (if provider_type_cd)
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 7243170
    AND NETWORK_ID = "03200"
    AND SERVICE_LOCATION_NBR = 7896102
    AND PROVIDER_TYPE_CD = "PH";

-- else
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 7243170
    AND NETWORK_ID = "03200"
    AND SERVICE_LOCATION_NBR = 7896102;

-- standard rate 
SELECT Max(RATE) AS RATE
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    RATE_SYSTEM_CD = "PjCB8~gh;"
    AND SERVICE_CD = "G0136"
    AND SERVICE_TYPE_CD = "HCPC"
    AND GEOGRAPHIC_AREA_CD = "27030"
    AND PLACE_OF_SERVICE_CD = "11"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND CONTRACT_TYPE = 'S';

-- non standard rate (if specialty_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "G0136"
    AND SERVICE_TYPE_CD = "HCPC"
    AND PLACE_OF_SERVICE_CD = "11"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE IN ('C', 'N')
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "G0136"
                    AND SERVICE_TYPE_CD = "HCPC"
                    AND PLACE_OF_SERVICE_CD = "11"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE IN ('C', 'N')
                    AND SPECIALTY_CD = "10201"
            )
            THEN "10201"
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- non standard rate (if provider_type_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "G0136"
    AND SERVICE_TYPE_CD = "HCPC"
    AND PLACE_OF_SERVICE_CD = "11"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE IN ('C', 'N')
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "G0136"
                    AND SERVICE_TYPE_CD = "HCPC"
                    AND PLACE_OF_SERVICE_CD = "11"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE IN ('C', 'N')
                    AND SPECIALTY_CD = "10201"
            )
            THEN "10201"
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- else 
SELECT
  payment_method_cd,
  service_group_changed_ind,
  service_grouping_priority_nbr,
  max(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
  SERVICE_CD = "G0136"
  AND SERVICE_TYPE_CD = "HCPC"
  AND PLACE_OF_SERVICE_CD = "11"
  AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
  AND PROVIDER_BUSINESS_GROUP_NBR = 
  AND CONTRACT_TYPE IN ('C', 'N')
GROUP BY payment_method_cd, service_group_changed_ind, service_grouping_priority_nbr;

-- Default rate (if specialty_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "G0136"
    AND SERVICE_TYPE_CD = "HCPC"
    AND PLACE_OF_SERVICE_CD = "11"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE = 'D'
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "G0136"
                    AND SERVICE_TYPE_CD = "HCPC"
                    AND PLACE_OF_SERVICE_CD = "11"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE = 'D'
                    AND SPECIALTY_CD = "10201"
            )
            THEN "10201"
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- default_rate (if provider_type_cd) 
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "G0136"
    AND SERVICE_TYPE_CD = "HCPC"
    AND PLACE_OF_SERVICE_CD = "11"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE = 'D'
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "G0136"
                    AND SERVICE_TYPE_CD = "HCPC"
                    AND PLACE_OF_SERVICE_CD = "11"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE = 'D'
                    AND SPECIALTY_CD = "PH"
            )
            THEN "PH"
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- else 
SELECT
  payment_method_cd,
  service_group_changed_ind,
  service_grouping_priority_nbr,
  max(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
  SERVICE_CD = "G0136"
  AND SERVICE_TYPE_CD = "HCPC"
  AND PLACE_OF_SERVICE_CD = "11"
  AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
  AND PROVIDER_BUSINESS_GROUP_NBR = 
  AND CONTRACT_TYPE = 'D' 
GROUP BY payment_method_cd, service_group_changed_ind, service_grouping_priority_nbr;


-- Row number: 861

-- OON
SELECT MAX(RATE) AS RATE
FROM CET_OON
WHERE
    SERVICE_CD = "87651"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "11"
    AND ZIP_CODE_UN = "28277";

-- Claim Based
SELECT MAX(RATE) AS RATE
FROM `prv_ps_ce_dec_hcb_dev.CET_CLAIM_BASED_AMOUNTS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 4233642
    AND NETWORK_ID = "00454"
    AND PLACE_OF_SERVICE_CD = "11"
    AND SERVICE_CD = "87651"
    AND SERVICE_TYPE_CD = "CPT4";

-- provider table (if specialty_cd)
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 4233642
    AND NETWORK_ID = "00454"
    AND SERVICE_LOCATION_NBR = 9536181
    AND SPECIALTY_CD = 
    (       SELECT CASE WHEN EXISTS 
                (SELECT 1 
                FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS` 
                WHERE PROVIDER_IDENTIFICATION_NBR = 4233642 
                    AND NETWORK_ID = "00454" 
                    AND SERVICE_LOCATION_NBR = 9536181  
                    AND SPECIALTY_CD = "10401"
                ) 
                THEN "10401" ELSE '' END
    );

-- provider table (if provider_type_cd)
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 4233642
    AND NETWORK_ID = "00454"
    AND SERVICE_LOCATION_NBR = 9536181
    AND PROVIDER_TYPE_CD = "PH";

-- else
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 4233642
    AND NETWORK_ID = "00454"
    AND SERVICE_LOCATION_NBR = 9536181;

-- standard rate 
SELECT Max(RATE) AS RATE
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    RATE_SYSTEM_CD = "sA4X@;~qu"
    AND SERVICE_CD = "87651"
    AND SERVICE_TYPE_CD = "CPT4"
    AND GEOGRAPHIC_AREA_CD = "28277"
    AND PLACE_OF_SERVICE_CD = "11"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND CONTRACT_TYPE = 'S';

-- non standard rate (if specialty_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "87651"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "11"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE IN ('C', 'N')
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "87651"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "11"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE IN ('C', 'N')
                    AND SPECIALTY_CD = "10401"
            )
            THEN "10401"
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- non standard rate (if provider_type_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "87651"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "11"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE IN ('C', 'N')
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "87651"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "11"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE IN ('C', 'N')
                    AND SPECIALTY_CD = "10401"
            )
            THEN "10401"
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- else 
SELECT
  payment_method_cd,
  service_group_changed_ind,
  service_grouping_priority_nbr,
  max(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
  SERVICE_CD = "87651"
  AND SERVICE_TYPE_CD = "CPT4"
  AND PLACE_OF_SERVICE_CD = "11"
  AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
  AND PROVIDER_BUSINESS_GROUP_NBR = 
  AND CONTRACT_TYPE IN ('C', 'N')
GROUP BY payment_method_cd, service_group_changed_ind, service_grouping_priority_nbr;

-- Default rate (if specialty_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "87651"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "11"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE = 'D'
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "87651"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "11"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE = 'D'
                    AND SPECIALTY_CD = "10401"
            )
            THEN "10401"
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- default_rate (if provider_type_cd) 
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "87651"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "11"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE = 'D'
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "87651"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "11"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE = 'D'
                    AND SPECIALTY_CD = "PH"
            )
            THEN "PH"
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- else 
SELECT
  payment_method_cd,
  service_group_changed_ind,
  service_grouping_priority_nbr,
  max(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
  SERVICE_CD = "87651"
  AND SERVICE_TYPE_CD = "CPT4"
  AND PLACE_OF_SERVICE_CD = "11"
  AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
  AND PROVIDER_BUSINESS_GROUP_NBR = 
  AND CONTRACT_TYPE = 'D' 
GROUP BY payment_method_cd, service_group_changed_ind, service_grouping_priority_nbr;


-- Row number: 864

-- OON
SELECT MAX(RATE) AS RATE
FROM CET_OON
WHERE
    SERVICE_CD = "99284"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "23"
    AND ZIP_CODE_UN = "84067";

-- Claim Based
SELECT MAX(RATE) AS RATE
FROM `prv_ps_ce_dec_hcb_dev.CET_CLAIM_BASED_AMOUNTS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 7005047
    AND NETWORK_ID = "09512"
    AND PLACE_OF_SERVICE_CD = "23"
    AND SERVICE_CD = "99284"
    AND SERVICE_TYPE_CD = "CPT4";

-- provider table (if specialty_cd)
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 7005047
    AND NETWORK_ID = "09512"
    AND SERVICE_LOCATION_NBR = 7944919
    AND SPECIALTY_CD = 
    (       SELECT CASE WHEN EXISTS 
                (SELECT 1 
                FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS` 
                WHERE PROVIDER_IDENTIFICATION_NBR = 7005047 
                    AND NETWORK_ID = "09512" 
                    AND SERVICE_LOCATION_NBR = 7944919  
                    AND SPECIALTY_CD = "10701"
                ) 
                THEN "10701" ELSE '' END
    );

-- provider table (if provider_type_cd)
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 7005047
    AND NETWORK_ID = "09512"
    AND SERVICE_LOCATION_NBR = 7944919
    AND PROVIDER_TYPE_CD = "PH";

-- else
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 7005047
    AND NETWORK_ID = "09512"
    AND SERVICE_LOCATION_NBR = 7944919;

-- standard rate 
SELECT Max(RATE) AS RATE
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    RATE_SYSTEM_CD = "aXDvHSxa_"
    AND SERVICE_CD = "99284"
    AND SERVICE_TYPE_CD = "CPT4"
    AND GEOGRAPHIC_AREA_CD = "84067"
    AND PLACE_OF_SERVICE_CD = "23"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND CONTRACT_TYPE = 'S';

-- non standard rate (if specialty_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "99284"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "23"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE IN ('C', 'N')
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "99284"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "23"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE IN ('C', 'N')
                    AND SPECIALTY_CD = "10701"
            )
            THEN "10701"
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- non standard rate (if provider_type_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "99284"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "23"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE IN ('C', 'N')
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "99284"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "23"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE IN ('C', 'N')
                    AND SPECIALTY_CD = "10701"
            )
            THEN "10701"
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- else 
SELECT
  payment_method_cd,
  service_group_changed_ind,
  service_grouping_priority_nbr,
  max(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
  SERVICE_CD = "99284"
  AND SERVICE_TYPE_CD = "CPT4"
  AND PLACE_OF_SERVICE_CD = "23"
  AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
  AND PROVIDER_BUSINESS_GROUP_NBR = 
  AND CONTRACT_TYPE IN ('C', 'N')
GROUP BY payment_method_cd, service_group_changed_ind, service_grouping_priority_nbr;

-- Default rate (if specialty_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "99284"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "23"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE = 'D'
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "99284"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "23"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE = 'D'
                    AND SPECIALTY_CD = "10701"
            )
            THEN "10701"
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- default_rate (if provider_type_cd) 
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "99284"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "23"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE = 'D'
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "99284"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "23"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE = 'D'
                    AND SPECIALTY_CD = "PH"
            )
            THEN "PH"
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- else 
SELECT
  payment_method_cd,
  service_group_changed_ind,
  service_grouping_priority_nbr,
  max(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
  SERVICE_CD = "99284"
  AND SERVICE_TYPE_CD = "CPT4"
  AND PLACE_OF_SERVICE_CD = "23"
  AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
  AND PROVIDER_BUSINESS_GROUP_NBR = 
  AND CONTRACT_TYPE = 'D' 
GROUP BY payment_method_cd, service_group_changed_ind, service_grouping_priority_nbr;


-- Row number: 1010

-- OON
SELECT MAX(RATE) AS RATE
FROM CET_OON
WHERE
    SERVICE_CD = "31231"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "11"
    AND ZIP_CODE_UN = "60169";

-- Claim Based
SELECT MAX(RATE) AS RATE
FROM `prv_ps_ce_dec_hcb_dev.CET_CLAIM_BASED_AMOUNTS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 9259598
    AND NETWORK_ID = "00243"
    AND PLACE_OF_SERVICE_CD = "11"
    AND SERVICE_CD = "31231"
    AND SERVICE_TYPE_CD = "CPT4";

-- provider table (if specialty_cd)
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 9259598
    AND NETWORK_ID = "00243"
    AND SERVICE_LOCATION_NBR = 2672805
    AND SPECIALTY_CD = 
    (       SELECT CASE WHEN EXISTS 
                (SELECT 1 
                FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS` 
                WHERE PROVIDER_IDENTIFICATION_NBR = 9259598 
                    AND NETWORK_ID = "00243" 
                    AND SERVICE_LOCATION_NBR = 2672805  
                    AND SPECIALTY_CD = "30601"
                ) 
                THEN "30601" ELSE '' END
    );

-- provider table (if provider_type_cd)
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 9259598
    AND NETWORK_ID = "00243"
    AND SERVICE_LOCATION_NBR = 2672805
    AND PROVIDER_TYPE_CD = "PH";

-- else
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 9259598
    AND NETWORK_ID = "00243"
    AND SERVICE_LOCATION_NBR = 2672805;

-- standard rate 
SELECT Max(RATE) AS RATE
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    RATE_SYSTEM_CD = "ux2ob}Mlb"
    AND SERVICE_CD = "31231"
    AND SERVICE_TYPE_CD = "CPT4"
    AND GEOGRAPHIC_AREA_CD = "60169"
    AND PLACE_OF_SERVICE_CD = "11"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND CONTRACT_TYPE = 'S';

-- non standard rate (if specialty_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "31231"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "11"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE IN ('C', 'N')
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "31231"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "11"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE IN ('C', 'N')
                    AND SPECIALTY_CD = "30601"
            )
            THEN "30601"
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- non standard rate (if provider_type_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "31231"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "11"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE IN ('C', 'N')
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "31231"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "11"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE IN ('C', 'N')
                    AND SPECIALTY_CD = "30601"
            )
            THEN "30601"
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- else 
SELECT
  payment_method_cd,
  service_group_changed_ind,
  service_grouping_priority_nbr,
  max(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
  SERVICE_CD = "31231"
  AND SERVICE_TYPE_CD = "CPT4"
  AND PLACE_OF_SERVICE_CD = "11"
  AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
  AND PROVIDER_BUSINESS_GROUP_NBR = 
  AND CONTRACT_TYPE IN ('C', 'N')
GROUP BY payment_method_cd, service_group_changed_ind, service_grouping_priority_nbr;

-- Default rate (if specialty_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "31231"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "11"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE = 'D'
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "31231"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "11"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE = 'D'
                    AND SPECIALTY_CD = "30601"
            )
            THEN "30601"
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- default_rate (if provider_type_cd) 
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "31231"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "11"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE = 'D'
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "31231"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "11"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE = 'D'
                    AND SPECIALTY_CD = "PH"
            )
            THEN "PH"
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- else 
SELECT
  payment_method_cd,
  service_group_changed_ind,
  service_grouping_priority_nbr,
  max(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
  SERVICE_CD = "31231"
  AND SERVICE_TYPE_CD = "CPT4"
  AND PLACE_OF_SERVICE_CD = "11"
  AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
  AND PROVIDER_BUSINESS_GROUP_NBR = 
  AND CONTRACT_TYPE = 'D' 
GROUP BY payment_method_cd, service_group_changed_ind, service_grouping_priority_nbr;


-- Row number: 1047

-- OON
SELECT MAX(RATE) AS RATE
FROM CET_OON
WHERE
    SERVICE_CD = "77067"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "22"
    AND ZIP_CODE_UN = "10591";

-- Claim Based
SELECT MAX(RATE) AS RATE
FROM `prv_ps_ce_dec_hcb_dev.CET_CLAIM_BASED_AMOUNTS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 6451270
    AND NETWORK_ID = "00357"
    AND PLACE_OF_SERVICE_CD = "22"
    AND SERVICE_CD = "77067"
    AND SERVICE_TYPE_CD = "CPT4";

-- provider table (if specialty_cd)
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 6451270
    AND NETWORK_ID = "00357"
    AND SERVICE_LOCATION_NBR = 1380685
    AND SPECIALTY_CD = 
    (       SELECT CASE WHEN EXISTS 
                (SELECT 1 
                FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS` 
                WHERE PROVIDER_IDENTIFICATION_NBR = 6451270 
                    AND NETWORK_ID = "00357" 
                    AND SERVICE_LOCATION_NBR = 1380685  
                    AND SPECIALTY_CD = ""
                ) 
                THEN "" ELSE '' END
    );

-- provider table (if provider_type_cd)
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 6451270
    AND NETWORK_ID = "00357"
    AND SERVICE_LOCATION_NBR = 1380685
    AND PROVIDER_TYPE_CD = "HO";

-- else
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 6451270
    AND NETWORK_ID = "00357"
    AND SERVICE_LOCATION_NBR = 1380685;

-- standard rate 
SELECT Max(RATE) AS RATE
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    RATE_SYSTEM_CD = "sqrhJE}#("
    AND SERVICE_CD = "77067"
    AND SERVICE_TYPE_CD = "CPT4"
    AND GEOGRAPHIC_AREA_CD = "10591"
    AND PLACE_OF_SERVICE_CD = "22"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND CONTRACT_TYPE = 'S';

-- non standard rate (if specialty_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "77067"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "22"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE IN ('C', 'N')
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "77067"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "22"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE IN ('C', 'N')
                    AND SPECIALTY_CD = ""
            )
            THEN ""
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- non standard rate (if provider_type_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "77067"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "22"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE IN ('C', 'N')
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "77067"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "22"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE IN ('C', 'N')
                    AND SPECIALTY_CD = ""
            )
            THEN ""
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- else 
SELECT
  payment_method_cd,
  service_group_changed_ind,
  service_grouping_priority_nbr,
  max(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
  SERVICE_CD = "77067"
  AND SERVICE_TYPE_CD = "CPT4"
  AND PLACE_OF_SERVICE_CD = "22"
  AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
  AND PROVIDER_BUSINESS_GROUP_NBR = 
  AND CONTRACT_TYPE IN ('C', 'N')
GROUP BY payment_method_cd, service_group_changed_ind, service_grouping_priority_nbr;

-- Default rate (if specialty_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "77067"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "22"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE = 'D'
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "77067"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "22"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE = 'D'
                    AND SPECIALTY_CD = ""
            )
            THEN ""
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- default_rate (if provider_type_cd) 
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "77067"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "22"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE = 'D'
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "77067"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "22"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE = 'D'
                    AND SPECIALTY_CD = "HO"
            )
            THEN "HO"
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- else 
SELECT
  payment_method_cd,
  service_group_changed_ind,
  service_grouping_priority_nbr,
  max(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
  SERVICE_CD = "77067"
  AND SERVICE_TYPE_CD = "CPT4"
  AND PLACE_OF_SERVICE_CD = "22"
  AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
  AND PROVIDER_BUSINESS_GROUP_NBR = 
  AND CONTRACT_TYPE = 'D' 
GROUP BY payment_method_cd, service_group_changed_ind, service_grouping_priority_nbr;


-- Row number: 1084

-- OON
SELECT MAX(RATE) AS RATE
FROM CET_OON
WHERE
    SERVICE_CD = "A9579"
    AND SERVICE_TYPE_CD = "HCPC"
    AND PLACE_OF_SERVICE_CD = "22"
    AND ZIP_CODE_UN = "77030";

-- Claim Based
SELECT MAX(RATE) AS RATE
FROM `prv_ps_ce_dec_hcb_dev.CET_CLAIM_BASED_AMOUNTS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 6541570
    AND NETWORK_ID = "00248"
    AND PLACE_OF_SERVICE_CD = "22"
    AND SERVICE_CD = "A9579"
    AND SERVICE_TYPE_CD = "HCPC";

-- provider table (if specialty_cd)
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 6541570
    AND NETWORK_ID = "00248"
    AND SERVICE_LOCATION_NBR = 160705
    AND SPECIALTY_CD = 
    (       SELECT CASE WHEN EXISTS 
                (SELECT 1 
                FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS` 
                WHERE PROVIDER_IDENTIFICATION_NBR = 6541570 
                    AND NETWORK_ID = "00248" 
                    AND SERVICE_LOCATION_NBR = 160705  
                    AND SPECIALTY_CD = ""
                ) 
                THEN "" ELSE '' END
    );

-- provider table (if provider_type_cd)
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 6541570
    AND NETWORK_ID = "00248"
    AND SERVICE_LOCATION_NBR = 160705
    AND PROVIDER_TYPE_CD = "CH";

-- else
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 6541570
    AND NETWORK_ID = "00248"
    AND SERVICE_LOCATION_NBR = 160705;

-- standard rate 
SELECT Max(RATE) AS RATE
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    RATE_SYSTEM_CD = "ZQvf9okGr"
    AND SERVICE_CD = "A9579"
    AND SERVICE_TYPE_CD = "HCPC"
    AND GEOGRAPHIC_AREA_CD = "77030"
    AND PLACE_OF_SERVICE_CD = "22"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND CONTRACT_TYPE = 'S';

-- non standard rate (if specialty_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "A9579"
    AND SERVICE_TYPE_CD = "HCPC"
    AND PLACE_OF_SERVICE_CD = "22"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE IN ('C', 'N')
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "A9579"
                    AND SERVICE_TYPE_CD = "HCPC"
                    AND PLACE_OF_SERVICE_CD = "22"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE IN ('C', 'N')
                    AND SPECIALTY_CD = ""
            )
            THEN ""
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- non standard rate (if provider_type_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "A9579"
    AND SERVICE_TYPE_CD = "HCPC"
    AND PLACE_OF_SERVICE_CD = "22"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE IN ('C', 'N')
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "A9579"
                    AND SERVICE_TYPE_CD = "HCPC"
                    AND PLACE_OF_SERVICE_CD = "22"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE IN ('C', 'N')
                    AND SPECIALTY_CD = ""
            )
            THEN ""
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- else 
SELECT
  payment_method_cd,
  service_group_changed_ind,
  service_grouping_priority_nbr,
  max(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
  SERVICE_CD = "A9579"
  AND SERVICE_TYPE_CD = "HCPC"
  AND PLACE_OF_SERVICE_CD = "22"
  AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
  AND PROVIDER_BUSINESS_GROUP_NBR = 
  AND CONTRACT_TYPE IN ('C', 'N')
GROUP BY payment_method_cd, service_group_changed_ind, service_grouping_priority_nbr;

-- Default rate (if specialty_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "A9579"
    AND SERVICE_TYPE_CD = "HCPC"
    AND PLACE_OF_SERVICE_CD = "22"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE = 'D'
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "A9579"
                    AND SERVICE_TYPE_CD = "HCPC"
                    AND PLACE_OF_SERVICE_CD = "22"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE = 'D'
                    AND SPECIALTY_CD = ""
            )
            THEN ""
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- default_rate (if provider_type_cd) 
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "A9579"
    AND SERVICE_TYPE_CD = "HCPC"
    AND PLACE_OF_SERVICE_CD = "22"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE = 'D'
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "A9579"
                    AND SERVICE_TYPE_CD = "HCPC"
                    AND PLACE_OF_SERVICE_CD = "22"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE = 'D'
                    AND SPECIALTY_CD = "CH"
            )
            THEN "CH"
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- else 
SELECT
  payment_method_cd,
  service_group_changed_ind,
  service_grouping_priority_nbr,
  max(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
  SERVICE_CD = "A9579"
  AND SERVICE_TYPE_CD = "HCPC"
  AND PLACE_OF_SERVICE_CD = "22"
  AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
  AND PROVIDER_BUSINESS_GROUP_NBR = 
  AND CONTRACT_TYPE = 'D' 
GROUP BY payment_method_cd, service_group_changed_ind, service_grouping_priority_nbr;


-- Row number: 1103

-- OON
SELECT MAX(RATE) AS RATE
FROM CET_OON
WHERE
    SERVICE_CD = "99417"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "11"
    AND ZIP_CODE_UN = "32207";

-- Claim Based
SELECT MAX(RATE) AS RATE
FROM `prv_ps_ce_dec_hcb_dev.CET_CLAIM_BASED_AMOUNTS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 9860434
    AND NETWORK_ID = "03892"
    AND PLACE_OF_SERVICE_CD = "11"
    AND SERVICE_CD = "99417"
    AND SERVICE_TYPE_CD = "CPT4";

-- provider table (if specialty_cd)
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 9860434
    AND NETWORK_ID = "03892"
    AND SERVICE_LOCATION_NBR = 5134124
    AND SPECIALTY_CD = 
    (       SELECT CASE WHEN EXISTS 
                (SELECT 1 
                FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS` 
                WHERE PROVIDER_IDENTIFICATION_NBR = 9860434 
                    AND NETWORK_ID = "03892" 
                    AND SERVICE_LOCATION_NBR = 5134124  
                    AND SPECIALTY_CD = "10401"
                ) 
                THEN "10401" ELSE '' END
    );

-- provider table (if provider_type_cd)
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 9860434
    AND NETWORK_ID = "03892"
    AND SERVICE_LOCATION_NBR = 5134124
    AND PROVIDER_TYPE_CD = "PH";

-- else
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 9860434
    AND NETWORK_ID = "03892"
    AND SERVICE_LOCATION_NBR = 5134124;

-- standard rate 
SELECT Max(RATE) AS RATE
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    RATE_SYSTEM_CD = "uSxG81h8d"
    AND SERVICE_CD = "99417"
    AND SERVICE_TYPE_CD = "CPT4"
    AND GEOGRAPHIC_AREA_CD = "32207"
    AND PLACE_OF_SERVICE_CD = "11"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND CONTRACT_TYPE = 'S';

-- non standard rate (if specialty_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "99417"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "11"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE IN ('C', 'N')
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "99417"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "11"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE IN ('C', 'N')
                    AND SPECIALTY_CD = "10401"
            )
            THEN "10401"
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- non standard rate (if provider_type_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "99417"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "11"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE IN ('C', 'N')
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "99417"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "11"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE IN ('C', 'N')
                    AND SPECIALTY_CD = "10401"
            )
            THEN "10401"
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- else 
SELECT
  payment_method_cd,
  service_group_changed_ind,
  service_grouping_priority_nbr,
  max(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
  SERVICE_CD = "99417"
  AND SERVICE_TYPE_CD = "CPT4"
  AND PLACE_OF_SERVICE_CD = "11"
  AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
  AND PROVIDER_BUSINESS_GROUP_NBR = 
  AND CONTRACT_TYPE IN ('C', 'N')
GROUP BY payment_method_cd, service_group_changed_ind, service_grouping_priority_nbr;

-- Default rate (if specialty_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "99417"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "11"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE = 'D'
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "99417"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "11"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE = 'D'
                    AND SPECIALTY_CD = "10401"
            )
            THEN "10401"
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- default_rate (if provider_type_cd) 
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "99417"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "11"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE = 'D'
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "99417"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "11"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE = 'D'
                    AND SPECIALTY_CD = "PH"
            )
            THEN "PH"
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- else 
SELECT
  payment_method_cd,
  service_group_changed_ind,
  service_grouping_priority_nbr,
  max(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
  SERVICE_CD = "99417"
  AND SERVICE_TYPE_CD = "CPT4"
  AND PLACE_OF_SERVICE_CD = "11"
  AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
  AND PROVIDER_BUSINESS_GROUP_NBR = 
  AND CONTRACT_TYPE = 'D' 
GROUP BY payment_method_cd, service_group_changed_ind, service_grouping_priority_nbr;


-- Row number: 1133

-- OON
SELECT MAX(RATE) AS RATE
FROM CET_OON
WHERE
    SERVICE_CD = "99459"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "11"
    AND ZIP_CODE_UN = "27713";

-- Claim Based
SELECT MAX(RATE) AS RATE
FROM `prv_ps_ce_dec_hcb_dev.CET_CLAIM_BASED_AMOUNTS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 9018694
    AND NETWORK_ID = "00606"
    AND PLACE_OF_SERVICE_CD = "11"
    AND SERVICE_CD = "99459"
    AND SERVICE_TYPE_CD = "CPT4";

-- provider table (if specialty_cd)
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 9018694
    AND NETWORK_ID = "00606"
    AND SERVICE_LOCATION_NBR = 4045564
    AND SPECIALTY_CD = 
    (       SELECT CASE WHEN EXISTS 
                (SELECT 1 
                FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS` 
                WHERE PROVIDER_IDENTIFICATION_NBR = 9018694 
                    AND NETWORK_ID = "00606" 
                    AND SERVICE_LOCATION_NBR = 4045564  
                    AND SPECIALTY_CD = ""
                ) 
                THEN "" ELSE '' END
    );

-- provider table (if provider_type_cd)
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 9018694
    AND NETWORK_ID = "00606"
    AND SERVICE_LOCATION_NBR = 4045564
    AND PROVIDER_TYPE_CD = "NP";

-- else
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 9018694
    AND NETWORK_ID = "00606"
    AND SERVICE_LOCATION_NBR = 4045564;

-- standard rate 
SELECT Max(RATE) AS RATE
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    RATE_SYSTEM_CD = "ARy%Nh(q:"
    AND SERVICE_CD = "99459"
    AND SERVICE_TYPE_CD = "CPT4"
    AND GEOGRAPHIC_AREA_CD = "27713"
    AND PLACE_OF_SERVICE_CD = "11"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND CONTRACT_TYPE = 'S';

-- non standard rate (if specialty_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "99459"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "11"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE IN ('C', 'N')
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "99459"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "11"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE IN ('C', 'N')
                    AND SPECIALTY_CD = ""
            )
            THEN ""
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- non standard rate (if provider_type_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "99459"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "11"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE IN ('C', 'N')
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "99459"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "11"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE IN ('C', 'N')
                    AND SPECIALTY_CD = ""
            )
            THEN ""
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- else 
SELECT
  payment_method_cd,
  service_group_changed_ind,
  service_grouping_priority_nbr,
  max(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
  SERVICE_CD = "99459"
  AND SERVICE_TYPE_CD = "CPT4"
  AND PLACE_OF_SERVICE_CD = "11"
  AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
  AND PROVIDER_BUSINESS_GROUP_NBR = 
  AND CONTRACT_TYPE IN ('C', 'N')
GROUP BY payment_method_cd, service_group_changed_ind, service_grouping_priority_nbr;

-- Default rate (if specialty_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "99459"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "11"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE = 'D'
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "99459"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "11"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE = 'D'
                    AND SPECIALTY_CD = ""
            )
            THEN ""
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- default_rate (if provider_type_cd) 
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "99459"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "11"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE = 'D'
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "99459"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "11"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE = 'D'
                    AND SPECIALTY_CD = "NP"
            )
            THEN "NP"
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- else 
SELECT
  payment_method_cd,
  service_group_changed_ind,
  service_grouping_priority_nbr,
  max(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
  SERVICE_CD = "99459"
  AND SERVICE_TYPE_CD = "CPT4"
  AND PLACE_OF_SERVICE_CD = "11"
  AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
  AND PROVIDER_BUSINESS_GROUP_NBR = 
  AND CONTRACT_TYPE = 'D' 
GROUP BY payment_method_cd, service_group_changed_ind, service_grouping_priority_nbr;


-- Row number: 1147

-- OON
SELECT MAX(RATE) AS RATE
FROM CET_OON
WHERE
    SERVICE_CD = "93798"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "22"
    AND ZIP_CODE_UN = "27607";

-- Claim Based
SELECT MAX(RATE) AS RATE
FROM `prv_ps_ce_dec_hcb_dev.CET_CLAIM_BASED_AMOUNTS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 6380685
    AND NETWORK_ID = "00606"
    AND PLACE_OF_SERVICE_CD = "22"
    AND SERVICE_CD = "93798"
    AND SERVICE_TYPE_CD = "CPT4";

-- provider table (if specialty_cd)
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 6380685
    AND NETWORK_ID = "00606"
    AND SERVICE_LOCATION_NBR = 111426
    AND SPECIALTY_CD = 
    (       SELECT CASE WHEN EXISTS 
                (SELECT 1 
                FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS` 
                WHERE PROVIDER_IDENTIFICATION_NBR = 6380685 
                    AND NETWORK_ID = "00606" 
                    AND SERVICE_LOCATION_NBR = 111426  
                    AND SPECIALTY_CD = ""
                ) 
                THEN "" ELSE '' END
    );

-- provider table (if provider_type_cd)
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 6380685
    AND NETWORK_ID = "00606"
    AND SERVICE_LOCATION_NBR = 111426
    AND PROVIDER_TYPE_CD = "HO";

-- else
SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR, PROVIDER_BUSINESS_GROUP_SCORE_NBR, PROVIDER_IDENTIFICATION_NBR,PRODUCT_CD, SERVICE_LOCATION_NBR, NETWORK_ID, RATING_SYSTEM_CD, EPDB_GEOGRAPHIC_AREA_CD
FROM `prv_ps_ce_dec_hcb_dev.CET_PROVIDERS`
WHERE
    PROVIDER_IDENTIFICATION_NBR = 6380685
    AND NETWORK_ID = "00606"
    AND SERVICE_LOCATION_NBR = 111426;

-- standard rate 
SELECT Max(RATE) AS RATE
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    RATE_SYSTEM_CD = "Ok+9S}AL-"
    AND SERVICE_CD = "93798"
    AND SERVICE_TYPE_CD = "CPT4"
    AND GEOGRAPHIC_AREA_CD = "27607"
    AND PLACE_OF_SERVICE_CD = "22"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND CONTRACT_TYPE = 'S';

-- non standard rate (if specialty_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "93798"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "22"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE IN ('C', 'N')
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "93798"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "22"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE IN ('C', 'N')
                    AND SPECIALTY_CD = ""
            )
            THEN ""
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- non standard rate (if provider_type_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "93798"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "22"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE IN ('C', 'N')
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "93798"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "22"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE IN ('C', 'N')
                    AND SPECIALTY_CD = ""
            )
            THEN ""
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- else 
SELECT
  payment_method_cd,
  service_group_changed_ind,
  service_grouping_priority_nbr,
  max(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
  SERVICE_CD = "93798"
  AND SERVICE_TYPE_CD = "CPT4"
  AND PLACE_OF_SERVICE_CD = "22"
  AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
  AND PROVIDER_BUSINESS_GROUP_NBR = 
  AND CONTRACT_TYPE IN ('C', 'N')
GROUP BY payment_method_cd, service_group_changed_ind, service_grouping_priority_nbr;

-- Default rate (if specialty_cd)
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "93798"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "22"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE = 'D'
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "93798"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "22"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE = 'D'
                    AND SPECIALTY_CD = ""
            )
            THEN ""
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- default_rate (if provider_type_cd) 
SELECT
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr,
    MAX(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
    SERVICE_CD = "93798"
    AND SERVICE_TYPE_CD = "CPT4"
    AND PLACE_OF_SERVICE_CD = "22"
    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
    AND PROVIDER_BUSINESS_GROUP_NBR = 
    AND CONTRACT_TYPE = 'D'
    AND SPECIALTY_CD = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
                WHERE SERVICE_CD = "93798"
                    AND SERVICE_TYPE_CD = "CPT4"
                    AND PLACE_OF_SERVICE_CD = "22"
                    AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
                    AND PROVIDER_BUSINESS_GROUP_NBR = 
                    AND CONTRACT_TYPE = 'D'
                    AND SPECIALTY_CD = "HO"
            )
            THEN "HO"
            ELSE ''
        END
    )
GROUP BY
    payment_method_cd,
    service_group_changed_ind,
    service_grouping_priority_nbr;

-- else 
SELECT
  payment_method_cd,
  service_group_changed_ind,
  service_grouping_priority_nbr,
  max(rate) AS rate
FROM `prv_ps_ce_dec_hcb_dev.CET_RATES`
WHERE
  SERVICE_CD = "93798"
  AND SERVICE_TYPE_CD = "CPT4"
  AND PLACE_OF_SERVICE_CD = "22"
  AND (PRODUCT_CD = "" OR PRODUCT_CD = 'ALL')
  AND PROVIDER_BUSINESS_GROUP_NBR = 
  AND CONTRACT_TYPE = 'D' 
GROUP BY payment_method_cd, service_group_changed_ind, service_grouping_priority_nbr;