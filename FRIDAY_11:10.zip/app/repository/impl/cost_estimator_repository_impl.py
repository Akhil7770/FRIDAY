from app.repository.cost_estimator_repository import CostEstimatorRepositoryInterface
from app.database.spanner_client import SpannerClient
from app.config.database_config import spanner_config
from app.config.queries import RATE_QUERIES
from app.core.logger import logger
from tenacity import retry, stop_after_attempt, wait_exponential
from app.core.circuitbreaker.circuit_breaker import circuit_breaker
from app.core.observability import response_time
from app.models.rate_criteria import CostEstimatorRateCriteria, NegotiatedRate
from typing import Any, Optional, List
from app.core.constants import (
    PERCENTAGE_PAYMENT_METHOD_CODES,
    PAYMENT_METHOD_HIERARCHY_CACHE_KEY,
    RATE_TYPE_PERCENTAGE,
    RATE_TYPE_AMOUNT,
    PCP_SPECIALTY_CODES_CACHE_KEY,
)


class CostEstimatorRepositoryImpl(CostEstimatorRepositoryInterface):
    def __init__(self):
        """Initialize repository with Spanner client."""
        if not spanner_config.is_valid():
            raise ValueError(
                "Invalid Spanner configuration. Please check environment variables."
            )

        self.db = SpannerClient(
            project_id=spanner_config.project_id,
            instance_id=spanner_config.instance_id,
            database_id=spanner_config.database_id,
            max_workers=40,  # Increase for better parallelism
        )

        # Initialize cache as instance variable instead of on db object
        self._cache = {}

    @circuit_breaker("rate_repository")
    @retry(
        stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=4, max=10)
    )
    @response_time("spanner_rate_repository", "get_rate")
    async def get_rate(
        self, rate_criteria: CostEstimatorRateCriteria, *args, **kwargs
    ) -> NegotiatedRate:
        """
        Retrieve the rate based on network status and criteria.

        Args:
            is_out_of_network: Whether to get out-of-network rate
            rate_criteria: Criteria for rate lookup
            *args: Variable length argument list
            **kwargs: Arbitrary keyword arguments

        Returns:
            NegotiatedRate: The negotiated rate object
        """

        # Try claim-based rate first - provide default values for missing parameters
        params = self._build_rate_params(rate_criteria)

        # Initialize negotiated_rate to avoid undefined variable errors
        negotiated_rate = None

        # Try out-of-network rate first
        if rate_criteria.isOutofNetwork:
            out_of_network_result = await self._get_out_of_network_rate(params)
            negotiated_rate = self.build_negotiated_rate(out_of_network_result)
            if negotiated_rate.isRateFound:
                return negotiated_rate
            else:
                logger.info("No out-of-network rate found")
        else:
            # Try claim-based rate next
            claim_result = await self._get_claim_based_rate(params)

            # Check if claim-based rate was found
            negotiated_rate = self.build_negotiated_rate(claim_result)
            if negotiated_rate.isRateFound:

                return negotiated_rate
            else:
                logger.info(
                    "No claim-based rate found, proceeding to get provider info"
                )

            params = self._add_optional_provider_params(rate_criteria, params)
            provider_info_result = await self._get_provider_info(params)

            # if "providerspecialtycode" in params:
            #     del params["providerspecialtycode"]
            # if "providertype" in params:
            #     del params["providertype"]

            # Extract provider information and update params
            updated_params = self._extract_provider_info_and_update_params(
                provider_info_result, params
            )

            if updated_params and "contracttype" in updated_params:
                contract_type = updated_params["contracttype"]
                del updated_params["contracttype"]
                if contract_type == "S":
                    del updated_params["providerbusinessgroupnbr"]
                    get_standard_rate = await self._get_standard_rate(updated_params)
                    negotiated_rate = self.build_negotiated_rate(get_standard_rate)
                else:
                    # You need to get the rate from somewhere - this might need adjustment
                    get_non_standard_rate = await self._get_non_standard_rate(
                        updated_params
                    )
                    negotiated_rate = self.build_negotiated_rate(get_non_standard_rate)
                    if not negotiated_rate.isRateFound:
                        get_default_rate = await self._get_default_rate(updated_params)
                        negotiated_rate = self.build_negotiated_rate(get_default_rate)
            else:
                # No provider info found, create a default negotiated rate
                negotiated_rate = NegotiatedRate(
                    paymentMethod="",
                    rate=0.0,
                    isRateFound=False,
                    rateType="",
                    isProviderInfoFound=False,
                )

        return negotiated_rate

    def find_max_score_value(self, result):
        #  Initialise the max_score as None, if this is None till the end, it means that all the scores were null
        max_score = None
        for row in result:
            pbg_score = row["PROVIDER_BUSINESS_GROUP_SCORE_NBR"]
            if pbg_score is None or pbg_score == "" or not pbg_score:
                continue
            if max_score is None:
                max_score = pbg_score
            else:
                max_score = max(max_score, pbg_score)
        return max_score

    def get_pbg_with_highest_pbg_score(self, result):
        # Custom function to find maximum score because result can containe null values too
        max_score_value = self.find_max_score_value(result)

        # If the max score we got comes out to be None, return the result as it is, this will lead our code to find standard rate
        if max_score_value is None:
            logger.warning(
                "All the PROVIDER_BUSINESS_GROUP_SCORE_NBR values were NONE in the PROVIDER_INFO RESULT"
            )
            return result
        result = [
            row
            for row in result
            if row["PROVIDER_BUSINESS_GROUP_SCORE_NBR"] == max_score_value
        ]
        return result

    async def _get_provider_info(self, params):
        try:
            if "providerspecialtycode" in params:
                provider_info_query = RATE_QUERIES.get(
                    "get_provider_info_with_specialty_cd"
                )
            elif "providertype" in params:
                provider_info_query = RATE_QUERIES.get(
                    "get_provider_info_with_provider_type_cd"
                )
            else:
                provider_info_query = RATE_QUERIES.get("get_provider_info")

            if not provider_info_query:
                logger.error("get_provider_info not found in RATE_QUERIES")
                return []

            result = await self.db.execute_query(provider_info_query, params)

            if len(result) > 1:
                result = self.get_pbg_with_highest_pbg_score(result)

            return result
        except Exception as e:
            logger.error("Error in _get_provider_info: %s", str(e))
            return []

    async def _get_out_of_network_rate(self, params):
        try:
            out_of_network_query = RATE_QUERIES.get("get_out_of_network_rate")
            if not out_of_network_query:
                logger.error("get_out_of_network_rate not found in RATE_QUERIES")
                return []
            result = await self.db.execute_query(out_of_network_query, params)
            return result
        except Exception as e:
            logger.error("Error in _get_out_of_network_rate: %s", str(e))
            return []

    async def _get_claim_based_rate(self, params):
        try:

            claim_query = RATE_QUERIES.get("get_claim_based_rate")
            if not claim_query:
                logger.error("get_claim_based_rate not found in RATE_QUERIES")
                return []
            # Execute the actual query with parameters
            result = await self.db.execute_query(claim_query, params)

            return result
        except Exception as e:
            logger.error("Error in _get_claim_based_rate: %s", str(e))
            return []

    def select_rate_query(self, contract_type, params):
        query = ""
        if contract_type == "N":
            if "providerspecialtycode" in params:
                query = RATE_QUERIES.get("get_non_standard_rate_with_specialty_cd")
            elif "providertype" in params:
                query = RATE_QUERIES.get("get_non_standard_rate_with_provider_type_cd")
            else:
                query = RATE_QUERIES.get("get_non_standard_rate")
        elif contract_type == "D":
            if "providerspecialtycode" in params:
                query = RATE_QUERIES.get("get_default_rate_with_specialty_cd")
            elif "providertype" in params:
                query = RATE_QUERIES.get("get_default_rate_with_provider_type_cd")
            else:
                query = RATE_QUERIES.get("get_default_rate")
        return query

    async def _get_non_standard_rate(self, params):
        try:
            non_standard_query = self.select_rate_query("N", params)
            if not non_standard_query:
                logger.error("get_non_standard_rate not found in RATE_QUERIES")
                return []
            result = await self.db.execute_query(non_standard_query, params)

            # If result has more than 1 payment method, use hierarchy to get best one
            if len(result) > 1:
                result = await self._select_payment_method(result)
                if result:
                    return [result]  # Return as list to maintain consistency
                else:
                    return []
            else:
                return result
        except Exception as e:
            logger.error("Error in _get_non_standard_rate: %s", str(e))
            return []

    async def _get_standard_rate(self, params):
        try:
            standard_query = RATE_QUERIES.get("get_standard_rate")
            if not standard_query:
                logger.error("get_standard_rate not found in RATE_QUERIES")
                return []
            result = await self.db.execute_query(standard_query, params)
            return result
        except Exception as e:
            logger.error("Error in _get_standard_rate: %s", str(e))
            return []

    async def _get_default_rate(self, params):
        try:
            default_query = self.select_rate_query("D", params)
            if not default_query:
                logger.error("get_default_rate not found in RATE_QUERIES")
                return []
            result = await self.db.execute_query(default_query, params)
            # If result has more than 1 payment method, use hierarchy to get best one
            if len(result) > 1:
                result = await self._select_payment_method(result)
                if result:
                    return [result]  # Return as list to maintain consistency
                else:
                    return []
            else:
                return result
        except Exception as e:
            logger.error("Error in _get_default_rate: %s", str(e))
            return []

    async def _validate_and_load_hierarchy(self):
        """Validate cache and load hierarchy if needed."""
        # Try to get hierarchy from cache
        hierarchy = self._cache.get(PAYMENT_METHOD_HIERARCHY_CACHE_KEY, {})

        # If hierarchy is empty, load it from database
        if not hierarchy:
            logger.warning(
                "Cached payment method hierarchy is empty! Loading from database..."
            )
            await self.load_payment_method_hierarchy()
            hierarchy = self._cache.get(PAYMENT_METHOD_HIERARCHY_CACHE_KEY, {})

        return hierarchy

    def select_rate_when_scores_are_equal(self, result):
        """
        Choose the best row from the list of rows with equal scores.
        """

        (
            rows_with_service_group_changed_ind_is_Y,
            rows_with_service_group_changed_ind_is_N,
        ) = ([], [])

        for row in result:
            if row.get("service_group_changed_ind") == "Y":
                rows_with_service_group_changed_ind_is_Y.append(row)
            elif row.get("service_group_changed_ind") == "N":
                rows_with_service_group_changed_ind_is_N.append(row)

        if rows_with_service_group_changed_ind_is_Y:
            return max(
                rows_with_service_group_changed_ind_is_Y, key=lambda x: x.get("rate", 0)
            )

        if rows_with_service_group_changed_ind_is_N:

            # If there are multiple non-standard rates with the same priority, select the best one
            max_service_grouping_priority_nbr = max(
                row.get("service_grouping_priority_nbr", 0)
                for row in rows_with_service_group_changed_ind_is_N
            )
            # Filter to get only the top priority rates
            rows_with_max_service_grouping_priority_nbr = [
                row
                for row in rows_with_service_group_changed_ind_is_N
                if row.get("service_grouping_priority_nbr", 0)
                == max_service_grouping_priority_nbr
            ]
            return max(
                rows_with_max_service_grouping_priority_nbr,
                key=lambda x: x.get("rate", 0),
            )

        return result[0] if result else None

    async def _select_payment_method(self, result):
        """
        Optimized selection of the best payment method based on cached hierarchy score.

        Args:
            result: List of rows, each with payment method code and rate

        Returns:
            The row with the highest hierarchy score, or None if not found
        """

        if not result:
            return None

        hierarchy = await self._validate_and_load_hierarchy()
        if not hierarchy:
            logger.error("Failed to load payment method hierarchy from database")
            return None

        # Build a list of tuples: (score, row)
        scored_rows = []
        for row in result:
            # Access by column name instead of index
            payment_method_code = row.get(
                "payment_method_cd", row.get("PAYMENT_METHOD_CD", "")
            )
            score = self.get_cached_payment_method_score(payment_method_code)

            if score is not None:
                scored_rows.append((score, row))
            else:
                logger.warning(
                    "Payment Method %s not found in hierarchy", payment_method_code
                )

        if not scored_rows:
            logger.warning("No valid payment methods found in cache hierarchy")
            return None

        # Select best highest score
        max_payment_method_score = max(scored_rows, key=lambda x: x[0])[0]

        # Select the row with the highest score
        rows_with_highest_payment_method_score = [
            row for score, row in scored_rows if score == max_payment_method_score
        ]

        if len(rows_with_highest_payment_method_score) > 1:
            return self.select_rate_when_scores_are_equal(
                rows_with_highest_payment_method_score
            )
        return (
            rows_with_highest_payment_method_score[0]
            if rows_with_highest_payment_method_score
            else None
        )

    def build_negotiated_rate(self, result) -> NegotiatedRate:
        """
        Build a NegotiatedRate object from query result.
        """

        if not result or len(result) == 0:
            return NegotiatedRate(
                paymentMethod="",
                rate=0.0,
                isRateFound=False,
                rateType="",
                isProviderInfoFound=True,
            )

        first_row = result[0]
        rate = first_row.get("rate", first_row.get("RATE", 0))

        if rate is None or rate == "":
            return NegotiatedRate(
                paymentMethod="",
                rate=0.0,
                isRateFound=False,
                rateType="",
                isProviderInfoFound=True,
            )

        paymentMethod = first_row.get(
            "payment_method_cd", first_row.get("PAYMENT_METHOD_CD", "")
        )
        # Determine rate type based on payment method
        if paymentMethod.strip() in PERCENTAGE_PAYMENT_METHOD_CODES:
            rateType = RATE_TYPE_PERCENTAGE
        else:
            rateType = RATE_TYPE_AMOUNT

        return NegotiatedRate(
            paymentMethod=str(paymentMethod),
            rate=float(rate),
            isRateFound=True,
            rateType=rateType,
            isProviderInfoFound=True,
        )

    def _extract_provider_info_and_update_params(self, result, params):
        """
        Extract provider information and update query parameters.

        Args:
            result: Query result with format [{'PROVIDER_BUSINESS_GROUP_NBR': 'None', 'PRODUCT_CD': 'MHMO', 'RATING_SYSTEM_CD': 'REF', 'EPDB_GEOGRAPHIC_AREA_CD': 'MD01'}, ...]
            params: Original query parameters

        Returns:
            Updated parameters dictionary with provider data, or None if no provider data found
        """
        if not result or len(result) == 0:
            return None

        updated_params = params.copy()

        # Remove keys from dictionary using del
        if "provideridentificationnumber" in updated_params:
            del updated_params["provideridentificationnumber"]
        if "networkid" in updated_params:
            del updated_params["networkid"]
        if "servicelocationnumber" in updated_params:
            del updated_params["servicelocationnumber"]

        # Get first row of provider data
        providerbusinessgroupnbr_list = []
        for i, row in enumerate(result):
            if i == 0:
                # Access values by column name instead of index
                provider_business_group_nbr = row.get("PROVIDER_BUSINESS_GROUP_NBR")
                product_cd = row.get("PRODUCT_CD")
                rating_system_cd = row.get("RATING_SYSTEM_CD")
                geographic_area_cd = row.get("EPDB_GEOGRAPHIC_AREA_CD")

                if all([product_cd, rating_system_cd, geographic_area_cd]):
                    # Determine contract type based on provider_business_group_nbr
                    if (
                        provider_business_group_nbr == "None"
                        or provider_business_group_nbr == ""
                        or not provider_business_group_nbr
                    ):
                        contract_type = "S"
                    else:
                        contract_type = "N"
                    updated_params.update(
                        {
                            "productcd": product_cd,  # Product Code
                            "ratesystemcd": rating_system_cd,  # Rating System Code
                            "geographicareacd": geographic_area_cd,  # Geographic Area Code
                            "contracttype": contract_type,
                        }
                    )
                else:
                    logger.warning("Row has insufficient columns: %s", row)
                    return None
            providerbusinessgroupnbr_list.append(row.get("PROVIDER_BUSINESS_GROUP_NBR"))

        updated_params.update(
            {"providerbusinessgroupnbr": providerbusinessgroupnbr_list}
        )

        return updated_params

    def _build_rate_params(self, rate_criteria: CostEstimatorRateCriteria) -> dict:
        """
        Build rate parameters from rate criteria.

        Args:
            rate_criteria: Rate criteria object

        Returns:
            Dictionary of rate parameters
        """
        if rate_criteria.isOutofNetwork:
            return {
                "servicecd": rate_criteria.serviceCode,
                "placeofservice": rate_criteria.placeOfService,
                "servicetype": rate_criteria.serviceType,
                "zipcode": rate_criteria.zipCode,
            }
        else:
            return {
                "servicecd": rate_criteria.serviceCode,
                "provideridentificationnumber": rate_criteria.providerIdentificationNumber,
                "placeofservice": rate_criteria.placeOfService,
                "servicetype": rate_criteria.serviceType,
                "networkid": rate_criteria.networkId,
                "servicelocationnumber": rate_criteria.serviceLocationNumber,
            }

    def _add_optional_provider_params(
        self, rate_criteria: CostEstimatorRateCriteria, params
    ) -> dict:
        if (
            rate_criteria.providerSpecialtyCode
            and rate_criteria.providerSpecialtyCode != ""
        ):
            params["providerspecialtycode"] = rate_criteria.providerSpecialtyCode
        if rate_criteria.providerType and rate_criteria.providerType != "":
            params["providertype"] = rate_criteria.providerType
        return params

    async def load_payment_method_hierarchy(self):
        """Load payment method hierarchy from Spanner into cache, optimized to avoid unnecessary DB calls."""
        # Check if already cached and not empty
        cached = self._cache.get(PAYMENT_METHOD_HIERARCHY_CACHE_KEY)
        # NOTE: WHY IS THIS HERE? WON'T THIS CAUSE CACHE TO NEVER BE REFRESHED?
        if cached and isinstance(cached, dict) and len(cached) > 0:
            return

        payment_info_query = RATE_QUERIES.get("get_payment_method_hierarchy")
        if not payment_info_query:
            logger.error("get_payment_method_hierarchy not found in RATE_QUERIES")
            return []
        try:
            result = await self.db.execute_query(payment_info_query)
            hierarchy = {
                row.get("payment_method_cd", row.get("PAYMENT_METHOD_CD", "")): row.get(
                    "score", row.get("SCORE", 0)
                )
                for row in result
                if row.get("payment_method_cd") is not None
                and row.get("score") is not None
            }
            self._cache[PAYMENT_METHOD_HIERARCHY_CACHE_KEY] = hierarchy
        except Exception as e:
            logger.error("Failed to load payment method hierarchy: %s", str(e))

    def get_cached_payment_method_score(self, payment_method_cd: str) -> Optional[int]:
        return self._cache.get(PAYMENT_METHOD_HIERARCHY_CACHE_KEY, {}).get(
            payment_method_cd
        )

    async def load_pcp_specialty_codes(self):
        query = "SELECT SPECIALTY_CODE FROM CET_PCP_SPECIALTY_CODE"
        try:
            result = await self.db.execute_query(query)
            self._cache[PCP_SPECIALTY_CODES_CACHE_KEY] = [
                row["SPECIALTY_CODE"] for row in result
            ]
        except Exception as e:
            logger.error("Failed to load pcp specialty codes: %s", str(e))

    def get_cached_pcp_specialty_codes(self) -> List[str]:
        return self._cache.get(PCP_SPECIALTY_CODES_CACHE_KEY, [])

    def _is_float(self, value: Any) -> bool:
        try:
            float(value)
            return True
        except (TypeError, ValueError):
            return False
