from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any
from datetime import datetime
from app.models.selected_benefit import SelectedBenefit
from app.schemas.accumulator_response import Accumulator as MatchedAccumulator

@dataclass
class TraceEntry:
    """Single trace entry for debugging"""

    timestamp: datetime = field(default_factory=datetime.now)
    step: str = ""
    description: str = ""
    values: Dict[str, Any] = field(default_factory=dict)

    def __str__(self):
        return f"[{self.timestamp.strftime('%H:%M:%S.%f')[:-3]}] {self.step}: {self.description}"


@dataclass
class InsuranceContext:
    """Context containing all data needed for insurance calculations"""

    # Input data
    service_amount: float = 0.0
    is_service_covered: bool = False

    has_limit_accum: bool = False
    has_oopmax_accum: bool = False

    # Values come from Benefits API
    benefit_id: str = ""
    # Indicates the amount of money that a patient is required to contribute towards the use of a given benefit.
    # Member pay a fixed amount per service.
    # we expect to see the value to use it in costshare calculation
    # Decimal  Values are possible for this field. for example 50.50
    # we are only expecting values and it is implied that for pay it is a $$ value.
    # If it is a whole number then send whole number instead of sending 20.00
    cost_share_copay: float = 0.0
    # The percentage of cost which is the responsibility of the patient towards a given benefit.
    # Member pay % for each service rendered.
    # Whole number always. Fraction values are not supported. we are only expecting values and it is implied that for co-insurance it is a percentage
    cost_share_coinsurance: float = 0.0  # percentage (e.g., 20.0 for 20%)
    # "Does Copay count towards OOP Limit Max.
    # Indicates if Copay will apply to Out of pocket max. It is always Y or N.
    # If it is Y , then we will take Copay and will apply to OOP Max
    # LOBs can send Null or Blank in this field, then IIB/Enterprise will assume it as a N and send it to HSQ
    # HSQ would always receive the field as Y or N
    copay_applies_oop: bool = False
    # "This indicates if the CoInsurance amount will apply to Out Of Pocket. It is always Y or N.
    # If it is Y , then we will take CoInsurance and will apply to OOP Max
    # LObs can send Null or Blank in this field, then IIB/Enterprise will assume it as a N and send it to HSQ
    # HSQ would always receive the field as Y or N"
    coins_applies_oop: bool = False
    # Indicates if the deductible applies to Out Of Pocket max Other. It is always Y or N.
    # If it is Y , then we will take Deductible and will apply to OOP Max other
    # LObs can send Null or Blank in this field, then IIB/Enterprise will assume it as a N and send it to HSQ
    # HSQ would always receive the field as Y or N
    # Meritain has a bucket called other. Check with Meritain on the correct definition of the concept of Other and also get an example from Meritain when does it apply.
    # commercial doesn't have this field.
    deductible_applies_oop: bool = False

    copay_continue_when_oop_met: bool = False
    # Does Copay continue after deductible has been met.
    # If Y then Copay will continue to be charged even when member has met their Deductible.
    # It is always Y or N.
    # LOBs can send Null or Blank in this field, then IIB/Enterprise will assume it as a N and send it to HSQ
    # HSQ would always receive the field as Y or N
    copay_continue_when_deductible_met: bool = False
    # Does Copay count towards deductible
    # If Y then Copay will count towards the deductible
    # It is always Y or N.
    copay_count_to_deductible: bool = False
    # Indicates if Deductible should apply before Copay applies.
    # If this indicator is "Y", check if deductible has been met. If so, charge the amount towards Copay.
    is_deductible_before_copay: bool = False
    # is has_limit_accum , has_oopmax_accum part of benefit code
    # we have limit, deductible and oopmax code.
    accum_code: set[str] = field(default_factory=set)
    # level : Individual, Family
    accum_level: set[str] = field(default_factory=set)

    # Values come from Accum API

    # A value that is precalculated in the backend to be carried forward, usually based on the difference between currentValue and limitValue.
    # E.x - If the limitValue is $400 and the currentValue is $100, the calculatedValue is $300.
    # Meritain would give $100, and $400. do they also needs to calculate the difference or Enterprise solution will do that? and when is it not difference b/w current value and Limit value. Any ither scenario?
    oopmax_family_calculated: Optional[float] = None
    # A value that is precalculated in the backend to be carried forward, usually based on the difference between currentValue and limitValue.
    # E.x - If the limitValue is $400 and the currentValue is $100, the calculatedValue is $300.
    # Meritain would give $100, and $400. do they also needs to calculate the difference or Enterprise solution will do that? and when is it not difference b/w current value and Limit value. Any ither scenario?
    oopmax_individual_calculated: Optional[float] = None
    # min of oopmax_individual_calculated and oopmax_family_calculated
    min_oopmax: Optional[float] = None
    # A value that is precalculated in the backend to be carried forward, usually based on the difference between currentValue and limitValue.
    # E.x - If the limitValue is $400 and the currentValue is $100, the calculatedValue is $300.
    # Meritain would give $100, and $400. do they also needs to calculate the difference or Enterprise solution will do that? and when is it not difference b/w current value and Limit value. Any ither scenario?
    deductible_individual_calculated: Optional[float] = None  # can be None
    # A value that is precalculated in the backend to be carried forward, usually based on the difference between currentValue and limitValue.
    # E.x - If the limitValue is $400 and the currentValue is $100, the calculatedValue is $300.
    # Meritain would give $100, and $400. do they also needs to calculate the difference or Enterprise solution will do that? and when is it not difference b/w current value and Limit value. Any ither scenario?
    deductible_family_calculated: Optional[float] = None  # can be None
    # The maximum value that an accumulator can contain,before the accumulator can be considered "met" or "fulfilled".
    # Ex- The limit/threshold amount of a deductible is $400.00. When the accumulation amount sums upto $400 , the deductible is said to be "met".
    limit_calculated: Optional[float] = None
    limit_type: Optional[str] = None  # counter, dollar
    # Optional field will only be populated when the plan requires a variable number of members to meet a phase. It signifies the number of Individuals who have met a phase.
    numOfIndividualsMet: Optional[int] = None
    # Optional field will only be populated when the plan requires a variable number of members to meet a phase. It signifies the number of Individuals who needed to meet a phase.
    numOfIndividualsNeededToMeet: Optional[int] = None

    # Results that will be populated
    member_pays: float = 0
    # calc_copay in flowchart
    amount_copay: float = 0.0
    # calc_coinsurance in flowchart
    amount_coinsurance: float = 0.0

    # Tracking for calculation flow
    calculation_complete: bool = False

    # Tracing functionality
    trace_entries: List[TraceEntry] = field(default_factory=list)
    trace_enabled: bool = True

    # Handler reference for processing
    handler: Optional["Handler"] = None

    # Tracking error
    error_code: Optional[str] = None
    error_message: Optional[str] = None

    def get_limit_matched_accum_object(
        self, benefit: SelectedBenefit
    ) -> Optional[MatchedAccumulator]:
        """Fetch the matched accumulator object for code 'limit'."""
        if not benefit.coverage.matchedAccumulators:
            return None
        for accum in benefit.coverage.matchedAccumulators:
            if hasattr(accum, "code") and str(accum.code).lower() == "limit":
                self.accum_code.add("limit")
                return accum
        return None

    def get_deductible_individual(
        self, benefit: SelectedBenefit
    ) -> Optional[MatchedAccumulator]:
        """Fetch the matched accumulator object for code 'Deductible'."""
        if not benefit.coverage.matchedAccumulators:
            return None
        for accum in benefit.coverage.matchedAccumulators:
            if (
                hasattr(accum, "code")
                and str(accum.code).lower() == "deductible"
                and accum.level is not None
                and accum.level.lower() == "individual"
            ):
                self.accum_code.add("deductible")
                self.accum_level.add("deductible_individual")
                return accum
        return None

    def get_deductible_family(
        self, benefit: SelectedBenefit
    ) -> Optional[MatchedAccumulator]:
        """Fetch the matched accumulator object for code 'Deductible'."""
        if not benefit.coverage.matchedAccumulators:
            return None
        for accum in benefit.coverage.matchedAccumulators:
            if (
                hasattr(accum, "code")
                and str(accum.code).lower() == "deductible"
                and accum.level is not None
                and accum.level.lower() == "family"
            ):
                self.accum_code.add("deductible")
                self.accum_level.add("deductible_family")
                return accum
        return None

    def get_oopmax_individual(
        self, benefit: SelectedBenefit
    ) -> Optional[MatchedAccumulator]:
        """Fetch the matched accumulator object for code 'OOP Max'."""
        if not benefit or not benefit.coverage.matchedAccumulators:
            return None
        for accum in benefit.coverage.matchedAccumulators:
            if (
                hasattr(accum, "code")
                and str(accum.code).lower() == "oop max"
                and accum.level is not None
                and accum.level.lower() == "individual"
            ):
                self.accum_code.add("oopmax")
                self.accum_level.add("oopmax_individual")
                return accum
        return None

    def get_oopmax_family(
        self, benefit: SelectedBenefit
    ) -> Optional[MatchedAccumulator]:
        """Fetch the matched accumulator object for code 'OOP Max'."""
        if not benefit or not benefit.coverage.matchedAccumulators:
            return None
        for accum in benefit.coverage.matchedAccumulators:
            if (
                hasattr(accum, "code")
                and str(accum.code).lower() == "oop max"
                and accum.level is not None
                and accum.level.lower() == "family"
            ):
                self.accum_code.add("oopmax")
                self.accum_level.add("oopmax_family")
                return accum
        return None

    def populate_from_benefit(
        self, benefit: SelectedBenefit, service_amount: float
    ) -> "InsuranceContext":
        """Populate InsuranceContext from a Benefit object"""
        # Map benefit coverage fields to context
        # Convert 'Y'/'N' style fields to boolean: True if 'Y', else False
        self.benefit_id = str(benefit.benefitCode)
        self.service_amount = service_amount
        self.copay_applies_oop = benefit.coverage.copayAppliesOutOfPocket == "Y"
        self.coins_applies_oop = benefit.coverage.coinsAppliesOutOfPocket == "Y"
        self.deductible_applies_oop = (
            benefit.coverage.deductibleAppliesOutOfPocket == "Y"
        )
        self.is_deductible_before_copay = (
            benefit.coverage.isDeductibleBeforeCopay == "Y"
        )
        self.has_benefit_limitation = benefit.coverage.benefitLimitation == "Y"
        self.is_service_covered = benefit.coverage.isServiceCovered == "Y"
        self.copay_continue_when_oop_met = (
            benefit.coverage.copayContinueWhenOutOfPocketMaxMetIndicator == "Y"
        )
        self.copay_continue_when_deductible_met = (
            benefit.coverage.copayContinueWhenDeductibleMetIndicator == "Y"
        )
        self.copay_count_to_deductible = (
            benefit.coverage.copayCountToDeductibleIndicator == "Y"
        )

        self.cost_share_copay = benefit.coverage.costShareCopay
        self.cost_share_coinsurance = benefit.coverage.costShareCoinsurance

        # Set benefit code from benefit - now as a set
        # self.accum_code = {str(benefit.benefitCode)}

        oopmax_family_accum = self.get_oopmax_family(benefit)
        oopmax_individual_accum = self.get_oopmax_individual(benefit)
        deductible_individual_accum = self.get_deductible_individual(benefit)
        deductible_family_accum = self.get_deductible_family(benefit)
        limit_accum = self.get_limit_matched_accum_object(benefit)

        if oopmax_family_accum:
            self.oopmax_family_calculated = oopmax_family_accum.calculatedValue
        if oopmax_individual_accum:
            self.oopmax_individual_calculated = oopmax_individual_accum.calculatedValue

        if (
            self.oopmax_family_calculated is None
            and self.oopmax_individual_calculated is not None
        ):
            self.min_oopmax = self.oopmax_individual_calculated
        elif (
            self.oopmax_individual_calculated is None
            and self.oopmax_family_calculated is not None
        ):
            self.min_oopmax = self.oopmax_family_calculated
        elif (
            self.oopmax_family_calculated is not None
            and self.oopmax_individual_calculated is not None
        ):
            self.min_oopmax = min(
                self.oopmax_individual_calculated, self.oopmax_family_calculated
            )

        if deductible_individual_accum:
            self.deductible_individual_calculated = (
                deductible_individual_accum.calculatedValue
            )
        if deductible_family_accum:
            self.deductible_family_calculated = deductible_family_accum.calculatedValue

        # Read numOfIndividualsMet and numOfIndividualsNeededToMeet from deductible accumulators
        if deductible_family_accum:
            self.numOfIndividualsMet = deductible_family_accum.numOfIndividualsMet
            self.numOfIndividualsNeededToMeet = (
                deductible_family_accum.numOfIndividualsNeededToMeet
            )
        elif deductible_individual_accum:
            self.numOfIndividualsMet = deductible_individual_accum.numOfIndividualsMet
            self.numOfIndividualsNeededToMeet = (
                deductible_individual_accum.numOfIndividualsNeededToMeet
            )

        limit_accum = self.get_limit_matched_accum_object(benefit)
        if limit_accum and limit_accum.calculatedValue is not None:
            self.limit_calculated = float(limit_accum.calculatedValue)

        # TODO: add hasLimititation true or false
        self.limit_type = limit_accum.limitType if limit_accum else None

        return self

    def trace(self, step: str, description: str = "", **kwargs):
        """Add a trace entry with current context values"""
        if not self.trace_enabled:
            return

        # Take a snapshot of all context fields (excluding trace-related fields)
        trace_values = {}

        # Get all fields from the dataclass
        import dataclasses

        for field in dataclasses.fields(self):
            field_name = field.name
            # Skip trace-related fields to avoid circular references
            if field_name not in ["trace_entries", "trace_enabled"]:
                trace_values[field_name] = getattr(self, field_name)

        # Add any additional values passed as kwargs
        trace_values.update(kwargs)

        entry = TraceEntry(step=step, description=description, values=trace_values)

        self.trace_entries.append(entry)

    def trace_decision(self, step: str, condition: str, decision: bool, **kwargs):
        """Specialized trace for boolean decisions"""
        description = f"Decision: {condition} -> {decision}"
        self.trace(step, description, condition=condition, decision=decision, **kwargs)

    def get_trace_summary(self) -> str:
        """Get a formatted summary of all trace entries"""
        if not self.trace_entries:
            return "No trace entries"

        summary = "=== Calculation Trace ===\n"
        for i, entry in enumerate(self.trace_entries):
            summary += f"{entry}\n"

            # Show changes from previous entry
            if i > 0:
                prev_values = self.trace_entries[i - 1].values
                curr_values = entry.values
                changes = {}

                for key, curr_val in curr_values.items():
                    if key in prev_values:
                        prev_val = prev_values[key]
                        if prev_val != curr_val:
                            changes[key] = f"{prev_val} -> {curr_val}"
                    elif curr_val is not None and curr_val != 0 and curr_val != "":
                        changes[key] = f"None -> {curr_val}"

                if changes:
                    summary += f"    Changes: {changes}\n"
            else:
                # For first entry, show non-default values
                non_defaults = {
                    k: v
                    for k, v in entry.values.items()
                    if v is not None and v != 0 and v != "" and v != False
                }
                if non_defaults:
                    summary += f"    Initial state: {non_defaults}\n"

            summary += "\n"

        return summary


class Handler(ABC):
    """Base handler in the chain of responsibility"""

    def __init__(self):
        self._next_handler = None

    def set_next(self, handler: "Handler") -> "Handler":
        """Set the next handler in the chain"""
        self._next_handler = handler
        return handler  # Return handler to allow chaining

    def handle(self, context: InsuranceContext) -> InsuranceContext:
        """Process this handler and pass to the next if needed"""

        # Add trace entry for new handler
        context.trace(
            self.__class__.__name__, f"Starting {self.__class__.__name__} processing"
        )

        # Process this handler's logic
        context = self.process(context)

        # If calculation is complete or there's no next handler, return
        if context.calculation_complete or self._next_handler is None:
            return context

        # Otherwise, pass to next handler
        return self._next_handler.handle(context)

    @abstractmethod
    def process(self, context: InsuranceContext) -> InsuranceContext:
        """Each concrete handler will implement this method"""
        pass
