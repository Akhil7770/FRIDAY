import time
import functools
import asyncio
from typing import Callable, Any, Optional
from app.core.logger import logger

# Import metrics from OpenTelemetry module
from .opentelemetry_metrics import (
    api_response_time_histogram,
    error_counter,
    exception_counter,
    request_counter,
)


def api_timer(operation_type: str, operation_name: str):
    """
    Generic decorator to measure API response time and record metrics.

    Args:
        operation_type: Name of the metric to record (e.g., 'benefit_api', 'accumulator_api')
        operation_name: Name of the operation for logging and tracing

    Usage:
        @api_timer('benefit_api', 'get_benefit')
        async def get_benefit(self, request):
            # API call implementation
            pass
    """

    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            start_time = time.time()
            success = False

            # Increment request counter
            if request_counter is not None:
                request_counter.add(
                    1, {"api": operation_type, "operation": operation_name}
                )

            try:
                # Execute the function
                result = await func(*args, **kwargs)
                success = True
                return result
            except Exception as e:
                # Record error metric
                if error_counter is not None:
                    error_counter.add(
                        1, {"api": operation_type, "operation": operation_name}
                    )
                logger.error(f"Error in {operation_name}: {str(e)}")
                raise
            finally:
                # Calculate response time
                response_time = time.time() - start_time

                # Record response time using API histogram
                if api_response_time_histogram is not None:
                    api_response_time_histogram.record(
                        response_time,
                        {
                            "operation_type": operation_type,
                            "operation": operation_name,
                            "success": str(success),
                        },
                    )

                # Log the timing
                logger.info(
                    f"{operation_name} completed in {response_time:.4f}s (success: {success})"
                )

        # Since all decorated functions are async, always return async_wrapper
        return async_wrapper

    return decorator


def response_time(api_type: str, operation_name: str):
    """
    Unified decorator for timing and recording metrics for both benefit and accumulator API calls.

    Args:
        api_type: 'benefit_api' or 'accumulator_api'
        operation_name: Name of the operation for logging and tracing

    Usage:
        @api_response_timer('benefit_api', 'get_benefit')
        async def get_benefit(self, request):
            ...
        @api_response_timer('accumulator_api', 'get_accumulator')
        def get_accumulator(self, request):
            ...
    """
    return api_timer(api_type, operation_name)


def exception_handler(exception_type: str, exception_name: str):
    """
    Generic decorator to record exception metrics using a single exception_counter.

    Args:
        exception_type: Type of exception (e.g., 'cost_estimation_service_exception')
        exception_name: Name of the exception to track (e.g., 'RateNotFoundException')

    Usage:
        @exception_handler('RateNotFoundException', 'RateNotFoundException')
        async def estimate_cost(self, request):
            # Your function that might raise RateNotFoundException
            pass
    """

    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            try:
                return await func(*args, **kwargs)
            except Exception as e:
                # Check if the exception matches the expected type
                if exception_name in str(type(e).__name__):
                    # Record the exception metric using generic exception_counter
                    if exception_counter is not None:
                        exception_counter.add(
                            1,
                            {
                                "api": exception_type,
                                "operation": exception_name,
                            },
                        )
                    else:
                        # Fallback to generic error counter
                        if error_counter is not None:
                            error_counter.add(
                                1,
                                {
                                    "api": exception_type,
                                    "operation": exception_name,
                                },
                            )

                    logger.warning(
                        f"{exception_name} caught in {exception_type}.{func.__name__}: {str(e)}"
                    )

                # Re-raise the exception
                raise

        @functools.wraps(func)
        def sync_wrapper(*args, **kwargs):
            # Record metrics when function is called (for exception handlers)
            if exception_counter is not None:
                exception_counter.add(
                    1,
                    {
                        "api": exception_type,
                        "operation": exception_name,
                        "exception_type": exception_name,
                        "endpoint": "/api/v1/cost-estimation",
                    },
                )
                logger.info(f"{exception_name} metric recorded in {func.__name__}")

            try:
                return func(*args, **kwargs)
            except Exception as e:
                # Check if the exception matches the expected type
                if exception_name in str(type(e).__name__):
                    # Record the exception metric using generic exception_counter
                    if exception_counter is not None:
                        exception_counter.add(
                            1,
                            {
                                "api": exception_type,
                                "operation": exception_name,
                            },
                        )
                    else:
                        # Fallback to generic error counter
                        if error_counter is not None:
                            error_counter.add(
                                1,
                                {
                                    "api": exception_type,
                                    "operation": exception_name,
                                },
                            )

                    logger.warning(
                        f"{exception_name} caught in {exception_type}.{func.__name__}: {str(e)}"
                    )

                # Re-raise the exception
                raise

        # Return appropriate wrapper based on function type
        if asyncio.iscoroutinefunction(func):
            return async_wrapper
        else:
            return sync_wrapper

    return decorator
