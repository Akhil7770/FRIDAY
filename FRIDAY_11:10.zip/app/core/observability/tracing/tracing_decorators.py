"""
Simplified tracing decorators for capturing request/response data in OpenTelemetry traces.
"""

import functools
import json
import time
from typing import Any, Callable, Dict, Optional
from opentelemetry import trace
from opentelemetry.trace import Status, StatusCode
from app.core.logger import logger


def trace_request_response(
    span_name: Optional[str] = None,
    capture_request: bool = True,
    capture_response: bool = True,
    max_request_size: int = 1024,
    max_response_size: int = 1024,
    include_headers: bool = True,
    sensitive_fields: Optional[list] = None,
):
    """
    Simplified decorator to add request/response tracing to functions.
    """

    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            tracer = trace.get_tracer(__name__)
            span_name_final = span_name or f"{func.__module__}.{func.__name__}"

            with tracer.start_as_current_span(span_name_final) as span:
                start_time = time.time()

                try:
                    # Capture request data
                    if capture_request:
                        _capture_simple_request_data(
                            span, args, kwargs, include_headers, sensitive_fields
                        )

                        # Try to capture HTTP request details from FastAPI context
                        try:
                            from fastapi import Request
                            from starlette.requests import Request as StarletteRequest

                            # Look for Request object in kwargs
                            for key, value in kwargs.items():
                                if isinstance(value, (Request, StarletteRequest)):
                                    span.set_attribute("http.method", value.method)
                                    span.set_attribute("http.url", str(value.url))
                                    span.set_attribute("http.path", value.url.path)
                                    span.set_attribute(
                                        "http.query_params", str(value.query_params)
                                    )
                                    span.set_attribute(
                                        "http.client_ip",
                                        (
                                            value.client.host
                                            if hasattr(value, "client") and value.client
                                            else "unknown"
                                        ),
                                    )
                                    break
                        except Exception as e:
                            span.set_attribute("http.capture_error", str(e))

                    # Execute the function
                    result = await func(*args, **kwargs)

                    # Capture response data
                    if capture_response:
                        _capture_simple_response_data(span, result, max_response_size)

                    # Set span status to success
                    span.set_status(Status(StatusCode.OK))

                    # Set operation name for trace storage
                    # TODO: pass in the operation name
                    span.set_attribute("operation", "cost_estimation_request")

                    # Explicitly set service name as resource attribute
                    # TODO: pass in the service name
                    # TODO: Do we need to pass in the service version?
                    span.set_attribute("service.name", "cost-estimator-calc-service")

                    return result

                except Exception as e:
                    # Set span status to error
                    span.set_status(Status(StatusCode.ERROR, str(e)))
                    span.set_attribute("error.message", str(e))
                    span.set_attribute("error.type", type(e).__name__)
                    logger.error(f"Error in {span_name_final}: {e}")
                    raise

                finally:
                    # Add timing information
                    duration = time.time() - start_time
                    span.set_attribute(
                        "function.duration_ms", round(duration * 1000, 2)
                    )
                    span.set_attribute("function.name", func.__name__)
                    span.set_attribute("function.module", func.__module__)

        # Since all decorated functions are async, always return async_wrapper
        return async_wrapper

    return decorator


def _capture_simple_request_data(
    span: trace.Span,
    args: tuple,
    kwargs: dict,
    include_headers: bool,
    sensitive_fields: Optional[list] = None,
):
    """Simplified request data capture."""
    # Capture basic info
    span.set_attribute("request.num_args", len(args))
    span.set_attribute("request.num_kwargs", len(kwargs))

    # Look for CostEstimatorRequest in args and kwargs
    cost_estimator_request = None

    # Check args first
    for i, arg in enumerate(args):
        if hasattr(arg, "membershipId"):  # CostEstimatorRequest
            cost_estimator_request = arg
            break

    # Check kwargs if not found in args
    if not cost_estimator_request:
        for key, value in kwargs.items():
            if hasattr(value, "membershipId"):  # CostEstimatorRequest
                cost_estimator_request = value
                break

    # Capture individual request attributes
    if cost_estimator_request:
        span.set_attribute(
            "request.membership_id", str(cost_estimator_request.membershipId)
        )
        if hasattr(cost_estimator_request, "benefitProductType"):
            span.set_attribute(
                "request.benefit_product_type",
                str(cost_estimator_request.benefitProductType),
            )
        if (
            hasattr(cost_estimator_request, "providerInfo")
            and cost_estimator_request.providerInfo
        ):
            span.set_attribute(
                "request.num_providers", len(cost_estimator_request.providerInfo)
            )
        if hasattr(cost_estimator_request, "service") and hasattr(
            cost_estimator_request.service, "code"
        ):
            span.set_attribute(
                "request.service_code", str(cost_estimator_request.service.code)
            )

        # Capture full request body as JSON
        try:
            import json

            request_dict = {
                "membershipId": str(cost_estimator_request.membershipId),
                "benefitProductType": (
                    str(cost_estimator_request.benefitProductType)
                    if hasattr(cost_estimator_request, "benefitProductType")
                    else None
                ),
                "service": (
                    {
                        "code": str(cost_estimator_request.service.code),
                        "type": (
                            str(cost_estimator_request.service.type)
                            if hasattr(cost_estimator_request.service, "type")
                            else None
                        ),
                        "description": (
                            str(cost_estimator_request.service.description)
                            if hasattr(cost_estimator_request.service, "description")
                            else None
                        ),
                    }
                    if hasattr(cost_estimator_request, "service")
                    and cost_estimator_request.service
                    else None
                ),
                "providerInfo": (
                    [
                        {
                            "serviceLocation": (
                                str(p.serviceLocation)
                                if hasattr(p, "serviceLocation")
                                else None
                            ),
                            "providerType": (
                                str(p.providerType)
                                if hasattr(p, "providerType")
                                else None
                            ),
                        }
                        for p in (cost_estimator_request.providerInfo or [])
                    ]
                    if hasattr(cost_estimator_request, "providerInfo")
                    and cost_estimator_request.providerInfo
                    else None
                ),
            }
            span.set_attribute("request.body", json.dumps(request_dict, default=str))
        except Exception as e:
            span.set_attribute("request.body_error", str(e))

    # Capture headers if present
    if include_headers:
        # Look for headers in kwargs (passed as individual parameters)
        # TODO: pass in the header params
        headers_dict = {}
        header_params = [
            "x_global_transaction_id",
            "x_client_ref_id",
            "content_type",
            "eie_header_action",
            "eie_header_application_identifier",
            "eie_header_orchestrating_application_identifier",
            "eie_header_user_context",
            "eie_header_version",
            "eie_header_transaction_id",
        ]

        for param in header_params:
            if param in kwargs and kwargs[param] is not None:
                # Convert snake_case to proper header names
                header_name = param.replace("_", "-").replace(
                    "x-global-transaction-id", "x-global-transaction-id"
                )
                if param == "x_global_transaction_id":
                    header_name = "x-global-transaction-id"
                elif param == "x_client_ref_id":
                    header_name = "x-clientrefid"
                elif param == "content_type":
                    header_name = "content-type"
                elif param == "eie_header_action":
                    header_name = "eieheaderaction"
                elif param == "eie_header_application_identifier":
                    header_name = "eieheaderapplicationidentifier"
                elif param == "eie_header_orchestrating_application_identifier":
                    header_name = "eieheaderorchestratingapplicationidentifier"
                elif param == "eie_header_user_context":
                    header_name = "eieheaderusercontext"
                elif param == "eie_header_version":
                    header_name = "eieheaderversion"
                elif param == "eie_header_transaction_id":
                    header_name = "eieheadertransactionid"

                headers_dict[header_name] = str(kwargs[param])

        # Also check if headers were passed as a dictionary
        if "headers" in kwargs and isinstance(kwargs["headers"], dict):
            headers_dict.update(kwargs["headers"])

        if headers_dict:
            _capture_simple_headers(span, headers_dict, sensitive_fields)


def _capture_simple_response_data(span: trace.Span, result: Any, max_size: int):
    """Simplified response data capture."""
    if result is None:
        span.set_attribute("response.type", "None")
        return

    result_type = type(result).__name__
    span.set_attribute("response.type", result_type)

    # Convert to dict and capture
    result_dict = _simple_object_to_dict(result)
    if result_dict:
        # Check for cost estimation response
        if "costEstimateResponseInfo" in result_dict:
            estimates = result_dict["costEstimateResponseInfo"]
            if isinstance(estimates, list):
                span.set_attribute("response.num_estimates", len(estimates))
                span.set_attribute("response.has_estimates", len(estimates) > 0)

        # Capture response body
        result_json = json.dumps(result_dict, default=str)
        if len(result_json) <= max_size:
            span.set_attribute("response.body", result_json)
        else:
            span.set_attribute("response.body", result_json[:max_size] + "...")
            span.set_attribute("response.truncated", True)


def _capture_simple_headers(
    span: trace.Span, headers: Any, sensitive_fields: Optional[list] = None
):
    """Enhanced header capture for comprehensive request tracing."""
    if not headers:
        span.set_attribute("request.headers_count", 0)
        return

    # Common headers to always capture
    important_headers = [
        "content-type",
        "authorization",
        "x-correlation-id",
        "x-global-transaction-id",
        "x-clientrefid",
        "x-client-ref-id",
        "eieheaderaction",
        "eieheaderapplicationidentifier",
        "eieheaderorchestratingapplicationidentifier",
        "eieheaderusercontext",
        "eieheaderversion",
        "eieheadertransactionid",
        "user-agent",
        "accept",
        "accept-encoding",
        "host",
        "origin",
        "referer",
    ]

    header_count = 0
    captured_headers = []

    # Handle different header types
    if hasattr(headers, "items"):
        # Dictionary-like headers
        for key, value in headers.items():
            if value is not None and str(value).strip():
                header_key = f"request.header.{key.lower().replace('-', '_')}"
                if sensitive_fields and any(
                    field in key.lower() for field in sensitive_fields
                ):
                    span.set_attribute(header_key, "[MASKED]")
                    captured_headers.append(f"{key}: [MASKED]")
                else:
                    span.set_attribute(header_key, str(value))
                    captured_headers.append(f"{key}: {value}")
                header_count += 1
    elif hasattr(headers, "get"):
        # Headers object with get method
        for header in important_headers:
            value = headers.get(header)
            if value:
                header_key = f"request.header.{header.replace('-', '_')}"
                if sensitive_fields and any(
                    field in header.lower() for field in sensitive_fields
                ):
                    span.set_attribute(header_key, "[MASKED]")
                    captured_headers.append(f"{header}: [MASKED]")
                else:
                    span.set_attribute(header_key, str(value))
                    captured_headers.append(f"{header}: {value}")
                header_count += 1

    # Set header count and summary
    span.set_attribute("request.headers_count", header_count)
    if captured_headers:
        span.set_attribute(
            "request.headers_summary", "; ".join(captured_headers[:10])
        )  # First 10 headers


def _simple_object_to_dict(obj: Any) -> Optional[dict]:
    """Simplified object to dictionary conversion."""
    if hasattr(obj, "model_dump"):  # Pydantic v2
        return obj.model_dump()
    elif hasattr(obj, "dict"):  # Pydantic v1
        return obj.dict()
    elif hasattr(obj, "__dict__"):
        return obj.__dict__
    else:
        return None
