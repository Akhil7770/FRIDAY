"""
Base Metrics Module

This module provides common functionality for metrics.
"""

from typing import Dict, Any, Optional


class MetricLabels:
    """Common metric label definitions for OpenTelemetry metrics."""

    # API labels - commonly used in decorators
    API_BENEFIT = "benefit_api"
    API_ACCUMULATOR = "accumulator_api"

    # Status labels - used in metric attributes
    STATUS_SUCCESS = "success"
    STATUS_ERROR = "error"
