import logging
import sys

LOG_FORMAT = "%(asctime)s | %(levelname)s | %(name)s | %(message)s"

# Create a logger instance for the app
logger = logging.getLogger("cost_estimator_calc_service")
logger.setLevel(logging.INFO)  # Default level, can be changed as needed

# Console handler with formatting
console_handler = logging.StreamHandler(sys.stdout)
console_handler.setFormatter(logging.Formatter(LOG_FORMAT))

# Avoid adding multiple handlers if this module is imported multiple times
if not logger.hasHandlers():
    logger.addHandler(console_handler)


# Optional: function to set log level dynamically
def set_log_level(level: str):
    logger.setLevel(getattr(logging, level.upper(), logging.INFO))


# Usage example (remove or comment out in production):
# logger.info("Logger initialized.")
