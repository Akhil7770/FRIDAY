import asyncio
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api.router import router
from app.exception.exception_handler import include_exceptions
from contextlib import asynccontextmanager
from app.services.token_service import TokenService
from app.core.logger import logger
from app.core.service_factory import ServiceFactory

# Import OpenTelemetry metrics and automatic instrumentation
from app.core.observability.tracing.opentelemetry_auto_instrumentation import (
    setup_automatic_instrumentation,
)

# Set up automatic instrumentation before creating the FastAPI app
setup_automatic_instrumentation()

# Import metrics module to ensure meter provider is configured BEFORE FastAPI instrumentation
# This must happen after setup_automatic_instrumentation() but before FastAPIInstrumentor
import app.core.observability.metrics.opentelemetry_metrics  # noqa: F401

logger.info("OpenTelemetry metrics module loaded")

app = FastAPI(
    title="Cost Estimator API",
    description="Handles input validation.",
    version="1.0.0",
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allow all origins for development. Restrict in production!
    allow_credentials=True,
    allow_methods=["*"],  # Allow all methods (GET, POST, OPTIONS, etc.)
    allow_headers=["*"],  # Allow all headers
)

app = include_exceptions(app)
app.include_router(router)

# Apply FastAPI instrumentation AFTER the app is created and configured
try:
    from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
    from opentelemetry import trace, metrics
    from opentelemetry.trace import get_current_span
    from app.api.routes.index import store_trace_info

    # Custom span processor to store trace info
    def custom_span_processor(span):
        """Custom span processor to store trace information."""
        try:
            if span and span.is_recording():
                span_context = span.get_span_context()
                trace_id = format(span_context.trace_id, "032x")
                span_id = format(span_context.span_id, "016x")
                span_name = getattr(span, "name", "unknown")
                attributes = dict(getattr(span, "attributes", {}))

                # Store trace info for querying
                store_trace_info(
                    trace_id, span_id, span_name, attributes, "fastapi_request"
                )
        except Exception as e:
            logger.warning(f"Error in custom span processor: {e}")

    # Apply FastAPI instrumentation with excluded URLs
    # This creates both traces AND metrics (http.server.duration, etc.)
    FastAPIInstrumentor().instrument_app(
        app,
        excluded_urls="/health,/metrics,/favicon.ico,/traces,/traces/search,/trace-info,/trace-debug,/trace-test,/trace-test-simple",
        meter_provider=metrics.get_meter_provider(),  # Enable HTTP metrics
    )

    # Note: Custom span processor approach removed due to compatibility issues
    # Real application traces will be captured by FastAPI instrumentation
    # and can be queried through the trace endpoints

    logger.info("FastAPI instrumentation applied successfully (traces + metrics)")
except ImportError as e:
    logger.warning(f"FastAPI instrumentation not available: {e}")
except Exception as e:
    logger.error(f"Failed to apply FastAPI instrumentation: {e}")

service_factory = ServiceFactory()
cost_estimation_service = service_factory.cost_estimation_service()


async def refresh_cache_every_24_hours():
    while True:
        logger.info("Refreshing cache")
        await cost_estimation_service.load_payment_method_hierarchy()
        await cost_estimation_service.load_pcp_specialty_codes()
        await asyncio.sleep(86400)  # 24 hours in seconds


# FastAPI lifespan event
@asynccontextmanager
async def lifespan(app: FastAPI):
    asyncio.create_task(refresh_cache_every_24_hours())
    yield  # Wait for the app to shut down


app.router.lifespan_context = lifespan
