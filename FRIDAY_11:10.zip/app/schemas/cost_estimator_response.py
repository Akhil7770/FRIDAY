from typing import List, Optional, Union, Dict, Any, Callable
from pydantic import BaseModel
from app.schemas.cost_estimator_request import (
    Service,
    ProviderInfo,
    CostEstimatorRequest,
)
from app.models.selected_benefit import SelectedBenefit
from app.models.rate_criteria import NegotiatedRate
from app.core.base import InsuranceContext
#from app.schemas.accumulator_response import Accumulator as AccumulatorResponse
from app.core.constants import RATE_TYPE_AMOUNT
from app.core.logger import logger
from app.exception.exceptions import (
    RateNotFoundException,
    InsuranceContextException,
    BenefitsNotMatchingException,
    ProviderNotFoundException,
)
from app.exception.exception_handler import (
    rate_not_found_exception_handler_logic,
    provider_not_found_exception_handler_logic,
    insurance_context_error_exception_handler_logic,
    benefits_not_matching_exception_handler_logic,
)


class Coverage(BaseModel):
    isServiceCovered: str
    maxCoverageAmount: str
    costShareCopay: float
    costShareCoinsurance: int


class Cost(BaseModel):
    inNetworkCosts: float
    outOfNetworkCosts: float
    inNetworkCostsType: str


class HealthClaimLine(BaseModel):
    amountCopay: float
    amountCoinsurance: float
    amountResponsibility: float
    percentResponsibility: float
    amountpayable: float


class Accumulator(BaseModel):
    code: str
    level: str
    limitValue: float
    calculatedValue: float


class AccumulatorWithLimitType(BaseModel):
    code: str
    level: str
    limitValue: float
    limitType: str
    calculatedValue: float


class AccumulatorCalculation(BaseModel):
    remainingValue: float
    appliedValue: float


class AccumulatorCalculationWithType(BaseModel):
    remainingValue: float
    appliedValue: float
    appliedValueType: str


class AccumulatorInfo(BaseModel):
    accumulator: Union[Accumulator, AccumulatorWithLimitType]
    accumulatorCalculation: Union[
        AccumulatorCalculation, AccumulatorCalculationWithType
    ]


class CostEstimateResponseInfo(BaseModel):
    providerInfo: ProviderInfo
    coverage: Coverage
    cost: Cost
    healthClaimLine: HealthClaimLine
    accumulators: List[AccumulatorInfo]


class CostEstimateResponseInfoError(BaseModel):
    providerInfo: ProviderInfo
    exception: Dict[str, Any]

    def __init__(
        self,
        providerInfo: ProviderInfo,
        exc: Exception,
        handler_logic: Callable[[Any], Dict[str, Any]],
    ):
        super().__init__(
            providerInfo=providerInfo,
            exception=handler_logic(exc),
        )
        logger.error(f"{exc.__class__.__name__} was handled and returned")


class CostEstimateResponse(BaseModel):
    service: Service
    costEstimateResponseInfo: List[
        Union[CostEstimateResponseInfo, CostEstimateResponseInfoError]
    ]


class CostEstimatorResponse(BaseModel):
    costEstimateResponse: CostEstimateResponse

    @classmethod
    def build_cost_estimate_response_info(
        cls,
        provider_info: ProviderInfo,
        selected_benefits: List[SelectedBenefit],
        insuranceContext: InsuranceContext,
        negotiated_rate: NegotiatedRate,
        raise_exception: bool = False,
    ) -> Union[CostEstimateResponseInfo, CostEstimateResponseInfoError]:
        """
        Build a CostEstimatorResponse with the provided details.
        """

        if not negotiated_rate.isProviderInfoFound:
            return CostEstimateResponseInfoError(
                providerInfo=provider_info,
                exc=ProviderNotFoundException(),
                handler_logic=provider_not_found_exception_handler_logic,
            )
        elif not negotiated_rate.isRateFound:
            return CostEstimateResponseInfoError(
                providerInfo=provider_info,
                exc=RateNotFoundException(),
                handler_logic=rate_not_found_exception_handler_logic,
            )

        if len(selected_benefits) == 0:
            return CostEstimateResponseInfoError(
                providerInfo=provider_info,
                exc=BenefitsNotMatchingException(),
                handler_logic=benefits_not_matching_exception_handler_logic,
            )
        if insuranceContext.error_code is not None:
            exc = InsuranceContextException(
                error_code=insuranceContext.error_code,
                error_message=insuranceContext.error_message,
            )
            if raise_exception:
                raise exc
            return CostEstimateResponseInfoError(
                providerInfo=provider_info,
                exc=exc,
                handler_logic=insurance_context_error_exception_handler_logic,
            )

        # Extract data from the request and context
        selected_benefit_of_highest_member_pay = cls.select_benefit(
            selected_benefits, insuranceContext
        )

        coverage = Coverage(
            isServiceCovered=(
                selected_benefit_of_highest_member_pay.coverage.isServiceCovered
                if selected_benefit_of_highest_member_pay
                else "N"
            ),
            maxCoverageAmount="",
            costShareCopay=float(
                selected_benefit_of_highest_member_pay.coverage.costShareCopay
                if selected_benefit_of_highest_member_pay
                else 0.0
            ),
            costShareCoinsurance=int(
                selected_benefit_of_highest_member_pay.coverage.costShareCoinsurance
                if selected_benefit_of_highest_member_pay
                else 0
            ),
        )

        # Create cost information
        cost = Cost(
            inNetworkCosts=float(negotiated_rate.rate),
            outOfNetworkCosts=float(0.0),
            inNetworkCostsType=negotiated_rate.rateType,
        )

        # Create health claim line
        if negotiated_rate.rateType == RATE_TYPE_AMOUNT:
            health_claim_line = HealthClaimLine(
                amountCopay=insuranceContext.amount_copay,
                amountCoinsurance=insuranceContext.amount_coinsurance,
                amountResponsibility=insuranceContext.member_pays,
                percentResponsibility=0.0,
                amountpayable=negotiated_rate.rate - insuranceContext.member_pays,
            )
        else:
            health_claim_line = HealthClaimLine(
                amountCopay=0.0,
                amountCoinsurance=0.0,
                amountResponsibility=0,
                percentResponsibility=negotiated_rate.rate,
                amountpayable=0.0,
            )

        logger.info(
            f"selected_benefit_of_highest_member_pay: {selected_benefit_of_highest_member_pay}"
        )

        if selected_benefit_of_highest_member_pay is not None:
            accumulators = []
            accumulators = cls.build_accumulator(
                selected_benefit_of_highest_member_pay.coverage.matchedAccumulators,
                insuranceContext,
                negotiated_rate.rateType,
            )
        else:
            accumulators = []

        cost_estimate_response_info = CostEstimateResponseInfo(
            providerInfo=provider_info,
            coverage=coverage,
            cost=cost,
            healthClaimLine=health_claim_line,
            accumulators=accumulators,
        )
        return cost_estimate_response_info

    @classmethod
    def build_cost_estimator_response_from_info_objects(
        cls,
        cost_estimator_request: CostEstimatorRequest,
        cost_estimate_response_info_list: List[
            Union[CostEstimateResponseInfo, CostEstimateResponseInfoError]
        ],
    ) -> "CostEstimatorResponse":
        """
        Build a CostEstimatorResponse with the provided details.
        """
        service = cost_estimator_request.service
        cost_estimate_response = CostEstimateResponse(
            service=service,
            costEstimateResponseInfo=cost_estimate_response_info_list,
        )
        return CostEstimatorResponse(costEstimateResponse=cost_estimate_response)

    @classmethod
    def select_benefit(
        cls,
        selected_benefits: List[SelectedBenefit],
        insuranceContext: InsuranceContext,
    ) -> Optional[SelectedBenefit]:
        # Filter benefits by matching benefit code with insurance context
        matching_benefits = [
            benefit
            for benefit in selected_benefits
            if str(benefit.benefitCode) == insuranceContext.benefit_id
        ]

        # If no matching benefits found, return the first benefit or None

        if not matching_benefits:
            return selected_benefits[0] if selected_benefits else None

        # For now, return the first matching benefit since we can't calculate member_pays here
        # The actual member_pays calculation happens in the calculation service
        return matching_benefits[0]

    @classmethod
    def build_accumulator(
        cls, accumulators: List, insuranceContext: InsuranceContext, rateType: str
    ) -> List[AccumulatorInfo]:

        result = []
        for acc in accumulators:
            code = acc.code.lower()
            level = acc.level.lower()
            limit_type = (acc.limitType or "").lower()

            if acc.code.lower() == "limit":
                accumulator = AccumulatorWithLimitType(
                    code=acc.code,
                    level=acc.level,
                    limitValue=acc.limitValue,
                    limitType=acc.limitType or "",
                    calculatedValue=acc.calculatedValue,
                )
            else:
                accumulator = Accumulator(
                    code=acc.code,
                    level=acc.level,
                    limitValue=acc.limitValue,
                    calculatedValue=acc.calculatedValue,
                )

            # Mapping for accumulator calculation logic
            remaining = 0.0
            applied = 0.0
            applied_type = None

            if code == "limit":
                # Note: "dollaer" typo is preserved for backward compatibility
                if rateType == RATE_TYPE_AMOUNT:
                    remaining = insuranceContext.limit_calculated or 0.0
                else:
                    remaining = acc.calculatedValue
                applied = acc.calculatedValue - remaining
                applied_type = limit_type if limit_type in ("dollar", "counter") else ""
            elif code == "deductible":
                if level == "individual":
                    if rateType == RATE_TYPE_AMOUNT:
                        remaining = (
                            insuranceContext.deductible_individual_calculated or 0.0
                        )
                    else:
                        remaining = acc.calculatedValue
                    applied = acc.calculatedValue - remaining
                elif level == "family":
                    if rateType == RATE_TYPE_AMOUNT:
                        remaining = insuranceContext.deductible_family_calculated or 0.0
                    else:
                        remaining = acc.calculatedValue
                    applied = acc.calculatedValue - remaining
                applied_type = None
            elif code == "oop max":
                if level == "individual":
                    if rateType == RATE_TYPE_AMOUNT:
                        remaining = insuranceContext.oopmax_individual_calculated or 0.0
                    else:
                        remaining = acc.calculatedValue
                    applied = acc.calculatedValue - remaining

                elif level == "family":
                    if rateType == RATE_TYPE_AMOUNT:
                        remaining = insuranceContext.oopmax_family_calculated or 0.0
                    else:
                        remaining = acc.calculatedValue
                    applied = acc.calculatedValue - remaining
                applied_type = None
            else:
                # Skip unknown accumulator types
                continue
            if code == "limit":
                accumulator_calc = AccumulatorCalculationWithType(
                    remainingValue=remaining,
                    appliedValue=applied,
                    appliedValueType=str(applied_type),
                )
            else:
                accumulator_calc = AccumulatorCalculation(
                    remainingValue=remaining,
                    appliedValue=applied,
                )
            result.append(
                AccumulatorInfo(
                    accumulator=accumulator,
                    accumulatorCalculation=accumulator_calc,
                )
            )
        return result