from typing import Annotated
from typing import List

from pydantic import BaseModel, Field


class SupportingService(BaseModel):
    code: str
    type: str


class Modifier(BaseModel):
    modifierCode: str


class PlaceOfService(BaseModel):
    code: Annotated[str, Field(..., description="Place of service code", min_length=1)]


class Speciality(BaseModel):
    code: Annotated[str, Field(..., json_schema_extra={"examples": ["91017"]})]


class ProviderNetworks(BaseModel):
    networkID: str


class ProviderNetworkParticipation(BaseModel):
    providerTier: str = ""


class ProviderInfo(BaseModel):
    serviceLocation: Annotated[
        str, Field(..., description="Service location code", min_length=1)
    ]
    providerType: str
    speciality: Speciality = Speciality(code="")
    taxIdentificationNumber: str
    taxIdQualifier: str
    providerNetworks: ProviderNetworks
    providerIdentificationNumber: Annotated[
        str, Field(..., description="Provider identification number", min_length=1)
    ]
    nationalProviderId: str
    providerNetworkParticipation: ProviderNetworkParticipation = (
        ProviderNetworkParticipation()
    )

    def hash(self):
        return "-".join(
            [
                self.serviceLocation,
                self.speciality.code,
                self.providerNetworks.networkID,
                self.providerIdentificationNumber,
            ]
        )


class Service(BaseModel):
    code: Annotated[
        str, Field(..., description="Service code (e.g., 99214)", min_length=1)
    ]
    type: Annotated[
        str, Field(..., description="Service type (e.g., CPT4)", min_length=1)
    ]
    description: str = ""
    supportingService: SupportingService
    modifier: Modifier
    diagnosisCode: str
    placeOfService: PlaceOfService


class CostEstimatorRequest(BaseModel):
    membershipId: str
    zipCode: str
    benefitProductType: str
    languageCode: str
    service: Service
    providerInfo: List[ProviderInfo]


class ProviderType(BaseModel):
    code: str


class ProviderSpecialty(BaseModel):
    code: str


class ServiceCodeInfo(BaseModel):
    providerType: List[ProviderType]
    placeOfService: List[PlaceOfService]
    providerSpecialty: List[ProviderSpecialty]
    code: Annotated[
        str, Field(..., description="Service code (e.g., 99214)", min_length=1)
    ]
    type: Annotated[
        str, Field(..., description="Service type (e.g., CPT4)", min_length=1)
    ]


class ServiceInfo(BaseModel):
    serviceCodeInfo: ServiceCodeInfo


class RequestModel(BaseModel):
    benefitProductType: str
    membershipID: str
    planIdentifier: str
    serviceInfo: List[ServiceInfo]
