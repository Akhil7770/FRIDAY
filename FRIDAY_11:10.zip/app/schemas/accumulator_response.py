from datetime import date
from tokenize import Double
from typing import List, Optional

from pydantic import BaseModel
from app.schemas.benefit_response import RelatedAccumulator


class EffectivePeriod(BaseModel):
    datetimeAsOf: Optional[str] = None
    datetimeBegin: Optional[date] = None
    datetimeEnd: Optional[date] = None


class Accumulator(BaseModel):
    level: Optional[str] = None
    deductibleCode: Optional[str] = None
    frequency: Optional[str] = None
    limitType: Optional[str] = None
    relationshipToSubscriber: Optional[str] = None
    suffix: Optional[str] = None
    Type: Optional[str] = None
    detailedDescription: Optional[str] = None
    benefitProductType: Optional[str] = None
    description: Optional[str] = None
    currentValue: Optional[float] = None
    limitValue: Optional[float] = None
    code: Optional[str] = None
    effectivePeriod: EffectivePeriod
    calculatedValue: Optional[float] = None
    savingsLevel: Optional[str] = None
    percentageCoinsurance: Optional[int] = None
    networkIndicator: Optional[str] = None
    networkIndicatorCode: Optional[str] = None
    networkTier: Optional[str] = None
    accumYear: Optional[str] = None
    numOfIndividualsMet: Optional[int] = None
    numOfIndividualsNeededToMeet: Optional[int] = None
    accumExCode: Optional[str] = None

    def matches(self, other: RelatedAccumulator) -> bool:
        return (
            other.code == self.code
            and other.level == self.level
            and (
                other.accumExCode == self.accumExCode
                or (other.accumExCode == "" and self.accumExCode is None)
            )
            and (
                other.deductibleCode == self.deductibleCode
                or (other.deductibleCode == "" and self.deductibleCode is None)
            )
            and other.networkIndicatorCode == self.networkIndicatorCode
        )


class MembershipIdentifier(BaseModel):
    idSource: str
    idValue: str
    idType: str
    resourceId: str


class Member(BaseModel):
    privacyRestriction: str
    membershipIdentifier: MembershipIdentifier
    Status: Optional[str] = None
    accumulators: List[Accumulator]


class Memberships(BaseModel):
    dependents: Optional[List[Member]] = None
    subscriber: Optional[Member] = None


class ReadAccumulatorsResponse(BaseModel):
    memberships: Memberships


class AccumulatorResponse(BaseModel):
    readAccumulatorsResponse: ReadAccumulatorsResponse

    def get_member_by_id(self, id: str) -> Optional[Member]:
        if (
            self.readAccumulatorsResponse.memberships.subscriber
            and self.readAccumulatorsResponse.memberships.subscriber.membershipIdentifier.resourceId
            == id
        ):
            return self.readAccumulatorsResponse.memberships.subscriber
        if self.readAccumulatorsResponse.memberships.dependents:
            for member in self.readAccumulatorsResponse.memberships.dependents:
                if member.membershipIdentifier.resourceId == id:
                    return member
        return None

    def get_accumulators_by_network(
        self, network_indicator: str = "InNetwork"
    ) -> List[Accumulator]:
        """Get accumulators filtered by network indicator."""
        accumulators = []
        if self.readAccumulatorsResponse.memberships.subscriber:
            for (
                accumulator
            ) in self.readAccumulatorsResponse.memberships.subscriber.accumulators:
                if accumulator.networkIndicator == network_indicator:
                    accumulators.append(accumulator)
        if self.readAccumulatorsResponse.memberships.dependents:
            for dependent in self.readAccumulatorsResponse.memberships.dependents:
                for accumulator in dependent.accumulators:
                    if accumulator.networkIndicator == network_indicator:
                        accumulators.append(accumulator)
        return accumulators

    def get_accumulator_by_code(
        self, code: str, network_indicator: str = "InNetwork"
    ) -> Optional[Accumulator]:
        """Get a specific accumulator by its code and network indicator."""
        if self.readAccumulatorsResponse.memberships.subscriber:
            for (
                accumulator
            ) in self.readAccumulatorsResponse.memberships.subscriber.accumulators:
                if (
                    accumulator.code == code
                    and accumulator.networkIndicator == network_indicator
                ):
                    return accumulator
        if self.readAccumulatorsResponse.memberships.dependents:
            for dependent in self.readAccumulatorsResponse.memberships.dependents:
                for accumulator in dependent.accumulators:
                    if (
                        accumulator.code == code
                        and accumulator.networkIndicator == network_indicator
                    ):
                        return accumulator
        return None

    def get_out_of_pocket_max(
        self, network_indicator: str = "InNetwork"
    ) -> Optional[Accumulator]:
        """Get the out-of-pocket maximum accumulator."""
        return self.get_accumulator_by_code("OOP Max", network_indicator)

    def get_deductible(
        self, network_indicator: str = "InNetwork"
    ) -> Optional[Accumulator]:
        """Get the deductible accumulator."""
        return self.get_accumulator_by_code("Deductible", network_indicator)

    def get_annual_maximum(
        self, network_indicator: str = "InNetwork"
    ) -> Optional[Accumulator]:
        """Get the annual maximum accumulator."""
        return self.get_accumulator_by_code("Annual Maximum", network_indicator)

    def get_accumulator_by_description(
        self, description: str, network_indicator: str = "InNetwork"
    ) -> Optional[Accumulator]:
        """Get a specific accumulator by its description and network indicator."""
        if self.readAccumulatorsResponse.memberships.subscriber:
            for (
                accumulator
            ) in self.readAccumulatorsResponse.memberships.subscriber.accumulators:
                if (
                    accumulator.description == description
                    and accumulator.networkIndicator == network_indicator
                ):
                    return accumulator
        if self.readAccumulatorsResponse.memberships.dependents:
            for dependent in self.readAccumulatorsResponse.memberships.dependents:
                for accumulator in dependent.accumulators:
                    if (
                        accumulator.description == description
                        and accumulator.networkIndicator == network_indicator
                    ):
                        return accumulator
        return None

    def get_accumulator_by_accum_ex_code(
        self, accum_ex_code: str, network_indicator: str = "InNetwork"
    ) -> Optional[Accumulator]:
        """Get a specific accumulator by its accumExCode and network indicator."""
        if self.readAccumulatorsResponse.memberships.subscriber:
            for (
                accumulator
            ) in self.readAccumulatorsResponse.memberships.subscriber.accumulators:
                if (
                    accumulator.accumExCode == accum_ex_code
                    and accumulator.networkIndicator == network_indicator
                ):
                    return accumulator
        if self.readAccumulatorsResponse.memberships.dependents:
            for dependent in self.readAccumulatorsResponse.memberships.dependents:
                for accumulator in dependent.accumulators:
                    if (
                        accumulator.accumExCode == accum_ex_code
                        and accumulator.networkIndicator == network_indicator
                    ):
                        return accumulator
        return None
