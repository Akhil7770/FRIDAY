from fastapi import APIRouter, Header
from app.schemas.cost_estimator_request import CostEstimatorRequest
from app.core.logger import logger
from app.core.observability.metrics.metrics_decorators import response_time
from app.core.observability.tracing.tracing_decorators import trace_request_response
from typing import Optional, Dict
from app.core.service_factory import ServiceFactory

service_factory = ServiceFactory()
cost_estimation_service = service_factory.cost_estimation_service()
router = APIRouter()


@router.post(
    "/rate",
    summary="Retrieve cost estimate for member",
    tags=["Cost Estimation"],
)
@trace_request_response(
    span_name="cost_estimation_endpoint",
    capture_request=True,
    capture_response=True,
    max_request_size=4096,
    max_response_size=4096,
    include_headers=True,
    sensitive_fields=[],
)
async def estimate_cost(
    request: CostEstimatorRequest,
    x_global_transaction_id: Optional[str] = Header(
        None, alias="x-global-transaction-id", description="Request correlation ID"
    ),
    x_client_ref_id: Optional[str] = Header(
        None, alias="x-clientrefid", description="Client reference ID"
    ),
    content_type: Optional[str] = Header(
        None, alias="content-type", description="Content type"
    ),
    eie_header_action: Optional[str] = Header(
        None, alias="eieheaderaction", description="EIE header action"
    ),
    eie_header_application_identifier: Optional[str] = Header(
        None,
        alias="eieheaderapplicationidentifier",
        description="EIE application identifier",
    ),
    eie_header_orchestrating_application_identifier: Optional[str] = Header(
        None,
        alias="eieheaderorchestratingapplicationidentifier",
        description="EIE orchestrating application identifier",
    ),
    eie_header_user_context: Optional[str] = Header(
        None, alias="eieheaderusercontext", description="EIE user context"
    ),
    eie_header_version: Optional[str] = Header(
        None, alias="eieheaderversion", description="EIE header version"
    ),
    eie_header_transaction_id: Optional[str] = Header(
        None, alias="eieheadertransactionid", description="EIE header transaction ID"
    ),
):
    # Collect headers for logging in a concise way, filtering out None values
    headers: Dict[str, str] = {}
    if x_global_transaction_id:
        headers["X-Correlation-ID"] = x_global_transaction_id
    if x_client_ref_id:
        headers["X-Client-Ref-ID"] = x_client_ref_id
    if content_type:
        headers["Content-Type"] = content_type
    if eie_header_action:
        headers["EIE-Header-Action"] = eie_header_action
    if eie_header_application_identifier:
        headers["EIE-Header-Application-Identifier"] = eie_header_application_identifier
    if eie_header_orchestrating_application_identifier:
        headers["EIE-Header-Orchestrating-Application-Identifier"] = (
            eie_header_orchestrating_application_identifier
        )
    if eie_header_user_context:
        headers["EIE-Header-User-Context"] = eie_header_user_context
    if eie_header_version:
        headers["EIE-Header-Version"] = eie_header_version
    if eie_header_transaction_id:
        headers["EIE-Header-Transaction-ID"] = eie_header_transaction_id
    # Log request information for debugging (OpenTelemetry handles tracing automatically)
    logger.info(
        f"Processing cost estimation request with correlation ID: {x_global_transaction_id}"
    )

    logger.info(f"Request Headers: {headers}")

    # Call the service to get the cost estimation
    logger.info(f"Cost Estimation Request: {request}")
    response = await cost_estimation_service.estimate_cost(request, headers=headers)
    logger.info(f"Cost Estimation Response: {response}")
    return response


@router.post(
    "/rate-only",
    summary="Retrieve rate only for member",
    tags=["Cost Estimation"],
)
async def get_rate_only(
    request: CostEstimatorRequest,
):
    response = await cost_estimation_service.get_rate_only(request)
    return response
