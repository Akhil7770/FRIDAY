from fastapi import APIRouter

from app.api.routes import index
from app.api.v1.routes import requests
from app.core.constants import API_VERSION_V1, SERVER_ROOT_PATH, INDEX_ROUTES_TAG

router = APIRouter()

router.include_router(
    index.router, prefix=f"{SERVER_ROOT_PATH}{API_VERSION_V1}", tags=[INDEX_ROUTES_TAG]
)

router.include_router(
    requests.router,
    prefix=f"{SERVER_ROOT_PATH}{API_VERSION_V1}",
    tags=["Cost Estimation"],
)
