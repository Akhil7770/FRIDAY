from unittest.mock import Mock
import json
import os

import pytest

from app.core.base import InsuranceContext
from app.models.rate_criteria import NegotiatedRate
from app.models.selected_benefit import SelectedBenefit, SelectedCoverage
from app.schemas.benefit_response import BenefitTier, Prerequisite, ServiceProviderItem
from app.schemas.cost_estimator_request import (
    CostEstimatorRequest,
    Service,
    ProviderInfo,
    SupportingService,
    Modifier,
    PlaceOfService,
    Speciality,
    ProviderNetworks,
    ProviderNetworkParticipation,
)
from app.schemas.cost_estimator_response import (
    CostEstimatorResponse,
    AccumulatorInfo,
)


def load_mock_data(filename):
    """Load mock data from JSON file"""
    mock_data_path = os.path.join(
        os.path.dirname(__file__),
        "..",
        "mock-data",
        "cost-estimator-response-test",
        filename,
    )
    with open(mock_data_path, "r") as f:
        return json.load(f)


class TestCostEstimatorResponse:
    @pytest.fixture
    def sample_request(self):
        """Load sample CostEstimatorRequest from mock data"""
        request_data = load_mock_data("CostEstimatorRequest.json")
        return CostEstimatorRequest(**request_data)

    @pytest.fixture
    def sample_selected_benefit(self):
        """Load sample SelectedBenefit from mock data"""
        benefit_data = load_mock_data("BenefitApiResponse.json")
        benefit = benefit_data["serviceInfo"][0]["benefit"][0]
        coverage_data = benefit["coverages"][0]

        coverage = SelectedCoverage(
            sequenceNumber=coverage_data["sequenceNumber"],
            benefitDescription=coverage_data["benefitDescription"],
            costShareCopay=coverage_data["costShareCopay"],
            costShareCoinsurance=coverage_data["costShareCoinsurance"],
            copayAppliesOutOfPocket=coverage_data["copayAppliesOutOfPocket"],
            coinsAppliesOutOfPocket=coverage_data["coinsAppliesOutOfPocket"],
            deductibleAppliesOutOfPocket=coverage_data["deductibleAppliesOutOfPocket"],
            deductibleAppliesOutOfPocketOtherIndicator=coverage_data[
                "deductibleAppliesOutOfPocketOtherIndicator"
            ],
            copayCountToDeductibleIndicator=coverage_data[
                "copayCountToDeductibleIndicator"
            ],
            copayContinueWhenDeductibleMetIndicator=coverage_data[
                "copayContinueWhenDeductibleMetIndicator"
            ],
            copayContinueWhenOutOfPocketMaxMetIndicator=coverage_data[
                "copayContinueWhenOutOfPocketMaxMetIndicator"
            ],
            coinsuranceToOutOfPocketOtherIndicator=coverage_data[
                "coinsuranceToOutOfPocketOtherIndicator"
            ],
            copayToOutofPocketOtherIndicator=coverage_data[
                "copayToOutofPocketOtherIndicator"
            ],
            isDeductibleBeforeCopay=coverage_data["isDeductibleBeforeCopay"],
            benefitLimitation=coverage_data["benefitLimitation"],
            isServiceCovered=coverage_data["isServiceCovered"],
            matchedAccumulators=[],
        )

        return SelectedBenefit(
            benefitName=benefit["benefitName"],
            benefitCode=benefit["benefitCode"],
            isInitialBenefit=benefit["isInitialBenefit"],
            benefitTier=BenefitTier(
                benefitTierName=benefit["benefitTier"]["benefitTierName"]
            ),
            networkCategory=benefit["networkCategory"],
            prerequisites=[
                Prerequisite(type=prereq["type"], isRequired=prereq["isRequired"])
                for prereq in benefit["prerequisites"]
            ],
            benefitProvider=benefit["benefitProvider"],
            serviceProvider=[
                ServiceProviderItem(providerDesignation=sp["providerDesignation"])
                for sp in benefit["serviceProvider"]
            ],
            coverage=coverage,
        )

    @pytest.fixture
    def sample_insurance_context(self):
        """Load sample InsuranceContext from mock data"""
        context_data = load_mock_data("InsuranceContext.json")
        context = InsuranceContext()

        # Set all the context values from mock data
        for key, value in context_data.items():
            if hasattr(context, key):
                setattr(context, key, value)

        return context

    def test_build_cost_estimator_response_success(
        self, sample_request, sample_selected_benefit, sample_insurance_context
    ):
        """Test successful building of CostEstimatorResponse"""
        selected_benefits = [sample_selected_benefit]
        rate_data = load_mock_data("NegotiatedRate.json")
        rate = NegotiatedRate(**rate_data)

        response = (
            CostEstimatorResponse.build_cost_estimator_response_from_info_objects(
                sample_request,
                [
                    CostEstimatorResponse.build_cost_estimate_response_info(
                        sample_request.providerInfo[0],
                        selected_benefits,
                        sample_insurance_context,
                        rate,
                    )
                ],
            )
        )

        assert response is not None
        assert isinstance(response, CostEstimatorResponse)
        assert response.costEstimateResponse is not None
        assert len(response.costEstimateResponse.costEstimateResponseInfo) == 1

        # Check coverage
        response_info = response.costEstimateResponse.costEstimateResponseInfo[0]
        from app.schemas.cost_estimator_response import CostEstimateResponseInfo

        assert isinstance(response_info, CostEstimateResponseInfo)

        coverage = response_info.coverage
        assert coverage.isServiceCovered == "Y"
        assert coverage.maxCoverageAmount == 0.0
        assert coverage.costShareCopay == 25.0
        assert coverage.costShareCoinsurance == 20.0

        # Check cost
        cost = response_info.cost
        assert cost.inNetworkCosts == 150.0
        assert cost.outOfNetworkCosts == 0.0
        assert cost.inNetworkCostsType == "AMOUNT"

        # Check health claim line
        health_claim = response_info.healthClaimLine
        assert health_claim.amountCopay == 25.0
        assert health_claim.amountCoinsurance == 30.0
        assert health_claim.amountResponsibility == 50.0
        assert health_claim.percentResponsibility == 0.0
        assert health_claim.amountpayable == 100.0

    def test_build_cost_estimator_response_no_benefits(
        self, sample_request, sample_insurance_context
    ):
        """Test building response with no selected benefits"""
        selected_benefits = []
        rate_data = load_mock_data("NegotiatedRate.json")
        rate = NegotiatedRate(**rate_data)

        response = (
            CostEstimatorResponse.build_cost_estimator_response_from_info_objects(
                sample_request,
                [
                    CostEstimatorResponse.build_cost_estimate_response_info(
                        sample_request.providerInfo[0],
                        selected_benefits,
                        sample_insurance_context,
                        rate,
                    )
                ],
            )
        )

        assert response is not None
        assert isinstance(response, CostEstimatorResponse)
        assert response.costEstimateResponse is not None
        assert len(response.costEstimateResponse.costEstimateResponseInfo) == 1

        # Check that we get an error response when no benefits
        response_info = response.costEstimateResponse.costEstimateResponseInfo[0]
        from app.schemas.cost_estimator_response import CostEstimateResponseInfoError

        assert isinstance(response_info, CostEstimateResponseInfoError)
        assert "exception" in response_info.model_dump()

    def test_build_cost_estimator_response_with_mock_data_validation(
        self, sample_request, sample_selected_benefit, sample_insurance_context
    ):
        """Test building response and validate against expected mock data structure"""
        selected_benefits = [sample_selected_benefit]
        rate_data = load_mock_data("NegotiatedRate.json")
        rate = NegotiatedRate(**rate_data)

        response = (
            CostEstimatorResponse.build_cost_estimator_response_from_info_objects(
                sample_request,
                [
                    CostEstimatorResponse.build_cost_estimate_response_info(
                        sample_request.providerInfo[0],
                        selected_benefits,
                        sample_insurance_context,
                        rate,
                    )
                ],
            )
        )

        # Load expected response structure for validation
        expected_data = load_mock_data("ExpectedCostEstimatorResponse.json")

        # Validate response structure
        assert response is not None
        assert isinstance(response, CostEstimatorResponse)
        assert response.costEstimateResponse is not None
        assert len(response.costEstimateResponse.costEstimateResponseInfo) == 1

        # Validate service information
        service = response.costEstimateResponse.service
        assert service.code == expected_data["costEstimateResponse"]["service"]["code"]
        assert service.type == expected_data["costEstimateResponse"]["service"]["type"]
        assert (
            service.description
            == expected_data["costEstimateResponse"]["service"]["description"]
        )

        # Validate response info
        response_info = response.costEstimateResponse.costEstimateResponseInfo[0]
        from app.schemas.cost_estimator_response import CostEstimateResponseInfo

        assert isinstance(response_info, CostEstimateResponseInfo)

        # Validate coverage
        coverage = response_info.coverage
        expected_coverage = expected_data["costEstimateResponse"][
            "costEstimateResponseInfo"
        ][0]["coverage"]
        assert coverage.isServiceCovered == expected_coverage["isServiceCovered"]
        assert coverage.maxCoverageAmount == expected_coverage["maxCoverageAmount"]
        assert coverage.costShareCopay == expected_coverage["costShareCopay"]
        assert (
            coverage.costShareCoinsurance == expected_coverage["costShareCoinsurance"]
        )

        # Validate cost
        cost = response_info.cost
        expected_cost = expected_data["costEstimateResponse"][
            "costEstimateResponseInfo"
        ][0]["cost"]
        assert cost.inNetworkCosts == expected_cost["inNetworkCosts"]
        assert cost.outOfNetworkCosts == expected_cost["outOfNetworkCosts"]
        assert cost.inNetworkCostsType == expected_cost["inNetworkCostsType"]

        # Validate health claim line
        health_claim = response_info.healthClaimLine
        expected_health_claim = expected_data["costEstimateResponse"][
            "costEstimateResponseInfo"
        ][0]["healthClaimLine"]
        assert health_claim.amountCopay == float(expected_health_claim["amountCopay"])
        assert health_claim.amountCoinsurance == float(
            expected_health_claim["amountCoinsurance"]
        )
        assert health_claim.amountResponsibility == float(
            expected_health_claim["amountResponsibility"]
        )
        # For AMOUNT rate type, percentResponsibility should be 0.0 (empty string in mock data)
        expected_percent = expected_health_claim["percentResponsibility"]
        if expected_percent == "":
            assert health_claim.percentResponsibility == 0.0
        else:
            assert health_claim.percentResponsibility == float(expected_percent)
        assert health_claim.amountpayable == float(
            expected_health_claim["amountpayable"]
        )

        print("✅ All mock data validations passed!")

    def test_build_cost_estimator_response_percentage_rate_type(
        self, sample_request, sample_selected_benefit, sample_insurance_context
    ):
        """Test building response with PERCENTAGE rate type"""
        selected_benefits = [sample_selected_benefit]
        rate_data = load_mock_data("NegotiatedRatePercentage.json")
        rate = NegotiatedRate(**rate_data)

        response = (
            CostEstimatorResponse.build_cost_estimator_response_from_info_objects(
                sample_request,
                [
                    CostEstimatorResponse.build_cost_estimate_response_info(
                        sample_request.providerInfo[0],
                        selected_benefits,
                        sample_insurance_context,
                        rate,
                    )
                ],
            )
        )

        # Load expected response structure for validation
        expected_data = load_mock_data("ExpectedCostEstimatorResponsePercentage.json")

        # Validate response structure
        assert response is not None
        assert isinstance(response, CostEstimatorResponse)
        assert response.costEstimateResponse is not None
        assert len(response.costEstimateResponse.costEstimateResponseInfo) == 1

        # Validate response info
        response_info = response.costEstimateResponse.costEstimateResponseInfo[0]
        from app.schemas.cost_estimator_response import CostEstimateResponseInfo

        assert isinstance(response_info, CostEstimateResponseInfo)

        # Validate cost - should be PERCENTAGE type
        cost = response_info.cost
        expected_cost = expected_data["costEstimateResponse"][
            "costEstimateResponseInfo"
        ][0]["cost"]
        assert cost.inNetworkCosts == expected_cost["inNetworkCosts"]
        assert cost.outOfNetworkCosts == expected_cost["outOfNetworkCosts"]
        assert cost.inNetworkCostsType == expected_cost["inNetworkCostsType"]

        # Validate health claim line - should have percentage responsibility and empty amounts
        health_claim = response_info.healthClaimLine
        expected_health_claim = expected_data["costEstimateResponse"][
            "costEstimateResponseInfo"
        ][0]["healthClaimLine"]
        assert health_claim.amountCopay == 0.0
        assert health_claim.amountCoinsurance == 0.0
        assert health_claim.amountResponsibility == 0.0
        assert health_claim.percentResponsibility == float(
            expected_health_claim["percentResponsibility"]
        )
        assert health_claim.amountpayable == 0.0

        print("✅ All percentage rate type validations passed!")

    def test_compare_amount_vs_percentage_rate_types(
        self, sample_request, sample_selected_benefit, sample_insurance_context
    ):
        """Test comparing AMOUNT vs PERCENTAGE rate types"""
        selected_benefits = [sample_selected_benefit]

        # Test AMOUNT rate type
        amount_rate_data = load_mock_data("NegotiatedRate.json")
        amount_rate = NegotiatedRate(**amount_rate_data)

        amount_response = (
            CostEstimatorResponse.build_cost_estimator_response_from_info_objects(
                sample_request,
                [
                    CostEstimatorResponse.build_cost_estimate_response_info(
                        sample_request.providerInfo[0],
                        selected_benefits,
                        sample_insurance_context,
                        amount_rate,
                    )
                ],
            )
        )

        # Test PERCENTAGE rate type
        percentage_rate_data = load_mock_data("NegotiatedRatePercentage.json")
        percentage_rate = NegotiatedRate(**percentage_rate_data)

        percentage_response = (
            CostEstimatorResponse.build_cost_estimator_response_from_info_objects(
                sample_request,
                [
                    CostEstimatorResponse.build_cost_estimate_response_info(
                        sample_request.providerInfo[0],
                        selected_benefits,
                        sample_insurance_context,
                        percentage_rate,
                    )
                ],
            )
        )

        # Compare the responses
        amount_response_info = (
            amount_response.costEstimateResponse.costEstimateResponseInfo[0]
        )
        percentage_response_info = (
            percentage_response.costEstimateResponse.costEstimateResponseInfo[0]
        )

        # Type check to ensure we have the correct response type
        from app.schemas.cost_estimator_response import CostEstimateResponseInfo

        assert isinstance(amount_response_info, CostEstimateResponseInfo)
        assert isinstance(percentage_response_info, CostEstimateResponseInfo)

        # Compare cost types
        assert amount_response_info.cost.inNetworkCostsType == "AMOUNT"
        assert percentage_response_info.cost.inNetworkCostsType == "PERCENTAGE"

        # Compare health claim lines
        amount_health_claim = amount_response_info.healthClaimLine
        percentage_health_claim = percentage_response_info.healthClaimLine

        # AMOUNT type should have amount values and zero percentage
        assert amount_health_claim.amountCopay != 0.0
        assert amount_health_claim.amountCoinsurance != 0.0
        assert amount_health_claim.amountResponsibility != 0.0
        assert amount_health_claim.percentResponsibility == 0.0
        assert amount_health_claim.amountpayable != 0.0

        # PERCENTAGE type should have percentage value and zero amounts
        assert percentage_health_claim.amountCopay == 0.0
        assert percentage_health_claim.amountCoinsurance == 0.0
        assert percentage_health_claim.amountResponsibility == 0.0
        assert percentage_health_claim.percentResponsibility != 0.0
        assert percentage_health_claim.amountpayable == 0.0

        print("✅ AMOUNT vs PERCENTAGE rate type comparison passed!")
        print(
            f"   - AMOUNT: {amount_health_claim.amountResponsibility} responsibility, {amount_health_claim.amountpayable} payable"
        )
        print(
            f"   - PERCENTAGE: {percentage_health_claim.percentResponsibility}% responsibility"
        )

    def test_select_benefit_with_highest_member_pay_matching_code(
        self, sample_selected_benefit, sample_insurance_context
    ):
        """Test selecting benefit when benefit code matches"""
        selected_benefits = [sample_selected_benefit]

        result = CostEstimatorResponse.select_benefit(
            selected_benefits, sample_insurance_context
        )

        assert result is not None
        assert result == sample_selected_benefit

    def test_select_benefit_with_highest_member_pay_no_matching_code(
        self, sample_selected_benefit, sample_insurance_context
    ):
        """Test selecting benefit when no benefit code matches"""
        sample_insurance_context.benefit_id = "999"  # Different code
        selected_benefits = [sample_selected_benefit]

        result = CostEstimatorResponse.select_benefit(
            selected_benefits, sample_insurance_context
        )

        assert result is not None
        assert (
            result == sample_selected_benefit
        )  # Should return first benefit when no match

    def test_select_benefit_with_highest_member_pay_empty_list(
        self, sample_insurance_context
    ):
        """Test selecting benefit from empty list"""
        selected_benefits = []

        result = CostEstimatorResponse.select_benefit(
            selected_benefits, sample_insurance_context
        )

        assert result is None

    def test_build_accumulator_info_limit(self, sample_insurance_context):
        """Test building accumulator info for limit type"""
        # Create mock accumulator
        mock_accumulator = Mock()
        mock_accumulator.code = "limit"
        mock_accumulator.level = "individual"
        mock_accumulator.limitValue = 1000.0
        mock_accumulator.limitType = "dollar"
        mock_accumulator.calculatedValue = 500.0

        accumulators = [mock_accumulator]

        result = CostEstimatorResponse.build_accumulator(
            accumulators, sample_insurance_context, "AMOUNT"
        )

        assert len(result) == 1
        assert isinstance(result[0], AccumulatorInfo)
        assert result[0].accumulator.code == "limit"
        assert result[0].accumulator.level == "individual"
        assert result[0].accumulator.limitValue == 1000.0
        from app.schemas.cost_estimator_response import AccumulatorWithLimitType

        assert isinstance(result[0].accumulator, AccumulatorWithLimitType)
        assert result[0].accumulator.limitType == "dollar"
        assert result[0].accumulator.calculatedValue == 500.0

    def test_build_accumulator_info_limit_percentage(self, sample_insurance_context):
        """Test building accumulator info for limit type with PERCENTAGE rate"""
        # Create mock accumulator
        mock_accumulator = Mock()
        mock_accumulator.code = "limit"
        mock_accumulator.level = "individual"
        mock_accumulator.limitValue = 1000.0
        mock_accumulator.limitType = "dollar"
        mock_accumulator.calculatedValue = 500.0

        accumulators = [mock_accumulator]

        result = CostEstimatorResponse.build_accumulator(
            accumulators, sample_insurance_context, "PERCENTAGE"
        )

        assert len(result) == 1
        assert isinstance(result[0], AccumulatorInfo)
        assert result[0].accumulator.code == "limit"
        assert result[0].accumulator.level == "individual"
        assert result[0].accumulator.limitValue == 1000.0
        from app.schemas.cost_estimator_response import AccumulatorWithLimitType

        assert isinstance(result[0].accumulator, AccumulatorWithLimitType)
        assert result[0].accumulator.limitType == "dollar"
        assert result[0].accumulator.calculatedValue == 500.0

        # For PERCENTAGE rate type, remaining should be calculatedValue (not from insuranceContext)
        assert result[0].accumulatorCalculation.remainingValue == 500.0
        assert result[0].accumulatorCalculation.appliedValue == 0.0

    def test_build_accumulator_info_deductible_individual_percentage(
        self, sample_insurance_context
    ):
        """Test building accumulator info for individual deductible with PERCENTAGE rate"""
        # Create mock accumulator
        mock_accumulator = Mock()
        mock_accumulator.code = "deductible"
        mock_accumulator.level = "individual"
        mock_accumulator.limitValue = 1000.0
        mock_accumulator.limitType = "dollar"
        mock_accumulator.calculatedValue = 200.0

        accumulators = [mock_accumulator]

        result = CostEstimatorResponse.build_accumulator(
            accumulators, sample_insurance_context, "PERCENTAGE"
        )

        assert len(result) == 1
        assert isinstance(result[0], AccumulatorInfo)
        assert result[0].accumulator.code == "deductible"
        assert result[0].accumulator.level == "individual"

        # For PERCENTAGE rate type, remaining should be calculatedValue (not from insuranceContext)
        assert result[0].accumulatorCalculation.remainingValue == 200.0
        assert result[0].accumulatorCalculation.appliedValue == 0.0

    def test_build_accumulator_info_deductible_family_percentage(
        self, sample_insurance_context
    ):
        """Test building accumulator info for family deductible with PERCENTAGE rate"""
        # Create mock accumulator
        mock_accumulator = Mock()
        mock_accumulator.code = "deductible"
        mock_accumulator.level = "family"
        mock_accumulator.limitValue = 2000.0
        mock_accumulator.limitType = "dollar"
        mock_accumulator.calculatedValue = 400.0

        accumulators = [mock_accumulator]

        result = CostEstimatorResponse.build_accumulator(
            accumulators, sample_insurance_context, "PERCENTAGE"
        )

        assert len(result) == 1
        assert isinstance(result[0], AccumulatorInfo)
        assert result[0].accumulator.code == "deductible"
        assert result[0].accumulator.level == "family"

        # For PERCENTAGE rate type, remaining should be calculatedValue (not from insuranceContext)
        assert result[0].accumulatorCalculation.remainingValue == 400.0
        assert result[0].accumulatorCalculation.appliedValue == 0.0

    def test_build_accumulator_info_oopmax_individual_percentage(
        self, sample_insurance_context
    ):
        """Test building accumulator info for individual OOP max with PERCENTAGE rate"""
        # Create mock accumulator
        mock_accumulator = Mock()
        mock_accumulator.code = "oop max"
        mock_accumulator.level = "individual"
        mock_accumulator.limitValue = 5000.0
        mock_accumulator.limitType = "dollar"
        mock_accumulator.calculatedValue = 250.0

        accumulators = [mock_accumulator]

        result = CostEstimatorResponse.build_accumulator(
            accumulators, sample_insurance_context, "PERCENTAGE"
        )

        assert len(result) == 1
        assert isinstance(result[0], AccumulatorInfo)
        assert result[0].accumulator.code == "oop max"
        assert result[0].accumulator.level == "individual"

        # For PERCENTAGE rate type, remaining should be calculatedValue (not from insuranceContext)
        assert result[0].accumulatorCalculation.remainingValue == 250.0
        assert result[0].accumulatorCalculation.appliedValue == 0.0

    def test_build_accumulator_info_oopmax_family_percentage(
        self, sample_insurance_context
    ):
        """Test building accumulator info for family OOP max with PERCENTAGE rate"""
        # Create mock accumulator
        mock_accumulator = Mock()
        mock_accumulator.code = "oop max"
        mock_accumulator.level = "family"
        mock_accumulator.limitValue = 10000.0
        mock_accumulator.limitType = "dollar"
        mock_accumulator.calculatedValue = 500.0

        accumulators = [mock_accumulator]

        result = CostEstimatorResponse.build_accumulator(
            accumulators, sample_insurance_context, "PERCENTAGE"
        )

        assert len(result) == 1
        assert isinstance(result[0], AccumulatorInfo)
        assert result[0].accumulator.code == "oop max"
        assert result[0].accumulator.level == "family"

        # For PERCENTAGE rate type, remaining should be calculatedValue (not from insuranceContext)
        assert result[0].accumulatorCalculation.remainingValue == 500.0
        assert result[0].accumulatorCalculation.appliedValue == 0.0

    def test_build_accumulator_info_multiple_accumulators_percentage(
        self, sample_insurance_context
    ):
        """Test building accumulator info with multiple accumulators and PERCENTAGE rate"""
        # Create multiple mock accumulators
        mock_limit = Mock()
        mock_limit.code = "limit"
        mock_limit.level = "individual"
        mock_limit.limitValue = 1000.0
        mock_limit.limitType = "dollar"
        mock_limit.calculatedValue = 500.0

        mock_deductible = Mock()
        mock_deductible.code = "deductible"
        mock_deductible.level = "individual"
        mock_deductible.limitValue = 1000.0
        mock_deductible.limitType = "dollar"
        mock_deductible.calculatedValue = 200.0

        mock_oopmax = Mock()
        mock_oopmax.code = "oop max"
        mock_oopmax.level = "family"
        mock_oopmax.limitValue = 5000.0
        mock_oopmax.limitType = "dollar"
        mock_oopmax.calculatedValue = 500.0

        accumulators = [mock_limit, mock_deductible, mock_oopmax]

        result = CostEstimatorResponse.build_accumulator(
            accumulators, sample_insurance_context, "PERCENTAGE"
        )

        assert len(result) == 3
        assert result[0].accumulator.code == "limit"
        assert result[1].accumulator.code == "deductible"
        assert result[2].accumulator.code == "oop max"

        # For PERCENTAGE rate type, all remaining values should be calculatedValue
        assert result[0].accumulatorCalculation.remainingValue == 500.0
        assert result[0].accumulatorCalculation.appliedValue == 0.0
        assert result[1].accumulatorCalculation.remainingValue == 200.0
        assert result[1].accumulatorCalculation.appliedValue == 0.0
        assert result[2].accumulatorCalculation.remainingValue == 500.0
        assert result[2].accumulatorCalculation.appliedValue == 0.0

    def test_build_accumulator_info_deductible_individual(
        self, sample_insurance_context
    ):
        """Test building accumulator info for individual deductible"""
        # Create mock accumulator
        mock_accumulator = Mock()
        mock_accumulator.code = "deductible"
        mock_accumulator.level = "individual"
        mock_accumulator.limitValue = 1000.0
        mock_accumulator.limitType = "dollar"
        mock_accumulator.calculatedValue = 200.0

        accumulators = [mock_accumulator]

        result = CostEstimatorResponse.build_accumulator(
            accumulators, sample_insurance_context, "AMOUNT"
        )

        assert len(result) == 1
        assert isinstance(result[0], AccumulatorInfo)
        assert result[0].accumulator.code == "deductible"
        assert result[0].accumulator.level == "individual"
        assert result[0].accumulatorCalculation.remainingValue == 200.0

    def test_build_accumulator_info_deductible_family(self, sample_insurance_context):
        """Test building accumulator info for family deductible"""
        # Create mock accumulator
        mock_accumulator = Mock()
        mock_accumulator.code = "deductible"
        mock_accumulator.level = "family"
        mock_accumulator.limitValue = 2000.0
        mock_accumulator.limitType = "dollar"
        mock_accumulator.calculatedValue = 400.0

        accumulators = [mock_accumulator]

        result = CostEstimatorResponse.build_accumulator(
            accumulators, sample_insurance_context, "AMOUNT"
        )

        assert len(result) == 1
        assert isinstance(result[0], AccumulatorInfo)
        assert result[0].accumulator.code == "deductible"
        assert result[0].accumulator.level == "family"
        assert result[0].accumulatorCalculation.remainingValue == 400.0

    def test_build_accumulator_info_oopmax_individual(self, sample_insurance_context):
        """Test building accumulator info for individual OOP max"""
        # Create mock accumulator
        mock_accumulator = Mock()
        mock_accumulator.code = "oop max"
        mock_accumulator.level = "individual"
        mock_accumulator.limitValue = 5000.0
        mock_accumulator.limitType = "dollar"
        mock_accumulator.calculatedValue = 250.0

        accumulators = [mock_accumulator]

        result = CostEstimatorResponse.build_accumulator(
            accumulators, sample_insurance_context, "AMOUNT"
        )

        assert len(result) == 1
        assert isinstance(result[0], AccumulatorInfo)
        assert result[0].accumulator.code == "oop max"
        assert result[0].accumulator.level == "individual"
        assert result[0].accumulatorCalculation.remainingValue == 250.0

    def test_build_accumulator_info_oopmax_family(self, sample_insurance_context):
        """Test building accumulator info for family OOP max"""
        # Create mock accumulator
        mock_accumulator = Mock()
        mock_accumulator.code = "oop max"
        mock_accumulator.level = "family"
        mock_accumulator.limitValue = 10000.0
        mock_accumulator.limitType = "dollar"
        mock_accumulator.calculatedValue = 500.0

        accumulators = [mock_accumulator]

        result = CostEstimatorResponse.build_accumulator(
            accumulators, sample_insurance_context, "AMOUNT"
        )

        assert len(result) == 1
        assert isinstance(result[0], AccumulatorInfo)
        assert result[0].accumulator.code == "oop max"
        assert result[0].accumulator.level == "family"
        assert result[0].accumulatorCalculation.remainingValue == 500.0

    def test_build_accumulator_info_unknown_type(self, sample_insurance_context):
        """Test building accumulator info for unknown accumulator type"""
        # Create mock accumulator with unknown code
        mock_accumulator = Mock()
        mock_accumulator.code = "unknown"
        mock_accumulator.level = "individual"
        mock_accumulator.limitValue = 1000.0
        mock_accumulator.limitType = "dollar"
        mock_accumulator.calculatedValue = 500.0

        accumulators = [mock_accumulator]

        result = CostEstimatorResponse.build_accumulator(
            accumulators, sample_insurance_context, "AMOUNT"
        )

        assert len(result) == 0  # Should not process unknown accumulator types

    def test_build_accumulator_info_empty_list(self, sample_insurance_context):
        """Test building accumulator info with empty list"""
        accumulators = []

        result = CostEstimatorResponse.build_accumulator(
            accumulators, sample_insurance_context, "AMOUNT"
        )

        assert len(result) == 0

    def test_build_accumulator_info_none_limit_type(self, sample_insurance_context):
        """Test building accumulator info with None limit type"""
        # Create mock accumulator with None limitType
        mock_accumulator = Mock()
        mock_accumulator.code = "limit"
        mock_accumulator.level = "individual"
        mock_accumulator.limitValue = 1000.0
        mock_accumulator.limitType = None
        mock_accumulator.calculatedValue = 500.0

        accumulators = [mock_accumulator]

        result = CostEstimatorResponse.build_accumulator(
            accumulators, sample_insurance_context, "AMOUNT"
        )

        assert len(result) == 1
        from app.schemas.cost_estimator_response import AccumulatorWithLimitType

        assert isinstance(result[0].accumulator, AccumulatorWithLimitType)
        assert (
            result[0].accumulator.limitType == ""
        )  # Should convert None to empty string

    def test_build_accumulator_info_multiple_accumulators(
        self, sample_insurance_context
    ):
        """Test building accumulator info with multiple accumulators"""
        # Create multiple mock accumulators
        mock_limit = Mock()
        mock_limit.code = "limit"
        mock_limit.level = "individual"
        mock_limit.limitValue = 1000.0
        mock_limit.limitType = "dollar"
        mock_limit.calculatedValue = 500.0

        mock_deductible = Mock()
        mock_deductible.code = "deductible"
        mock_deductible.level = "individual"
        mock_deductible.limitValue = 1000.0
        mock_deductible.limitType = "dollar"
        mock_deductible.calculatedValue = 200.0

        mock_oopmax = Mock()
        mock_oopmax.code = "oop max"
        mock_oopmax.level = "family"
        mock_oopmax.limitValue = 5000.0
        mock_oopmax.limitType = "dollar"
        mock_oopmax.calculatedValue = 500.0

        accumulators = [mock_limit, mock_deductible, mock_oopmax]

        result = CostEstimatorResponse.build_accumulator(
            accumulators, sample_insurance_context, "AMOUNT"
        )

        assert len(result) == 3
        assert result[0].accumulator.code == "limit"
        assert result[1].accumulator.code == "deductible"
        assert result[2].accumulator.code == "oop max"

    def test_build_cost_estimate_response_info_provider_not_found(
        self, sample_request, sample_selected_benefit, sample_insurance_context
    ):
        """Test that ProviderNotFoundException is returned when isProviderInfoFound is False"""
        selected_benefits = [sample_selected_benefit]

        # Create a NegotiatedRate with isProviderInfoFound=False
        rate = NegotiatedRate(
            paymentMethod="COPAY",
            rate=150.0,
            rateType="AMOUNT",
            isRateFound=True,
            isProviderInfoFound=False,
        )

        result = CostEstimatorResponse.build_cost_estimate_response_info(
            sample_request.providerInfo[0],
            selected_benefits,
            sample_insurance_context,
            rate,
        )

        # Should return CostEstimateResponseInfoError
        from app.schemas.cost_estimator_response import CostEstimateResponseInfoError
        from app.exception.exceptions import ProviderNotFoundException

        assert isinstance(result, CostEstimateResponseInfoError)
        assert "exception" in result.model_dump()
        assert result.providerInfo == sample_request.providerInfo[0]

    def test_build_cost_estimate_response_info_rate_not_found(
        self, sample_request, sample_selected_benefit, sample_insurance_context
    ):
        """Test that RateNotFoundException is returned when isRateFound is False"""
        selected_benefits = [sample_selected_benefit]

        # Create a NegotiatedRate with isRateFound=False
        rate = NegotiatedRate(
            paymentMethod="COPAY",
            rate=0.0,
            rateType="AMOUNT",
            isRateFound=False,
            isProviderInfoFound=True,
        )

        result = CostEstimatorResponse.build_cost_estimate_response_info(
            sample_request.providerInfo[0],
            selected_benefits,
            sample_insurance_context,
            rate,
        )

        # Should return CostEstimateResponseInfoError
        from app.schemas.cost_estimator_response import CostEstimateResponseInfoError
        from app.exception.exceptions import RateNotFoundException

        assert isinstance(result, CostEstimateResponseInfoError)
        assert "exception" in result.model_dump()
        assert result.providerInfo == sample_request.providerInfo[0]

    def test_build_cost_estimate_response_info_insurance_context_error(
        self, sample_request, sample_selected_benefit
    ):
        """Test that InsuranceContextException is returned when insuranceContext has error_code"""
        selected_benefits = [sample_selected_benefit]

        # Create an InsuranceContext with error
        insurance_context = InsuranceContext()
        insurance_context.error_code = "INVALID_BENEFIT"
        insurance_context.error_message = "Invalid benefit configuration"

        rate = NegotiatedRate(
            paymentMethod="COPAY",
            rate=150.0,
            rateType="AMOUNT",
            isRateFound=True,
            isProviderInfoFound=True,
        )

        result = CostEstimatorResponse.build_cost_estimate_response_info(
            sample_request.providerInfo[0], selected_benefits, insurance_context, rate
        )

        # Should return CostEstimateResponseInfoError
        from app.schemas.cost_estimator_response import CostEstimateResponseInfoError
        from app.exception.exceptions import InsuranceContextException

        assert isinstance(result, CostEstimateResponseInfoError)
        assert "exception" in result.model_dump()
        assert result.providerInfo == sample_request.providerInfo[0]

    def test_build_cost_estimate_response_info_insurance_context_error_with_raise_exception(
        self, sample_request, sample_selected_benefit
    ):
        """Test that InsuranceContextException is raised when raise_exception=True"""
        selected_benefits = [sample_selected_benefit]

        # Create an InsuranceContext with error
        insurance_context = InsuranceContext()
        insurance_context.error_code = "INVALID_BENEFIT"
        insurance_context.error_message = "Invalid benefit configuration"

        rate = NegotiatedRate(
            paymentMethod="COPAY",
            rate=150.0,
            rateType="AMOUNT",
            isRateFound=True,
            isProviderInfoFound=True,
        )

        # Should raise the exception when raise_exception=True
        from app.exception.exceptions import InsuranceContextException

        with pytest.raises(InsuranceContextException) as exc_info:
            CostEstimatorResponse.build_cost_estimate_response_info(
                sample_request.providerInfo[0],
                selected_benefits,
                insurance_context,
                rate,
                raise_exception=True,
            )

        assert exc_info.value.error_code == "INVALID_BENEFIT"
        assert exc_info.value.error_message == "Invalid benefit configuration"
