import pytest
from app.schemas.benefit_request import (
    BenefitRequest,
    ServiceInfo,
    ServiceCodeInfo,
    ProviderType,
    PlaceOfService,
    ProviderSpecialty,
)


def test_benefit_request():
    request = BenefitRequest(
        membershipID="5~265642286+34+44+20250101+784461+AM+39",
        benefitProductType="medical",
        serviceInfo=[
            ServiceInfo(
                serviceCodeInfo=ServiceCodeInfo(
                    code="99214",
                    type="CPT4",
                    modifier=[],
                    supportingServiceCodes=[],
                    placeOfService=[PlaceOfService(code="POS1")],
                    providerType=[ProviderType(code="PT1")],
                    providerSpecialty=[ProviderSpecialty(code="PS1")],
                    pin="",
                )
            )
        ],
    )

    assert request.benefitProductType == "medical"
    assert request.membershipID == "5~265642286+34+44+20250101+784461+AM+39"
    assert len(request.serviceInfo) == 1
    assert request.serviceInfo[0].serviceCodeInfo.code == "99214"
    assert request.serviceInfo[0].serviceCodeInfo.type == "CPT4"
    assert request.serviceInfo[0].serviceCodeInfo.modifier == []
    assert request.serviceInfo[0].serviceCodeInfo.supportingServiceCodes == []
    assert request.serviceInfo[0].serviceCodeInfo.pin == ""
