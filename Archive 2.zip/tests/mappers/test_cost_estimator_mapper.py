import pytest
from app.schemas.cost_estimator_request import (
    CostEstimatorRequest,
    Service,
    ProviderInfo,
    Speciality,
    SupportingService,
    Modifier,
    PlaceOfService,
    ProviderNetworks,
    ProviderNetworkParticipation,
)
from app.mappers.cost_estimator_mapper import CostEstimatorMapper
from app.exception.exceptions import ProviderNotFoundException


@pytest.fixture
def sample_cost_estimator_request():
    return CostEstimatorRequest(
        membershipId=" 5~265639479+10+110+20250101+827528+CJ+324    ",  # intentional whitespaces for testing
        zipCode="85305",
        benefitProductType="Medical",
        languageCode="11",
        service=Service(
            code=" 43277    ",
            type="  CPT4 ",
            description="Adult Office visit Age 30-39",
            supportingService=SupportingService(code="470", type="DRG"),
            modifier=Modifier(modifierCode="E1"),
            diagnosisCode="F33 40",
            placeOfService=PlaceOfService(code="11"),
        ),
        providerInfo=None,
    )


@pytest.fixture
def sample_provider_info():
    return ProviderInfo(
        serviceLocation="9013494",
        providerType="HO",
        speciality=Speciality(code=""),
        taxIdentificationNumber="0000431173518",
        taxIdQualifier="SN",
        providerNetworks=ProviderNetworks(networkID="01965"),
        providerIdentificationNumber="8679669",
        nationalProviderId="1386660504",
        providerNetworkParticipation=ProviderNetworkParticipation(providerTier="1"),
    )


def test_to_benefit_request(sample_cost_estimator_request, sample_provider_info):
    sample_cost_estimator_request.providerInfo = [
        sample_provider_info,
        sample_provider_info,
    ]
    benefit_request = CostEstimatorMapper.to_benefit_request(
        sample_cost_estimator_request
    )
    assert len(benefit_request) == 2
    assert benefit_request[0].benefitProductType == "Medical"
    assert (
        benefit_request[0].membershipID == "5~265639479+10+110+20250101+827528+CJ+324"
    )
    assert len(benefit_request[0].serviceInfo) == 1
    assert benefit_request[0].serviceInfo[0].serviceCodeInfo.code == "43277"
    assert benefit_request[0].serviceInfo[0].serviceCodeInfo.type == "CPT4"
    assert (
        benefit_request[0].serviceInfo[0].serviceCodeInfo.providerType[0].code == "HO"
    )
    assert (
        benefit_request[0].serviceInfo[0].serviceCodeInfo.placeOfService[0].code == "11"
    )
    assert (
        benefit_request[0].serviceInfo[0].serviceCodeInfo.providerSpecialty[0].code
        == ""
    )


def test_to_rate_criteria_no_provider_info(sample_cost_estimator_request):
    rate_criteria = CostEstimatorMapper.to_rate_criteria(sample_cost_estimator_request)
    assert len(rate_criteria) == 1
    assert rate_criteria[0].providerIdentificationNumber == ""
    assert rate_criteria[0].serviceCode == "43277"
    assert rate_criteria[0].serviceType == "CPT4"
    assert rate_criteria[0].serviceLocationNumber == ""
    assert rate_criteria[0].networkId is None
    assert rate_criteria[0].placeOfService == "11"
    assert rate_criteria[0].zipCode == "85305"
    assert rate_criteria[0].isOutofNetwork == True
    assert rate_criteria[0].providerSpecialtyCode is None
    assert rate_criteria[0].providerType is None


def test_to_rate_criteria_with_empty_provider_info(sample_cost_estimator_request):
    sample_cost_estimator_request.providerInfo = []
    with pytest.raises(ProviderNotFoundException):
        CostEstimatorMapper.to_rate_criteria(sample_cost_estimator_request)


def test_to_rate_criteria_with_provider_info(
    sample_cost_estimator_request, sample_provider_info
):
    sample_cost_estimator_request.providerInfo = [sample_provider_info]
    rate_criteria = CostEstimatorMapper.to_rate_criteria(sample_cost_estimator_request)
    assert len(rate_criteria) == 1
    assert rate_criteria[0].providerIdentificationNumber == "8679669"
    assert rate_criteria[0].serviceCode == "43277"
    assert rate_criteria[0].serviceType == "CPT4"
    assert rate_criteria[0].serviceLocationNumber == "9013494"
    assert rate_criteria[0].networkId == "01965"
    assert rate_criteria[0].placeOfService == "11"
    assert rate_criteria[0].zipCode == "85305"
    assert rate_criteria[0].isOutofNetwork == False
    assert rate_criteria[0].providerSpecialtyCode == ""
    assert rate_criteria[0].providerType == "HO"
