from behave import given, when, then  # type: ignore
from unittest.mock import Mock
from app.services.handlers.cost_share_co_pay_handler import CostShareCoPayHandler
from app.core.base import InsuranceContext


@given("an CopayHandler is created")
def step_impl(context):
    """Create a CostShareCoPayHandler with mocked dependencies"""
    # Create the handler
    context.handler = CostShareCoPayHandler()

    # Create insurance context first
    context.insurance_context = InsuranceContext()

    # Create mocked dependencies
    context.mock_oopmax_copay_handler = Mock()
    context.mock_deductible_co_insurance_handler = Mock()

    # Configure mocked handlers to return the insurance context with calculation_complete set
    def mock_oopmax_handler_handle(context):
        context.calculation_complete = True
        return context

    def mock_deductible_co_insurance_handler_handle(context):
        context.calculation_complete = True
        return context

    context.mock_oopmax_copay_handler.handle.side_effect = mock_oopmax_handler_handle
    context.mock_deductible_co_insurance_handler.handle.side_effect = (
        mock_deductible_co_insurance_handler_handle
    )

    # Set the mocked dependencies
    context.handler.set_oopmax_copay_handler(context.mock_oopmax_copay_handler)
    context.handler.set_deductible_co_insurance_handler(
        context.mock_deductible_co_insurance_handler
    )

    # Reset mock call counts for this scenario
    context.mock_oopmax_copay_handler.reset_mock()
    context.mock_deductible_co_insurance_handler.reset_mock()


@given("the member co-pay is {amount}")
def step_member_copay(context, amount):
    """Set the member co-pay amount in the insurance context"""
    copay_amount = float(amount)
    context.insurance_context.cost_share_copay = copay_amount

    # Also update selected_benefit_of_highest_member_pay.coverage.costShareCopay if it exists
    selected_benefit = getattr(
        context.insurance_context, "selected_benefit_of_highest_member_pay", None
    )
    if selected_benefit and hasattr(selected_benefit, "coverage"):
        selected_benefit.coverage.costShareCopay = copay_amount


@then("the co-pay amount is updated to {amount}")
def step_copay_amount_updated(context, amount):
    """Verify the co-pay amount is updated to the expected amount"""
    expected_amount = float(amount)
    actual_amount = context.result.amount_copay
    assert (
        actual_amount == expected_amount
    ), f"Expected co-pay amount to be {expected_amount}, but it is {actual_amount}"


@then("the member co-pay is updated to {amount}")
def step_member_copay_updated(context, amount):
    """Verify the member co-pay is updated to the expected amount"""
    expected_amount = float(amount)
    actual_amount = context.result.cost_share_copay
    assert (
        actual_amount == expected_amount
    ), f"Expected member co-pay to be {expected_amount}, but it is {actual_amount}"


@given("the copay continue when OOPMax met indicator is {indicator}")
def step_copay_continue_indicator(context, indicator):
    """Set the copay continue when OOPMax met indicator"""
    context.insurance_context.copay_continue_when_oop_met = indicator == "True"


@then("the oopmax copay handler is called")
def step_oopmax_copay_handler_called(context):
    """Verify that the oopmax copay handler was called"""
    context.mock_oopmax_copay_handler.handle.assert_called_once_with(
        context.insurance_context
    )


@then("the oopmax copay handler is not called")
def step_oopmax_copay_handler_not_called(context):
    """Verify that the oopmax copay handler was NOT called"""
    context.mock_oopmax_copay_handler.handle.assert_not_called()


@then("the deductible coinsurance handler is called")
def step_deductible_coinsurance_handler_called(context):
    """Verify that the deductible coinsurance handler was called"""
    context.mock_deductible_co_insurance_handler.handle.assert_called_once_with(
        context.insurance_context
    )


@then("the deductible coinsurance handler is not called")
def step_deductible_coinsurance_handler_not_called(context):
    """Verify that the deductible coinsurance handler was NOT called"""
    context.mock_deductible_co_insurance_handler.handle.assert_not_called()
