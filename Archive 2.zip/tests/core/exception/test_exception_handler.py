import pytest
import json
from unittest.mock import Mock, patch
from fastapi import Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse

from app.exception.exception_handler import (
    produce_response_content,
    validation_exception_handler,
    rate_not_found_exception_handler,
    rate_not_found_exception_handler_logic,
    benefits_not_found_exception_handler,
    benefits_not_found_exception_handler_logic,
    benefits_member_not_found_exception_handler,
    benefits_member_not_found_exception_handler_logic,
    benefits_not_matching_exception_handler,
    benefits_not_matching_exception_handler_logic,
    accumulator_not_found_exception_handler,
    accumulator_member_not_found_exception_handler,
    insurance_context_error_exception_handler,
    insurance_context_error_exception_handler_logic,
    generic_exception_handler,
    include_exceptions,
)
from app.exception.exceptions import (
    RateNotFoundException,
    BenefitsNotFoundException,
    BenefitsMemberNotFoundException,
    BenefitsNotMatchingException,
    AccumulatorNotFoundException,
    AccumulatorMemberNotFoundException,
    InsuranceContextException,
)


def get_response_content(response: JSONResponse) -> dict:
    """Helper function to get JSON response content as dict."""
    return json.loads(bytes(response.body).decode("utf-8"))


class TestProduceResponseContent:
    """Test the produce_response_content function."""

    @patch("app.exception.exception_handler.logger")
    def test_produce_response_content_basic(self, mock_logger):
        """Test basic response content production."""
        exc = Exception("Test error")

        result = produce_response_content(exc)

        assert result["correlationId"] == "069d197a-1e14-453f-8cf4-63f74eb626ff"
        assert result["type"] == "https://www.rfc-editor.org/rfc/rfc7231#section-6.5.4"
        assert result["title"] == "Error"
        assert result["status"] == 500
        assert result["detail"] == "Test error"
        assert result["message"] == "Test error"
        mock_logger.error.assert_called_once_with("Exception: Test error")


class TestValidationExceptionHandler:
    """Test the validation_exception_handler function."""

    @pytest.mark.asyncio
    async def test_validation_exception_handler_missing_field(self):
        """Test validation exception handler with missing field error."""
        request = Mock(spec=Request)

        # Create a mock validation error
        validation_error = Mock(spec=RequestValidationError)
        validation_error.errors.return_value = [
            {
                "loc": ("body", "membershipId"),
                "type": "missing",
                "msg": "Field required",
            }
        ]

        response = await validation_exception_handler(request, validation_error)

        assert isinstance(response, JSONResponse)
        assert response.status_code == 400

        # Get response content as dict
        content = get_response_content(response)
        assert "Missing required field: membershipId" in content["detail"]
        assert content["title"] == "Validation Error"
        assert content["message"] == "One or more validation errors occurred"

    @pytest.mark.asyncio
    async def test_validation_exception_handler_string_too_short(self):
        """Test validation exception handler with string too short error."""
        request = Mock(spec=Request)

        validation_error = Mock(spec=RequestValidationError)
        validation_error.errors.return_value = [
            {
                "loc": ("body", "zipCode"),
                "type": "string_too_short",
                "msg": "String too short",
                "ctx": {"min_length": 5},
            }
        ]

        response = await validation_exception_handler(request, validation_error)

        assert isinstance(response, JSONResponse)
        assert response.status_code == 400

        content = get_response_content(response)
        assert "Field 'zipCode' must have at least 5 character(s)" in content["detail"]

    @pytest.mark.asyncio
    async def test_validation_exception_handler_json_invalid(self):
        """Test validation exception handler with JSON invalid error."""
        request = Mock(spec=Request)

        validation_error = Mock(spec=RequestValidationError)
        validation_error.errors.return_value = [
            {
                "loc": ("body",),
                "type": "json_invalid",
                "msg": "Invalid JSON",
                "ctx": {"error": "Expecting ',' delimiter"},
            }
        ]

        response = await validation_exception_handler(request, validation_error)

        assert isinstance(response, JSONResponse)
        assert response.status_code == 400

        content = get_response_content(response)
        assert "Invalid JSON format: Expecting ',' delimiter" in content["detail"]

    @pytest.mark.asyncio
    async def test_validation_exception_handler_multiple_errors(self):
        """Test validation exception handler with multiple errors."""
        request = Mock(spec=Request)

        validation_error = Mock(spec=RequestValidationError)
        validation_error.errors.return_value = [
            {
                "loc": ("body", "membershipId"),
                "type": "missing",
                "msg": "Field required",
            },
            {
                "loc": ("body", "service", "code"),
                "type": "string_too_short",
                "msg": "String too short",
                "ctx": {"min_length": 1},
            },
        ]

        response = await validation_exception_handler(request, validation_error)

        assert isinstance(response, JSONResponse)
        assert response.status_code == 400

        content = get_response_content(response)
        assert "Missing required field: membershipId" in content["detail"]
        assert (
            "Field 'service.code' must have at least 1 character(s)"
            in content["detail"]
        )


class TestRateNotFoundExceptionHandler:
    """Test the rate_not_found_exception_handler functions."""

    def test_rate_not_found_exception_handler_logic(self):
        """Test rate_not_found_exception_handler_logic function."""
        exc = RateNotFoundException("Custom rate not found message")

        result = rate_not_found_exception_handler_logic(exc)

        assert result["detail"] == "Custom rate not found message"
        assert result["title"] == "Rate not found"
        assert result["message"] == "Rate not found for the provided criteria"
        assert result["status"] == 500

    @pytest.mark.asyncio
    async def test_rate_not_found_exception_handler_with_correct_exception(self):
        """Test rate_not_found_exception_handler with RateNotFoundException."""
        request = Mock(spec=Request)
        exc = RateNotFoundException("Rate not found for provider")

        response = await rate_not_found_exception_handler(request, exc)

        assert isinstance(response, JSONResponse)
        assert response.status_code == 500

        content = get_response_content(response)
        assert "Rate not found for provider" in content["detail"]
        assert "Rate not found" in content["title"]

    @pytest.mark.asyncio
    async def test_rate_not_found_exception_handler_with_other_exception(self):
        """Test rate_not_found_exception_handler with non-RateNotFoundException."""
        request = Mock(spec=Request)
        exc = Exception("Some other error")

        response = await rate_not_found_exception_handler(request, exc)

        assert isinstance(response, JSONResponse)
        assert response.status_code == 500

        content = get_response_content(response)
        assert "Some other error" in content["detail"]


class TestBenefitsNotFoundExceptionHandler:
    """Test the benefits_not_found_exception_handler functions."""

    def test_benefits_not_found_exception_handler_logic_default_status(self):
        """Test benefits_not_found_exception_handler_logic with default status."""
        exc = BenefitsNotFoundException("Benefits not found")

        result = benefits_not_found_exception_handler_logic(exc)

        assert result["detail"] == "Benefits not found"
        assert result["title"] == "Benefits not found"
        assert result["message"] == "Benefits not found for the provided request"
        assert result["status"] == 500

    def test_benefits_not_found_exception_handler_logic_with_status_400(self):
        """Test benefits_not_found_exception_handler_logic with status 400."""
        exc = BenefitsNotFoundException("Status 400: Member not found")

        result = benefits_not_found_exception_handler_logic(exc)

        assert result["detail"] == "Member not found"
        assert result["title"] == "Benefits not found"
        assert result["message"] == "Benefits not found for the provided request"
        assert result["status"] == 400

    def test_benefits_not_found_exception_handler_logic_with_status_404(self):
        """Test benefits_not_found_exception_handler_logic with status 404."""
        exc = BenefitsNotFoundException("Status 404: No benefits available")

        result = benefits_not_found_exception_handler_logic(exc)

        assert result["detail"] == "No benefits available"
        assert result["title"] == "Benefits not found"
        assert result["message"] == "Benefits not found for the provided request"
        assert result["status"] == 404

    def test_benefits_not_found_exception_handler_logic_invalid_status_format(self):
        """Test benefits_not_found_exception_handler_logic with invalid status format."""
        exc = BenefitsNotFoundException("Status invalid: Some message")

        result = benefits_not_found_exception_handler_logic(exc)

        # Should keep original message and default status
        assert result["detail"] == "Status invalid: Some message"
        assert result["status"] == 500

    @pytest.mark.asyncio
    async def test_benefits_not_found_exception_handler_with_correct_exception(self):
        """Test benefits_not_found_exception_handler with BenefitsNotFoundException."""
        request = Mock(spec=Request)
        exc = BenefitsNotFoundException("Status 400: Member not found")

        response = await benefits_not_found_exception_handler(request, exc)

        assert isinstance(response, JSONResponse)
        assert response.status_code == 500

        content = get_response_content(response)
        assert "Member not found" in content["detail"]
        assert "Benefits not found" in content["title"]


class TestBenefitsMemberNotFoundExceptionHandler:
    """Test the benefits_member_not_found_exception_handler functions."""

    def test_benefits_member_not_found_exception_handler_logic_default_status(self):
        """Test benefits_member_not_found_exception_handler_logic with default status."""
        exc = BenefitsMemberNotFoundException("Member not found")

        result = benefits_member_not_found_exception_handler_logic(exc)

        assert result["detail"] == "Member not found"
        assert result["title"] == "Member not found by benefits api"
        assert result["message"] == "Member not found by benefits api"
        assert result["status"] == 500

    def test_benefits_member_not_found_exception_handler_logic_with_status_400(self):
        """Test benefits_member_not_found_exception_handler_logic with status 400."""
        exc = BenefitsMemberNotFoundException("Status 400: Invalid member ID")

        result = benefits_member_not_found_exception_handler_logic(exc)

        assert result["detail"] == "Invalid member ID"
        assert result["title"] == "Member not found by benefits api"
        assert result["message"] == "Member not found by benefits api"
        assert result["status"] == 400

    @pytest.mark.asyncio
    async def test_benefits_member_not_found_exception_handler_with_correct_exception(
        self,
    ):
        """Test benefits_member_not_found_exception_handler with BenefitsMemberNotFoundException."""
        request = Mock(spec=Request)
        exc = BenefitsMemberNotFoundException("Status 404: Member ID not found")

        response = await benefits_member_not_found_exception_handler(request, exc)

        assert isinstance(response, JSONResponse)
        assert response.status_code == 500

        content = get_response_content(response)
        assert "Member ID not found" in content["detail"]
        assert "Member not found by benefits api" in content["title"]


class TestBenefitsNotMatchingExceptionHandler:
    """Test the benefits_not_matching_exception_handler functions."""

    def test_benefits_not_matching_exception_handler_logic(self):
        """Test benefits_not_matching_exception_handler_logic function."""
        exc = BenefitsNotMatchingException("No matching benefits found")

        result = benefits_not_matching_exception_handler_logic(exc)

        assert result["detail"] == "No matching benefits found"
        assert result["title"] == "Benefits not matching"
        assert result["message"] == "No matching selected benefits"
        assert result["status"] == 500

    @pytest.mark.asyncio
    async def test_benefits_not_matching_exception_handler_with_correct_exception(self):
        """Test benefits_not_matching_exception_handler with BenefitsNotMatchingException."""
        request = Mock(spec=Request)
        exc = BenefitsNotMatchingException("No benefits match the criteria")

        response = await benefits_not_matching_exception_handler(request, exc)

        assert isinstance(response, JSONResponse)
        assert response.status_code == 500

        content = get_response_content(response)
        assert "No benefits match the criteria" in content["detail"]
        assert "Benefits not matching" in content["title"]


class TestAccumulatorNotFoundExceptionHandler:
    """Test the accumulator_not_found_exception_handler function."""

    @pytest.mark.asyncio
    async def test_accumulator_not_found_exception_handler_with_correct_exception(self):
        """Test accumulator_not_found_exception_handler with AccumulatorNotFoundException."""
        request = Mock(spec=Request)
        exc = AccumulatorNotFoundException("Status 400: Accumulator not found")

        response = await accumulator_not_found_exception_handler(request, exc)

        assert isinstance(response, JSONResponse)
        assert response.status_code == 500

        content = get_response_content(response)
        assert "Accumulator not found" in content["detail"]
        assert "Accumulator not found" in content["title"]

    @pytest.mark.asyncio
    async def test_accumulator_not_found_exception_handler_with_other_exception(self):
        """Test accumulator_not_found_exception_handler with non-AccumulatorNotFoundException."""
        request = Mock(spec=Request)
        exc = Exception("Some other error")

        response = await accumulator_not_found_exception_handler(request, exc)

        assert isinstance(response, JSONResponse)
        assert response.status_code == 500

        content = get_response_content(response)
        assert "Some other error" in content["detail"]


class TestAccumulatorMemberNotFoundExceptionHandler:
    """Test the accumulator_member_not_found_exception_handler function."""

    @pytest.mark.asyncio
    async def test_accumulator_member_not_found_exception_handler_with_correct_exception(
        self,
    ):
        """Test accumulator_member_not_found_exception_handler with AccumulatorMemberNotFoundException."""
        request = Mock(spec=Request)
        exc = AccumulatorMemberNotFoundException(
            "Status 404: Member not found in accumulator"
        )

        response = await accumulator_member_not_found_exception_handler(request, exc)

        assert isinstance(response, JSONResponse)
        assert response.status_code == 500

        content = get_response_content(response)
        assert "Member not found in accumulator" in content["detail"]
        assert "Member not found by accumulator api" in content["title"]

    @pytest.mark.asyncio
    async def test_accumulator_member_not_found_exception_handler_with_other_exception(
        self,
    ):
        """Test accumulator_member_not_found_exception_handler with non-AccumulatorMemberNotFoundException."""
        request = Mock(spec=Request)
        exc = Exception("Some other error")

        response = await accumulator_member_not_found_exception_handler(request, exc)

        assert isinstance(response, JSONResponse)
        assert response.status_code == 500

        content = get_response_content(response)
        assert "Some other error" in content["detail"]


class TestInsuranceContextExceptionHandler:
    """Test the insurance_context_error_exception_handler functions."""

    def test_insurance_context_error_exception_handler_logic_basic(self):
        """Test insurance_context_error_exception_handler_logic with basic message."""
        exc = InsuranceContextException("Insurance context error")

        result = insurance_context_error_exception_handler_logic(exc)

        assert result["detail"] == "Insurance context error"
        assert result["title"] == "Insurance context error"
        assert result["message"] == "Insurance context error for the provided request"

    def test_insurance_context_error_exception_handler_logic_with_error_code(self):
        """Test insurance_context_error_exception_handler_logic with error code."""
        exc = InsuranceContextException("Insurance context error", error_code="IC001")

        result = insurance_context_error_exception_handler_logic(exc)

        assert result["detail"] == "Insurance context error with error code IC001"
        assert result["title"] == "Insurance context error"
        assert result["message"] == "Insurance context error for the provided request"

    def test_insurance_context_error_exception_handler_logic_with_error_message(self):
        """Test insurance_context_error_exception_handler_logic with error message."""
        exc = InsuranceContextException(
            "Insurance context error", error_message="Invalid context"
        )

        result = insurance_context_error_exception_handler_logic(exc)

        assert (
            result["detail"]
            == "Insurance context error and error message Invalid context"
        )
        assert result["title"] == "Insurance context error"
        assert result["message"] == "Insurance context error for the provided request"

    def test_insurance_context_error_exception_handler_logic_with_both_error_code_and_message(
        self,
    ):
        """Test insurance_context_error_exception_handler_logic with both error code and message."""
        exc = InsuranceContextException(
            "Insurance context error",
            error_code="IC001",
            error_message="Invalid context",
        )

        result = insurance_context_error_exception_handler_logic(exc)

        assert (
            result["detail"]
            == "Insurance context error with error code IC001 and error message Invalid context"
        )
        assert result["title"] == "Insurance context error"
        assert result["message"] == "Insurance context error for the provided request"

    @pytest.mark.asyncio
    async def test_insurance_context_error_exception_handler_with_correct_exception(
        self,
    ):
        """Test insurance_context_error_exception_handler with InsuranceContextException."""
        request = Mock(spec=Request)
        exc = InsuranceContextException("Context validation failed", error_code="CV001")

        response = await insurance_context_error_exception_handler(request, exc)

        assert isinstance(response, JSONResponse)
        assert response.status_code == 500

        content = get_response_content(response)
        assert "Context validation failed with error code CV001" in content["detail"]
        assert "Insurance context error" in content["title"]


class TestGenericExceptionHandler:
    """Test the generic_exception_handler function."""

    @pytest.mark.asyncio
    async def test_generic_exception_handler(self):
        """Test generic_exception_handler with any exception."""
        request = Mock(spec=Request)
        exc = Exception("Some unexpected error")

        response = await generic_exception_handler(request, exc)

        assert isinstance(response, JSONResponse)
        assert response.status_code == 500

        content = get_response_content(response)
        assert "Some unexpected error" in content["detail"]


class TestIncludeExceptions:
    """Test the include_exceptions function."""

    def test_include_exceptions_adds_all_handlers(self):
        """Test that include_exceptions adds all exception handlers to the app."""
        from fastapi import FastAPI

        app = FastAPI()

        # Call include_exceptions
        result_app = include_exceptions(app)

        # Verify the app is returned
        assert result_app is app

        # Verify all exception handlers are registered
        # Note: We can't easily test the internal registration without accessing private attributes
        # But we can verify the function doesn't raise any exceptions
        assert True  # If we get here, the function executed successfully


# Integration tests using FastAPI TestClient
class TestExceptionHandlerIntegration:
    """Integration tests for exception handlers using FastAPI TestClient."""

    def test_validation_error_integration(self):
        """Test validation error handling in a real FastAPI request."""
        from fastapi.testclient import TestClient
        from fastapi import FastAPI
        from pydantic import BaseModel

        # Create a simple FastAPI app for testing
        app = FastAPI()
        include_exceptions(app)

        class TestModel(BaseModel):
            required_field: str
            optional_field: str | None = None

        @app.post("/test")
        async def test_endpoint(data: TestModel):
            return {"message": "success"}

        client = TestClient(app)

        # Test with missing required field
        response = client.post("/test", json={})

        assert response.status_code == 400
        response_data = response.json()
        assert "type" in response_data
        assert "title" in response_data
        assert "detail" in response_data
        assert "Missing required field: required_field" in response_data["detail"]

    def test_custom_exception_integration(self):
        """Test custom exception handling in a real FastAPI request."""
        from fastapi.testclient import TestClient
        from fastapi import FastAPI

        # Create a simple FastAPI app for testing
        app = FastAPI()
        include_exceptions(app)

        @app.get("/test-rate-error")
        async def test_rate_error():
            raise RateNotFoundException("Test rate not found")

        @app.get("/test-benefits-error")
        async def test_benefits_error():
            raise BenefitsNotFoundException("Status 400: Test benefits not found")

        client = TestClient(app)

        # Test rate not found exception
        response = client.get("/test-rate-error")
        assert response.status_code == 500
        response_data = response.json()
        assert "Test rate not found" in response_data["detail"]
        assert "Rate not found" in response_data["title"]

        # Test benefits not found exception
        response = client.get("/test-benefits-error")
        assert response.status_code == 500
        response_data = response.json()
        assert "Test benefits not found" in response_data["detail"]
        assert "Benefits not found" in response_data["title"]
