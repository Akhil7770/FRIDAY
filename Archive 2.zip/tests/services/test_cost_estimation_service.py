import pytest
from unittest.mock import AsyncMock, patch
from app.services.impl.cost_estimation_service_impl import CostEstimationServiceImpl
from app.schemas.cost_estimator_request import CostEstimatorRequest
from app.schemas.cost_estimator_response import CostEstimatorResponse
from app.models.rate_criteria import NegotiatedRate
from app.schemas.benefit_response import (
    BenefitApiResponse,
    ServiceInfoItem,
    Benefit,
    Coverage,
    RelatedAccumulator,
    BenefitTier,
    Prerequisite,
    ServiceProviderItem,
    ProviderTypeItem,
)
from app.schemas.accumulator_response import (
    AccumulatorResponse,
    Accumulator,
    EffectivePeriod,
)


@pytest.mark.asyncio
@patch(
    "app.services.impl.cost_estimation_service_impl.BenefitServiceImpl.get_benefit",
    new_callable=AsyncMock,
)
@patch(
    "app.services.impl.cost_estimation_service_impl.AccumulatorServiceImpl.get_accumulator",
    new_callable=AsyncMock,
)
@patch(
    "app.services.impl.cost_estimation_service_impl.CostEstimatorRepositoryImpl.get_rate",
    new_callable=AsyncMock,
)
@patch(
    "app.services.impl.cost_estimation_service_impl.TokenServiceImpl.get_token",
    new_callable=AsyncMock,
)
async def test_estimate_cost_success(
    mock_get_token, mock_get_rate, mock_get_accumulator, mock_get_benefit
):
    # Mock benefit response with proper structure
    mock_benefit = Benefit(
        benefitName="Test Benefit",
        benefitCode=1001,
        isInitialBenefit="Y",
        benefitTier=BenefitTier(benefitTierName="1"),
        networkCategory="InNetwork",
        prerequisites=[Prerequisite(type="None", isRequired="N")],
        benefitProvider="Test Provider",
        serviceProvider=[ServiceProviderItem()],
        coverages=[
            Coverage(
                sequenceNumber=1,
                benefitDescription="Test Coverage",
                isServiceCovered="Y",
                costShareCopay=25.0,
                costShareCoinsurance=20.0,
                copayAppliesOutOfPocket="Y",
                coinsAppliesOutOfPocket="Y",
                deductibleAppliesOutOfPocket="Y",
                deductibleAppliesOutOfPocketOtherIndicator="N",
                copayCountToDeductibleIndicator="Y",
                copayContinueWhenDeductibleMetIndicator="Y",
                copayContinueWhenOutOfPocketMaxMetIndicator="Y",
                coinsuranceToOutOfPocketOtherIndicator="Y",
                copayToOutofPocketOtherIndicator="Y",
                isDeductibleBeforeCopay="N",
                benefitLimitation="N",
                relatedAccumulators=[
                    RelatedAccumulator(
                        code="Deductible",
                        level="Individual",
                        networkIndicatorCode="IN",
                    )
                ],
            )
        ],
    )

    mock_service_info = ServiceInfoItem(
        serviceCodeInfo=[],
        placeOfService=[],
        providerSpecialty=[],
        providerType=[ProviderTypeItem(code="HO")],
        benefit=[mock_benefit],
    )
    mock_get_benefit.return_value = BenefitApiResponse(serviceInfo=[mock_service_info])

    # Mock accumulator response with simple dictionary structure
    mock_get_accumulator.return_value = {
        "readAccumulatorsResponse": {
            "memberships": {
                "subscriber": {
                    "accumulators": [
                        {
                            "code": "Deductible",
                            "level": "Individual",
                            "limitValue": 5000.0,
                            "calculatedValue": 345.0,
                            "networkIndicator": "InNetwork",
                        }
                    ]
                }
            }
        }
    }

    mock_get_rate.return_value = NegotiatedRate(
        paymentMethod="COPAY",
        rate=500.0,
        rateType="AMOUNT",
        isRateFound=True,
        isProviderInfoFound=True,
    )

    # Mock token service response
    mock_get_token.return_value = {
        "access_token": "test_access_token",
        "id_token": "test_id_token",
        "token_type": "Bearer",
        "expires_in": 3600,
    }

    payload = {
        "membershipId": "5~265642286+34+44+20250101+784461+AM+39",
        "zipCode": "85305",
        "benefitProductType": "Medical",
        "languageCode": "11",
        "service": {
            "code": "99214",
            "type": "CPT4",
            "description": "Adult Office visit Age 30-39",
            "supportingService": {"code": "470", "type": "DRG"},
            "modifier": {"modifierCode": "E1"},
            "diagnosisCode": "F33 40",
            "placeOfService": {"code": "11"},
        },
        "providerInfo": [
            {
                "serviceLocation": "000761071",
                "providerType": "HO",
                "speciality": {"code": "91017"},
                "taxIdentificationNumber": "0000431173518",
                "taxIdQualifier": "SN",
                "providerNetworks": {"networkID": "58921"},
                "providerIdentificationNumber": "0004000317",
                "nationalProviderId": "1386660504",
                "providerNetworkParticipation": {"providerTier": "1"},
            }
        ],
    }

    request = CostEstimatorRequest(**payload)
    service = CostEstimationServiceImpl()
    response = await service.estimate_cost(request)

    # With proper mock data, we should get a CostEstimatorResponse
    assert isinstance(response, CostEstimatorResponse)
    assert response.costEstimateResponse is not None
    assert len(response.costEstimateResponse.costEstimateResponseInfo) > 0
