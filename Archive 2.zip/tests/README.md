# Tests

This directory contains all tests for the cost estimator service.

## Structure

- `conftest.py` - Pytest configuration and shared fixtures
- `test_main.py` - Tests for the main application functionality
- `test_repository.py` - Tests for the repository layer
- `test_service.py` - Tests for the service layer

## Running Tests

### Using pytest directly

```bash
# Run all tests
pytest

# Run with verbose output
pytest -v

# Run specific test types
pytest -m unit
pytest -m integration
pytest -m api
pytest -m repository
pytest -m service

# Run with coverage
pytest --cov=app --cov-report=term-missing
```

### Using the test runner script

```bash
# Run all tests
python run_tests.py

# Run specific test types
python run_tests.py --type unit
python run_tests.py --type repository
python run_tests.py --type service

# Run with verbose output
python run_tests.py --verbose

# Run with coverage
python run_tests.py --coverage
```

## Test Categories

- **unit**: Unit tests for individual components
- **integration**: Integration tests for component interactions
- **api**: API endpoint tests
- **repository**: Database and repository layer tests
- **service**: Business logic service tests

## Fixtures

The `conftest.py` file provides several shared fixtures:

- `client`: FastAPI test client
- `async_client`: Async test client
- `valid_request_data`: Sample request data for testing
- `mock_service`: Mock service for testing
- `rate_criteria`: Sample rate criteria for testing

## Adding New Tests

1. Create a new test file with the prefix `test_`
2. Use appropriate pytest markers to categorize tests
3. Use the provided fixtures when possible
4. Follow the existing naming conventions

Example:

```python
@pytest.mark.unit
def test_new_feature():
    """Test description."""
    # Test implementation
    pass
``` 